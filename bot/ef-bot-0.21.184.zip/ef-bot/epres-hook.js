// 🔌 e-prescription: το bot ΒΛΕΠΕΙ (δεν αλλάζει) τις κεφαλίδες που στέλνει η ίδια η εφαρμογή στο API της,
// ώστε να μπορεί να κάνει τις ΙΔΙΕΣ κλήσεις μέσα στην ίδια σύνδεση. Μένουν ΜΟΝΟ στη μνήμη της σελίδας (όχι αποθήκευση, όχι αποστολή).
// 🗺 + χάρτης κλήσεων (μόνο στη μνήμη, έως 300): μέθοδος, διαδρομή (αριθμοί ≥5 ψηφίων → #), κωδικός συναλλαγής,
//   αν υπάρχει μονάδα, κατάσταση απάντησης και ΟΝΟΜΑΤΑ πεδίων αιτήματος/απάντησης — ΚΑΜΙΑ τιμή.
(() => {
  if (window.__efEp) return;
  const S = window.__efEp = { h: {}, at: 0, n: 0, log: [] };
  const KEEP = /^(x-authorization|x-sender-code|x-webapp-version|x-sender-req-type|x-sender-req-id|x-sender-unit-id)$/i;
  const take = (k, v) => { if (KEEP.test(k) && v) { S.h[k.toLowerCase()] = String(v); S.at = Date.now(); S.n++; } };
  const mask = (u) => { try { const x = new URL(u, location.href); return x.pathname.replace(/\d{5,}/g, "#").replace(/[0-9a-f]{8}-[0-9a-f-]{27,}/gi, "#") + (x.search ? "?" + [...x.searchParams.keys()].join("&") : ""); } catch (e) { return ""; } };
  // πρότυπο ερωτήματος ανά διαδρομή: τιμές ΜΟΝΟ για παραμέτρους-ρυθμίσεις (σελίδα, πλήθος, τρόπος…) — ποτέ λέξη αναζήτησης/ηλικία/ασθενής
  const SAFE = /^(page|pageSize|mode|limitedByProtocol|dhpcMode|isConsumable|isActive|sortBy|sortOrder|isScreening|filterByFavorites|numberOfLinksPerCategory|patientType|skipCache)$/;
  S.tpl = S.tpl || {};
  const tplOf = (u) => { try { const x = new URL(u, location.href); const q = {}; for (const [k, v] of x.searchParams) q[k] = SAFE.test(k) ? String(v).slice(0, 30) : null; S.tpl[x.pathname.replace(/\d{5,}/g, "#")] = q; } catch (e) {} };
  const keysOf = (o, d) => { if (!o || typeof o !== "object" || d > 2) return []; const ks = Array.isArray(o) ? (o.length ? keysOf(o[0], d) .map((k) => "[]." + k) : ["[]"]) : Object.keys(o).slice(0, 40).flatMap((k) => { const v = o[k]; return v && typeof v === "object" && d < 2 ? [k, ...keysOf(v, d + 1).map((x) => k + "." + x)] : [k]; }); return ks.slice(0, 60); };
  // 9/11: για τη ΣΥΝΤΑΓΗ (prescription/create κ.λπ.) πλήρες δέντρο πεδίων (βάθος 6, έως 400) + ΤΥΠΟΣ κάθε τιμής (s/n/b/null) — ΚΑΜΙΑ τιμή
  const ty = (v) => v === null ? "null" : typeof v === "string" ? "s" : typeof v === "number" ? "n" : typeof v === "boolean" ? "b" : "";
  const keysDeep = (o, d, pre, out) => { if (out.length > 400 || d > 6) return out; if (Array.isArray(o)) { if (!o.length) out.push(pre + "[]"); else keysDeep(o[0], d + 1, pre + "[].", out); return out; }
    if (o && typeof o === "object") { for (const k of Object.keys(o)) { const v = o[k]; if (v && typeof v === "object") keysDeep(v, d + 1, pre + k + ".", out); else out.push(pre + k + ":" + ty(v)); } } return out; };
  const bodyKeys = (b, deep) => { try { if (typeof b === "string" && /^\s*[{[]/.test(b)) { const j = JSON.parse(b); return deep ? keysDeep(j, 0, "", []) : keysOf(j, 0); } } catch (e) {} return []; };
  const DEEP = /\/prescription\/v\d+\/(create|update|submit|issue)|\/prescription\/v\d+\/[^?]*\/(treatment|medicine)/;
  const rec = (e) => { try { S.log.push(e); if (S.log.length > 300) S.log.shift(); } catch (x) {} };
  // 7/11: κείμενο ΣΦΑΛΜΑΤΟΣ του API (κατάσταση ≥400, ή απάντηση με «errors»/«message») — αριθμοί ≥5 ψηφίων κρυμμένοι· έως 10, μόνο στη μνήμη
  S.errs = S.errs || [];
  const errOf = (e, st, txt) => { try { if (!(st >= 400 || /"(errors|errorCode|businessError|validationErrors)"/.test(txt || ""))) return; S.errs.push({ at: Date.now(), m: e && e.m, p: e && e.p, st, t: String(txt || "").replace(/\d{5,}/g, "#").slice(0, 600) }); if (S.errs.length > 10) S.errs.shift(); } catch (x) {} };
  const hget = (hs, k) => { try { if (!hs) return ""; if (typeof hs.get === "function") return hs.get(k) || ""; const f = Object.keys(hs).find((x) => x.toLowerCase() === k); return f ? hs[f] : ""; } catch (e) { return ""; } };
  const f0 = window.fetch;
  window.fetch = function (input, init) {
    let e = null;
    try {
      const u = typeof input === "string" ? input : (input && input.url) || "";
      if (/\/epres\/api\//.test(u)) { const hs = (init && init.headers) || (input && input.headers);
        if (hs) { if (typeof hs.forEach === "function") hs.forEach((v, k) => take(k, v)); else Object.entries(hs).forEach(([k, v]) => take(k, v)); }
        tplOf(u);
        e = { t: Date.now(), m: String((init && init.method) || (input && input.method) || "GET").toUpperCase(), p: mask(u), tc: String(hget(hs, "x-sender-transaction-code") || "").slice(0, 60), unit: !!hget(hs, "x-sender-unit-id"), req: bodyKeys(init && init.body, DEEP.test(u)) }; }
    } catch (x) {}
    const pr = f0.apply(this, arguments);
    if (e) pr.then((r) => { e.st = r.status; e.ms = Date.now() - e.t; r.clone().text().then((tx) => errOf(e, r.status, tx), () => {}); r.clone().json().then((j) => { e.res = keysOf(j, 0); rec(e); }, () => rec(e)); }, () => { e.st = 0; rec(e); });
    return pr;
  };
  const o0 = XMLHttpRequest.prototype.open, s0 = XMLHttpRequest.prototype.setRequestHeader, d0 = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, u) { this.__efApi = /\/epres\/api\//.test(String(u || "")); if (this.__efApi) tplOf(String(u)); if (this.__efApi) this.__efE = { t: 0, m: String(m || "GET").toUpperCase(), p: mask(String(u)), tc: "", unit: false, req: [] }; return o0.apply(this, arguments); };
  XMLHttpRequest.prototype.setRequestHeader = function (k, v) { try { if (this.__efApi) { take(k, v); const lk = String(k).toLowerCase(); if (lk === "x-sender-transaction-code") this.__efE.tc = String(v).slice(0, 60); if (lk === "x-sender-unit-id" && v) this.__efE.unit = true; } } catch (e) {} return s0.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function (b) { try { if (this.__efApi && this.__efE) { const e = this.__efE; e.t = Date.now(); e.req = bodyKeys(b, DEEP.test(e.p || "")); this.addEventListener("loadend", () => { try { e.st = this.status; e.ms = Date.now() - e.t; try { errOf(e, this.status, (this.responseType === "" || this.responseType === "text") ? this.responseText : (this.responseType === "json" ? JSON.stringify(this.response) : "")); } catch (x) {} try { e.res = keysOf(JSON.parse(this.responseText), 0); } catch (x) {} rec(e); } catch (x) {} }); } } catch (e) {} return d0.apply(this, arguments); };
})();
// 🔎 8/11: σφάλματα JS της σελίδας (π.χ. λευκή σελίδα σε κάποιον υπολογιστή) → ένδειξη στο DOM για το bot (μόνο κείμενο σφάλματος)
try { const mk = (m) => { try { document.documentElement.setAttribute("data-ef-jserr", String(m || "").replace(/\d{5,}/g, "#").slice(0, 200)); } catch (e) {} };
  window.addEventListener("error", (e) => mk((e.message || "") + " @" + String(e.filename || "").split("/").pop() + ":" + (e.lineno || "")), true);
  window.addEventListener("unhandledrejection", (e) => mk("promise: " + String((e.reason && (e.reason.message || e.reason)) || "")), true); } catch (e) {}
