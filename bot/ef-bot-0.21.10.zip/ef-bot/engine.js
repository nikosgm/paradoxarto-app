// Κοινός μηχανισμός εκτέλεσης βημάτων. Τον φορτώνουν το πλευρικό πάνελ και το background
// (για την παρακολούθηση). Δεν αγγίζει DOM, ώστε να τρέχει και σε service worker.
//
// «sess» (συνεδρία) = { tabId, homeTabId, vars, vals(), settings(), isAborted(), log(text, cls),
//                       manual?(text), copy?(value, step), heartbeat?(), noTabSwitch? }
(function (g) {
  "use strict";
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const BUILTIN = ["ώρα", "ημερομηνία"];
  const BULKVAR = "ασθενής"; // γεμίζει από τη λίστα της μαζικής εκτέλεσης / παρακολούθησης
  const pad = (n) => String(n).padStart(2, "0");
  const isWeb = (t) => t && /^(https?|file):/.test(t.url || "");

  // ---------- Μεταβλητές ----------
  // {Χ_στήλες} = οι τιμές του Χ (χωρισμένες με , ; ή νέα γραμμή) ως στήλες Excel (χωρισμένες με tab)
  function deriveCols(all, k) {
    const m = /^(.+)_στήλες$/.exec(k);
    if (!m || !(m[1] in all)) return "";
    return String(all[m[1]]).split(/[,;\n]/).map((x) => x.trim()).filter(Boolean).join("\t");
  }
  function render(tpl, vals, extra = {}, opts = {}) {
    const d = new Date();
    const all = { ...vals, ...extra };
    const builtins = {
      "ώρα": `${pad(d.getHours())}:${pad(d.getMinutes())}`,
      "ημερομηνία": `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`,
    };
    return (tpl || "")
      .replace(/\{([^}]+)\}/g, (_, k) => {
        let v = k in builtins ? builtins[k] : all[k];
        if (v === undefined) {
          const m = /^(.+)\.(\d+)$/.exec(k); // {ασθενής.1} όταν υπάρχει μόνο το {ασθενής}
          v = m && m[1] in all ? String(all[m[1]]).split(";")[m[2] - 1]?.trim() : undefined;
        }
        if (v === undefined) v = deriveCols(all, k);
        return opts.url ? encodeURIComponent(v ?? "") : v ?? "";
      })
      .replace(/\\t/g, "\t")
      .replace(/\\n/g, "\n");
  }
  function varsOf(w) {
    const out = [];
    const produced = [];
    for (const s of w.steps)
      if (s.type === "read" && s.saveAs) {
        produced.push(s.saveAs);
        if (s.filter) produced.push(s.saveAs + "_στήλες");
      }
    for (const s of w.steps) {
      if (s.disabled) continue;
      for (const src of [s.value, s.fillValue, s.filter]) {
        for (const m of (src || "").matchAll(/\{([^}]+)\}/g)) {
          let k = m[1].replace(/\.\d+$/, ""); // {φάρμακα.2} → φάρμακα
          if (!produced.includes(k) && /_στήλες$/.test(k)) k = k.replace(/_στήλες$/, "");
          if (!BUILTIN.includes(k) && !produced.includes(k) && !out.includes(k)) out.push(k);
        }
      }
    }
    return out;
  }
  // Μία γραμμή → {όνομα} = όλη η γραμμή, {όνομα.1}, {όνομα.2}… = τα κομμάτια χωρισμένα με «;»
  function lineVars(name, line) {
    const o = { [name]: line };
    line.split(";").forEach((p, j) => (o[`${name}.${j + 1}`] = p.trim()));
    return o;
  }
  // Σειρά εκτέλεσης. Συνεχόμενα βήματα με ίδιο «Για κάθε γραμμή» επαναλαμβάνονται μαζί.
  // «base» = επιπλέον τιμές για όλα τα βήματα (π.χ. ο ασθενής της μαζικής εκτέλεσης).
  function plan(w, vals, base = {}) {
    const steps = w.steps.map((s, i) => [s, i]).filter(([s]) => !s.disabled);
    const blocks = [];
    for (const it of steps) {
      const last = blocks[blocks.length - 1];
      if (it[0].each && last && last.each === it[0].each) last.items.push(it);
      else blocks.push({ each: it[0].each || null, items: [it] });
    }
    const out = [];
    for (const b of blocks) {
      const rounds = b.each
        ? String(vals[b.each] || "").split(/\r?\n/).map((x) => x.trim()).filter(Boolean).map((x) => lineVars(b.each, x))
        : [{}];
      for (const extra of rounds)
        for (const [s, i] of b.items)
          out.push({ s, i, extra: { ...base, ...extra }, tag: b.each ? ` [${extra[b.each]}]` : "", wf: w });
    }
    return out;
  }

  // ---------- Κλείδωμα (να μην τρέχουν μαζί πάνελ και παρακολούθηση στην ίδια καρτέλα) ----------
  const LOCK_TTL = 8 * 60000;
  async function lockAcquire(owner) {
    const { efbotLock: l } = await chrome.storage.session.get("efbotLock");
    if (l && l.owner !== owner && Date.now() - l.ts < LOCK_TTL) return false;
    await chrome.storage.session.set({ efbotLock: { owner, ts: Date.now() } });
    return true;
  }
  async function lockTouch(owner) {
    const { efbotLock: l } = await chrome.storage.session.get("efbotLock");
    if (!l || l.owner === owner) await chrome.storage.session.set({ efbotLock: { owner, ts: Date.now() } });
  }
  async function lockRelease(owner) {
    const { efbotLock: l } = await chrome.storage.session.get("efbotLock");
    if (l && l.owner === owner) await chrome.storage.session.remove("efbotLock");
  }

  // ---------- Καρτέλες & πλαίσια ----------
  // Μετάβαση σε άλλη καρτέλα με βάση κομμάτι της διεύθυνσης ή του τίτλου («αρχική» = η καρτέλα που ξεκίνησε)
  async function switchTab(sess, q) {
    let tab;
    if (/^αρχική$/i.test(q.trim())) tab = await chrome.tabs.get(sess.homeTabId).catch(() => null);
    else {
      const want = q.trim().toLowerCase();
      tab = (await chrome.tabs.query({ windowType: "normal" })).find(
        (t) => isWeb(t) && ((t.url || "").toLowerCase().includes(want) || (t.title || "").toLowerCase().includes(want))
      );
    }
    if (!tab) throw new Error(`Δεν βρέθηκε ανοιχτή καρτέλα για «${q}». Ανοίξτε την εφαρμογή και ξαναδοκιμάστε.`);
    await chrome.tabs.update(tab.id, { active: true });
    await chrome.windows.update(tab.windowId, { focused: true }).catch(() => {});
    sess.tabId = tab.id;
  }

  async function waitLoaded(tabId, ms, isAborted) {
    const t0 = Date.now();
    let sawLoading = false;
    while (Date.now() - t0 < ms) {
      if (isAborted && isAborted()) throw new Error("Διακόπηκε");
      const t = await chrome.tabs.get(tabId).catch(() => null);
      if (!t) throw new Error("Η καρτέλα έκλεισε");
      if (t.status === "loading") sawLoading = true;
      // Σε αλλαγή μόνο του #hash η σελίδα δεν ξαναφορτώνει: μετά από 1,5 δευτ. θεωρούμε ότι τελείωσε
      if (t.status === "complete" && (sawLoading || Date.now() - t0 > 1500)) return;
      await sleep(250);
    }
    throw new Error("Η σελίδα δεν φόρτωσε εγκαίρως");
  }

  // Άμεση μετάβαση σε διεύθυνση (μόνο http/https). Σχετική διαδρομή (/...) λύνεται με βάση την τρέχουσα καρτέλα.
  async function gotoUrl(sess, s, value) {
    if (!value.trim()) throw new Error("Η διεύθυνση είναι κενή");
    const cur = await chrome.tabs.get(sess.tabId);
    let u;
    try { u = new URL(value.trim(), cur.url); } catch (e) { throw new Error("Μη έγκυρη διεύθυνση: " + value); }
    if (!/^https?:$/.test(u.protocol)) throw new Error("Επιτρέπονται μόνο διευθύνσεις http/https");
    if (s.newTab) {
      if (sess.noTabSwitch) throw new Error("Νέα καρτέλα δεν επιτρέπεται εδώ");
      const t = await chrome.tabs.create({ url: u.href, active: true, windowId: cur.windowId });
      sess.tabId = t.id;
    } else {
      await chrome.tabs.update(sess.tabId, { url: u.href });
    }
    await waitLoaded(sess.tabId, 60000, sess.isAborted);
    await sleep(300);
  }

  async function frames(tabId) {
    let fr = null;
    try { fr = await chrome.webNavigation.getAllFrames({ tabId }); } catch (e) {}
    fr = fr || [{ frameId: 0 }];
    // Σιγουρευόμαστε ότι το script υπάρχει (π.χ. καρτέλα ανοιχτή πριν την εγκατάσταση)
    try {
      await chrome.tabs.sendMessage(tabId, { cmd: "ping" }, { frameId: 0 });
    } catch (e) {
      await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, files: ["content.js"] }).catch(() => {});
    }
    return fr;
  }
  // Μήνυμα σε πλαίσιο με όριο χρόνου: πλαίσιο που δεν απαντά (π.χ. ξαναφορτώνει) δεν κολλάει την εκτέλεση
  const send = (tabId, frameId, msg, ms = 4000) =>
    Promise.race([chrome.tabs.sendMessage(tabId, msg, { frameId }).catch(() => null), sleep(ms).then(() => null)]);

  // Βρίσκει σε ποιο πλαίσιο υπάρχει το στοιχείο, περιμένοντας να φορτώσει η σελίδα.
  // Όσο η εφαρμογή «φορτώνει», η αναμονή παρατείνεται (έως 3 λεπτά συνολικά).
  async function findFrame(sess, step, value, timeout, maxExtra = 30000) {
    // Χωρίς ρυθμίσεις (π.χ. υπολογιστής που δεν άνοιξε ποτέ το πάνελ) το timeout γινόταν NaN → «δεν βρέθηκε» σε 0ms
    if (!(timeout > 0)) timeout = 30000;
    const st = sess.settings() || {};
    const tabId = sess.tabId;
    let until = Date.now() + timeout;
    const t0 = Date.now();
    // Όσο κάτι φορτώνει, η αναμονή παρατείνεται έως 30 δευτ. πάνω από το κανονικό όριο
    const hardLimit = t0 + timeout + maxExtra;
    const perm = (sess.permBusy ||= new Set());
    let busyNote = null, last = null;
    while (Date.now() < until && !sess.isAborted()) {
      const fr = await frames(tabId);
      const path = step.target?.framePath;
      const pathOf = (u) => { try { return new URL(u).pathname; } catch (e) { return ""; } };
      const order = [...fr].sort((a, b) => (pathOf(a.url) === path ? 0 : 1) - (pathOf(b.url) === path ? 0 : 1));
      let busy = "", seen = false, covered = "", dialog = false, answered = 0, ambiguous = 0;
      for (const f of order) {
        const r = await send(tabId, f.frameId, { cmd: "find", step, value, busySel: st.busySel, busyOff: !!st.busyOff }, 4000);
        if (!r) continue;
        answered++;
        if (r.found) {
          busyNote?.remove();
          diag(sess, { ev: "found", frames: fr.length, frame: f.frameId === 0 ? "κύριο" : "πλαίσιο", busy: r.busyWhat || "", dialog: !!r.dialog, ms: Date.now() - t0 });
          return f.frameId;
        }
        if (r.busy && !busy && !perm.has(r.busyWhat)) busy = r.busyWhat;
        if (r.seen) { seen = true; covered = covered || r.coveredBy; }
        if (r.dialog) dialog = true;
        if (r.ambiguous) ambiguous = r.ambiguous;
      }
      last = { frames: fr.length, answered, busy, seen, covered, dialog, ambiguous };
      if (ambiguous) break; // δύο ίδια ονόματα: δεν έχει νόημα να περιμένουμε
      // Παράταση μόνο αν όντως κάτι φορτώνει ή σκεπάζει το στοιχείο (έως 60 δευτ. συνολικά)
      if (busy || covered) {
        if (!busyNote) busyNote = sess.log(`⏳ Η εφαρμογή φορτώνει, περιμένω… (${busy || "κάλυμμα " + covered})`, "run");
        until = Math.min(Math.max(until, Date.now() + 3000), hardLimit);
      }
      await sleep(300);
    }
    busyNote?.remove();
    // Ένδειξη «φορτώνει» που δεν έφυγε σε όλη την αναμονή: μόνιμο στοιχείο, την αγνοούμε στο εξής
    if (last?.busy && maxExtra >= 30000) perm.add(last.busy);
    sess.why = last;
    diag(sess, { ev: "notfound", ms: Date.now() - t0, ...(last || {}) });
    return null;
  }

  // Μετά από κλικ/συμπλήρωση: περιμένουμε να φύγει η ένδειξη φόρτωσης (έως settleMax δευτ.).
  // Αν η ένδειξη δεν φεύγει (π.χ. μόνιμο εικονίδιο), απλώς συνεχίζουμε· το επόμενο βήμα κρίνει μόνο του.
  // Η εφαρμογή (PrimeFaces) ξέρει πότε τελείωσαν τα αιτήματά της: τη ρωτάμε κατευθείαν. null = δεν υπάρχει PrimeFaces.
  const pfIdle = (sess) => inPage(sess, () => {
    try { return window.PrimeFaces && PrimeFaces.ajax && PrimeFaces.ajax.Queue ? PrimeFaces.ajax.Queue.isEmpty() : null; } catch (e) { return null; }
  }, []);
  async function settle(sess) {
    const st = sess.settings();
    if (st.busyOff) return;
    const t0 = Date.now(), max = (st.settleMax ?? 8) * 1000;
    if (sess.pf !== false) {
      let idle = await pfIdle(sess);
      if (idle !== null) {
        sess.pf = true;
        while (!idle && Date.now() - t0 < max && !sess.isAborted()) { await sleep(60); idle = await pfIdle(sess); }
        await sleep(60); // να προλάβει η σελίδα να ζωγραφίσει την απάντηση
        if (Date.now() - t0 > 1000) diag(sess, { ev: "settle", ms: Date.now() - t0, pf: 1 });
        return;
      }
      sess.pf = false;
    }
    await sleep(150);
    let what = "";
    while (Date.now() - t0 < max && !sess.isAborted()) {
      const fr = await frames(sess.tabId);
      what = "";
      for (const f of fr) {
        const r = await send(sess.tabId, f.frameId, { cmd: "busy", busySel: st.busySel }, 2000);
        if (r?.busy && !(sess.permBusy || new Set()).has(r.busy)) { what = r.busy; break; }
      }
      if (!what) break;
      await sleep(250);
    }
    // Ένδειξη που δεν έφυγε ποτέ: μόνιμο στοιχείο της σελίδας, την αγνοούμε στο εξής
    if (what) (sess.permBusy ||= new Set()).add(what);
    if (Date.now() - t0 > 1000) diag(sess, { ev: "settle", ms: Date.now() - t0, still: what });
  }

  // ---------- Διάγνωση: καταγραφή ΧΩΡΙΣ ονόματα, ΑΜΚΑ ή τιμές πεδίων ----------
  function diag(sess, o) {
    if (!sess.diag) return;
    sess.diag.push({ t: Date.now(), ...o });
    if (sess.diag.length > 300) sess.diag.splice(0, sess.diag.length - 300);
  }

  // ---------- Εντολές μέσα στη σελίδα (PrimeFaces) ----------
  // Εκτελούνται στον «κόσμο» της σελίδας (MAIN), όπου υπάρχει το αντικείμενο PrimeFaces της εφαρμογής.
  // Κάνουν ό,τι και το χέρι (ίδια αιτήματα στον server), απλώς χωρίς να ανοίγουν/κλείνουν μενού.
  async function inPage(sess, func, args) {
    try {
      const [r] = await chrome.scripting.executeScript({ target: { tabId: sess.tabId, frameIds: [0] }, world: "MAIN", func, args });
      return r?.result ?? null;
    } catch (e) { return null; }
  }
  async function pfSelect(sess, id, label) {
    const r = await inPage(sess, (id, label) => {
      const W = window.PrimeFaces && PrimeFaces.widgets;
      const w = W && Object.values(W).find((x) => x && x.id === id);
      const sel = document.getElementById(id + "_input");
      if (!w || typeof w.selectValue !== "function" || !sel) return { ok: false, why: "widget" };
      const nm = (t) => String(t).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/ς/g, "σ").replace(/\s+/g, " ").trim();
      const want = nm(label), opts = [...sel.options];
      const o = opts.find((x) => nm(x.text) === want) || opts.find((x) => nm(x.text).startsWith(want + " ")) || null;
      if (!o) return { ok: false, why: "option" };
      if (sel.value === o.value) return { ok: true, same: true };
      w.selectValue(o.value);
      return { ok: sel.value === o.value };
    }, [id, label]);
    diag(sess, { ev: "pfSelect", ok: !!r?.ok, why: r?.why || (r?.same ? "ήδη" : "") });
    return !!r?.ok;
  }

  // ---------- Αναζήτηση ασθενή ----------
  async function searchSeek(sess, s, value) {
    const S = s.target.search, within = s.target.within;
    // Το κουμπί είναι σε κλειστό πλαίσιο (δεν φαίνεται): εντοπίζουμε τη σελίδα από τη λίστα ασθενών, που φαίνεται
    const probe = { type: "read", target: { css: within, tag: "div", cls: [], text: "", framePath: s.target.framePath } };
    const fid = await findFrame(sess, probe, "", (s.timeout || sess.settings().timeout) * 1000);
    if (fid === null) { diag(sess, { ev: "search", skip: "χωρίς πεδίο" }); return; }
    const up = (t) => t.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase();
    const toks = up(value).split(/[\s,.;]+/).filter((t) => t.length >= 2);
    for (const tok of toks.slice(0, 3)) {
      const r = await send(sess.tabId, fid, { cmd: "searchSet", field: S.field, button: S.button, within, value: tok }, 6000);
      if (!r?.ok) break;
      await sleep(250);
      await settle(sess);
      await sleep(200);
      const c = await send(sess.tabId, fid, { cmd: "choiceCount", step: s, value }, 5000);
      diag(sess, { ev: "search", n: toks.indexOf(tok) + 1, hits: c?.hits ?? -1 });
      if (c?.hits) return; // βρέθηκε: συνεχίζει ο έλεγχος σελίδων/μοναδικότητας και το κλικ
    }
    // Δεν βρέθηκε με κανένα κομμάτι του ονόματος: επαναφορά της πλήρους λίστας, για να ψάξει ο κανονικός τρόπος
    await send(sess.tabId, fid, { cmd: "searchSet", field: S.field, button: S.button, within, value: "" }, 6000);
    await sleep(250); await settle(sess);
  }

  // ---------- Λίστα με σελίδες ----------
  // 1) Πρώτη σελίδα, 2) μέτρημα ταιριασμάτων σε κάθε σελίδα, 3) αν ακριβώς ένα, επιστροφή στη σελίδα του.
  // Αν βρεθούν 2+ σε όλη τη λίστα (ίδιο επώνυμο σε άλλη σελίδα), σταματάμε: δεν μαντεύουμε ασθενή.
  async function pagedSeek(sess, s, value) {
    const within = s.target.within;
    const probe = { type: "read", target: { css: within, tag: "div", cls: [], text: "", framePath: s.target.framePath } };
    const fid = await findFrame(sess, probe, "", (s.timeout || sess.settings().timeout) * 1000);
    if (fid === null) throw new Error("Δεν φαίνεται η λίστα ασθενών στην οθόνη");
    const pager = async (action, page) => {
      const r = await send(sess.tabId, fid, { cmd: "pager", within, action, page }, 8000);
      if (r?.ok) { await settle(sess); await sleep(250); }
      return r;
    };
    await pager("first");
    let total = 0, hitPage = -1, pages = 0;
    for (; pages < 20 && !sess.isAborted(); pages++) {
      const c = await send(sess.tabId, fid, { cmd: "choiceCount", step: s, value }, 5000);
      if (c?.hits) { total += c.hits; if (hitPage < 0) hitPage = pages; }
      const n = await pager("next");
      if (!n?.ok) { pages++; break; }
    }
    diag(sess, { ev: "pages", pages, total, hitPage });
    if (!total) throw new Error(`Δεν βρέθηκε «${value}» σε καμία από τις ${pages} σελίδες της λίστας`);
    if (total > 1) {
      const e = new Error(`Βρέθηκαν ${total} ασθενείς που ταιριάζουν με «${value}» (σε όλες τις σελίδες). Για ασφάλεια το bot σταμάτησε: ανοίξτε τον σωστό με το χέρι και πατήστε «Συνέχεια», ή γράψτε ολόκληρο το ονοματεπώνυμο.`);
      e.mismatch = true;
      throw e;
    }
    // Είμαστε στην τελευταία σελίδα: αν ο ασθενής είναι αλλού, πάμε κατευθείαν στον αριθμό της σελίδας του
    if (pages > 1 && hitPage !== pages - 1) {
      const j = await pager("page", hitPage + 1);
      if (!j?.ok && !j?.already) { await pager("first"); for (let k = 0; k < hitPage; k++) await pager("next"); }
    }
  }

  // ---------- Ένα βήμα ----------
  async function runStep(sess, s, i, extra = {}) {
    const vals = sess.vals();
    const value = render(s.value, vals, extra, { url: s.type === "goto" });
    const tabId = sess.tabId;
    if (s.type === "wait") { await sleep(parseInt(value) || 1000); return true; }
    if (s.type === "tab") {
      if (sess.noTabSwitch) throw new Error("Η αλλαγή καρτέλας δεν επιτρέπεται στην αυτόματη παρακολούθηση");
      await switchTab(sess, value);
      return true;
    }
    if (s.type === "goto") { await gotoUrl(sess, s, value); return true; }
    if (s.type === "copy") {
      if (!sess.copy) throw new Error("Η αντιγραφή δεν επιτρέπεται εδώ");
      await sess.copy(value, s);
      return true;
    }
    // «Παράλειψη αν ήδη έγινε»: αν το στοιχείο φαίνεται / έχει ήδη την τιμή, παραλείπονται τα επόμενα Ν βήματα.
    // Χωρίς στοιχείο (δεν έχει γίνει εκμάθηση) δεν κάνει τίποτα.
    if (s.type === "skipif") {
      const count = parseInt(s.count) || 1;
      if (!s.target) return "skipif:0";
      // Έλεγχος της οθόνης όπως είναι τώρα (η φόρτωση έχει ήδη τελειώσει): χωρίς μεγάλη αναμονή
      const fid = await findFrame(sess, s, "", 300, 3000);
      if (fid === null) { diag(sess, { ev: "skipif", seen: false, skip: 0 }); return "skipif:0"; }
      const want = value.trim();
      if (!want) { diag(sess, { ev: "skipif", seen: true, skip: count }); return "skipif:" + count; } // κενή τιμή: αρκεί να φαίνεται
      const r = await send(sess.tabId, fid, { cmd: "exec", step: { ...s, type: "read", asValue: true }, value: "" }, 8000);
      const got = (r?.text || "").trim();
      const nm = (x) => x.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/ς/g, "σ").replace(/\s+/g, " ").trim();
      // Αν διαβάστηκε μόνο η ετικέτα που μάθατε (π.χ. «Θεράπων»), το πεδίο θεωρείται κενό
      const isLabel = !r?.field && !!s.target.text && nm(got) === nm(s.target.text);
      const done = want === "*" ? !!got && !isLabel : nm(got).includes(nm(want));
      diag(sess, { ev: "skipif", seen: true, read: r?.tag || "", field: !!r?.field, empty: !got, labelOnly: isLabel, skip: done ? count : 0 });
      return "skipif:" + (done ? count : 0);
    }
    // ΑΗΦΥ: έλεγχος ότι ο ΑΜΚΑ του ασθενή στην οθόνη είναι ο ζητούμενος (αγνοεί τον ΑΜΚΑ του γιατρού στην πάνω μπάρα).
    if (s.type === "check" && s.target?.ehrAmka) {
      const want = String(value).replace(/\D/g, "");
      const until = Date.now() + 15000;
      let r = null;
      do {
        r = await send(tabId, 0, { cmd: "ehrAmka" }, 8000);
        if (r?.list?.includes(want)) { diag(sess, { ev: "ehr-amka", ok: true }); return true; }
        await sleep(600);
      } while (Date.now() < until && !sess.isAborted());
      diag(sess, { ev: "ehr-amka", ok: false, n: (r?.list || []).length });
      const e = new Error((r?.list || []).length ? "ΑΣΥΜΦΩΝΙΑ: ο ΑΜΚΑ του ασθενή που άνοιξε δεν είναι ο ζητούμενος" : "Δεν φάνηκε ΑΜΚΑ ασθενή στην οθόνη (άνοιξε ο ασθενής;)");
      e.mismatch = (r?.list || []).length > 0; throw e;
    }
    // Radio με κείμενο ετικέτας (π.χ. «λόγος πρόσβασης» στον ΑΗΦΥ). Αν δεν εμφανιστούν καθόλου radio μέσα στο optWait
    // (π.χ. μπήκατε στον ασθενή τις τελευταίες 24 ώρες και δεν ζητείται λόγος), παραλείπεται μαζί με τα επόμενα «missSkip».
    // Αν εμφανιστούν αλλά κανένα δεν ταιριάζει με την «Τιμή», σταματά και λέει ποιες επιλογές υπάρχουν.
    if (s.type === "choose" && s.target?.radio) {
      const until = Date.now() + (s.optWait || 8) * 1000;
      let r = null;
      do {
        if (sess.isAborted()) { const e = new Error("Διακόπηκε"); e.aborted = true; throw e; }
        r = await send(tabId, 0, { cmd: "radioPick", want: value }, 8000);
        if (r?.present) break;
        await sleep(500);
      } while (Date.now() < until);
      diag(sess, { ev: "radio", present: !!r?.present, ok: !!r?.ok, n: (r?.labels || []).length });
      if (!r?.present) return s.missSkip ? "skipif:" + (parseInt(s.missSkip) || 0) : "skip";
      if (!r.ok) throw new Error(`Δεν βρέθηκε μία επιλογή «${value}»${r.ambiguous ? " (ταιριάζουν πολλές)" : ""}. Επιλογές στην οθόνη: ${(r.labels || []).map((x) => "«" + x + "»").join(", ") || "—"}`);
      await settle(sess);
      return true;
    }
    // Προαιρετικό βήμα: περιμένει λίγο· αν το στοιχείο δεν εμφανιστεί, παραλείπεται
    if (s.optional || (s.type === "manual" && s.target)) {
      if (!s.target) throw new Error("Το προαιρετικό βήμα χρειάζεται στοιχείο (🎯) για να ξέρει πότε να τρέξει");
      const t = (s.optional ? s.optWait || 4 : s.timeout || sess.settings().timeout) * 1000;
      const fid = await findFrame(sess, s, value, t, s.optional ? 10000 : 30000);
      if (fid === null) {
        // «Αν λείπει, παράλειψε και τα επόμενα Ν» (π.χ. κωδικός ICD που δεν υπάρχει στη λίστα: δεν πατάμε «Προσθήκη»,
        // κλείνουμε το παράθυρο και πάμε στον επόμενο κωδικό). Ό,τι παραλείφθηκε μαζεύεται στο sess.misses.
        if (s.optional && s.missSkip) { (sess.misses ||= []).push(value); diag(sess, { ev: "miss", skip: s.missSkip }); return "skipif:" + (parseInt(s.missSkip) || 0); }
        if (s.optional) return "skip";
        throw new Error("Δεν εμφανίστηκε το στοιχείο");
      }
    }
    // Φύλακας ασθενή: αφού περάσει ο «Έλεγχος ασθενή», πριν από κάθε βήμα που γράφει/πατά ξαναβλέπουμε την κεφαλίδα.
    // Αν άλλαξε ο ασθενής (π.χ. ο χρήστης διάλεξε άλλον σε άλλη καρτέλα της ίδιας σύνδεσης), σταματάμε πριν γράψουμε.
    if (sess.guard && ["fill", "click", "choose", "select", "key"].includes(s.type)) {
      const g = sess.guard;
      const fg = await findFrame(sess, g.step, g.value, 300, 3000);
      if (fg !== null) {
        const rg = await send(tabId, fg, { cmd: "exec", step: g.step, value: g.value }, 8000);
        if (rg && !rg.ok && /^ΑΣΥΜΦΩΝΙΑ/.test(rg.error || "")) {
          diag(sess, { ev: "guard-mismatch", step: i });
          const e = new Error("Ο ασθενής στον φάκελο άλλαξε ενώ δούλευε το bot (π.χ. διαλέχτηκε άλλος σε άλλη καρτέλα). Για ασφάλεια σταμάτησε πριν γράψει κάτι.");
          e.mismatch = true; throw e;
        }
      }
    }
    // Λίστα με σελίδες (π.χ. «Ασθενείς Κλινικής» 1 of 3): ψάχνουμε σε ΟΛΕΣ τις σελίδες πριν διαλέξουμε
    // Γρήγορο άνοιγμα ασθενή: «Αναζήτηση Ασθενών» με το επώνυμο (κεφαλαία, χωρίς τόνους) αντί για ξεφύλλισμα
    if (s.type === "choose" && s.target?.search) await searchSeek(sess, s, value);
    if (s.type === "choose" && s.target?.pages && s.target.within) await pagedSeek(sess, s, value);
    // Λίστα PrimeFaces (Τύπος/Έκβαση): επιλογή τιμής κατευθείαν με την εντολή της λίστας. Αν δεν γίνει, άνοιγμα με κλικ.
    if (s.type === "choose" && s.target?.pfSelect) {
      if (await pfSelect(sess, s.target.pfSelect, value)) { await settle(sess); return true; }
      const opener = { ...s, type: "click", target: { css: "#" + s.target.pfSelect.replace(/:/g, "\\:"), tag: "div", cls: ["ui-selectonemenu"], text: "", framePath: s.target.framePath } };
      const fo = await findFrame(sess, opener, "", 8000);
      if (fo !== null) { await send(sess.tabId, fo, { cmd: "exec", step: opener, value: "" }, 8000); await settle(sess); }
    }
    if (s.type === "manual") {
      if (!sess.manual) throw new Error("Χειροκίνητο βήμα: δεν επιτρέπεται στην αυτόματη παρακολούθηση");
      return await sess.manual(s.label, i);
    }
    if (!s.target) throw new Error("Δεν έχει οριστεί στοιχείο. Πηγαίνετε στη Ρύθμιση και πατήστε 🎯");
    let frameId = await findFrame(sess, s, value, (s.timeout || sess.settings().timeout) * 1000);
    // 6/11: ΑΗΦΥ — ενημερωτικό παράθυρο (PrimeNG dialog) σκεπάζει το πεδίο → κλείνει ΜΟΝΟ αν είναι καθαρά ενημερωτικό (χωρίς πεδία) και ξαναδοκιμάζει μία φορά
    if (frameId === null && sess.why && sess.why.covered && /p-dialog|p-component-overlay|cdk-overlay|modal/i.test(sess.why.covered) && /ehealthrecord\.gov\.gr/i.test(((await chrome.tabs.get(tabId).catch(() => ({}))).url) || "")) {
      const dz = await chrome.scripting.executeScript({ target: { tabId }, func: () => {
        const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
        const out = [];
        // 6/11 (απόφαση χρήστη: «Είμαστε θεράποντες — να πατάει πάντα θεράπων»): «Όροι Χρήσης / Καταγραφή Πρόσβασης… επιβεβαιώστε ότι είστε ο θεράπων ιατρός»
        // → τικ ΜΟΝΟ στο κουτάκι του θεράποντα + κουμπί επιβεβαίωσης. Ποτέ σε παράθυρο με OTP/κωδικό/πεδίο κειμένου.
        const att = (d) => { const t = String(d.innerText || "").replace(/\s+/g, " ");
          if (!/(Καταγραφ[ήη]ς?\s+Πρόσβασης|θεράπων\s+ιατρ|Όροι\s+Χρήσης)/i.test(t) || /OTP|κωδικ[όο]ς\s+μιας|SMS/i.test(t)) return false;
          if (d.querySelector("input[type=text]:not([readonly]), input[type=password], textarea")) return false;
          const boxes = [...d.querySelectorAll("p-checkbox, .p-checkbox, input[type=checkbox], [role=checkbox]")];
          const lab = (b) => String((b.closest("label, .p-field-checkbox, .field-checkbox, div") || b).innerText || "");
          const want = boxes.filter((b) => /θεράπων|ενημερώθηκα|αποδέχομαι|επιβεβαιώνω/i.test(lab(b))); const use = want.length ? want : boxes.length === 1 ? boxes : [];
          for (const b of use) { const inp = b.matches("input") ? b : b.querySelector("input[type=checkbox]"); const on = inp ? inp.checked : /p-highlight|p-checkbox-checked/.test(b.className + " " + ((b.querySelector(".p-checkbox-box") || {}).className || "")) || b.getAttribute("aria-checked") === "true";
            if (!on) (b.querySelector(".p-checkbox-box") || b).click(); }
          const ok = [...d.querySelectorAll("button")].find((x) => /^(Επιβεβαίωση|Συνέχεια|Αποδοχή|Αποδέχομαι|OK|ΟΚ|Εντάξει|Υποβολή)$/i.test(String(x.innerText || "").trim()) && !x.disabled);
          if (ok) { setTimeout(() => ok.click(), 250); return true; } return false; };
        for (const d of [...document.querySelectorAll(".p-dialog, [role=dialog], [role=alertdialog], .modal.show")].filter(vis)) {
          const t = String(d.innerText || "").replace(/\s+/g, " ").trim().slice(0, 160);
          if (att(d)) { out.push({ t: t.slice(0, 60), closed: true }); continue; }
          if (d.querySelector("input:not([type=hidden]),textarea,select,[role=combobox]")) { out.push({ t, skip: "έχει πεδία" }); continue; }
          if (/διαγραφ|ακύρωσ|υποβολ|καταχώρ|αποστολ|αποθήκ|σίγουρ|επιβεβαί|συναίνεσ|OTP|κωδικ|αιτιολ/i.test(t)) { out.push({ t, skip: "όχι ενημερωτικό" }); continue; }
          const b = d.querySelector(".p-dialog-header-close, [aria-label=Close], [aria-label='Κλείσιμο'], .btn-close") || [...d.querySelectorAll("button")].find((x) => /^(OK|ΟΚ|Εντάξει|Κλείσιμο|Συνέχεια|Το κατάλαβα)$/i.test(String(x.innerText || "").trim()));
          if (b) { b.click(); out.push({ t, closed: true }); } else out.push({ t, skip: "χωρίς κουμπί κλεισίματος" });
        }
        return out;
      } }).catch(() => [null]);
      const info = dz && dz[0] && dz[0].result || [];
      diag(sess, { ev: "dialog-dismiss", step: i, info });
      if (info.some((x) => x.closed)) { await sleep(800); sess.why = {}; frameId = await findFrame(sess, s, value, 8000); }
      else if (info.length && sess.why) sess.why.covered += " · παράθυρο: «" + info.map((x) => x.t + " (" + (x.skip || "") + ")").join(" | ").slice(0, 220) + "»";
    }
    if (frameId === null) {
      if (sess.isAborted()) { const e = new Error("Διακόπηκε"); e.aborted = true; throw e; }
      const w = sess.why || {};
      if (w.ambiguous) {
        const who = /doctor/i.test(s.target?.within || "") ? "γιατροί" : "ασθενείς";
        const e = new Error(`Βρέθηκαν ${w.ambiguous} ${who} που ταιριάζουν με «${value}». Για ασφάλεια το bot σταμάτησε: διαλέξτε τον σωστό με το χέρι και πατήστε «Συνέχεια», ή γράψτε ολόκληρο το ονοματεπώνυμο${who === "γιατροί" ? " (Γενικές ρυθμίσεις → Παραδόχαρτο: θεράποντες)" : ""}.`);
        e.mismatch = true; throw e;
      }
      if (w.covered) throw new Error(`Το στοιχείο φαίνεται, αλλά κάτι το σκεπάζει (${w.covered}). Κλείστε τυχόν μήνυμα/παράθυρο και πατήστε «Συνέχεια».`);
      if (w.busy && !w.seen) throw new Error(`Η εφαρμογή έδειχνε συνεχώς «φορτώνει» (${w.busy}) και το στοιχείο δεν εμφανίστηκε. Αν η οθόνη είναι έτοιμη, ξαναμάθετε το βήμα (🎯) ή κλείστε την «Αναμονή φόρτωσης» στις Γενικές ρυθμίσεις.`);
      if (w.frames && !w.answered) throw new Error("Η σελίδα δεν απαντά στο bot. Ανανεώστε την καρτέλα (F5) και ξαναδοκιμάστε.");
      throw new Error(s.type === "choose" ? `Δεν βρέθηκε «${value}» στη λίστα` : "Δεν βρέθηκε στη σελίδα (άλλαξε η οθόνη;)");
    }
    let r = await send(tabId, frameId, { cmd: "exec", step: s, value }, 15000);
    // «Έλεγχος ασθενή»: μετά την επιλογή, ο server χρειάζεται λίγο για να φέρει τον νέο ασθενή.
    // Αν βλέπουμε ακόμα άλλο όνομα, ξαναδοκιμάζουμε έως 12 δευτ. πριν σταματήσουμε.
    if (s.type === "check" && r && !r.ok && /^ΑΣΥΜΦΩΝΙΑ/.test(r.error || "")) {
      const until = Date.now() + 12000;
      while (Date.now() < until && !sess.isAborted() && !r?.ok) {
        await sleep(500);
        await settle(sess);
        const f2 = await findFrame(sess, s, value, 3000, 5000);
        if (f2 !== null) r = await send(tabId, f2, { cmd: "exec", step: s, value }, 15000) || r;
      }
      diag(sess, { ev: "check-wait", ok: !!r?.ok });
    }
    if (!r) {
      diag(sess, { ev: "exec-noreply", type: s.type });
      // Το κλικ συνήθως έγινε, αλλά η σελίδα ξαναφόρτωσε πριν απαντήσει: συνεχίζουμε κανονικά
      if (s.type === "click") { await waitLoaded(tabId, 30000, sess.isAborted).catch(() => {}); return true; }
    }
    // Κλικ που πρέπει να ανοίξει κάτι (π.χ. «Έκδοση Εξιτηρίου» → φόρμα). Η εφαρμογή μερικές φορές δεν αντιδρά:
    // ξαναπατάμε μία φορά· αν πάλι τίποτα, ανανεώνουμε τη σελίδα και ζητάμε επανάληψη από την αρχή (e.restart).
    if (r?.ok && s.type === "click" && s.target?.expect) {
      const probe = { type: "read", target: { css: s.target.expect, tag: "", cls: [], text: "", framePath: s.target.framePath } };
      const opened = async () => { await settle(sess); return (await findFrame(sess, probe, "", 6000, 12000)) !== null; };
      let ok = await opened();
      if (!ok && !sess.isAborted()) {
        diag(sess, { ev: "expect-retry" });
        const f2 = await findFrame(sess, s, value, 3000, 5000);
        if (f2 !== null) { await send(tabId, f2, { cmd: "exec", step: s, value }, 15000); ok = await opened(); }
      }
      if (!ok && !sess.isAborted()) {
        diag(sess, { ev: "expect-reload" });
        await chrome.tabs.reload(tabId).catch(() => {});
        await waitLoaded(tabId, 60000, sess.isAborted).catch(() => {});
        await sleep(1500);
        const e = new Error("Το κουμπί δεν άνοιξε τη φόρμα: ανανέωσα τον φάκελο");
        e.restart = true;
        throw e;
      }
    }
    if (!r?.ok) {
      const e = new Error(r?.error || "Αποτυχία ενέργειας");
      if (/^ΑΣΥΜΦΩΝΙΑ/.test(e.message)) e.mismatch = true;
      throw e;
    }
    if (s.type === "check" && s.target) sess.guard = { step: s, value };
    if (s.type === "read") {
      let text = r.text || "";
      if (s.value) text = text.split(s.value).pop(); // αφαίρεση ετικέτας, π.χ. «Επώνυμο:»
      let cols = null;
      // Φίλτρο: κρατάμε μόνο τις γραμμές που ξεκινούν με κάποιο από τα ονόματα (π.χ. Hb, CRP).
      // Αν το φίλτρο είναι κενό, κρατάμε όλες τις γραμμές.
      if (s.filter) {
        const names = render(s.filter, vals, extra).split(/[,;\n]/).map((x) => x.trim().toLowerCase()).filter(Boolean);
        const lines = text.split(/\n/).map((l) => l.replace(/\t+/g, " ").replace(/\s+/g, " ").trim()).filter(Boolean);
        if (names.length) {
          const picked = names.map((n) =>
            lines.find((l) => l.toLowerCase().startsWith(n + " ") || l.toLowerCase() === n || l.toLowerCase().startsWith(n + ":"))
          );
          text = picked.filter(Boolean).join("\n");
          // Μία στήλη ανά εξέταση, με τη σειρά του φίλτρου (κενή αν λείπει), για επικόλληση σε Excel
          cols = picked.map((l, k) => (l ? l.slice(names[k].length).replace(/^[:\s]+/, "") : "")).join("\t");
        } else text = lines.join("\n");
      }
      text = text.trim();
      if (!text) {
        const e = new Error(s.filter ? "Δεν βρέθηκαν οι εξετάσεις στον πίνακα" : "Το πεδίο ήταν κενό");
        e.empty = true;
        throw e;
      }
      const name = s.saveAs || "κείμενο";
      sess.vars[name] = text;
      if (cols !== null) sess.vars[name + "_στήλες"] = cols;
      return "read:" + text.slice(0, 40);
    }
    return true;
  }

  // Εκτελεί μια σειρά βημάτων (από το plan). Σε σφάλμα ρίχνει exception με e.k = θέση αποτυχίας.
  async function execPlan(sess, items, { from = 0, onStart, onDone } = {}) {
    let k = from;
    try {
      for (; k < items.length; k++) {
        if (sess.isAborted()) { const e = new Error("Διακόπηκε"); e.aborted = true; throw e; }
        const it = items[k];
        sess.heartbeat?.();
        onStart?.(it, k);
        const t1 = Date.now();
        diag(sess, { ev: "start", step: it.i + 1, type: it.s.type, label: it.s.label, target: !!it.s.target, optional: !!it.s.optional });
        let r;
        try { r = await runStep(sess, it.s, it.i, it.extra); }
        catch (e) {
          // Στη διάγνωση δεν μπαίνει τίποτα μέσα σε «…» (εκεί είναι ονόματα/τιμές)
          diag(sess, { ev: "error", step: it.i + 1, ms: Date.now() - t1, msg: String(e.message).replace(/«[^»]*»/g, "«…»") });
          throw e;
        }
        diag(sess, { ev: "done", step: it.i + 1, ms: Date.now() - t1, r: typeof r === "string" ? r.replace(/^read:[\s\S]*/, "read") : r });
        onDone?.(it, k, r);
        if (typeof r === "string" && r.startsWith("skipif:")) { k += parseInt(r.slice(7)) || 0; continue; }
        if (r === true) {
          if (["click", "fill", "choose"].includes(it.s.type)) await settle(sess);
          await sleep(it.s.delay ?? sess.settings().delay ?? 0);
        }
        else if (r === false && sess.isAborted()) { const e = new Error("Διακόπηκε"); e.aborted = true; throw e; }
      }
    } catch (e) {
      e.k = k;
      throw e;
    }
  }

  // 0.10: στις «Επιπλέον διαγνώσεις» του Εξιτηρίου ένας κωδικός που δεν βρίσκεται στη λίστα ICD δεν σταματά πια
  // όλο το εξιτήριο: παραλείπεται, κλείνει το παράθυρο αναζήτησης και αναφέρεται στο τέλος. Τρέχει σε κάθε φόρτωση (ίδιο αποτέλεσμα κάθε φορά).
  const DX_CLOSE = "Επιπλέον διάγνωση: κλείσιμο παραθύρου αν έμεινε ανοιχτό";
  function patchWorkflows(st) {
    let changed = false;
    // ΑΗΦΥ: ο λόγος πρόσβασης γράφεται «Θεράπων ιατρός» (οδηγία του χρήστη), αν δεν έχει οριστεί άλλος
    { const ah = (st?.workflows || []).find((w) => w.id === "aihfy_dx");
      if (ah) { ah.defaults = ah.defaults || {}; if (!String(ah.defaults["λόγος_πρόσβασης"] || "").trim()) { ah.defaults["λόγος_πρόσβασης"] = "Θεράπων ιατρός"; changed = true; } }
      st.values = st.values || {}; const v = st.values.aihfy_dx = st.values.aihfy_dx || {};
      if (!String(v["λόγος_πρόσβασης"] || "").trim()) { v["λόγος_πρόσβασης"] = "Θεράπων ιατρός"; changed = true; } }
    const ex = (st?.workflows || []).find((w) => w.id === "exitirio");
    if (!ex) return false;
    const ch = ex.steps.find((x) => x.label === "Επιπλέον διάγνωση: επιλογή από λίστα");
    const add = ex.steps.findIndex((x) => x.label === "Επιπλέον διάγνωση: «Προσθήκη Διάγνωσης» στο παράθυρο");
    if (ch && !ch.missSkip) { ch.optional = true; ch.optWait = 10; ch.missSkip = 1; changed = true; }
    if (add >= 0 && !ex.steps.some((x) => x.label === DX_CLOSE)) {
      ex.steps.splice(add + 1, 0, { label: DX_CLOSE, type: "click", each: "επιπλέον_διαγνώσεις", optional: true, optWait: 1,
        target: { css: "div.ui-dialog:has(#appForm\\:diagnosisInput) .ui-dialog-titlebar-close", tag: "a", cls: ["ui-dialog-titlebar-close"], text: "", name: "", aria: "", placeholder: "", title: "",
                  editable: false, isSelect: false, framePath: "/emr-ui/views/home.xhtml", preset: true } });
      changed = true;
    }
    return patchAihfy(st) || changed;
  }
  // 0.13: ΑΗΦΥ — κουμπί αναζήτησης μετά τον ΑΜΚΑ· λόγος πρόσβασης με το κείμενο (radio) και μόνο αν ζητηθεί
  // (μέσα σε 24 ώρες από την προηγούμενη πρόσβαση δεν ζητείται). Κρατά ό,τι έχει ήδη μάθει ο χρήστης.
  function patchAihfy(st) {
    const w = (st?.workflows || []).find((x) => x.id === "aihfy_dx");
    if (w && w.patched13 && !w.patched13c) return patchAihfyPresets(w);
    // 0.18.26: όσα έτοιμα βήματα έμειναν ΧΩΡΙΣ στόχο παίρνουν τον έτοιμο (ποτέ δεν αντικαθίσταται ό,τι έμαθε ο χρήστης)
    if (w && !w.patched1826) { for (const s of w.steps) if (!s.target && EHR_PRESETS[s.label]) s.target = structuredClone(EHR_PRESETS[s.label]); w.patched1826 = true; return true; }
    if (!w || w.patched13) return false;
    const at = (lbl) => w.steps.findIndex((x) => x.label === lbl);
    const amka = at("ΑΗΦΥ: πεδίο ΑΜΚΑ");
    if (amka >= 0 && at("ΑΗΦΥ: κουμπί αναζήτησης (μετά τον ΑΜΚΑ)") < 0) w.steps.splice(amka + 1, 0, { label: "ΑΗΦΥ: κουμπί αναζήτησης (μετά τον ΑΜΚΑ)", type: "click" });
    const o = at("ΑΗΦΥ: λόγος πρόσβασης: άνοιγμα λίστας");
    if (o >= 0) w.steps[o] = { label: "ΑΗΦΥ: λόγος πρόσβασης (μόνο αν τον ζητήσει)", type: "choose", value: "{λόγος_πρόσβασης}", optional: true, optWait: 8, missSkip: 1,
      target: { radio: true, css: "", tag: "div", cls: [], text: "", name: "", aria: "", placeholder: "", title: "", editable: false, isSelect: false, framePath: "", preset: true } };
    const c = at("ΑΗΦΥ: λόγος πρόσβασης: επιλογή");
    if (c >= 0) w.steps[c] = { ...w.steps[c], label: "ΑΗΦΥ: επιβεβαίωση λόγου (κουμπί)", type: "click", value: "", optional: true, optWait: 4 };
    // το παλιό «αναζήτηση / είσοδος» (αν υπάρχει ακόμα αμάθητο ανάμεσα σε λόγο και έλεγχο) δεν χρειάζεται πια
    const old = at("ΑΗΦΥ: αναζήτηση / είσοδος στον ασθενή");
    if (old >= 0 && !w.steps[old].target) w.steps.splice(old, 1);
    w.patched13 = true;
    patchAihfyPresets(w);
    return true;
  }
  // Έτοιμοι στόχοι από το πραγματικό doctor.ehealthrecord.gov.gr (καταγράφηκαν 31/10/2026): δεν χρειάζονται 🎯
  const EHR_T = (o) => ({ css: "", tag: "", cls: [], text: "", name: "", aria: "", placeholder: "", title: "", editable: false, isSelect: false, framePath: "", preset: true, ...o });
  const EHR_PRESETS = {
    "ΑΗΦΥ: πεδίο ΑΜΚΑ": EHR_T({ css: 'input[placeholder="Εισάγετε ΑΜΚΑ ασθενή προς αναζήτηση"]', tag: "input", placeholder: "Εισάγετε ΑΜΚΑ ασθενή προς αναζήτηση", editable: true }),
    "ΑΗΦΥ: κουμπί αναζήτησης (μετά τον ΑΜΚΑ)": EHR_T({ css: 'button[aria-label="εκτέλεση αναζήτησης ασθενή"]', tag: "button", aria: "εκτέλεση αναζήτησης ασθενή" }),
    "ΑΗΦΥ: Έλεγχος: ο ΑΜΚΑ στην οθόνη ταιριάζει": EHR_T({ ehrAmka: true, tag: "span" }),
    // κρυφό επιτρέπεται: σε στενό παράθυρο (ή μεγέθυνση οθόνης Windows 125–150%) το πλευρικό μενού κρύβεται πίσω από το ☰
    "ΑΗΦΥ: μενού «Διαγνώσεις»": EHR_T({ css: 'a[href="/doctor/app/clinical/diagnosis"]', tag: "a", text: "", hidden: true }),
    // 0.18.26: έτοιμο και το κουμπί επιβεβαίωσης λόγου (μόνο μέσα σε παράθυρο διαλόγου· αν δεν ζητηθεί λόγος, παραλείπεται σε 4″)
    "ΑΗΦΥ: επιβεβαίωση λόγου (κουμπί)": EHR_T({ css: 'mat-dialog-container button[type="submit"], [role="dialog"] button[type="submit"], .modal.show button[type="submit"], mat-dialog-actions button.mat-primary, [role="dialog"] button.btn-primary', tag: "button" }),
  };
  function patchAihfyPresets(w) {
    if (!w || w.patched13c) return false;
    for (const s of w.steps) if (EHR_PRESETS[s.label]) s.target = structuredClone(EHR_PRESETS[s.label]);
    w.patched13b = true; w.patched13c = true;
    return true;
  }

  g.EFEngine = {
    VERSION: "0.16.51", patchWorkflows,
    sleep, BUILTIN, BULKVAR, isWeb, render, varsOf, lineVars, plan, lockAcquire, lockTouch, lockRelease,
    switchTab, gotoUrl, waitLoaded, frames, send, findFrame, settle, runStep, execPlan,
  };
})(typeof self !== "undefined" ? self : window);
