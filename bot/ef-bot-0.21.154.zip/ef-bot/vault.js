// ===== 🔒 Κρυπτογραφημένοι κωδικοί (Windows DPAPI) =====
// Οι κωδικοί (ΑΗΦΥ/φάκελος/Medilabi) κρυπτογραφούνται με AES-GCM 256 (WebCrypto). Το κλειδί AES το «κλειδώνουν» τα
// Windows (DPAPI, λογαριασμός του τρέχοντος χρήστη) μέσω του μικρού βοηθητικού «gr.efbot.vault» που εγκαθιστά ο updater.
//  - Στον δίσκο υπάρχουν μόνο: efbotVaultWrapped (κλειδί κλειδωμένο από τα Windows) + efbotVault (κρυπτογραφημένοι κωδικοί).
//  - Το ξεκλείδωτο κλειδί μένει μόνο στη μνήμη (chrome.storage.session, μόνο για τις σελίδες της επέκτασης).
//  - Αντίγραφο του φακέλου του Chrome σε άλλο υπολογιστή/χρήστη ΔΕΝ ανοίγει.
//  - Χωρίς το βοηθητικό (π.χ. Mac): οι κωδικοί μένουν όπως πριν (μη κρυπτογραφημένοι) και το πάνελ το δείχνει.
// Μόνο το background μιλά με το βοηθητικό· το πάνελ ζητά/γράφει κωδικούς με μηνύματα (secretsGet/secretsSet).
(function () {
  const HOST = "gr.efbot.vault";
  const KEYS = ["efbotCredByHost", "efbotEmrCred", "efbotLabsCred", "efbotXferKey", "efbotPdxCred", "efbotClinicKey"];
  const ENTROPY_NOTE = "ef-bot-vault-v1";   // το ίδιο «αλάτι» χρησιμοποιεί και το βοηθητικό (DPAPI optionalEntropy)
  const b64 = (u8) => { let s = ""; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); };
  const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

  function native(msg, timeoutMs = 15000) {
    return new Promise((res) => {
      let done = false;
      const t = setTimeout(() => { if (!done) { done = true; res({ ok: false, err: "το βοηθητικό δεν απάντησε" }); } }, timeoutMs);
      try {
        chrome.runtime.sendNativeMessage(HOST, msg, (r) => {
          if (done) return; done = true; clearTimeout(t);
          const e = chrome.runtime.lastError;
          res(e ? { ok: false, err: e.message, missing: /not found|not exist|forbidden|Specified native messaging host/i.test(e.message) } : (r || { ok: false, err: "κενή απάντηση" }));
        });
      } catch (e) { done = true; clearTimeout(t); res({ ok: false, err: e.message, missing: true }); }
    });
  }

  let keyP = null;   // Promise<CryptoKey|null> στη μνήμη του worker
  async function importRaw(raw) { return crypto.subtle.importKey("raw", raw, "AES-GCM", false, ["encrypt", "decrypt"]); }
  async function getKey() {
    const { efbotVaultK: k } = await chrome.storage.session.get("efbotVaultK");
    if (k) return importRaw(unb64(k));
    const { efbotVaultWrapped: w } = await chrome.storage.local.get("efbotVaultWrapped");
    if (!w) return null;
    const r = await native({ op: "unprotect", data: w });
    if (!r.ok || !r.data) { lastErr = "δεν ξεκλειδώνουν οι κωδικοί: " + (r.err || "άγνωστο"); return null; }
    await chrome.storage.session.set({ efbotVaultK: r.data });
    lastErr = "";
    return importRaw(unb64(r.data));
  }
  function key() { if (!keyP) keyP = getKey().then((k) => { if (!k) keyP = null; return k; }, (e) => { keyP = null; lastErr = e.message; return null; }); return keyP; }

  async function enc(k, obj) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, k, new TextEncoder().encode(JSON.stringify(obj))));
    return { v: 1, iv: b64(iv), ct: b64(ct) };
  }
  async function dec(k, box) {
    const pt = await crypto.subtle.decrypt({ name: "AES-GCM", iv: unb64(box.iv) }, k, unb64(box.ct));
    return JSON.parse(new TextDecoder().decode(pt));
  }

  // Όλες οι εγγραφές περνούν από μία ουρά (να μη χάνεται αλλαγή όταν γράφουν ταυτόχρονα εκμάθηση + εναλλαγή λογαριασμών)
  let chain = Promise.resolve();
  const serial = (fn) => { const p = chain.then(fn, fn); chain = p.catch(() => {}); return p; };
  let lastErr = "";

  // Πρώτη φορά με το βοηθητικό: φτιάχνει κλειδί, κρυπτογραφεί ό,τι υπάρχει και σβήνει τα μη κρυπτογραφημένα.
  async function ensureVault() {
    const st = await chrome.storage.local.get(["efbotVault", "efbotVaultWrapped", ...KEYS]);
    if (st.efbotVault && st.efbotVaultWrapped) return true;
    const ping = await native({ op: "ping" }, 8000);
    if (!ping.ok) { lastErr = ping.missing ? "" : ("βοηθητικό: " + (ping.err || "")); return false; }
    const raw = crypto.getRandomValues(new Uint8Array(32));
    const w = await native({ op: "protect", data: b64(raw) });
    if (!w.ok || !w.data) { lastErr = "κλείδωμα κλειδιού: " + (w.err || ""); return false; }
    // έλεγχος ότι ξεκλειδώνει πριν σβηστεί οτιδήποτε
    const back = await native({ op: "unprotect", data: w.data });
    if (!back.ok || back.data !== b64(raw)) { lastErr = "ο έλεγχος του κλειδιού απέτυχε"; return false; }
    const k = await importRaw(raw);
    const plain = {}; for (const n of KEYS) if (st[n] != null) plain[n] = st[n];
    const box = await enc(k, plain);
    const chk = await dec(k, box);
    if (JSON.stringify(chk) !== JSON.stringify(plain)) { lastErr = "ο έλεγχος κρυπτογράφησης απέτυχε"; return false; }
    await chrome.storage.local.set({ efbotVaultWrapped: w.data, efbotVault: box });
    await chrome.storage.session.set({ efbotVaultK: b64(raw) });
    keyP = Promise.resolve(k);
    await chrome.storage.local.remove(KEYS);
    lastErr = "";
    return true;
  }

  async function readAll() {
    const st = await chrome.storage.local.get(["efbotVault", ...KEYS]);
    if (!st.efbotVault) { const o = {}; for (const n of KEYS) if (st[n] != null) o[n] = st[n]; return { mode: "plain", data: o }; }
    const k = await key();
    if (!k) return { mode: "locked", data: {} };
    try { return { mode: "dpapi", data: await dec(k, st.efbotVault) }; }
    catch (e) { lastErr = "οι κωδικοί δεν αποκρυπτογραφούνται"; return { mode: "locked", data: {} }; }
  }

  // Ανάγνωση: ίδια μορφή με το chrome.storage.local.get (π.χ. { efbotCredByHost: {...} })
  async function get(keys) {
    const want = Array.isArray(keys) ? keys : [keys];
    const { data } = await readAll();
    const o = {}; for (const n of want) if (data[n] != null) o[n] = data[n];
    return o;
  }
  // Εγγραφή: { κλειδί: τιμή } — τιμή null = διαγραφή
  function set(patch) {
    return serial(async () => {
      for (const n of Object.keys(patch)) if (!KEYS.includes(n)) throw new Error("άγνωστο κλειδί κωδικών: " + n);
      let st = await chrome.storage.local.get(["efbotVault"]);
      if (!st.efbotVault) { await ensureVault().catch(() => false); st = await chrome.storage.local.get(["efbotVault"]); }
      if (!st.efbotVault) {   // χωρίς βοηθητικό: όπως πριν
        const put = {}, del = [];
        for (const [n, v] of Object.entries(patch)) (v == null ? del.push(n) : (put[n] = v));
        if (Object.keys(put).length) await chrome.storage.local.set(put);
        if (del.length) await chrome.storage.local.remove(del);
        return { ok: true, mode: "plain" };
      }
      const k = await key();
      if (!k) throw new Error(lastErr || "οι κωδικοί είναι κλειδωμένοι (λείπει το βοηθητικό των Windows;)");
      const data = await dec(k, st.efbotVault);
      for (const [n, v] of Object.entries(patch)) { if (v == null) delete data[n]; else data[n] = v; }
      await chrome.storage.local.set({ efbotVault: await enc(k, data), efbotVaultTs: Date.now() });
      return { ok: true, mode: "dpapi" };
    });
  }
  // Ανάγνωση-αλλαγή-εγγραφή ΜΕΣΑ στην ίδια ουρά: fn(τρέχουσα τιμή) → νέα τιμή. Αν οι κωδικοί είναι κλειδωμένοι, ΑΠΟΤΥΓΧΑΝΕΙ
  // (πριν: get → «κενό» επειδή δεν είχε ξεκλειδώσει ακόμα → set έγραφε από πάνω και χάνονταν οι υπόλοιποι λογαριασμοί).
  function update(name, fn) {
    return serial(async () => {
      if (!KEYS.includes(name)) throw new Error("άγνωστο κλειδί κωδικών: " + name);
      const st = await chrome.storage.local.get(["efbotVault", name]);
      if (!st.efbotVault) {
        const nv = await fn(st[name] == null ? undefined : st[name]);
        if (nv == null) await chrome.storage.local.remove(name); else await chrome.storage.local.set({ [name]: nv });
        return { ok: true, mode: "plain" };
      }
      const k = await key();
      if (!k) throw new Error(lastErr || "οι κωδικοί είναι κλειδωμένοι");
      const data = await dec(k, st.efbotVault);
      const nv = await fn(data[name]);
      if (nv == null) delete data[name]; else data[name] = nv;
      await chrome.storage.local.set({ efbotVault: await enc(k, data), efbotVaultTs: Date.now() });
      return { ok: true, mode: "dpapi" };
    });
  }
  // Διαγραφή όλων (και του κλειδιού): «Διαγραφή όλων» στο πάνελ
  function wipe() {
    return serial(async () => {
      await chrome.storage.local.remove(["efbotVault", "efbotVaultWrapped", "efbotVaultTs", ...KEYS]);
      await chrome.storage.session.remove("efbotVaultK"); keyP = null;
      await ensureVault().catch(() => false);   // καινούριο άδειο κρυπτογραφημένο «χρηματοκιβώτιο» αν υπάρχει βοηθητικό
      return { ok: true };
    });
  }
  async function status() {
    const st = await chrome.storage.local.get(["efbotVault"]);
    if (!st.efbotVault) {
      const p = await native({ op: "ping" }, 8000);
      return { mode: "plain", helper: !!p.ok, err: p.ok ? "" : (p.missing ? "" : p.err || "") };
    }
    const k = await key();
    return { mode: k ? "dpapi" : "locked", helper: true, err: k ? "" : lastErr };
  }
  function migrate() { return serial(() => ensureVault().catch((e) => { lastErr = e.message; return false; })); }

  self.EFVault = { get, set, update, wipe, status, migrate, KEYS, _native: native, _dec: dec, _enc: enc, ENTROPY_NOTE };
})();
