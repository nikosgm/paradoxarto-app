// Ανάγνωση σελίδων του Medilabi (εργαστήρια). Χρησιμοποιείται από το offscreen.html (όπου υπάρχει DOMParser).
// Δεν κρατά τίποτα· παίρνει HTML και επιστρέφει δομημένα δεδομένα.
(function (g) {
  "use strict";
  const norm = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/ς/g, "σ").replace(/\s+/g, " ").trim();
  const txt = (e) => (e ? e.textContent.replace(/\s+/g, " ").trim() : "");
  const isDate = (t) => /^\d{2}\/\d{2}\/\d{2}\s+\d{2}:\d{2}$/.test(String(t).trim());
  const doc = (html) => new DOMParser().parseFromString(html, "text/html");

  // Σελίδα σύνδεσης; (έληξε η σύνδεση)
  function isLogin(html) {
    return /txtPassword|Login\.aspx/i.test(html) && !/lnkPatName|PatientResults\.aspx/i.test(html);
  }

  // Λίστα αναμονής: [{ name, pid }]
  function parseWaiting(html) {
    const d = doc(html);
    const out = [];
    for (const a of d.querySelectorAll("a[id$=lnkPatName]")) {
      const m = (a.getAttribute("onclick") || "").match(/ONLINE_RESULTS_EXAMS\((\d+)\)/);
      let pid = m ? m[1] : "";
      if (!pid) {
        const row = a.closest("tr");
        const r = row && row.querySelector("a[href*='PatientResults.aspx?PatientID=']");
        pid = r ? (r.getAttribute("href").match(/PatientID=(\d+)/) || [])[1] || "" : "";
      }
      // υπογραφή γραμμής (ημερομηνίες/κατάσταση δείγματος): αν δεν αλλάξει, δεν χρειάζεται νέο άνοιγμα του ασθενή
      if (pid) { const row = a.closest("tr"); out.push({ name: txt(a), pid, sig: row ? txt(row).slice(0, 300) : "" }); }
    }
    return out;
  }

  // Κατάσταση εξετάσεων: [{ group, state: "done"|"pending"|"abnormal" }]
  function parseExams(html) {
    const d = doc(html);
    const map = { green: "done", red: "pending", blue: "abnormal" };
    const out = [];
    for (const img of d.querySelectorAll("img[src*='bullet_']")) {
      const color = ((img.getAttribute("src") || "").match(/bullet_(\w+)/) || [])[1];
      const row = img.closest("tr") || img.parentElement;
      const t = txt(row);
      // η λεζάντα (Ολοκληρώθηκε / Εκκρεμεί / Παθολογική) δεν είναι εξέταση
      if (!t || (/Ολοκληρώθηκε/i.test(t) && /Εκκρεμεί/i.test(t)) || row.querySelectorAll("img[src*='bullet_']").length > 1) continue;
      if (map[color]) out.push({ group: t, state: map[color] });
    }
    return out;
  }

  // Ολόκληρος ο πίνακας αποτελεσμάτων, όπως στο Medilabi:
  // { dates: ["dd/mm/yy hh:mm", ... (νεότερη πρώτη)], rows: [{ g: "ΟΜΑΔΑ" } | { t, r, u, v: { δείκτης_ημερομηνίας: "τιμή" + "↑"/"↓" } }] }
  // Οι γραμμές-τίτλοι ομάδων (results_profilerow) έχουν στις στήλες την ώρα δείγματος, όχι τιμές.
  function parseAll(html) {
    const d = doc(html);
    let hdr = null;
    for (const tr of d.querySelectorAll("tr")) {
      const ds = [...tr.cells].map((c) => txt(c));
      if (ds.some(isDate) && ds.every((t) => !t || isDate(t))) { hdr = tr; break; }
    }
    if (!hdr) return { dates: [], rows: [] };
    const hd = [...hdr.cells].map((c) => txt(c)), n = hd.length, idx = [], dates = [];
    hd.forEach((t, i) => { if (isDate(t)) { idx[i] = dates.length; dates.push(t); } });
    const rows = [], seen = new Set();
    for (const tr of d.querySelectorAll("tr")) {
      if (tr === hdr || tr.cells.length !== n) continue;
      const t = tr.closest("table"), O = t && t.closest("tr");
      if (!O || seen.has(O) || O.cells.length < 5) continue;
      seen.add(O);
      const name = txt(O.cells[2]);
      if (!name) continue;
      if (/results_profilerow/.test(O.className)) { rows.push({ g: name }); continue; }
      const v = {};
      [...tr.cells].forEach((c, i) => {
        if (idx[i] === undefined) return;
        const val = txt(c);
        if (!val) return;
        const img = c.querySelector("img[src*='Arrow_']");
        v[idx[i]] = val + (img ? (/Arrow_Up/i.test(img.getAttribute("src")) ? "↑" : "↓") : "");
      });
      rows.push({ t: name, r: txt(O.cells[3]), u: txt(O.cells[4]), v });
    }
    return { dates, rows };
  }

  // Μόνο τα αποτελέσματα μιας ημέρας (dd/mm/yy): [{ test, range, unit, time, value, flag: "H"|"L"|"" }]
  function parseResults(html, day) {
    const a = parseAll(html), out = [];
    for (const r of a.rows) {
      if (!r.t) continue;
      for (const [i, raw] of Object.entries(r.v)) {
        const dt = a.dates[i];
        if (!dt || !dt.startsWith(day)) continue;
        const flag = raw.endsWith("↑") ? "H" : raw.endsWith("↓") ? "L" : "";
        out.push({ test: r.t, range: r.r, unit: r.u, time: dt.slice(9), value: flag ? raw.slice(0, -1) : raw, flag });
      }
    }
    return out;
  }

  // Φόρμα σύνδεσης (ASP.NET): όλα τα πεδία που στέλνει ο browser, εκτός από όνομα/κωδικό που συμπληρώνει το bot.
  function parseLoginForm(html) {
    const d = doc(html);
    const pass = d.querySelector("input[type=password]");
    if (!pass) return null;
    const form = pass.closest("form") || d;
    const fields = [];
    let user = null;
    for (const el of form.querySelectorAll("input, select, textarea")) {
      const name = el.getAttribute("name") || el.id;
      if (!name || el === pass) continue;
      const type = (el.getAttribute("type") || "text").toLowerCase();
      if (el.tagName === "SELECT") { const o = el.querySelector("option[selected]") || el.querySelector("option"); if (o) fields.push([name, o.getAttribute("value") ?? txt(o)]); continue; }
      if (type === "submit" || type === "button" || type === "image" || type === "reset" || type === "file") continue;
      if ((type === "checkbox" || type === "radio") && !el.hasAttribute("checked")) continue;
      if (!user && (type === "text" || type === "email") && /user|login|xrhst|onoma|name/i.test(name + " " + (el.id || ""))) { user = name; continue; }
      fields.push([name, el.getAttribute("value") || ""]);
    }
    if (!user) { const t = form.querySelector("input[type=text], input:not([type])"); if (t) { user = t.getAttribute("name") || t.id; const i = fields.findIndex((f) => f[0] === user); if (i >= 0) fields.splice(i, 1); } }
    // κουμπί σύνδεσης: submit με name, ή LinkButton (__doPostBack)
    let btn = null, evTarget = "";
    const sub = form.querySelector("input[type=submit][id*=ogin i], input[type=submit][name*=ogin i], input[type=submit], button[type=submit], input[type=image]");
    if (sub && sub.getAttribute("name")) btn = [sub.getAttribute("name"), sub.getAttribute("value") || ""];
    if (!btn) { const a = form.querySelector("a[href*='__doPostBack']"); const m = a && a.getAttribute("href").match(/__doPostBack\('([^']+)'/); if (m) evTarget = m[1]; }
    if (evTarget) { const i = fields.findIndex((f) => f[0] === "__EVENTTARGET"); if (i >= 0) fields[i][1] = evTarget; else fields.push(["__EVENTTARGET", evTarget]); }
    return { action: (form.getAttribute && form.getAttribute("action")) || "", user, pass: pass.getAttribute("name") || pass.id, btn, fields };
  }

  // Αντιστοίχιση ονόματος του Παραδόχαρτου με γραμμή του Medilabi (όλες οι λέξεις, από την αρχή τους). Μόνο αν είναι μοναδική.
  function matchName(name, list) {
    const toks = norm(name).split(/[\s,.;\-]+/).filter((t) => t.length >= 2);
    if (!toks.length) return { hits: 0 };
    const atWord = (s, w) => { for (let i = s.indexOf(w); i >= 0; i = s.indexOf(w, i + 1)) if (i === 0 || s[i - 1] === " ") return true; return false; };
    const hits = list.filter((p) => { const s = norm(p.name); return toks.every((t) => atWord(s, t)); });
    return { hits: hits.length, item: hits.length === 1 ? hits[0] : null };
  }

  g.Medilabi = { isLogin, parseWaiting, parseExams, parseResults, parseAll, parseLoginForm, matchName, norm };
})(typeof self !== "undefined" ? self : window);
