// Προεπιλεγμένη διαδικασία. Τα στοιχεία (target) ορίζονται με την «εκμάθηση».
// Τύποι βημάτων:
//   click  – κλικ σε κουμπί/σύνδεσμο. Αν το στοιχείο είναι λίστα (dropdown), επιλέγει την «Τιμή».
//   fill   – γράφει την «Τιμή» σε πεδίο κειμένου.
//   choose – επιλέγει από λίστα αποτελεσμάτων τη γραμμή που περιέχει την «Τιμή».
//   manual – παύση· ο χρήστης κάνει κάτι μόνος του και πατά «Συνέχεια».
//   wait   – αναμονή (ms στην «Τιμή»).
//   skipif – αν το στοιχείο (🎯) φαίνεται / έχει τιμή, παραλείπει τα επόμενα «count» βήματα.
//   goto   – άμεση μετάβαση σε διεύθυνση (http/https) με {μεταβλητές}.
// since: 2  → διαδικασία που προστέθηκε στην έκδοση 0.2 (προστίθεται αυτόματα σε όσους αναβαθμίζουν).
// hidden    → δεν εμφανίζεται στα κουμπιά της εφαρμογής (βοηθητική).
// Έτοιμος στόχος για τον φάκελο apps.e-ygeia.gov.gr (καταγράφηκε από το πραγματικό σύστημα, 30/10/2026).
// Ίδια μορφή με αυτό που αποθηκεύει η εκμάθηση 🎯. «within» = ψάξε μόνο μέσα σε αυτό το κομμάτι της σελίδας.
const EF_PATH = "/emr-ui/views/home.xhtml";
function EF_T(css, tag, o = {}) {
  return { css, tag, cls: o.cls || [], text: o.text || "", name: o.name || "", aria: "", placeholder: "", title: "",
           editable: !!o.editable, isSelect: !!o.isSelect, framePath: EF_PATH, ...(o.within ? { within: o.within } : {}), ...(o.unique ? { unique: true } : {}), ...(o.pages ? { pages: true } : {}), ...(o.search ? { search: o.search } : {}), ...(o.pfSelect ? { pfSelect: o.pfSelect } : {}), ...(o.clickSel ? { clickSel: o.clickSel, skipIfSel: o.skipIfSel } : {}), ...(o.expect ? { expect: o.expect } : {}), ...(o.upper ? { upper: true } : {}), ...(o.hidden ? { hidden: true } : {}), preset: true };
}

const DEFAULT_WORKFLOWS = [
  {
    id: "exitirio",
    name: "Εξιτήριο",
    pre: "Επιλέξτε πρώτα τον ασθενή στον φάκελο. Θεράπων: γράψτε το επώνυμο όπως στη λίστα «Εντελών Ιατρός». Διάγνωση: κωδικός ICD (π.χ. N40) ή λέξη από την περιγραφή. Στο τέλος ελέγξτε και πατήστε εσείς «Αποθήκευση».",
    steps: [
      { label: "Αν είστε ήδη στη φόρμα εξιτηρίου: παράλειψη πλοήγησης", type: "skipif", count: 2, target: EF_T("#appForm\\:doctorInput", "input", { name: "appForm:doctorInput", editable: true }) },
      // Κατευθείαν στο «Ιατρικό Εξιτήριο», χωρίς να ανοίξει το μενού «Ιατρικές Πράξεις» (ο σύνδεσμος πατιέται και κρυφός)
      { label: "Ιατρικό Εξιτήριο", type: "click", target: EF_T("#appForm\\:patientRightMenu a.ui-menuitem-link", "a", { cls: ["ui-menuitem-link"], text: "Ιατρικό Εξιτήριο", hidden: true }) },
      { label: "Προσθήκη (Έκδοση Εξιτηρίου)", type: "click", target: EF_T("#appForm\\:SkipValidationAddDischargeCenter", "button", { cls: ["ui-button"], name: "appForm:SkipValidationAddDischargeCenter", text: "Έκδοση Εξιτηρίου", expect: "#appForm\\:doctorInput" }) },
      { label: "Αν ο θεράπων είναι ήδη συμπληρωμένος: παράλειψη", type: "skipif", value: "*", count: 3, target: EF_T("#appForm\\:doctorInput", "input", { name: "appForm:doctorInput", editable: true }) },
      { label: "Θεράπων (Εντελών Ιατρός): γράψιμο ονόματος", type: "fill", value: "{θεράπων}", target: EF_T("#appForm\\:doctorInput", "input", { name: "appForm:doctorInput", editable: true, upper: true }) },
      { label: "Θεράπων: κουμπί αναζήτησης 🔍", type: "click", target: EF_T("#appForm\\:searchButtonDoctor", "button", { cls: ["ui-button"], name: "appForm:searchButtonDoctor" }) },
      { label: "Θεράπων: επιλογή από λίστα", type: "choose", value: "{θεράπων}", target: EF_T("", "tr", { cls: ["ui-widget-content"], within: "#appForm\\:doctorSearchResultModal", unique: true }) },
      // Οι λίστες Τύπος/Έκβαση (PrimeFaces): 1) άνοιγμα, 2) επιλογή γραμμής. Αν η τιμή είναι ήδη σωστή, παραλείπονται.
      { label: "Αν ο τύπος εξιτηρίου είναι ήδη Κανονικό: παράλειψη", type: "skipif", value: "Κανονικό", count: 1, target: EF_T("#appForm\\:dischargeType_drg", "div", { cls: ["ui-selectonemenu"] }) },
      { label: "Τύπος: «Κανονικό»", type: "choose", value: "Κανονικό", target: EF_T("", "li", { cls: ["ui-selectonemenu-item"], within: "#appForm\\:dischargeType_drg_panel", pfSelect: "appForm:dischargeType_drg" }) },
      { label: "Αν η έκβαση είναι ήδη επιλεγμένη: παράλειψη", type: "skipif", value: "{έκβαση}", count: 1, target: EF_T("#appForm\\:medicalOutcome_drg", "div", { cls: ["ui-selectonemenu"] }) },
      { label: "Έκβαση", type: "choose", value: "{έκβαση}", target: EF_T("", "li", { cls: ["ui-selectonemenu-item"], within: "#appForm\\:medicalOutcome_drg_panel", pfSelect: "appForm:medicalOutcome_drg" }) },
      { label: "Ημ/νία - ώρα Εξόδου: τώρα", type: "fill", value: "{ημερομηνία} {ώρα}", target: EF_T("#appForm\\:dischargeTimeInput_drg_input", "input", { name: "appForm:dischargeTimeInput_drg_input", editable: true }) },
      // Διάγνωση εισόδου (γραμμή «ΕΙΣΟΔΟΥ» στον πίνακα Διάγνωση ICD): τικ στο checkbox και «Κύρια» = Ναι
      { label: "Διάγνωση εισόδου: τικ στο checkbox", type: "choose", value: "ΕΙΣΟΔΟΥ", optional: true, optWait: 4, target: EF_T("", "tr", { cls: ["ui-widget-content"], within: "#appForm\\:diagnosis_table_drg", clickSel: ".ui-chkbox-box", skipIfSel: ".ui-state-active" }) },
      { label: "Διάγνωση εισόδου: Κύρια = Ναι", type: "choose", value: "ΕΙΣΟΔΟΥ", optional: true, optWait: 4, target: EF_T("", "tr", { cls: ["ui-widget-content"], within: "#appForm\\:diagnosis_table_drg", clickSel: ".ui-selectbooleanbutton", skipIfSel: ".ui-state-active" }) },
      // Κύρια διάγνωση: κουμπί → παράθυρο αναζήτησης ICD → επιλογή γραμμής → «Προσθήκη Διάγνωσης»
      { label: "Κύρια διάγνωση: «Προσθήκη Κύριας Διάγνωσης»", each: "κύρια_διάγνωση", type: "click", target: EF_T("#appForm\\:addDiagnBtn_drg_primary", "button", { cls: ["ui-button"], name: "appForm:addDiagnBtn_drg_primary", text: "Προσθήκη Κύριας Διάγνωσης" }) },
      { label: "Κύρια διάγνωση: πεδίο αναζήτησης ICD", each: "κύρια_διάγνωση", type: "fill", value: "{κύρια_διάγνωση}", target: EF_T("#appForm\\:diagnosisInput", "input", { name: "appForm:diagnosisInput", editable: true }) },
      { label: "Κύρια διάγνωση: κουμπί αναζήτησης 🔍", each: "κύρια_διάγνωση", type: "click", target: EF_T("#appForm\\:searchButtonDiagnosis", "button", { cls: ["ui-button"], name: "appForm:searchButtonDiagnosis" }) },
      { label: "Κύρια διάγνωση: επιλογή από λίστα", each: "κύρια_διάγνωση", type: "choose", value: "{κύρια_διάγνωση}", target: EF_T("", "tr", { cls: ["ui-widget-content"], within: "#appForm\\:diagnosisDrgSearchResultModal" }) },
      { label: "Κύρια διάγνωση: «Προσθήκη Διάγνωσης» στο παράθυρο", each: "κύρια_διάγνωση", type: "click", target: EF_T("#appForm\\:POPnewDiagnosisBtnDRG", "button", { cls: ["ui-button"], name: "appForm:POPnewDiagnosisBtnDRG", text: "Προσθήκη Διάγνωσης" }) },
      // Επιπλέον διαγνώσεις: επαναλαμβάνεται για κάθε γραμμή (αν το πεδίο μείνει κενό, παραλείπεται)
      { label: "Επιπλέον διάγνωση: «Προσθήκη Διάγνωσης»", type: "click", each: "επιπλέον_διαγνώσεις", target: EF_T("#appForm\\:addDiagnBtn_drg", "button", { cls: ["ui-button"], name: "appForm:addDiagnBtn_drg", text: "Προσθήκη Διάγνωσης" }) },
      { label: "Επιπλέον διάγνωση: πεδίο αναζήτησης ICD", type: "fill", value: "{επιπλέον_διαγνώσεις}", each: "επιπλέον_διαγνώσεις", target: EF_T("#appForm\\:diagnosisInput", "input", { name: "appForm:diagnosisInput", editable: true }) },
      { label: "Επιπλέον διάγνωση: κουμπί αναζήτησης 🔍", type: "click", each: "επιπλέον_διαγνώσεις", target: EF_T("#appForm\\:searchButtonDiagnosis", "button", { cls: ["ui-button"], name: "appForm:searchButtonDiagnosis" }) },
      { label: "Επιπλέον διάγνωση: επιλογή από λίστα", type: "choose", value: "{επιπλέον_διαγνώσεις}", each: "επιπλέον_διαγνώσεις", target: EF_T("", "tr", { cls: ["ui-widget-content"], within: "#appForm\\:diagnosisDrgSearchResultModal" }) },
      { label: "Επιπλέον διάγνωση: «Προσθήκη Διάγνωσης» στο παράθυρο", type: "click", each: "επιπλέον_διαγνώσεις", target: EF_T("#appForm\\:POPnewDiagnosisBtnDRG", "button", { cls: ["ui-button"], name: "appForm:POPnewDiagnosisBtnDRG", text: "Προσθήκη Διάγνωσης" }) },
      { label: "Ιατρική Γνωμάτευση: επικόλληση κειμένου", type: "fill", value: "{κείμενο_διάγνωσης}", target: EF_T("#appForm\\:medicalOpinionTxtInputDRG", "textarea", { name: "appForm:medicalOpinionTxtInputDRG", editable: true }) },
    ],
    optionalVars: ["κύρια_διάγνωση", "επιπλέον_διαγνώσεις", "κείμενο_διάγνωσης"],
    defaults: { "έκβαση": "Βελτίωση" },
    // Μεταβλητές που κρατιούνται για τον επόμενο ασθενή. Οι υπόλοιπες σβήνουν μετά από κάθε επιτυχή εκτέλεση.
    keep: ["θεράπων", "έκβαση"],
    preset: 4,
  },
  {
    id: "exetaseis",
    name: "Παραγγελία εξετάσεων",
    pre: "Επιλέξτε πρώτα τον ασθενή. Γράψτε τις εξετάσεις μία ανά γραμμή. Στο τέλος ελέγξτε και πατήστε εσείς «Αποθήκευση/Αποστολή».",
    steps: [
      { label: "Δεξιά στήλη: Παραγγελίες εξετάσεων", type: "click" },
      { label: "Νέα παραγγελία", type: "click" },
      // Τα επόμενα 3 βήματα επαναλαμβάνονται για κάθε γραμμή του πεδίου «εξετάσεις»
      { label: "Εξέταση: πεδίο αναζήτησης", type: "fill", value: "{εξετάσεις}", enter: true, each: "εξετάσεις" },
      { label: "Εξέταση: επιλογή από λίστα", type: "choose", value: "{εξετάσεις}", each: "εξετάσεις" },
      { label: "Εξέταση: κουμπί προσθήκης (αν υπάρχει)", type: "click", each: "εξετάσεις", optional: true },
      // Αν εμφανιστεί παράθυρο με προϋποθέσεις (checkbox), το bot σταματά και περιμένει τον χρήστη
      { label: "Προϋποθέσεις (αν εμφανιστούν): τσεκάρετε και πατήστε Συνέχεια", type: "manual", optional: true, each: "εξετάσεις" },
    ],
    defaults: {},
    keep: [],
  },
  {
    id: "ektimisi",
    name: "Κλήση για εκτίμηση",
    pre: "Επιλέξτε πρώτα τον ασθενή. Στο τέλος ελέγξτε και πατήστε εσείς «Αποθήκευση».",
    steps: [
      { label: "Κλήση για εκτίμηση", type: "click" },
      { label: "Προσθήκη", type: "click" },
      { label: "Ειδικότητα / κλινική (λίστα ή αναζήτηση)", type: "click", value: "{ειδικότητα}" },
      { label: "Ειδικότητα: επιλογή από λίστα (αν χρειάζεται)", type: "choose", value: "{ειδικότητα}", optional: true },
      { label: "Επείγον (αν χρειάζεται)", type: "click", disabled: true },
      { label: "Αιτιολογία / ερώτημα", type: "fill", value: "{αιτιολογία}" },
    ],
    defaults: {},
    keep: [],
  },
  {
    id: "barcode",
    name: "Barcode εξέτασης",
    pre: "Επιλέξτε πρώτα τον ασθενή. Γράψτε την εξέταση (ή μέρος του ονόματος) όπως φαίνεται στη λίστα παραγγελιών.",
    steps: [
      { label: "Δεξιά στήλη: Παραγγελίες εξετάσεων", type: "click" },
      { label: "Επιλογή παραγγελίας από λίστα", type: "choose", value: "{εξετάσεις}", each: "εξετάσεις" },
      { label: "Εκτύπωση barcode", type: "click", each: "εξετάσεις" },
      { label: "Παράθυρο εκτύπωσης: ΟΚ (αν εμφανιστεί)", type: "click", optional: true, each: "εξετάσεις" },
    ],
    defaults: {},
    keep: [],
  },
  {
    id: "xeirourgeio",
    name: "Στοιχεία → Excel χειρουργείου",
    pre: "Επιλέξτε τον ασθενή. Τα στοιχεία αντιγράφονται σε στήλες: πατήστε Ctrl+V στο πρώτο κελί της γραμμής στο Excel.",
    steps: [
      { label: "Ανάγνωση: Επώνυμο", type: "read", saveAs: "επώνυμο" },
      { label: "Ανάγνωση: Όνομα", type: "read", saveAs: "όνομα" },
      { label: "Ανάγνωση: Πατρώνυμο", type: "read", saveAs: "πατρώνυμο" },
      { label: "Ανάγνωση: ΑΜ", type: "read", saveAs: "αμ" },
      { label: "Αντιγραφή για Excel", type: "copy", value: "{επώνυμο}\\t{όνομα}\\t{πατρώνυμο}\\t{αμ}", collect: true },
    ],
    defaults: {},
    keep: [],
  },
  {
    id: "syntagi",
    name: "Συνταγή (ΗΔΙΚΑ)",
    pre: "Ανοίξτε σε άλλη καρτέλα τη συνταγογράφηση (συνδεδεμένοι). Επιλέξτε τον ασθενή στον φάκελο. Φάρμακα ένα ανά γραμμή: όνομα ; δοσολογία ; ημέρες. Την υποβολή την κάνετε ΕΣΕΙΣ.",
    steps: [
      { label: "Φάκελος: ανάγνωση ΑΜΚΑ", type: "read", saveAs: "αμκα" },
      { label: "Μετάβαση στην καρτέλα συνταγογράφησης", type: "tab", value: "syntagografisi" },
      { label: "Συνταγογράφηση: πεδίο ΑΜΚΑ", type: "fill", value: "{αμκα}", enter: true },
      { label: "Συνταγογράφηση: αναζήτηση ασθενή", type: "click", optional: true },
      { label: "Έλεγχος: ο ΑΜΚΑ στην οθόνη ταιριάζει", type: "check", value: "{αμκα}" },
      { label: "Νέα συνταγή", type: "click" },
      { label: "Φάρμακο: πεδίο αναζήτησης", type: "fill", value: "{φάρμακα.1}", enter: true, each: "φάρμακα" },
      { label: "Φάρμακο: επιλογή από λίστα", type: "choose", value: "{φάρμακα.1}", each: "φάρμακα" },
      { label: "Δοσολογία", type: "fill", value: "{φάρμακα.2}", each: "φάρμακα" },
      { label: "Ημέρες θεραπείας", type: "fill", value: "{φάρμακα.3}", each: "φάρμακα" },
      { label: "Προσθήκη φαρμάκου", type: "click", each: "φάρμακα" },
      { label: "Ελέγξτε τη συνταγή και υποβάλετε εσείς", type: "manual" },
    ],
    defaults: {},
    keep: [],
  },
  {
    id: "ergastiriaka",
    name: "Εργαστηριακά → φάκελος",
    pre: "Ανοίξτε σε άλλη καρτέλα την εφαρμογή εργαστηρίων. Επιλέξτε τον ασθενή στον φάκελο. Το bot ελέγχει ότι ταιριάζει το ΑΜ πριν γράψει.",
    steps: [
      { label: "Φάκελος: ανάγνωση ΑΜ ασθενή", type: "read", saveAs: "αμ" },
      { label: "Μετάβαση στην καρτέλα εργαστηρίων", type: "tab", value: "lab" },
      { label: "Εργαστήρια: πεδίο αναζήτησης ΑΜ", type: "fill", value: "{αμ}", enter: true },
      { label: "Εργαστήρια: αναζήτηση", type: "click", optional: true },
      { label: "Εργαστήρια: επιλογή ασθενή από λίστα", type: "choose", value: "{αμ}", optional: true },
      { label: "Έλεγχος: το ΑΜ στην οθόνη ταιριάζει", type: "check", value: "{αμ}" },
      { label: "Εργαστήρια: ανάγνωση πίνακα αποτελεσμάτων", type: "read", saveAs: "αποτελέσματα", filter: "{ποιες_εξετάσεις}" },
      { label: "Επιστροφή στον φάκελο", type: "tab", value: "αρχική" },
      { label: "Έλεγχος: ίδιος ασθενής στον φάκελο", type: "check", value: "{αμ}" },
      { label: "Φάκελος: καρτέλα εργαστηριακών/σημειώσεων", type: "click" },
      { label: "Φάκελος: Προσθήκη", type: "click", optional: true },
      { label: "Φάκελος: πεδίο κειμένου", type: "fill", value: "{ημερομηνία}\\n{αποτελέσματα}" },
    ],
    defaults: { "ποιες_εξετάσεις": "Hb, WBC, PLT, CRP, Cr, Ur, K, Na" },
    keep: ["ποιες_εξετάσεις"],
  },
  // ------------------------------------------------------------------ Έκδοση 0.2
  {
    id: "anoigma",
    since: 2,
    hidden: true,
    name: "Άνοιγμα ασθενή (για μαζική εκτέλεση)",
    pre: "Βοηθητική: την καλεί αυτόματα η «Μαζική εκτέλεση» και το πεδίο «Ασθενής» της καρτέλας Εκτέλεση. Βρίσκει τον ασθενή με το ΟΝΟΜΑ μέσω της «Αναζήτησης Ασθενών» (αριστερά) και ελέγχει ότι άνοιξε ο σωστός (γραμμή πάνω: Κωδικός / Όνομα / ΑΜΚΑ). Η λίστα πρέπει να φαίνεται στην οθόνη.",
    steps: [
      { label: "Μετάβαση απευθείας στον ασθενή (αν υπάρχει διεύθυνση ανά ΑΜ)", type: "goto", value: "", disabled: true },
      { label: "Λίστα ασθενών: επιλογή ασθενή", type: "choose", value: "{ασθενής.1}", target: EF_T("", "tr", { cls: ["ui-widget-content"], within: "#appForm\\:tabview\\:patientsTable", unique: true, pages: true,
        search: { field: "#appForm\\:tabview\\:surname", button: "#appForm\\:tabview\\:SkipValidationSearchPatientsBtn" } }) },
      { label: "Έλεγχος: άνοιξε ο σωστός ασθενής (γραμμή στοιχείων πάνω)", type: "check", value: "{ασθενής.1}", target: EF_T("#appForm\\:content > nav > ol", "ol", {}) },
    ],
    defaults: {},
    keep: [],
    preset: 4,
  },
  {
    id: "ergastiriaka_pinakas",
    since: 2,
    name: "Εργαστηριακά → πίνακας Excel (μαζικά)",
    pre: "Για τη «Μαζική εκτέλεση»: για κάθε ασθενή της λίστας διαβάζει τις εξετάσεις από την εφαρμογή εργαστηρίων και τις προσθέτει ως γραμμή σε πίνακα (μία στήλη ανά εξέταση). Στο τέλος πατάτε «Αντιγραφή όλων» και Ctrl+V στο Excel. Δεν γράφει τίποτα στον φάκελο.",
    steps: [
      { label: "Φάκελος: ανάγνωση ΑΜ ασθενή", type: "read", saveAs: "αμ" },
      { label: "Μετάβαση στην καρτέλα εργαστηρίων", type: "tab", value: "lab" },
      { label: "Εργαστήρια: πεδίο αναζήτησης ΑΜ", type: "fill", value: "{αμ}", enter: true },
      { label: "Εργαστήρια: αναζήτηση", type: "click", optional: true },
      { label: "Εργαστήρια: επιλογή ασθενή από λίστα", type: "choose", value: "{αμ}", optional: true },
      { label: "Έλεγχος: το ΑΜ στην οθόνη ταιριάζει", type: "check", value: "{αμ}" },
      { label: "Εργαστήρια: ανάγνωση πίνακα αποτελεσμάτων", type: "read", saveAs: "αποτελέσματα", filter: "{ποιες_εξετάσεις}" },
      { label: "Επιστροφή στον φάκελο", type: "tab", value: "αρχική" },
      { label: "Έλεγχος: ίδιος ασθενής στον φάκελο", type: "check", value: "{αμ}" },
      { label: "Προσθήκη γραμμής στον πίνακα", type: "copy", value: "{ημερομηνία}\\t{αμ}\\t{αποτελέσματα_στήλες}", collect: true },
    ],
    collectHeader: "Ημερομηνία\\tΑΜ\\t{ποιες_εξετάσεις_στήλες}",
    defaults: { "ποιες_εξετάσεις": "Hb, WBC, PLT, CRP, Cr, Ur, K, Na" },
    keep: ["ποιες_εξετάσεις"],
  },
  {
    id: "elegxos_ergastirion",
    since: 2,
    hidden: true,
    name: "Έλεγχος νέων εργαστηριακών (παρακολούθηση)",
    pre: "Βοηθητική: την τρέχει η «Παρακολούθηση» μέσα στην καρτέλα εργαστηρίων, χωρίς να αλλάζει καρτέλα. Η ανάγνωση πρέπει να αποθηκεύει ως «αποτελέσματα».",
    steps: [
      { label: "Μετάβαση απευθείας στον ασθενή (αν υπάρχει διεύθυνση ανά ΑΜ)", type: "goto", value: "", disabled: true },
      { label: "Εργαστήρια: πεδίο αναζήτησης ΑΜ", type: "fill", value: "{ασθενής.1}", enter: true },
      { label: "Εργαστήρια: αναζήτηση", type: "click", optional: true },
      { label: "Εργαστήρια: επιλογή ασθενή από λίστα", type: "choose", value: "{ασθενής.1}", optional: true },
      { label: "Έλεγχος: το ΑΜ στην οθόνη ταιριάζει", type: "check", value: "{ασθενής.1}" },
      { label: "Εργαστήρια: ανάγνωση πίνακα αποτελεσμάτων", type: "read", saveAs: "αποτελέσματα", filter: "{ποιες_εξετάσεις}" },
    ],
    defaults: {},
    keep: [],
  },
  // ------------------------------------------------------------------ Έκδοση 0.11
  // Αυτόματες συννοσηρότητες: για κάθε νέο ασθενή του Παραδόχαρτου, ΑΜΚΑ από τον φάκελο → διαγνώσεις από τον ΑΗΦΥ
  {
    id: "fakelos_amka",
    since: 12,
    hidden: true,
    name: "Φάκελος: ανάγνωση ΑΜΚΑ (για τις αυτόματες συννοσηρότητες)",
    pre: "Βοηθητική: την τρέχουν οι «αυτόματες συννοσηρότητες». Το bot ανοίγει πρώτα τον ασθενή με το όνομα (όπως στο εξιτήριο). Εκμάθηση μία φορά: ανοίξτε έναν ασθενή στον φάκελο, πατήστε 🎯 στο σημείο όπου φαίνεται ο ΑΜΚΑ και ▶. Αρκεί το στοιχείο να περιέχει τον ΑΜΚΑ (11 ψηφία), ακόμα κι αν έχει και άλλο κείμενο.",
    steps: [
      { label: "Φάκελος: ανάγνωση ΑΜΚΑ", type: "read", saveAs: "αμκα" },
    ],
    defaults: {},
    keep: [],
  },
  {
    id: "aihfy_dx",
    since: 12,
    hidden: true,
    name: "ΑΗΦΥ: διαγνώσεις με ΑΜΚΑ (για τις αυτόματες συννοσηρότητες)",
    pre: "Βοηθητική: τρέχει στο doctor.ehealthrecord.gov.gr. Βρίσκει τον ασθενή με τον ΑΜΚΑ, διαλέγει τον λόγο πρόσβασης, ελέγχει ότι άνοιξε ο σωστός ΑΜΚΑ και πηγαίνει στις διαγνώσεις. Τους κωδικούς τους μαζεύει μετά το bot από τη σελίδα. Εκμάθηση μία φορά: στην Εκτέλεση γράψτε έναν ΑΜΚΑ ασθενή σας και τον «Λόγο πρόσβασης» όπως είναι γραμμένος δίπλα στην επιλογή (αρκεί κομμάτι του, π.χ. «Νοσηλεία»). Πεδίο ΑΜΚΑ, κουμπί αναζήτησης, Έλεγχος ΑΜΚΑ και μενού «Διαγνώσεις» έρχονται έτοιμα (καταγράφηκαν από το πραγματικό σύστημα). 🎯 θέλει μόνο το «κουμπί επιβεβαίωσης λόγου», την πρώτη φορά που θα εμφανιστεί η σελίδα του λόγου. Ο λόγος δεν θέλει 🎯: το bot βρίσκει μόνο του την επιλογή με το κείμενο και, αν δεν ζητηθεί λόγος (πρόσβαση τις τελευταίες 24 ώρες), την παραλείπει. Το βήμα «Έλεγχος» είναι υποχρεωτικό: χωρίς αυτό η αυτόματη αναζήτηση δεν ξεκινά.",
    steps: [
      { label: "ΑΗΦΥ: μετάβαση στην αρχική / αναζήτηση ασθενή", type: "goto", value: "https://doctor.ehealthrecord.gov.gr/doctor/app/" },
      { label: "ΑΗΦΥ: πεδίο ΑΜΚΑ", type: "fill", value: "{αμκα}" },
      { label: "ΑΗΦΥ: κουμπί αναζήτησης (μετά τον ΑΜΚΑ)", type: "click" },
      // Λόγος πρόσβασης: επιλογή με το κείμενο. Αν δεν ζητηθεί (πρόσβαση τις τελευταίες 24 ώρες), παραλείπεται μαζί με την επιβεβαίωση
      { label: "ΑΗΦΥ: λόγος πρόσβασης (μόνο αν τον ζητήσει)", type: "choose", value: "{λόγος_πρόσβασης}", optional: true, optWait: 8, missSkip: 1,
        target: { radio: true, css: "", tag: "div", cls: [], text: "", name: "", aria: "", placeholder: "", title: "", editable: false, isSelect: false, framePath: "", preset: true } },
      { label: "ΑΗΦΥ: επιβεβαίωση λόγου (κουμπί)", type: "click", optional: true, optWait: 4 },
      { label: "ΑΗΦΥ: Έλεγχος: ο ΑΜΚΑ στην οθόνη ταιριάζει", type: "check", value: "{αμκα}" },
      { label: "ΑΗΦΥ: μενού «Διαγνώσεις»", type: "click" },
      { label: "ΑΗΦΥ: ή μετάβαση με διεύθυνση στις διαγνώσεις", type: "goto", value: "https://doctor.ehealthrecord.gov.gr/doctor/app/clinical/diagnosis", disabled: true },
      { label: "ΑΗΦΥ: αναμονή φόρτωσης διαγνώσεων", type: "wait", value: "1500" },
    ],
    defaults: { "λόγος_πρόσβασης": "Θεράπων ιατρός" },
    keep: ["λόγος_πρόσβασης"],
    patched13: true, // οι έτοιμοι στόχοι μπαίνουν από το engine.patchWorkflows (patched13b)
  },
  // ------------------------------------------------------------------ Έκδοση 0.10
  {
    id: "istoriko_synn",
    since: 11,
    name: "Συννοσηρότητες → Ατομικό ιστορικό",
    pre: "Περνά τις συννοσηρότητες (κωδικοί ICD-10, ένας ανά γραμμή) στην οθόνη ιστορικού του ασθενή. Συνήθως έρχονται έτοιμες από το Παραδόχαρτο (🩺 Συννοσηρότητες → «Ατομικό ιστορικό»). Εκμάθηση μία φορά: ανοίξτε έναν ασθενή, γράψτε στο πεδίο έναν δοκιμαστικό κωδικό (π.χ. I10) και μάθετε κάθε βήμα με 🎯 και ▶. Αν η οθόνη έχει ελεύθερο κείμενο αντί για αναζήτηση ICD, απενεργοποιήστε τα βήματα 2–6 και ενεργοποιήστε το τελευταίο. Την Αποθήκευση την πατάτε εσείς.",
    steps: [
      { label: "Ιστορικό: άνοιγμα οθόνης (από το μενού του ασθενή)", type: "click" },
      { label: "Ιστορικό: «Προσθήκη» νόσου/διάγνωσης", type: "click", each: "συννοσηρότητες" },
      { label: "Ιστορικό: πεδίο αναζήτησης ICD", type: "fill", value: "{συννοσηρότητες}", each: "συννοσηρότητες" },
      { label: "Ιστορικό: κουμπί αναζήτησης 🔍", type: "click", each: "συννοσηρότητες" },
      // Κωδικός που δεν υπάρχει στη λίστα: παραλείπεται (δεν πατιέται «Προσθήκη») και αναφέρεται στο τέλος
      { label: "Ιστορικό: επιλογή κωδικού από τη λίστα", type: "choose", value: "{συννοσηρότητες}", each: "συννοσηρότητες", optional: true, optWait: 10, missSkip: 1 },
      { label: "Ιστορικό: «Προσθήκη»/«ΟΚ» στο παράθυρο", type: "click", each: "συννοσηρότητες" },
      { label: "Ιστορικό: κλείσιμο παραθύρου αν έμεινε ανοιχτό (🎯 στο ✕)", type: "click", each: "συννοσηρότητες", optional: true, optWait: 1, disabled: true },
      { label: "Ιστορικό: ή επικόλληση ως κείμενο (αν η οθόνη έχει ελεύθερο κείμενο)", type: "fill", value: "{συννοσηρότητες_κείμενο}", disabled: true },
    ],
    optionalVars: ["συννοσηρότητες_κείμενο"],
    defaults: {},
    keep: [],
  },
];
