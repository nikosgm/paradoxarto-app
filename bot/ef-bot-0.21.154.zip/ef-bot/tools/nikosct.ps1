﻿# Νίκος CT Viewer — «Άνοιγμα με…» από το δεξί κλικ σε φάκελο/CD (7/11/2026)
# Μαζεύει τα DICOM του φακέλου σε ΕΝΑ προσωρινό αρχείο .nct (στο %TEMP%) και το ανοίγει με την εγκατεστημένη εφαρμογή.
# Δεν αλλάζει/σβήνει τίποτα στον φάκελο. Τα προσωρινά .nct σβήνονται μετά από 12 ώρες.
param([string]$Dir)
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Windows.Forms
function Msg($t) { [void][System.Windows.Forms.MessageBox]::Show($t, "Νίκος CT Viewer") }
$LogF = Join-Path $env:LOCALAPPDATA "ef-bot\nikosct\log.txt"
function L($t) { try { Add-Content -LiteralPath $LogF -Value ("[" + (Get-Date -Format "dd/MM HH:mm:ss") + "] " + $t) -Encoding UTF8 } catch {} }
# μικρό παράθυρο προόδου (για μεγάλους φακέλους από το δίκτυο)
$F = $null; $PB = $null; $LB = $null; $Cancel = $false
function ShowProg($n) { try {
  $script:F = New-Object System.Windows.Forms.Form; $F.Text = "Νίκος CT Viewer"; $F.Width = 420; $F.Height = 140; $F.StartPosition = "CenterScreen"; $F.TopMost = $true; $F.FormBorderStyle = "FixedDialog"; $F.MaximizeBox = $false; $F.MinimizeBox = $false
  $script:LB = New-Object System.Windows.Forms.Label; $LB.Left = 14; $LB.Top = 12; $LB.Width = 380; $LB.Text = "Ανοίγω " + $n + " εικόνες…"; $F.Controls.Add($LB)
  $script:PB = New-Object System.Windows.Forms.ProgressBar; $PB.Left = 14; $PB.Top = 40; $PB.Width = 380; $PB.Maximum = [Math]::Max(1, $n); $F.Controls.Add($PB)
  $F.Add_FormClosing({ $script:Cancel = $true }); $F.Show(); [System.Windows.Forms.Application]::DoEvents() } catch {} }
function Prog($i, $n) { try { if ($PB) { $PB.Value = [Math]::Min($PB.Maximum, $i); $LB.Text = "Ανοίγω τις εικόνες… " + $i + " / " + $n; [System.Windows.Forms.Application]::DoEvents() } } catch {} }
try {
  L ("άνοιγμα: " + $Dir)
  $Dir = $Dir.TrimEnd('"'); if ($Dir.EndsWith('\.')) { $Dir = $Dir.Substring(0, $Dir.Length - 1) }
  if (-not (Test-Path -LiteralPath $Dir)) { Msg ("Δεν βρέθηκε ο φάκελος: " + $Dir); exit 1 }
  # η εγκατεστημένη εφαρμογή (συντόμευση του Chrome στο μενού Έναρξη)
  $roots = @("$env:APPDATA\Microsoft\Windows\Start Menu\Programs", "$env:USERPROFILE\Desktop")
  $lnk = $null; foreach ($r in $roots) { if (-not $lnk -and (Test-Path $r)) { $lnk = Get-ChildItem -LiteralPath $r -Recurse -Filter "*.lnk" -ErrorAction SilentlyContinue | Where-Object { $_.BaseName -match 'Νίκος CT|Nikos CT|Αξονικές' } | Select-Object -First 1 } }
  L ("συντόμευση: " + $(if ($lnk) { $lnk.FullName } else { "—" }))
  if (-not $lnk) { Start-Process "https://paradoxarto.urol.workers.dev/ct?install=1"; Msg "Πρώτα εγκαταστήστε το «Νίκος CT Viewer» (άνοιξε η σελίδα στο Chrome → «💻 Εγκατάσταση»). Μετά ξαναδοκιμάστε το δεξί κλικ."; exit 0 }
  $sc = (New-Object -ComObject WScript.Shell).CreateShortcut($lnk.FullName)
  if ($sc.Arguments -notmatch '--app-id=') { Msg "Η συντόμευση της εφαρμογής δεν είναι του Chrome."; exit 1 }
  $tmp = Join-Path $env:TEMP "nikosct"; New-Item -ItemType Directory -Force -Path $tmp | Out-Null
  Get-ChildItem -LiteralPath $tmp -Filter *.nct -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt (Get-Date).AddHours(-12) } | Remove-Item -Force -ErrorAction SilentlyContinue
  $skip = '\.(jpe?g|png|gif|bmp|txt|html?|xml|pdf|exe|ini|inf|dll|ico|js|css|json|zip|rar|7z|lnk|db|log|mp4|avi|docx?|xlsx?|bat|cmd|sys|cab|msi|url|nct)$'
  $files = @(Get-ChildItem -LiteralPath $Dir -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Length -gt 128 -and $_.Name -notmatch $skip -and $_.Name -notmatch '^(dicomdir|thumbs\.db|desktop\.ini|autorun\.inf)$' })
  if (-not $files.Count) { Msg "Δεν βρέθηκαν εικόνες σε αυτόν τον φάκελο."; exit 0 }
  $base = (Get-Item -LiteralPath $Dir).FullName.TrimEnd('\')
  $name = ((Split-Path $base -Leaf) -replace '[^\w\-]', '_'); if (-not $name) { $name = "CD" }
  $out = Join-Path $tmp ($name + "-" + (Get-Date -Format yyyyMMdd-HHmmss) + ".nct")
  # σειρά-σειρά: ταξινόμηση ανά υποφάκελο (στα CD κάθε σειρά είναι συνήθως σε δικό της φάκελο) και όνομα αρχείου
  $files = @($files | Sort-Object DirectoryName, @{ e = { [regex]::Replace($_.Name, '\d+', { param($m) $m.Value.PadLeft(10, '0') }) } })
  # 7/11: ΡΟΗ (NCT2) — η εφαρμογή ανοίγει ΑΜΕΣΩΣ και διαβάζει όσο γράφεται το αρχείο
  $fs = New-Object IO.FileStream($out, [IO.FileMode]::Create, [IO.FileAccess]::Write, [IO.FileShare]::ReadWrite)
  $bw = New-Object IO.BinaryWriter($fs)
  $bw.Write([byte[]](0x4E,0x43,0x54,0x32)); $bw.Write([int]-1); $bw.Flush(); $fs.Flush()
  L ("εκκίνηση: " + $sc.TargetPath + " " + $sc.Arguments + " · " + $files.Count + " αρχεία → " + $out)
  Start-Process -FilePath $sc.TargetPath -ArgumentList ($sc.Arguments + ' "' + $out + '"')
  # παράλληλη ανάγνωση (12 αρχεία μαζί από το δίκτυο/CD), εγγραφή με τη σειρά
  $B = 12
  for ($i = 0; $i -lt $files.Count; $i += $B) {
    $batch = @($files[$i..([Math]::Min($files.Count, $i + $B) - 1)])
    $jobs = @(); foreach ($f in $batch) { try { $st = New-Object IO.FileStream($f.FullName, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite, 65536, $true); $buf = New-Object byte[] ($f.Length); $jobs += ,@($f, $st, $buf, $st.ReadAsync($buf, 0, $buf.Length)) } catch { L ("ανάγνωση: " + $f.Name + " " + $_.Exception.Message) } }
    foreach ($j in $jobs) {
      $f = $j[0]; $st = $j[1]; $buf = $j[2]
      try { $n = $j[3].GetAwaiter().GetResult(); while ($n -lt $buf.Length) { $k = $st.Read($buf, $n, $buf.Length - $n); if ($k -le 0) { break }; $n += $k } } catch { $n = -1 } finally { $st.Close() }
      if ($n -ne $buf.Length) { continue }
      $rel = $f.FullName.Substring([Math]::Min($f.FullName.Length, $base.Length)).TrimStart('\')
      $nb = [Text.Encoding]::UTF8.GetBytes($rel); $bw.Write([int]$nb.Length); $bw.Write($nb); $bw.Write([long]$buf.Length); $bw.Write($buf)
    }
    $bw.Flush(); $fs.Flush()
  }
  $bw.Write([int]0); $bw.Flush(); $fs.Close()
  L ("τέλος: " + $files.Count + " αρχεία")
} catch { L ("ΣΦΑΛΜΑ: " + $_.Exception.Message); Msg ("Σφάλμα: " + $_.Exception.Message) }
