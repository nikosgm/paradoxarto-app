﻿# ef-bot: 🩻 ανάγνωση φακέλου απεικονιστικών (Chrome native messaging host "gr.efbot.files")
# ΜΟΝΟ ΑΝΑΓΝΩΣΗ και ΜΟΝΟ μέσα στις σταθερές ρίζες: C:\OUROLOGIKI_KLINIKH και όσες γραμμές έχει το τοπικό roots.txt
# δίπλα σε αυτό το αρχείο. Οι ρίζες δεν ορίζονται ποτέ από μήνυμα. Τίποτα δεν γράφεται, μετακινείται ή σβήνεται.
# Ξεχωριστό από το βοηθητικό κωδικών (gr.efbot.vault): ό,τι κι αν συμβεί εδώ, οι κωδικοί δεν επηρεάζονται.
# Πρωτόκολλο Chrome: 4 bytes μήκος (little-endian) + JSON UTF-8. Εξυπηρετεί αιτήματα μέχρι να κλείσει το stdin.
$ErrorActionPreference = "Stop"
$stdin  = [Console]::OpenStandardInput()
$stdout = [Console]::OpenStandardOutput()
function ReadN([int]$n) {
  $b = New-Object byte[] $n; $o = 0
  while ($o -lt $n) { $r = $stdin.Read($b, $o, $n - $o); if ($r -le 0) { exit 0 }; $o += $r }
  return ,$b
}
function Reply($obj) {
  $j = [Text.Encoding]::UTF8.GetBytes(($obj | ConvertTo-Json -Compress -Depth 6))
  $stdout.Write([BitConverter]::GetBytes([int]$j.Length), 0, 4)
  $stdout.Write($j, 0, $j.Length)
  $stdout.Flush()
}
# Ρίζες (ΜΟΝΟ φάκελοι με όνομα που περιέχει OUROLOGIK / ΟΥΡΟΛΟΓΙΚ, ή γραμμές του τοπικού roots.txt):
#  βάσεις αναζήτησης = ρίζες τοπικών δίσκων + δίσκοι/κοινόχρηστοι δικτύου που γνωρίζει ΑΥΤΟΣ ο χρήστης των Windows
#  (αντιστοιχισμένοι δίσκοι, ακόμα και αποσυνδεδεμένοι — HKCU\Network, «net use», κοινόχρηστοι που ανοίχτηκαν από την
#  Εξερεύνηση — MountPoints2, συντομεύσεις στην Επιφάνεια εργασίας / «Θέση δικτύου»). Σε κάθε βάση: η ίδια ή υποφάκελοι
#  έως 2 επίπεδα. Διαβάζονται ΜΟΝΟ ονόματα φακέλων για τον εντοπισμό· τα αρχεία μόνο μέσα στη ρίζα που βρέθηκε.
$script:RootsCache = $null; $script:Bases = @()
$NameRx = '(?i)(OUROLOGIK.{0,3}KLINIK|ΟΥΡΟΛΟΓΙΚ.{0,3}ΚΛΙΝΙΚ)'
function UncBases {
  $u = @()
  try { foreach ($k in Get-ChildItem -Path "HKCU:\Network" -ErrorAction SilentlyContinue) { $rp = (Get-ItemProperty -Path $k.PSPath -ErrorAction SilentlyContinue).RemotePath; if ($rp) { $u += [string]$rp } } } catch {}
  try { foreach ($l in (& net use 2>$null)) { $m = [regex]::Match([string]$l, '(\\\\[^\s]+)'); if ($m.Success) { $u += $m.Groups[1].Value } } } catch {}
  try { foreach ($k in Get-ChildItem -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\MountPoints2" -ErrorAction SilentlyContinue) { $n = [string]$k.PSChildName; if ($n.StartsWith("##")) { $u += ("\\" + $n.Substring(2).Replace('#', '\')) } } } catch {}
  try {
    $dirs = @([Environment]::GetFolderPath("Desktop"), [Environment]::GetFolderPath("CommonDesktopDirectory"), (Join-Path $env:APPDATA "Microsoft\Windows\Network Shortcuts"))
    $sh = New-Object -ComObject WScript.Shell
    foreach ($d in $dirs) {
      if (-not $d -or -not [IO.Directory]::Exists($d)) { continue }
      foreach ($f in [IO.Directory]::GetFiles($d, "*.lnk")) { try { $t = [string]$sh.CreateShortcut($f).TargetPath; if ($t.StartsWith("\\") -or $t -match '^[A-Za-z]:\\') { $u += $t } } catch {} }
      foreach ($sd in [IO.Directory]::GetDirectories($d)) { $tl = Join-Path $sd "target.lnk"; if ([IO.File]::Exists($tl)) { try { $t = [string]$sh.CreateShortcut($tl).TargetPath; if ($t) { $u += $t } } catch {} } }
    }
  } catch {}
  # Γρήγορη πρόσβαση της Εξερεύνησης (καρφιτσωμένοι / συχνοί φάκελοι — συχνά εκεί είναι ο φάκελος του δικτύου)
  try {
    $shA = New-Object -ComObject Shell.Application
    $qa = $shA.Namespace('shell:::{679f85cb-0220-4080-b29b-5540cc05aab6}')
    if ($qa) { foreach ($it in @($qa.Items())) { try { $pth = [string]$it.Path; if ($pth -and ($pth.StartsWith("\\") -or $pth -match '^[A-Za-z]:\\')) { $u += $pth } } catch {} } }
  } catch {}
  $out = @()
  foreach ($x in $u) {
    $x = $x.Trim().TrimEnd('\'); if (-not $x) { continue }
    if ($x.StartsWith("\\")) { $parts = $x.Substring(2).Split('\'); if ($parts.Count -ge 2) { $share = "\\" + $parts[0] + "\" + $parts[1]; if (-not ($out -contains $share)) { $out += $share } } }
    if (-not ($out -contains $x)) { $out += $x }
  }
  return ,$out
}
function Roots {
  if ($null -ne $script:RootsCache) { return ,$script:RootsCache }
  $list = @()
  $rf = Join-Path $PSScriptRoot "roots.txt"
  if (Test-Path -LiteralPath $rf) { foreach ($l in [IO.File]::ReadAllLines($rf)) { $t = $l.Trim(); if ($t -and -not $t.StartsWith("#")) { $list += $t } } }
  $bases = @()
  try { foreach ($dr in [IO.DriveInfo]::GetDrives()) { if ($dr.DriveType -eq [IO.DriveType]::Fixed -or $dr.DriveType -eq [IO.DriveType]::Network) { $bases += $dr.RootDirectory.FullName.TrimEnd('\') } } } catch {}
  $bases += (UncBases)
  $script:Bases = $bases
  foreach ($b in $bases) {
    try {
      if (-not [IO.Directory]::Exists($b)) { continue }
      if ([IO.Path]::GetFileName($b) -match $NameRx) { $list += $b; continue }
      $lv1 = @(); try { $lv1 = [IO.Directory]::GetDirectories($b) } catch { $lv1 = @() }
      foreach ($s in $lv1) {
        if ([IO.Path]::GetFileName($s) -match $NameRx) { $list += $s; continue }
        $lv2 = @(); try { $lv2 = [IO.Directory]::GetDirectories($s) } catch { $lv2 = @() }
        foreach ($s2 in $lv2) { if ([IO.Path]::GetFileName($s2) -match $NameRx) { $list += $s2 } }
      }
    } catch {}
  }
  $out = @()
  foreach ($r in $list) { try { $f = [IO.Path]::GetFullPath($r).TrimEnd('\'); if ([IO.Directory]::Exists($f) -and -not ($out -contains $f)) { $out += $f } } catch {} }
  # ρίζα μέσα σε άλλη ρίζα → περιττή (θα διαβαζόταν δύο φορές)
  $out = @($out | Where-Object { $r = $_; -not ($out | Where-Object { $_ -ne $r -and $r.StartsWith($_ + '\', [StringComparison]::OrdinalIgnoreCase) }) })
  if ($out.Count -gt 0) { $script:RootsCache = $out }  # κενό αποτέλεσμα δεν κρατιέται: ξαναψάχνει στο επόμενο αίτημα
  return ,$out
}
# σχετική διαδρομή → πλήρης, ΜΟΝΟ αν μένει μέσα στη ρίζα #ri (χωρίς "..", χωρίς άλλο δίσκο)
function Inside([int]$ri, [string]$rel) {
  $roots = Roots
  if ($ri -lt 0 -or $ri -ge $roots.Count) { throw "άγνωστος φάκελος" }
  $root = $roots[$ri]
  $rel = ([string]$rel).Replace('/', '\').TrimStart('\')
  if ($rel -match '(^|\\)\.\.(\\|$)' -or $rel -match ':') { throw "μη επιτρεπτή διαδρομή" }
  $full = [IO.Path]::GetFullPath((Join-Path $root $rel)).TrimEnd('\')
  if (-not ($full -eq $root -or $full.StartsWith($root + '\', [StringComparison]::OrdinalIgnoreCase))) { throw "εκτός φακέλου κλινικής" }
  return $full
}
function RelOf([string]$root, [string]$full) { if ($full.Length -le $root.Length) { return "" }; return $full.Substring($root.Length + 1) }
function Ms($dt) { return [long](($dt - [DateTime]'1970-01-01').TotalMilliseconds) }


# 📁 «Αρχεία κλινικής»: σκελετός ονόματος (ίδιος με τον viewer/bot: ελληνικά ↔ λατινικά, τόνοι, διπλά γράμματα)
$GR2 = @(@('ου','u'),@('αι','e'),@('ει','i'),@('οι','i'),@('υι','i'),@('αυ','av'),@('ευ','ev'),@('μπ','b'),@('ντ','d'),@('γκ','g'),@('γγ','g'),@('τσ','ts'),@('τζ','tz'))
$GR1 = @{ 'α'='a';'β'='v';'γ'='g';'δ'='d';'ε'='e';'ζ'='z';'η'='i';'θ'='th';'ι'='i';'κ'='k';'λ'='l';'μ'='m';'ν'='n';'ξ'='x';'ο'='o';'π'='p';'ρ'='r';'σ'='s';'τ'='t';'υ'='i';'φ'='f';'χ'='ch';'ψ'='ps';'ω'='o' }
function Skel([string]$s) {
  $d = $s.Normalize([Text.NormalizationForm]::FormD); $sb = New-Object Text.StringBuilder
  foreach ($ch in $d.ToCharArray()) { if ([Globalization.CharUnicodeInfo]::GetUnicodeCategory($ch) -ne [Globalization.UnicodeCategory]::NonSpacingMark) { [void]$sb.Append($ch) } }
  $x = $sb.ToString().ToLowerInvariant() -creplace '[^a-zα-ως]+', ' '
  $x = $x.Replace('ς', 'σ')
  foreach ($pr in $GR2) { $x = $x.Replace($pr[0], $pr[1]) }
  $sb = New-Object Text.StringBuilder
  foreach ($ch in $x.ToCharArray()) { $c = [string]$ch; if ($GR1.ContainsKey($c)) { [void]$sb.Append($GR1[$c]) } else { [void]$sb.Append($c) } }
  $x = $sb.ToString()
  $x = $x.Replace('ou','u') -creplace 'kh|ch','h' -creplace 'th','t' -creplace 'ph','f' -creplace 'ks','x' -creplace 'c','k' -creplace '[yj]','i' -creplace 'w','v' -creplace 'b','v' -creplace 'ee|ie|ei|oi','i' -creplace 'oo','u' -creplace 'ai','e' -creplace 'dh','d'
  return ($x -creplace '(.)\1+', '$1').Trim()
}
$DocRx = '(?i)\.(pdf|docx?|xlsx?|pptx?|rtf|txt|jpe?g|png|heic|gif|bmp|tiff?|mp4|mov|zip)$'
$script:Idx = $null; $script:IdxAt = [DateTime]::MinValue; $script:IdxTrunc = $false
# ευρετήριο: φάκελοι + «έγγραφα» (όχι τα χιλιάδες DICOM), βάθος ≤10, όριο χρόνου 60″ — κρατιέται 15′
function BuildIdx {
  $roots = Roots; $L = New-Object System.Collections.ArrayList; $sw = [Diagnostics.Stopwatch]::StartNew(); $script:IdxTrunc = $false
  for ($ri = 0; $ri -lt $roots.Count; $ri++) {
    $root = $roots[$ri]; $st = New-Object System.Collections.Stack; $st.Push(@($root, 0))
    while ($st.Count -gt 0) {
      if ($sw.Elapsed.TotalSeconds -gt 60 -or $L.Count -gt 150000) { $script:IdxTrunc = $true; break }
      $it = $st.Pop(); $d = [string]$it[0]; $dep = [int]$it[1]
      $sd = @(); try { $sd = [IO.Directory]::GetDirectories($d) } catch {}
      foreach ($s in $sd) { $n = [IO.Path]::GetFileName($s); [void]$L.Add(@($ri, (RelOf $root $s), 1, 0, $s, (Skel $n).Replace(' ',''), $n.ToLowerInvariant())); if ($dep -lt 10) { $st.Push(@($s, ($dep + 1))) } }
      $fl = @(); try { $fl = [IO.Directory]::GetFiles($d) } catch {}
      foreach ($f in $fl) { $n = [IO.Path]::GetFileName($f); if ($n -match $DocRx) { [void]$L.Add(@($ri, (RelOf $root $f), 0, 0, $f, (Skel ([IO.Path]::GetFileNameWithoutExtension($n))).Replace(' ',''), $n.ToLowerInvariant())) } }
    }
  }
  $script:Idx = $L; $script:IdxAt = Get-Date
}
function Item([int]$ri, [string]$rel, [string]$full, [bool]$dir) {
  $o = @{ ri = $ri; rel = $rel; name = [IO.Path]::GetFileName($full); dir = $dir; t = 0; size = 0 }
  try { if ($dir) { $o.t = Ms ([IO.Directory]::GetLastWriteTimeUtc($full)) } else { $fi = New-Object IO.FileInfo $full; $o.size = $fi.Length; $o.t = Ms $fi.LastWriteTimeUtc } } catch {}
  return $o
}


# ⚡ ευρετήριο σε C# (μεταγλωττίζεται μία φορά, χτίζεται στο παρασκήνιο από το πρώτο ping, κρατιέται 30′) — εφεδρεία: BuildIdx σε PowerShell
$EfCs = @'
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
public class EfIdx {
  public class E { public int Ri; public string Rel; public bool Dir; public string Sk; public long Size; public long T; public string Name; }
  static readonly object L = new object();
  static List<E> live = new List<E>();
  static volatile bool running = false, done = false;
  static DateTime at = DateTime.MinValue;
  public static int Folders = 0;
  public static bool Running { get { return running; } }
  public static bool Done { get { return done; } }
  public static int AgeSec { get { return done ? (int)(DateTime.UtcNow - at).TotalSeconds : 0; } }
  public static int Count { get { lock (L) { return live.Count; } } }
  static readonly Regex DocRx = new Regex(@"\.(pdf|docx?|xlsx?|pptx?|rtf|txt|jpe?g|png|heic|gif|bmp|tiff?|mp4|mov|zip)$", RegexOptions.IgnoreCase | RegexOptions.Compiled);
  static readonly string[][] GR2 = { new[]{"ου","u"}, new[]{"αι","e"}, new[]{"ει","i"}, new[]{"οι","i"}, new[]{"υι","i"}, new[]{"αυ","av"}, new[]{"ευ","ev"}, new[]{"μπ","b"}, new[]{"ντ","d"}, new[]{"γκ","g"}, new[]{"γγ","g"}, new[]{"τσ","ts"}, new[]{"τζ","tz"} };
  static readonly Dictionary<char, string> GR1 = new Dictionary<char, string> { {'α',"a"},{'β',"v"},{'γ',"g"},{'δ',"d"},{'ε',"e"},{'ζ',"z"},{'η',"i"},{'θ',"th"},{'ι',"i"},{'κ',"k"},{'λ',"l"},{'μ',"m"},{'ν',"n"},{'ξ',"x"},{'ο',"o"},{'π',"p"},{'ρ',"r"},{'σ',"s"},{'τ',"t"},{'υ',"i"},{'φ',"f"},{'χ',"ch"},{'ψ',"ps"},{'ω',"o"} };
  static readonly Regex NonL = new Regex("[^a-zα-ω]+", RegexOptions.Compiled);
  static readonly Regex[] LR = { new Regex("kh|ch", RegexOptions.Compiled), new Regex("th", RegexOptions.Compiled), new Regex("ph", RegexOptions.Compiled), new Regex("ks", RegexOptions.Compiled), new Regex("c", RegexOptions.Compiled), new Regex("[yj]", RegexOptions.Compiled), new Regex("w", RegexOptions.Compiled), new Regex("b", RegexOptions.Compiled), new Regex("ee|ie|ei|oi", RegexOptions.Compiled), new Regex("oo", RegexOptions.Compiled), new Regex("ai", RegexOptions.Compiled), new Regex("dh", RegexOptions.Compiled) };
  static readonly string[] LT = { "h", "t", "f", "x", "k", "i", "v", "v", "i", "u", "e", "d" };
  static readonly Regex Dup = new Regex(@"(.)\1+", RegexOptions.Compiled);
  public static string Skel(string s) {
    if (s == null) return "";
    string d = s.Normalize(NormalizationForm.FormD); StringBuilder sb = new StringBuilder(d.Length);
    foreach (char ch in d) if (CharUnicodeInfo.GetUnicodeCategory(ch) != UnicodeCategory.NonSpacingMark) sb.Append(ch);
    string x = sb.ToString().ToLowerInvariant().Replace('ς', 'σ');
    x = NonL.Replace(x, " ");
    foreach (string[] p in GR2) x = x.Replace(p[0], p[1]);
    sb = new StringBuilder(x.Length + 8);
    foreach (char ch in x) { string m; if (GR1.TryGetValue(ch, out m)) sb.Append(m); else sb.Append(ch); }
    x = sb.ToString().Replace("ou", "u");
    for (int i = 0; i < LR.Length; i++) x = LR[i].Replace(x, LT[i]);
    return Dup.Replace(x, "$1").Trim();
  }
  static E Mk(int ri, string root, FileSystemInfo fi, bool dir) {
    E e = new E(); e.Ri = ri; string full = fi.FullName; e.Rel = full.Length > root.Length ? full.Substring(root.Length + 1) : ""; e.Dir = dir; e.Name = fi.Name;   // λιγότερη μνήμη: χωρίς πλήρη διαδρομή/πεζά ανά εγγραφή
    try { e.T = (long)(fi.LastWriteTimeUtc - new DateTime(1970, 1, 1)).TotalMilliseconds; if (!dir) e.Size = ((FileInfo)fi).Length; } catch { }
    e.Sk = Skel(dir ? fi.Name : Path.GetFileNameWithoutExtension(fi.Name)).Replace(" ", ""); return e;
  }
  static string cachePath = null;
  public static void Start(string[] roots, bool force, string cache) {
    lock (L) {
      if (running) return;
      if (cache != null) cachePath = cache;
      if (live.Count == 0 && !done && cachePath != null) Load(roots);
      // ΦΟΡΤΩΝΕ ΤΟΝ ΚΟΙΝΟ ΔΙΣΚΟ ΤΗΣ ΚΛΙΝΙΚΗΣ: ανανέωση ευρετηρίου μόνο τη νύχτα (22:00–06:59) και το πολύ ανά 12 ώρες· ποτέ στη βάρδια
      int hr = DateTime.Now.Hour; bool night = hr >= 22 || hr < 7;
      if (done && !(force && (DateTime.UtcNow - at).TotalMinutes >= 30) && !(night && (DateTime.UtcNow - at).TotalHours >= 12)) return;
      running = true;
    }
    Thread t = new Thread(delegate() { Build(roots); }); t.IsBackground = true; t.Priority = ThreadPriority.Lowest; t.Start();
  }
  // αποθηκευμένο ευρετήριο (ίδιος υπολογιστής): άμεσες αναζητήσεις μετά από επανεκκίνηση, ανανέωση στο παρασκήνιο
  static void Load(string[] roots) {
    try {
      if (!File.Exists(cachePath)) return;
      string[] lines = File.ReadAllLines(cachePath, Encoding.UTF8);
      if (lines.Length < 2 || lines[0] != "efidx1|" + string.Join("|", roots)) return;
      List<E> l = new List<E>(lines.Length);
      for (int i = 1; i < lines.Length; i++) {
        string[] p = lines[i].Split('\t'); if (p.Length < 5) continue;
        E e = new E(); e.Ri = int.Parse(p[0]); e.Rel = p[1]; e.Dir = p[2] == "1"; e.Size = long.Parse(p[3]); e.T = long.Parse(p[4]);
        e.Name = Path.GetFileName(e.Rel);
        e.Sk = string.Intern(Skel(e.Dir ? e.Name : Path.GetFileNameWithoutExtension(e.Name)).Replace(" ", "")); l.Add(e);
      }
      live = l; done = true; at = File.GetLastWriteTimeUtc(cachePath);
    } catch { }
  }
  static void Save(string[] roots, List<E> all) {
    try {
      if (cachePath == null) return;
      StringBuilder sb = new StringBuilder(); sb.Append("efidx1|" + string.Join("|", roots)).Append('\n');
      foreach (E e in all) sb.Append(e.Ri).Append('\t').Append(e.Rel.Replace('\t', ' ').Replace('\n', ' ')).Append('\t').Append(e.Dir ? "1" : "0").Append('\t').Append(e.Size).Append('\t').Append(e.T).Append('\n');
      string tmp = cachePath + ".tmp"; File.WriteAllText(tmp, sb.ToString(), new UTF8Encoding(false));
      if (File.Exists(cachePath)) File.Delete(cachePath); File.Move(tmp, cachePath);
    } catch { }
  }
  // 8 νήματα: ο NAS απαντά αργά σε κάθε φάκελο (καθυστέρηση δικτύου), όχι στον όγκο — παράλληλα ερωτήματα = πολλαπλάσια ταχύτητα
  static void Build(string[] roots) {
    bool first; lock (L) { first = live.Count == 0; }
    List<E> all = new List<E>(); object AL = new object();
    Stack<KeyValuePair<int, KeyValuePair<string, int>>> st = new Stack<KeyValuePair<int, KeyValuePair<string, int>>>();
    for (int ri = 0; ri < roots.Length; ri++) st.Push(new KeyValuePair<int, KeyValuePair<string, int>>(ri, new KeyValuePair<string, int>(roots[ri].TrimEnd('\\'), 0)));
    int busy = 0, folders = 0;
    ThreadStart work = delegate() {
      List<E> mine = new List<E>();
      while (true) {
        KeyValuePair<int, KeyValuePair<string, int>> it; bool got = false;
        lock (st) { if (st.Count > 0) { it = st.Pop(); busy++; got = true; } else { it = default(KeyValuePair<int, KeyValuePair<string, int>>); if (busy == 0) break; } }
        if (!got) { Thread.Sleep(15); continue; }
        int ri = it.Key; string root = roots[ri].TrimEnd('\\'); string dir = it.Value.Key; int dep = it.Value.Value;
        List<KeyValuePair<int, KeyValuePair<string, int>>> push = new List<KeyValuePair<int, KeyValuePair<string, int>>>();
        try {
          foreach (FileSystemInfo fi in new DirectoryInfo(dir).EnumerateFileSystemInfos()) {
            bool isDir = (fi.Attributes & FileAttributes.Directory) != 0;
            if (isDir) { mine.Add(Mk(ri, root, fi, true)); if (dep < 12) push.Add(new KeyValuePair<int, KeyValuePair<string, int>>(ri, new KeyValuePair<string, int>(fi.FullName, dep + 1))); }
            else if (DocRx.IsMatch(fi.Name)) mine.Add(Mk(ri, root, fi, false));
          }
        } catch { }
        lock (st) { foreach (KeyValuePair<int, KeyValuePair<string, int>> p in push) st.Push(p); busy--; folders++; Folders = folders; }
        Thread.Sleep(25);   // ήπια: λίγα ερωτήματα/δευτερόλεπτο στον δίσκο δικτύου
        if (mine.Count >= 200) { lock (AL) { all.AddRange(mine); } if (first) lock (L) { live.AddRange(mine); } mine.Clear(); }
      }
      lock (AL) { all.AddRange(mine); } if (first) lock (L) { live.AddRange(mine); }
    };
    Thread[] ts = new Thread[2];
    try {
      for (int i = 0; i < ts.Length; i++) { ts[i] = new Thread(work); ts[i].IsBackground = true; ts[i].Start(); }
      foreach (Thread t in ts) t.Join();
    } catch { }
    finally {
      lock (L) { if (!first) live = all; done = true; running = false; at = DateTime.UtcNow; }
      Save(roots, all);
    }
  }
  public static List<E> Find(string q, int max) {
    E[] arr; lock (L) { arr = live.ToArray(); }
    string qs = Skel(q).Replace(" ", ""), ql = (q ?? "").Trim().ToLowerInvariant();
    List<E> r = new List<E>();
    foreach (E e in arr) { if ((qs.Length >= 3 && e.Sk.Contains(qs)) || (ql.Length >= 2 && e.Name.IndexOf(ql, StringComparison.OrdinalIgnoreCase) >= 0)) { r.Add(e); if (r.Count >= max) break; } }
    return r;
  }
}
'@
$EfOk = $false; $EfErr = ''
# μεταγλωττισμένο αντίγραφο στον δίσκο (efidx-<hash>.dll): η μεταγλώττιση σε παλιό υπολογιστή κοστίζει 10–15″ — γίνεται μόνο μία φορά
try {
  if (-not ('EfIdx' -as [type])) {
    $h = [BitConverter]::ToString((New-Object Security.Cryptography.SHA1Managed).ComputeHash([Text.Encoding]::UTF8.GetBytes($EfCs))).Replace('-', '').Substring(0, 12)
    $dll = Join-Path $PSScriptRoot ("efidx-" + $h + ".dll")
    if (-not (Test-Path -LiteralPath $dll)) {
      try { Add-Type -TypeDefinition $EfCs -Language CSharp -OutputAssembly $dll -OutputType Library -ErrorAction Stop } catch { }
      Get-ChildItem -LiteralPath $PSScriptRoot -Filter 'efidx-*.dll' -ErrorAction SilentlyContinue | Where-Object { $_.FullName -ne $dll } | Remove-Item -Force -ErrorAction SilentlyContinue
    }
    if (Test-Path -LiteralPath $dll) { Add-Type -Path $dll -ErrorAction Stop } else { Add-Type -TypeDefinition $EfCs -Language CSharp -ErrorAction Stop }
  }
  $EfOk = $true
} catch { $EfErr = [string]$_.Exception.Message; try { if (-not ('EfIdx' -as [type])) { Add-Type -TypeDefinition $EfCs -Language CSharp -ErrorAction Stop }; $EfOk = $true } catch { $EfErr = [string]$_.Exception.Message } }

# 🐕 8/11: ΦΥΛΑΚΑΣ — στο Παράθυρο έμεναν 82 αδρανή efbot-files.ps1 (≈2 GB). Αν δεν έρθει αίτημα για 15′ και δεν χτίζεται ευρετήριο,
# η διεργασία κλείνει μόνη της (ακόμα κι αν το κύριο νήμα κόλλησε σε δίσκο δικτύου). Το bot ανοίγει νέα όταν χρειαστεί.
try { if (-not ('EfWd' -as [type])) { Add-Type -Language CSharp -TypeDefinition @"
using System; using System.Threading; using System.Reflection;
public static class EfWd {
  static long last = DateTime.UtcNow.Ticks;
  public static void Touch() { Interlocked.Exchange(ref last, DateTime.UtcNow.Ticks); }
  static bool Building() { try { foreach (Assembly a in AppDomain.CurrentDomain.GetAssemblies()) { Type t = a.GetType("EfIdx", false); if (t == null) continue; PropertyInfo p = t.GetProperty("Running"); if (p != null) return (bool)p.GetValue(null, null); } } catch (Exception) {} return false; }
  public static void Start(int idleSec) {
    Thread t = new Thread(delegate() { while (true) { Thread.Sleep(15000); long idle = (DateTime.UtcNow.Ticks - Interlocked.Read(ref last)) / TimeSpan.TicksPerSecond; if (idle > idleSec && !Building()) Environment.Exit(0); } });
    t.IsBackground = true; t.Start();
  }
}
"@ }; [EfWd]::Start(900) } catch {}
while ($true) {
  try {
    $len = [BitConverter]::ToInt32((ReadN 4), 0); try { [EfWd]::Touch() } catch {}
    if ($len -le 0 -or $len -gt 65536) { Reply @{ ok = $false; err = "bad length" }; exit 0 }
    $msg = [Text.Encoding]::UTF8.GetString((ReadN $len)) | ConvertFrom-Json
    $op = [string]$msg.op
    if ($op -eq "ping") {
      $roots = Roots
      if ($EfOk -and $roots.Count) { try { [EfIdx]::Start([string[]]$roots, $false, (Join-Path $PSScriptRoot 'efidx.cache')) } catch {} }
      $bld = $false; if ($EfOk) { try { $bld = [EfIdx]::Running } catch {} }
      Reply @{ ok = $true; v = 11; idx = $EfOk; idxErr = $EfErr; roots = @($roots); bases = @($script:Bases); building = $bld }
    }
    elseif ($op -eq "fsdirs") {
      # φάκελοι έως βάθος 1..3 κάτω από τη ρίζα (ή κάτω από rel): [{ri, rel, name, depth, t}]
      $roots = Roots; $out = New-Object System.Collections.ArrayList
      $maxd = [Math]::Min([Math]::Max([int]$msg.depth, 1), 4)
      for ($ri = 0; $ri -lt $roots.Count; $ri++) {
        if ($null -ne $msg.ri -and [int]$msg.ri -ne $ri) { continue }
        $base = $roots[$ri]; if ($msg.rel) { $base = Inside $ri ([string]$msg.rel) }
        $q = New-Object System.Collections.Queue
        $q.Enqueue(@($base, 0))
        while ($q.Count -gt 0 -and $out.Count -lt 6000) {
          $it = $q.Dequeue(); $d = [string]$it[0]; $dep = [int]$it[1]
          $subs = @(); try { $subs = [IO.Directory]::GetDirectories($d) } catch { $subs = @() }
          foreach ($s in $subs) {
            $t = 0; try { $t = Ms ([IO.Directory]::GetLastWriteTimeUtc($s)) } catch {}
            [void]$out.Add(@{ ri = $ri; rel = (RelOf $roots[$ri] $s); name = [IO.Path]::GetFileName($s); depth = $dep + 1; t = $t })
            if ($dep + 1 -lt $maxd) { $q.Enqueue(@($s, ($dep + 1))) }
          }
        }
      }
      Reply @{ ok = $true; dirs = $out }
    }
    elseif ($op -eq "fslist") {
      # αρχεία ενός φακέλου (αναδρομικά, βάθος ≤6, έως 6000): [{rel, size}]
      $ri = [int]$msg.ri; $full = Inside $ri ([string]$msg.rel); $root = (Roots)[$ri]
      $out = New-Object System.Collections.ArrayList
      $st = New-Object System.Collections.Stack
      $st.Push(@($full, 0))
      while ($st.Count -gt 0 -and $out.Count -lt 6000) {
        $it = $st.Pop(); $d = [string]$it[0]; $dep = [int]$it[1]
        $fl = @(); try { $fl = [IO.Directory]::GetFiles($d) } catch { $fl = @() }
        foreach ($f in $fl) { $fi = New-Object IO.FileInfo $f; [void]$out.Add(@{ rel = (RelOf $root $f); size = $fi.Length }) }
        if ($dep -lt 6) { $sd = @(); try { $sd = [IO.Directory]::GetDirectories($d) } catch { $sd = @() }; foreach ($s in $sd) { $st.Push(@($s, ($dep + 1))) } }
      }
      Reply @{ ok = $true; files = $out }
    }
    elseif ($op -eq "fsread") {
      # κομμάτι αρχείου (έως 640 KB) σε base64
      $ri = [int]$msg.ri; $full = Inside $ri ([string]$msg.rel)
      $off = [long]$msg.off; $n = [Math]::Min([Math]::Max([int]$msg.len, 1), 655360)
      $fs = [IO.File]::Open($full, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
      $size = 0; $got = 0; $buf = New-Object byte[] 0
      try {
        $size = $fs.Length
        $want = [long][Math]::Max([Math]::Min([long]$n, $size - $off), 0)
        $buf = New-Object byte[] $want
        [void]$fs.Seek($off, [IO.SeekOrigin]::Begin)
        while ($got -lt $buf.Length) { $r = $fs.Read($buf, $got, $buf.Length - $got); if ($r -le 0) { break }; $got += $r }
      } finally { $fs.Dispose() }
      Reply @{ ok = $true; size = $size; data = [Convert]::ToBase64String($buf, 0, $got) }
    }
    elseif ($op -eq "fsls") {
      # περιεχόμενα ΕΝΟΣ φακέλου (όχι αναδρομικά): φάκελοι + αρχεία · χωρίς ri → οι ρίζες
      $roots = Roots
      if ($null -eq $msg.ri) { $out = @(); for ($i = 0; $i -lt $roots.Count; $i++) { $out += (Item $i "" $roots[$i] $true) }; Reply @{ ok = $true; dirs = $out; files = @() } }
      else {
        $ri = [int]$msg.ri; $full = Inside $ri ([string]$msg.rel); $root = $roots[$ri]
        $Dirs = New-Object System.Collections.ArrayList; $Files = New-Object System.Collections.ArrayList
        $sd = @(); try { $sd = [IO.Directory]::GetDirectories($full) } catch {}
        foreach ($s in $sd) { if ($Dirs.Count -lt 3000) { [void]$Dirs.Add((Item $ri (RelOf $root $s) $s $true)) } }
        $fl = @(); try { $fl = [IO.Directory]::GetFiles($full) } catch {}
        foreach ($f in $fl) { if ($Files.Count -lt 3000) { [void]$Files.Add((Item $ri (RelOf $root $f) $f $false)) } }
        Reply @{ ok = $true; dirs = $Dirs; files = $Files; more = (($sd.Count -gt 3000) -or ($fl.Count -gt 3000)); nf = $fl.Count }
      }
    }
    elseif ($op -eq "fsfind") {
      # αναζήτηση ονόματος σε όλους τους φακέλους + έγγραφα (σκελετός ή κυριολεκτικά), έως 300
      $q = [string]$msg.q; $qs = (Skel $q).Replace(' ',''); $ql = $q.Trim().ToLowerInvariant()
      if ($ql.Length -lt 2) { throw "πολύ μικρή αναζήτηση" }
      if ($EfOk) {
        $roots = Roots; [EfIdx]::Start([string[]]$roots, [bool]$msg.fresh, (Join-Path $PSScriptRoot 'efidx.cache'))
        $sw = [Diagnostics.Stopwatch]::StartNew()
        do { $r = [EfIdx]::Find($q, 300); if ([EfIdx]::Done -or $r.Count -gt 0 -or $sw.Elapsed.TotalSeconds -gt 4) { break }; Start-Sleep -Milliseconds 700 } while ($true)
        $H = New-Object System.Collections.ArrayList
        foreach ($e in $r) { [void]$H.Add(@{ ri = $e.Ri; rel = $e.Rel; name = $e.Name; dir = $e.Dir; t = $e.T; size = $e.Size }) }
        Reply @{ ok = $true; hits = $H; n = [EfIdx]::Count; trunc = [EfIdx]::Running; building = [EfIdx]::Running; folders = [EfIdx]::Folders; age = [EfIdx]::AgeSec; fast = $true }
        continue
      }
      $fresh = $false
      if ($null -eq $script:Idx -or $msg.fresh -or ((Get-Date) - $script:IdxAt).TotalMinutes -gt 15) { BuildIdx; $fresh = $true }
      $H = New-Object System.Collections.ArrayList
      foreach ($e in $script:Idx) {
        if (($qs.Length -ge 3 -and $e[5].Contains($qs)) -or $e[6].Contains($ql)) { [void]$H.Add((Item $e[0] $e[1] $e[4] ([bool]$e[2]))); if ($H.Count -ge 300) { break } }
      }
      Reply @{ ok = $true; hits = $H; n = $script:Idx.Count; trunc = $script:IdxTrunc; fresh = $fresh; age = [int]((Get-Date) - $script:IdxAt).TotalSeconds }
    }
    elseif ($op -eq "fsstat") {
      $ri = [int]$msg.ri; $full = Inside $ri ([string]$msg.rel)
      Reply @{ ok = $true; item = (Item $ri ([string]$msg.rel) $full ([IO.Directory]::Exists($full))) }
    }
    else { Reply @{ ok = $false; err = "unknown op" } }
  } catch {
    try { Reply @{ ok = $false; err = $_.Exception.Message } } catch { exit 0 }
  }
}
