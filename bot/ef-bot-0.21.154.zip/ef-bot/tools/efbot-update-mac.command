#!/bin/bash
# Πρόγραμμα ενημέρωσης του «Βοηθού Ηλεκτρονικού Φακέλου» (ef-bot) για Mac.
# Ίδια λειτουργία με το efbot-update.bat των Windows: κάθε 60 δευτ. ελέγχει αν υπάρχει νέα έκδοση στο
# https://ef-bot-updates.netlify.app και, αν υπάρχει, την αντιγράφει στον φάκελο της επέκτασης.
# Η επέκταση το βλέπει και ξαναφορτώνεται μόνη της.
#
#   διπλό κλικ                                  -> τρέχει σε παράθυρο Τερματικού (μπορεί να μείνει ελαχιστοποιημένο)
#   ./efbot-update-mac.command install          -> τρέχει μόνο του στο παρασκήνιο, και με κάθε εκκίνηση του Mac (χωρίς παράθυρο)
#   ./efbot-update-mac.command uninstall        -> σταματά και δεν ξεκινά πια μόνο του
#   ./efbot-update-mac.command once             -> ένας έλεγχος και τέλος
#   ./efbot-update-mac.command status           -> τι κάνει τώρα (τελευταίες γραμμές του αρχείου καταγραφής)
set -u
MODE="${1:-loop}"
BASE="${EFBOT_BASE:-https://ef-bot-updates.netlify.app}"   # EFBOT_BASE μόνο για δοκιμές
LABEL="gr.efbot.update"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"
LOGF="$HOME/Library/Logs/efbot-update.log"
SELF="$(cd "$(dirname "$0")" && pwd -P)/$(basename "$0")"
EXT_DIR="$(cd "$(dirname "$SELF")/.." && pwd -P)"          # ο φάκελος ef-bot (όπου είναι το manifest.json)
EXT_NAME="Βοηθός Ηλεκτρονικού Φακέλου"

log() { printf '[%s] %s\n' "$(date +%H:%M:%S)" "$*"; }

# ---- βοηθητικά (μόνο εργαλεία που έχει κάθε Mac· στο Linux για δοκιμές: python3/sha256sum/unzip) ----
json_get() { # json_get <αρχείο> <κλειδί>
  local v=""
  if command -v plutil >/dev/null 2>&1; then v="$(plutil -extract "$2" raw -o - "$1" 2>/dev/null)"; fi
  if [ -z "$v" ] && command -v osascript >/dev/null 2>&1; then
    v="$(osascript -l JavaScript -e 'function run(a){ var s=$.NSString.stringWithContentsOfFileEncodingError(a[0],4,null).js; var o=JSON.parse(s); return o[a[1]]===undefined?"":String(o[a[1]]); }' "$1" "$2" 2>/dev/null)"
  fi
  if [ -z "$v" ] && command -v python3 >/dev/null 2>&1; then
    v="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1],encoding="utf-8")).get(sys.argv[2],""))' "$1" "$2" 2>/dev/null)"
  fi
  printf '%s' "$v"
}
sha256() { if command -v shasum >/dev/null 2>&1; then shasum -a 256 "$1" | awk '{print tolower($1)}'; else sha256sum "$1" | awk '{print tolower($1)}'; fi; }
unpack() { if command -v ditto >/dev/null 2>&1; then ditto -x -k "$1" "$2"; else unzip -q -o "$1" -d "$2"; fi; }
lower() { printf '%s' "$1" | tr '[:upper:]' '[:lower:]'; }

# Το macOS δεν αφήνει προγράμματα του παρασκηνίου (launchd) να γράφουν σε Λήψεις/Έγγραφα/Επιφάνεια εργασίας
protected_dir() { case "$EXT_DIR/" in "$HOME/Downloads/"*|"$HOME/Documents/"*|"$HOME/Desktop/"*) return 0;; esac; return 1; }
assert_ext_dir() { # ασφάλεια πριν από οποιαδήποτε διαγραφή: ο φάκελος πρέπει να είναι πράγματι η επέκταση ef-bot
  [ -f "$EXT_DIR/manifest.json" ] || { log "Ο φάκελος $EXT_DIR δεν έχει manifest.json: δεν σβήνω τίποτα."; return 1; }
  [ "$(json_get "$EXT_DIR/manifest.json" name)" = "$EXT_NAME" ] || { log "Ο φάκελος $EXT_DIR δεν είναι της επέκτασης ef-bot: δεν σβήνω τίποτα."; return 1; }
  case "$EXT_DIR" in /|"$HOME"|"$HOME/"|/Users|/Applications|/System*|/Library) log "Μη ασφαλής φάκελος: $EXT_DIR"; return 1;; esac
  return 0
}
local_version() { json_get "$EXT_DIR/manifest.json" version; }

check_once() { # 0 = εγκαταστάθηκε νέα έκδοση, 1 = καμία αλλαγή, 2 = σφάλμα
  local tmp r
  tmp="$(mktemp -d "${TMPDIR:-/tmp}/efbot.XXXXXX")" || return 2
  check_body "$tmp"; r=$?
  rm -rf "$tmp"
  return $r
}
check_body() {
  local tmp="$1" info ver zipname zipurl want got src n busy del rel dst
  info="$tmp/version.json"
  curl -fsS --max-time 20 -H 'Cache-Control: no-cache' -o "$info" "$BASE/version.json?t=$(date +%s)" || { log "Σφάλμα: δεν διαβάστηκε το version.json (δίκτυο;)"; return 2; }
  ver="$(json_get "$info" version)"; zipname="$(json_get "$info" zip)"; want="$(lower "$(json_get "$info" sha256)")"
  [ -n "$ver" ] && [ "$ver" != "$(local_version)" ] || return 1
  # μόνο αρχεία από τη δική μας διεύθυνση
  zipname="${zipname#/}"
  if ! printf '%s' "$zipname" | grep -Eq '^[A-Za-z0-9._-]+\.zip$'; then log "Σφάλμα: μη αποδεκτό όνομα αρχείου: $zipname"; return 2; fi
  zipurl="$BASE/$zipname"
  log "Νέα έκδοση $ver (έχετε $(local_version)). Λήψη..."
  curl -fsS --max-time 120 -o "$tmp/u.zip" "$zipurl" || { log "Σφάλμα: η λήψη απέτυχε."; return 2; }
  got="$(sha256 "$tmp/u.zip")"
  [ -n "$want" ] && [ "$got" = "$want" ] || { log "Σφάλμα: το αρχείο δεν ταιριάζει (SHA256). Δεν έγινε αλλαγή."; return 2; }
  mkdir -p "$tmp/x" && unpack "$tmp/u.zip" "$tmp/x" || { log "Σφάλμα: δεν αποσυμπιέστηκε."; return 2; }
  src="$tmp/x/ef-bot"
  [ -f "$src/manifest.json" ] || { log "Σφάλμα: το πακέτο δεν έχει ef-bot/manifest.json"; return 2; }
  [ "$(json_get "$src/manifest.json" name)" = "$EXT_NAME" ] || { log "Σφάλμα: το πακέτο δεν είναι του ef-bot."; return 2; }
  assert_ext_dir || return 2
  # 1) όλα τα αρχεία της νέας έκδοσης, ΤΕΛΕΥΤΑΙΟ το manifest.json (η επέκταση ανανεώνεται μόλις αλλάξει αυτό)
  n=0
  while IFS= read -r -d '' f; do
    rel="${f#"$src"/}"
    [ "$rel" = "manifest.json" ] && continue
    case "$rel" in ..*|/*|*/../*) log "Σφάλμα: απρόσμενη διαδρομή: $rel"; return 2;; esac
    dst="$EXT_DIR/$rel"
    mkdir -p "$(dirname "$dst")" && cp -f "$f" "$dst" || { log "Σφάλμα: δεν αντιγράφηκε: $rel"; return 2; }
    [ "$(sha256 "$dst")" = "$(sha256 "$f")" ] || { log "Σφάλμα: δεν αντιγράφηκε σωστά: $rel"; return 2; }
    n=$((n+1))
  done < <(find "$src" -type f -print0)
  chmod +x "$EXT_DIR"/tools/*.command 2>/dev/null
  log "Αντιγράφηκαν και ελέγχθηκαν $n αρχεία."
  # 2) καθαρισμός: ό,τι ΔΕΝ ανήκει στη νέα έκδοση (παλιά/σκόρπια αρχεία). Το δίσκο του Mac δεν τον νοιάζουν κεφαλαία/πεζά.
  local keep="$tmp/keep.txt"; : > "$keep"
  (cd "$src" && find . -type f | sed 's|^\./||') | while IFS= read -r r; do lower "$r"; echo; done > "$keep"
  del=0; busy=0
  while IFS= read -r -d '' f; do
    rel="${f#"$EXT_DIR"/}"
    case "$(lower "$rel")" in .ds_store|*/.ds_store) continue;; esac
    if ! grep -Fxq "$(lower "$rel")" "$keep"; then if rm -f "$f" 2>/dev/null; then del=$((del+1)); else busy=$((busy+1)); fi; fi
  done < <(find "$EXT_DIR" -type f -print0)
  find "$EXT_DIR" -mindepth 1 -type d -empty -delete 2>/dev/null
  [ $del -gt 0 ] || [ $busy -gt 0 ] && log "Καθαρισμός: σβήστηκαν $del παλιά αρχεία$( [ $busy -gt 0 ] && echo ", $busy δεν σβήστηκαν")."
  cp -f "$src/manifest.json" "$EXT_DIR/manifest.json" || { log "Σφάλμα: δεν αντιγράφηκε το manifest.json"; return 2; }
  log "Εγκαταστάθηκε η $ver. Η επέκταση θα ανανεωθεί μόνη της σε λίγα δευτερόλεπτα."
  local notes; notes="$(json_get "$info" notes)"; [ -n "$notes" ] && log "Τι άλλαξε: $notes"
  return 0
}

# ---- έλεγχοι πριν από όλα ----
if [ ! -f "$EXT_DIR/manifest.json" ]; then
  echo "Δεν βρέθηκε το manifest.json στο $EXT_DIR. Το αρχείο πρέπει να είναι στον φάκελο ef-bot/tools."
  [ -t 0 ] && read -r -p "Enter για έξοδο " _
  exit 1
fi

case "$MODE" in
  install)
    if protected_dir; then
      echo "⚠ Ο φάκελος $EXT_DIR είναι σε Λήψεις/Έγγραφα/Επιφάνεια εργασίας: το macOS δεν αφήνει την ενημέρωση στο παρασκήνιο να γράφει εκεί."
      echo "  Μετακινήστε τον στον προσωπικό σας φάκελο, π.χ.:  mv \"$EXT_DIR\" ~/ef-bot"
      echo "  φορτώστε τον ξανά στον Chrome από εκεί, και τρέξτε:  bash ~/ef-bot/tools/efbot-update-mac.command install"
      exit 1
    fi
    chmod +x "$SELF"
    mkdir -p "$HOME/Library/LaunchAgents" "$HOME/Library/Logs"
    cat > "$PLIST" <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$LABEL</string>
  <key>ProgramArguments</key><array><string>/bin/bash</string><string>$SELF</string><string>loop</string></array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>ThrottleInterval</key><integer>30</integer>
  <key>StandardOutPath</key><string>$LOGF</string>
  <key>StandardErrorPath</key><string>$LOGF</string>
</dict></plist>
PL
    launchctl bootout "gui/$(id -u)/$LABEL" 2>/dev/null
    launchctl bootstrap "gui/$(id -u)" "$PLIST" 2>/dev/null || launchctl load -w "$PLIST"
    echo "OK: τρέχει στο παρασκήνιο και θα ξεκινά μόνο του με κάθε εκκίνηση του Mac."
    echo "Καταγραφή: $LOGF   (ή: ./efbot-update-mac.command status)"
    sleep 2; exit 0;;
  uninstall)
    launchctl bootout "gui/$(id -u)/$LABEL" 2>/dev/null || launchctl unload -w "$PLIST" 2>/dev/null
    rm -f "$PLIST"
    echo "OK: σταμάτησε και δεν θα ξεκινά πια μόνο του."; sleep 2; exit 0;;
  status)
    if launchctl print "gui/$(id -u)/$LABEL" >/dev/null 2>&1; then echo "Τρέχει στο παρασκήνιο (launchd)."; else echo "Δεν τρέχει στο παρασκήνιο."; fi
    echo "Έκδοση στον φάκελο: $(local_version)  ($EXT_DIR)"
    [ -f "$LOGF" ] && { echo "--- τελευταίες γραμμές ---"; tail -n 15 "$LOGF"; }
    [ -t 0 ] && read -r -p "Enter για έξοδο " _
    exit 0;;
esac

printf '\033]0;ef-bot: ενημερώσεις\007'
# Ένα μόνο πρόγραμμα ενημέρωσης (αρχείο pid). Αν τρέχει ήδη αυτό του παρασκηνίου (launchd), ένα χειροκίνητο παράθυρο
# δεν χρειάζεται και κλείνει. Αλλιώς το νέο κλείνει το παλιό (π.χ. ξεχασμένο παράθυρο ή παλιά έκδοση).
PIDF="$HOME/Library/Caches/efbot-update.pid"
if [ "$MODE" = "loop" ]; then
  mkdir -p "$(dirname "$PIDF")"
  OLD="$(cat "$PIDF" 2>/dev/null)"
  if [ -n "$OLD" ] && [ "$OLD" != "$$" ] && kill -0 "$OLD" 2>/dev/null && ps -p "$OLD" -o command= 2>/dev/null | grep -q 'efbot-update-mac'; then
    if [ "${XPC_SERVICE_NAME:-}" != "$LABEL" ] && launchctl print "gui/$(id -u)/$LABEL" >/dev/null 2>&1; then
      log "Τρέχει ήδη στο παρασκήνιο (launchd). Δεν χρειάζεται και αυτό το παράθυρο."; sleep 3; exit 0
    fi
    kill "$OLD" 2>/dev/null && log "Έκλεισε παλιό πρόγραμμα ενημέρωσης (PID $OLD)."
  fi
  echo $$ > "$PIDF"
fi
log "Φάκελος επέκτασης: $EXT_DIR (έκδοση $(local_version))"
if [ "$MODE" = "once" ]; then check_once; r=$?; [ $r -eq 1 ] && log "Έχετε την τελευταία έκδοση."; sleep 3; exit 0; fi
log "Έλεγχος για ενημερώσεις κάθε 60 δευτ. Αφήστε αυτό το παράθυρο ανοιχτό (ελαχιστοποιημένο) — ή: ./efbot-update-mac.command install"
SELF_HASH="$(sha256 "$SELF")"
while true; do
  check_once
  # αν ενημερώθηκε το ίδιο το πρόγραμμα, ξαναξεκινά με τον νέο κώδικα (launchd το ξανανοίγει μόνο του)
  if [ "$(sha256 "$SELF")" != "$SELF_HASH" ]; then
    log "Το πρόγραμμα ενημέρωσης ανανεώθηκε. Επανεκκίνηση..."
    if [ "${XPC_SERVICE_NAME:-}" = "$LABEL" ]; then exit 0; else exec /bin/bash "$SELF" loop; fi
  fi
  sleep "${EFBOT_INTERVAL:-60}"
done
