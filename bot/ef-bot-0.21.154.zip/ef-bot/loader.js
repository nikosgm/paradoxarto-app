// Φορτώνει τα αρχεία του πάνελ με την έκδοση στη διεύθυνση (engine.js?v=0.5.4),
// ώστε μετά από αυτόματη ενημέρωση να μη χρησιμοποιηθεί ποτέ παλιό αντίγραφο από τη μνήμη του Chrome.
(() => {
  const v = chrome.runtime.getManifest().version + "-" + Date.now();
  for (const f of ["engine.js", "defaults.js", "sidepanel.js"]) {
    const s = document.createElement("script");
    s.src = f + "?v=" + v;
    s.async = false;
    document.body.appendChild(s);
  }
})();
