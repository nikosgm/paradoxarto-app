// 🔌 ΑΗΦΥ: το bot ΒΛΕΠΕΙ (δεν αλλάζει) τις κεφαλίδες που στέλνει η ίδια η εφαρμογή στο API της (/doctor/api/),
// ώστε οι απευθείας κλήσεις να γίνονται μέσα στην ΙΔΙΑ σύνδεση. Μένουν ΜΟΝΟ στη μνήμη της σελίδας (όχι αποθήκευση, όχι αποστολή).
// 🗺 + χάρτης κλήσεων (μόνο μνήμη, έως 300): μέθοδος, διαδρομή, ΟΝΟΜΑΤΑ παραμέτρων/πεδίων, κατάσταση — ΚΑΜΙΑ τιμή.
(() => {
  if (window.__efAh) return;
  const S = window.__efAh = { h: {}, at: 0, n: 0, log: [] };
  const KEEP = /^(authorization|x-[a-z0-9-]+)$/i;
  const take = (k, v) => { if (KEEP.test(k) && v) { S.h[k.toLowerCase()] = String(v); S.at = Date.now(); S.n++; } };
  const mask = (u) => { try { const x = new URL(u, location.href); return x.pathname.replace(/\d{5,}/g, "#").replace(/[0-9a-f]{8}-[0-9a-f-]{27,}/gi, "#") + (x.search ? "?" + [...x.searchParams.keys()].join("&") : ""); } catch (e) { return ""; } };
  const keysOf = (o, d) => { if (!o || typeof o !== "object" || d > 2) return []; const ks = Array.isArray(o) ? (o.length ? keysOf(o[0], d).map((k) => "[]." + k) : ["[]"]) : Object.keys(o).slice(0, 40).flatMap((k) => { const v = o[k]; return v && typeof v === "object" && d < 2 ? [k, ...keysOf(v, d + 1).map((x) => k + "." + x)] : [k]; }); return ks.slice(0, 60); };
  const bodyKeys = (b) => { try { if (typeof b === "string" && /^\s*[{[]/.test(b)) return keysOf(JSON.parse(b), 0); } catch (e) {} return []; };
  const rec = (e) => { try { S.log.push(e); if (S.log.length > 300) S.log.shift(); } catch (x) {} };
  const API = /\/doctor\/api\/|\/auth\/doctor\//;
  // πρότυπο ερωτήματος: τιμές ΜΟΝΟ για παραμέτρους-ρυθμίσεις (λόγος πρόσβασης, σελίδα) — ποτέ ΑΜΚΑ/ασθενής/ehrId
  const SAFE = /^(reason|pageNo|pageSize|sortBy|sortOrder)$/; S.tpl = {};
  const tplOf = (u) => { try { const x = new URL(u, location.href); if (!API.test(x.pathname)) return; const q = {}; for (const [k, v] of x.searchParams) q[k] = SAFE.test(k) ? String(v).slice(0, 40) : null; S.tpl[x.pathname.replace(/\d{5,}/g, "#")] = q; } catch (e) {} };
  const f0 = window.fetch;
  window.fetch = function (input, init) {
    let e = null;
    try {
      const u = typeof input === "string" ? input : (input && input.url) || "";
      if (API.test(u)) { tplOf(u); const hs = (init && init.headers) || (input && input.headers);
        if (hs) { if (typeof hs.forEach === "function") hs.forEach((v, k) => take(k, v)); else Object.entries(hs).forEach(([k, v]) => take(k, v)); }
        e = { t: Date.now(), m: String((init && init.method) || (input && input.method) || "GET").toUpperCase(), p: mask(u), auth: !!(hs && ((typeof hs.get === "function" && hs.get("authorization")) || hs.Authorization || hs.authorization)), req: bodyKeys(init && init.body) }; }
    } catch (x) {}
    const pr = f0.apply(this, arguments);
    if (e) pr.then((r) => { e.st = r.status; e.ms = Date.now() - e.t; r.clone().json().then((j) => { e.res = keysOf(j, 0); rec(e); }, () => rec(e)); }, () => { e.st = 0; rec(e); });
    return pr;
  };
  const o0 = XMLHttpRequest.prototype.open, s0 = XMLHttpRequest.prototype.setRequestHeader, d0 = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, u) { this.__efApi = API.test(String(u || "")); if (this.__efApi) tplOf(String(u)); if (this.__efApi) this.__efE = { t: 0, m: String(m || "GET").toUpperCase(), p: mask(String(u)), auth: false, req: [] }; return o0.apply(this, arguments); };
  XMLHttpRequest.prototype.setRequestHeader = function (k, v) { try { if (this.__efApi) { take(k, v); if (/^authorization$/i.test(k) && v) this.__efE.auth = true; } } catch (e) {} return s0.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function (b) { try { if (this.__efApi && this.__efE) { const e = this.__efE; e.t = Date.now(); e.req = bodyKeys(b); this.addEventListener("loadend", () => { try { e.st = this.status; e.ms = Date.now() - e.t; try { e.res = keysOf(JSON.parse(this.responseText), 0); } catch (x) {} rec(e); } catch (x) {} }); } } catch (e) {} return d0.apply(this, arguments); };
})();
