// 🗺📕 12/11 23:00 (χρήστης: «το καλύτερο μποτάκι: χαρτογράφηση των συστημάτων ΞΕΧΩΡΙΣΤΑ — κάθε κλικ, κάθε λεπτομέρεια, κάθε σφάλμα —
// και ΑΡΧΕΙΑ ΣΦΑΛΜΑΤΩΝ»). ΚΑΘΑΡΕΣ συναρτήσεις (χωρίς chrome.*, χωρίς DOM) → δοκιμάζονται με Node (tests/sysmap.js).
//  • Χάρτης ανά σύστημα  : oncall_labs «sysmap|<σύστημα>» (συσσωρευτικός, με ιστορικό αλλαγών) + «sysmap|<σύστημα>|md» (έτοιμο αρχείο Markdown)
//  • Σφάλματα ανά σύστημα: oncall_labs «syserr|<σύστημα>» (μοναδικά σφάλματα: κείμενο, πού/πότε, πόσες φορές, χειρισμός bot) + «syserr|<σύστημα>|md»
// ΧΩΡΙΣ στοιχεία ασθενών: αριθμοί ≥5 ψηφίων → #, κείμενα σε «…» → «…», ονόματα (2+ λέξεις με κεφαλαία) → «όνομα».
/* global self */
(function (G) {
  const SYS_NAME = { nps: "ΝΠΣ (Ιατρικός Φάκελος)", npspt: "ΝΠΣ — καρτέλα ασθενή", medilabi: "Medilabi", epres: "e-prescription", ahfy: "ΑΗΦΥ", evorad: "Evorad", bot: "Bot / υπολογιστές / λοιπά" };
  const SYS_FILE = { nps: "ΝΠΣ", npspt: "ΝΠΣ_ΑΣΘΕΝΗΣ", medilabi: "MEDILABI", epres: "EPRES", ahfy: "ΑΗΦΥ", evorad: "EVORAD", bot: "ΛΟΙΠΑ" };
  const ERR_SYS = ["nps", "medilabi", "epres", "ahfy", "evorad", "bot"];

  // ---------- απόκρυψη στοιχείων ----------
  const CAPS_OK = /^(ΝΠΣ|ΕΨΙΝΕ|ΑΗΦΥ|ΗΔΙΚΑ|ΕΟΠΥΥ|ΑΜΚΑ|ΕΤΙΠ|ΚΕΝ|DRG|ΚΛΙΝΙΚΗ\S*|ΟΥΡΟΛΟΓΙΚ\S*|ΗΜΕΡΑΣ|ΤΜΗΜΑ\S*|ΝΟΣΟΚΟΜΕΙ\S*|ΓΕΝΙΚ\S*|ΧΩΡΙΣ|ΔΕΝ|ΟΧΙ|ΝΑΙ|ΜΟΝΟ|ΠΡΟΣΟΧΗ|ΟΛΑ|ΟΛΕΣ|ΟΛΟΙ|ΚΑΙ|ΤΟΥ|ΤΗΣ|ΤΩΝ|ΤΟΝ|ΤΗΝ|ΣΤΟ|ΣΤΗ|ΣΤΗΝ|ΣΤΟΝ|ΑΠΟ|ΓΙΑ|ΠΡΟΣ|ΠΟΤΕ|ΠΑΝΤΑ|ΠΡΙΝ|ΜΕΤΑ|ΕΙΝΑΙ|ΕΧΕΙ|ΠΑΘΗΣΗ|ΔΙΑΓΝΩΣ\S*|ΕΙΣΟΔΟΥ|ΕΞΟΔΟΥ|ΑΤΟΜΙΚ\S*|ΕΙΔΙΚ\S*|ΑΝΤΙΒΙΟΤΙΚ\S*|ΝΑΡΚΩΤΙΚ\S*|ΝΟΣΗΛΕΥ\S*|ΚΟΙΝΑ|ΒΙΟΧΗΜΙΚ\S*|ΑΙΜΑΤΟΛΟΓΙΚ\S*|ΜΙΚΡΟ\S*|ΟΥΡΑ|ΟΥΡΩΝ|ΚΑΛΛΙΕΡΓ\S*|ΕΞΕΤΑΣ\S*|ΥΠΟΛΟΓΙΣΤΙΚ\S*|ΤΟΜΟΓΡΑΦ\S*|ΑΝΩ|ΚΑΤΩ|ΚΟΙΛΙΑΣ|ΘΩΡΑΚ\S*|ΑΡΧΕΙΟ|ΑΠΕΙΚΟΝΙΣ\S*|ΕΚΔΟΘΗΚΕ|ΚΑΤΑΧΩΡ\S*|ΛΕΙΠ\S*|ΣΤΟΠ|ΣΦΑΛΜΑ\S*|ΑΔΕΙΑ|ΕΞΩ|ΜΕΣΑ|ΝΕΑ|ΝΕΟ|ΑΛΛΟ\S*|ΙΔΙΟ\S*|ΚΑΝΕΝΑ\S*|ΚΑΜΙΑ|ΣΩΣΤ\S*|ΛΑΘΟΣ|ΖΩΝΤΑΝ\S*|ΑΥΤΟΜΑΤ\S*|ΧΕΙΡΟΚΙΝΗΤ\S*|ΕΛΕΓΞΤΕ|ΚΩΔΙΚΟΣ|ΑΝΑΓΝΩΣΗ|ΣΤΟΙΧΕΙ\S*|ΑΣΘΕΝ\S*|ΑΝΑΖΗΤ\S*|ΠΑΡΑΓΓΕΛ\S*|ΣΥΝΤΑΓ\S*|ΦΑΡΜΑΚ\S*|ΙΑΤΡΙΚ\S*|ΙΣΤΟΡΙΚ\S*|ΠΛΗΡΟΦΟΡ\S*|ΕΠΙΣΚΕΨ\S*|ΛΙΣΤΑ\S*|ΕΚΤΥΠΩΣ\S*|ΑΠΟΤΕΛΕΣΜ\S*|ΠΑΡΑΠΕΜΠΤ\S*|ΘΕΡΑΠΕΙ\S*|ΝΟΣΗΛΕΙ\S*|ΕΞΙΤΗΡΙ\S*|ΚΑΡΤΕΛ\S*|ΗΜΕΡΟΜΗΝ\S*|ΕΧΕΙ|ΛΗΞΕΙ|ΝΑΤΡΙΟ|ΚΑΛΙΟ|ΟΥΡΗΘΡΟ\S*|ΔΙΑΓΝΩΣΤΙΚ\S*|ΑΚΤΙΝΟΓΡΑΦ\S*|ΥΠΕΡΗΧ\S*|ΑΞΟΝΙΚ\S*|ΜΑΓΝΗΤΙΚ\S*|ΝΕΦΡ\S*|ΚΥΣΤ\S*|ΠΡΟΣΤΑΤ\S*)$/;
  const LAT_OK = /^(MEDILABI|EVORAD|DICOM|PRIMEFACES|VIEWSTATE|PARADOXARTO|CHROME|WINDOWS|SESSION|FORBIDDEN|UNAUTHORIZED|TIMEOUT|EXCEPTION|INTERNAL|SERVER|ERROR|FAILED|UNKNOWN|DELETE|OPTIONS|PARACETAMOL|EPRESCRIPTION)$/;
  function mask(s, extra) {
    let t = String(s == null ? "" : s).replace(/\s+/g, " ").trim();
    (extra || []).forEach((w) => { if (w && w.length >= 3) t = t.split(w).join("«ασθενής»"); });
    t = t.replace(/((?:ζητήθηκε|ασθενής|ασθενή|ασθενούς|ΑΣΘΕΝΗΣ|όνομα στη φόρμα|άνοιξε ο|άνοιξε η)\s*:?\s*\(?)[Α-ΩΆΈΉΊΌΎΏΪΫ]{3,}(?:\s+[Α-ΩΆΈΉΊΌΎΏΪΫ]{3,})?/g, "$1«όνομα»");   // και ΜΟΝΟ επώνυμο, όταν ξέρουμε ότι ακολουθεί όνομα
    t = t.replace(/«[^»]{1,120}»/g, "«…»").replace(/[\w.+-]+@[\w-]+\.[\w.]+/g, "@").replace(/\(AMKA[^)]*\)/gi, "").replace(/\d{5,}/g, "#");
    // 2+ συνεχόμενες λέξεις με ΚΕΦΑΛΑΙΑ ελληνικά που δεν είναι λέξεις του συστήματος = όνομα
    t = t.replace(/(^|[^Α-ΩΆ-Ώα-ωά-ώA-Za-z])([Α-ΩΆΈΉΊΌΎΏΪΫ]{3,}(?:[ ,]+[Α-ΩΆΈΉΊΌΎΏΪΫ]{3,}){1,4})(?![α-ωά-ώ])/g, (m, pre, run) => {
      const w = run.split(/[ ,]+/); let out = [], i = 0;
      while (i < w.length) { if (!CAPS_OK.test(w[i]) && i + 1 < w.length && !CAPS_OK.test(w[i + 1])) { let j = i; while (j < w.length && !CAPS_OK.test(w[j])) j++; out.push("«όνομα»"); i = j; } else out.push(w[i++]); }
      return pre + out.join(" "); });
    t = t.replace(/\b[A-Z]{6,}\b/g, (w) => LAT_OK.test(w) ? w : "«…»");
    return t;
  }
  const capsRun = /(^|[^Α-ΩΆ-Ώα-ωά-ώA-Za-z])([Α-ΩΆΈΉΊΌΎΏΪΫ]{3,}(?:[ ,]+[Α-ΩΆΈΉΊΌΎΏΪΫ]{3,}){1,4})(?![α-ωά-ώ])/g;
  function nameMask(s) { return String(s == null ? "" : s).replace(capsRun, (m, pre, run) => { const w = run.split(/[ ,]+/); return w.some((x) => CAPS_OK.test(x)) ? m : pre + "«όνομα»"; }); }
  // κλειδί ομαδοποίησης σφάλματος: χωρίς χρόνους, αριθμούς, ονόματα, emoji-μετρητές
  function errKey(s) {
    return mask(String(s || "").replace(/\s*·?\s*⏱.*$/s, "")).replace(/\d+([.,]\d+)?/g, "#").replace(/#(″|′|s|ms|%)/g, "#").replace(/\s+/g, " ").trim().slice(0, 140);
  }
  function hash(s) { let h = 5381; s = String(s); for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0; return h.toString(36); }
  const dd = (t) => { if (!t) return "—"; const d = new Date(t); const p = (n) => String(n).padStart(2, "0"); return p(d.getDate()) + "/" + p(d.getMonth() + 1) + " " + p(d.getHours()) + ":" + p(d.getMinutes()); };
  const esc = (s) => String(s == null ? "" : s).replace(/\|/g, "∣").replace(/\n+/g, " ⏎ ");

  // ---------- σύστημα μιας εργασίας ----------
  function sysOfJob(kind, note) {
    const k = String(kind || ""), n = String(note || "");
    if (/κανένας υπολογιστής δεν την πήρε|native messaging|βοηθητικό δεν απάντησε|διακόπηκε δύο φορές|επανεκκίνηση του bot|παλιό κλειδί/i.test(n)) return "bot";
    if (/^(epsine|epsinelist)$/.test(k)) return "nps";
    if (/^(ep|rx|ref$|eprx)/.test(k) || /e-?prescription/i.test(n)) return "epres";
    if (/^(ehr|ahfy)/.test(k) || /^ΑΗΦΥ|ΑΗΦΥ:|ΑΗΦΥ απευθείας/.test(n)) return "ahfy";
    if (/^(evo|ct|img)/.test(k) || /evorad/i.test(n)) return "evorad";
    if (/^(med|bx|barcode|labs?$|order)/.test(k) || /medilabi/i.test(n)) return /^order/.test(k) && /φάκελο|ΝΠΣ|λίστα/i.test(n) && !/medilabi/i.test(n) ? "nps" : "medilabi";
    if (/^(nps|discharge|consult|clinicview|emr|comorb|dayunit|dbident)/.test(k) || /ΝΠΣ|φάκελο|εξιτήρι/i.test(n)) return "nps";
    return "bot";
  }

  // ---------- γνωστά σφάλματα → τι κάνει το bot (✓ = υπάρχει χειρισμός) ----------
  const KNOWN = [
    [/^Υπολογιστής .{1,40}: χωρίς σήμα ζωής/i, "◐ καταγράφεται μόνο του (efbot|gaps|<bot>: πότε, πόσο, αιτία, μνήμη)· ο φύλακας server κλείνει ό,τι δεν παραλήφθηκε· το bot επανέρχεται μόνο του — αν επαναλαμβάνεται: επανεκκίνηση υπολογιστή (bot_nightreboot)"],
    [/κανένας υπολογιστής δεν την πήρε/i, "✓ φύλακας server: η εργασία κλείνει ως αποτυχία και ειδοποιείται η εφαρμογή· αιτία = bot κλειστό/κολλημένο (δες «efbot|hb|<bot>»)"],
    [/native messaging|βοηθητικό δεν απάντησε/i, "✓ το βοηθητικό (efbot-vault.ps1) ξαναξεκινά μόνο του σε ≤10′· η εργασία στέλνεται ξανά"],
    [/διακόπηκε δύο φορές από επανεκκίνηση/i, "✓ μετά από 2 διακοπές δεν ξαναδοκιμάζει (προστασία από βρόχο) — ξανά με το χέρι"],
    [/Δεν βρέθηκε «…» σε καμία από τις # σελίδες της λίστας|δεν βρέθηκε ο ασθενής στη λίστα/i, "✓ λίστα «ανά 20» + όλες οι σελίδες· για φάκελο/ΕΨΙΝΕ συνεχίζει «εκτός κλινικής» με επώνυμο/ΑΜΚΑ· αλλιώς αποτυχία με σαφές μήνυμα"],
    [/Βρέθηκαν # ασθενείς που ταιριάζουν/i, "✓ σκόπιμη διακοπή για ασφάλεια (συνωνυμία) — θέλει ΑΜΚΑ ή πλήρες όνομα"],
    [/ο φάκελος δεν ολοκλήρωσε τη σύνδεση/i, "✓ δεν θεωρείται λάθος κωδικός· ξαναδοκιμάζει στην επόμενη εντολή"],
    [/αυτόματη σύνδεση στον φάκελο απέτυχε/i, "✓ σταματά τις δοκιμές (όχι κλείδωμα λογαριασμού) και ειδοποιεί για τον κωδικό στο 🔐"],
    [/η φόρμα (εξιτηρίου|παραγγελίας) (δεν είναι πια ανοιχτή|έκλεισε)/i, "✓ λύθηκε 12/11 (0 από 10/11)· αν ξαναφανεί: η έγκριση ήρθε αφού έκλεισε η καρτέλα → ξαναστέλνεται"],
    [/ιατρική πράξη ΔΕΝ μπήκε/i, "◐ 0.21.310+: κρατά διάγνωση (act.diag) και ΔΕΝ εκδίδει εξιτήριο· πλευρά (Δεξιά/Αριστερά) όπου ζητείται· εκκρεμεί «δεν φάνηκε στον πίνακα»"],
    [/έμεινε ανοιχτή η ερώτηση/i, "✓ Εξιτήρια Ημέρας: «Ναι» σε όλα τα μηνύματα (κανόνας χρήστη)· μετρητής εκκρεμοτήτων πριν/μετά = εκδόθηκε"],
    [/δεν μπήκε με «…»|δεν είναι αποθηκευμένος σε αυτόν τον υπολογιστή/i, "✓ αλλαγή λογαριασμού ΝΠΣ μόνο με αποθηκευμένο κωδικό (🔐)· αλλιώς η εργασία πάει σε άλλον υπολογιστή"],
    [/χωρίς πίνακα (αποτελεσμάτων|ΕΨΙΝΕ)|δεν άνοιξε η σελίδα ΕΨΙΝΕ/i, "✓ 0.21.245: παράθυρα 30 ημερών + σωστός paginator· επανάληψη στον επόμενο κύκλο της νύχτας"],
    [/χωρίς εκμάθηση/i, "✓ καταργήθηκε η «εκμάθηση»: συννοσηρότητες απευθείας (npsComorbDirect 0.21.285+)"],
    [/χωρίς πεδίο ICD|δεν υπάρχει στη λίστα ICD/i, "✓ κανόνας «.x0» (N40 → N40.90/.00, E11.9 → E11.90) + NPSDX_MAP"],
    [/καμία (πρόταση|γραμμή)|δεν βρέθηκε φάρμακο/i, "✓ ο κατάλογος εξαρτάται από τον «Τύπο Συνταγής» (18/21/19/20): αυτόματη δοκιμή των άλλων τύπων (0.21.326+)"],
    [/δεν έχει κάνει ακόμα αυτή την αναζήτηση|πρότυπο αναζήτησης|δεν έστειλε ακόμα το κλειδί σύνδεσης/i, "✓ λύθηκε (0 από 10/11): το bot κάνει πρώτα μία κανονική αναζήτηση στη σελίδα για να πάρει τα headers"],
    [/οδηγός (συνταγής )?(δεν πέρασε|έκλεισε|δεν έφτασε|δεν άνοιξε)|στοιχεία της συνταγής δεν είναι έγκυρα/i, "✓ 0.21.320: καθαρή επανάληψη του οδηγού + αναμονή 2,5″· η συνταγή ΔΕΝ καταχωρίζεται αν μείνει ασάφεια"],
    [/δεν βρέθηκε το πεδίο ΑΜΚΑ|πεδίο ΑΜΚΑ δεν ξαναεμφανίστηκε|δεν βρέθηκε ο ασθενής/i, "✓ κλείνει το ενημερωτικό pop-up («Ενημερώσεις σχετικά με τον ασθενή») και ξαναψάχνει· ανοιχτή επίσκεψη → ολοκλήρωση πρώτα"],
    [/ΚΩΔΙΚΟΣ του λογαριασμού|δεν βρέθηκε το μενού λογαριασμού|δεν μπήκε ο/i, "✓ δοκιμάζει τον επόμενο αποθηκευμένο λογαριασμό· αν απορριφθούν όλοι → άλλος υπολογιστής· λήξη κωδικού = ειδοποίηση"],
    [/δεν εμφανίστηκε στον πίνακα εξετάσεων|ασαφής — υποψήφιες|δεν βρέθηκε ακριβές όνομα/i, "✓ παραπεμπτικό: ΔΕΝ καταχωρίζει με ασαφή εξέταση· επιστρέφει τις υποψήφιες για επιλογή (κατάλογος epcat|exam)"],
    [/επίσκεψη δεν (καταχωρίστηκε|φαίνεται να ολοκληρώθηκε)/i, "✓ σταματά πριν από συνταγή/παραπεμπτικό και επιστρέφει αυτούσιο το μήνυμα του e-prescription"],
    [/μήνυμα του Medilabi δεν είναι πια ανοιχτό|έγκριση δεν ολοκληρώθηκε/i, "◐ ζητά έλεγχο στο Medilabi πριν από νέα αποστολή (αποφυγή διπλής παραγγελίας)· 0.21.294 ελέγχει barcode/μήνυμα"],
    [/ο ασθενής άλλαξε θέση ή όνομα|στους # ασθενείς αυτού του υπολογιστή/i, "✓ η εργασία ακυρώνεται για να μη γραφτεί σε λάθος ασθενή"],
    [/κάτι το σκεπάζει/i, "✓ περιμένει να φύγει η μάσκα/διάλογος και ξαναπατά (έως 3 φορές)"],
    [/Kerio|Session\.login/i, "✓ λάθος κωδικός email: ειδοποίηση για νέο κωδικό στο 🔐· δεν ξαναδοκιμάζει (όχι κλείδωμα)"],
    [/δεν βρέθηκαν εξετάσεις στον Evorad|Evorad: δεν βρέθηκε το κουμπί/i, "✓ 2 περάσματα με λατινικά/ελληνικά· αλλιώς αποτυχία με τις δοκιμές που έγιναν"],
    [/πολλά για κινητό/i, "✓ όριο μεγέθους: ζητά μία σειρά/υποφάκελο"],
    [/συνεδρία σας έχει λήξει|session (has )?expired/i, "✓ αυτόματη νέα σύνδεση και επανάληψη"],
    [/Δε μπορείτε να συνεχίσετε στο συγκεκριμένο ασθενή/i, "✓ Medilabi κλειδωμένο σε άλλον ασθενή → ξανά άνοιγμα από το ΝΠΣ"],
    [/Μη προβλεπόμενες εξετάσεις βάσει πρωτοκόλλων/i, "✓ ΤΣΕΚ σε όλες + OK (κανόνας χρήστη)"],
    [/Ειδικές Πληροφορίες της παραγγελίας/i, "✓ «Όχι» / «-» / ☑ Φλεβοκαθετήρας + υπογραφή"],
    [/πεδία υποβολής στον ΕΗΦΥ/i, "✓ χωρίς ζωτικά → ISBAR αντί SOAP"],
    [/είναι υποχρεωτικό/i, "◐ μήνυμα επικύρωσης — το bot συμπληρώνει τα γνωστά υποχρεωτικά· νέο πεδίο → ☐ ΠΛΑΝΟ"],
  ];
  function handlerOf(text) { for (const [re, how] of KNOWN) if (re.test(text)) return how; return ""; }

  // ---------- σφάλματα από μία ενέργεια της σάρωσης ----------
  const NOISE_HOST = /^(https?:\/\/)?([\w-]+\.)*(userway\.org|docpilot\.[\w.]+|google-analytics\.com|googletagmanager\.com|gstatic\.com|fonts\.googleapis\.com|hotjar\.com|clarity\.ms|doubleclick\.net|facebook\.net|cloudflareinsights\.com|sentry\.io)(\/|$)/i;
  // 14/11 00:10 (σάρωση ΑΗΦΥ #3407): ένα παράθυρο («Όροι Χρήσης / θεράπων») σκέπαζε ΟΛΕΣ τις σελίδες → 44 ίδια στιγμιότυπα, 28 ψεύτικες «αλλαγές».
  // Σάρωση ΣΚΕΠΑΣΜΕΝΗ = ≥60 % των σελίδων (εκτός αρχικής, ≥4) έχουν το ΙΔΙΟ πρώτο παράθυρο με την αρχική και την ίδια διαδρομή → άκυρη, δεν αποθηκεύεται.
  function blockedBy(pages) {
    const ok = (pages || []).filter((x) => x && x.snap && !x.snap.err); const home = ok.find((x) => x.key === "⌂"); if (!home) return "";
    const d0 = ((home.snap.dialogs || [])[0] || "").trim(); if (!d0) return "";
    const rest = ok.filter((x) => x.key !== "⌂"); if (rest.length < 4) return "";
    const same = rest.filter((x) => ((x.snap.dialogs || [])[0] || "").trim() === d0 && x.snap.path === home.snap.path).length;
    return same / rest.length >= 0.6 ? d0.slice(0, 120) : "";
  }
  // 14/11 01:20 (σάρωση ΑΗΦΥ #3419, μετά τη διόρθωση του παραθύρου): 44/44 σελίδες ΙΔΙΕΣ (η «Αναζήτηση ασθενή» — το μενού δείχνει περιεχόμενο μόνο με ανοιχτό ασθενή).
  // ≥80 % των σελίδων (≥6) με την ίδια υπογραφή → ο χάρτης κρατά μόνο το μενού, ΔΕΝ γράφονται «αλλαγές».
  function uniformPages(pages) {
    const rest = (pages || []).filter((x) => x && x.key !== "⌂" && x.snap && !x.snap.err); if (rest.length < 6) return "";
    const sig = (s) => JSON.stringify([s.path, (s.fields || []).map((f) => f.l || f.id), s.buttons || [], (s.tables || []).map((t) => (t.h || []).join("|")), s.heads || []]);
    const c = {}; rest.forEach((x) => { const k = sig(x.snap); c[k] = (c[k] || 0) + 1; });
    const top = Math.max(...Object.values(c)); return top / rest.length >= 0.8 ? top + "/" + rest.length : "";
  }
  function errorsOf(where, by, d, snap) {
    // 13/11 (ζωντανή σάρωση ΝΠΣ #3238): η μόνιμη ταμπέλα «Εκκρεμότητες ΕΨΙΝΕ: …» δεν είναι σφάλμα
    const E = [], add = (type, text) => { text = mask(text); if (/^Εκκρεμότητες ΕΨΙΝΕ:/.test(text)) return; if (text) E.push({ where: mask(where).slice(0, 120), by: by ? mask(by).slice(0, 60) : "", type, text: text.slice(0, 260) }); };
    if (d) {
      // 14/11 00:10 (σάρωση ΑΗΦΥ #3407: 43/44 «σφάλματα» = cdn.userway.org + docpilot): αιτήματα ΤΡΙΤΩΝ (προσβασιμότητα, στατιστικά, γραμματοσειρές) δεν είναι σφάλματα του συστήματος
      (d.req || []).concat(d.perf || []).forEach((r) => { if (NOISE_HOST.test(String(r.p || ""))) return; if ((+r.st >= 400) || +r.st === 0 || (r.e && (r.msg || []).length)) add("αίτημα", (r.m || "GET") + " " + r.p + " → " + (r.st || "σφάλμα") + ((r.msg || []).length ? " · " + r.msg.join(" · ") : "")); });
      if (d.nav && +d.nav.st >= 400) add("σελίδα", "φόρτωση " + d.nav.p + " → " + d.nav.st);
      (d.js || []).forEach((x) => add("javascript", x));
      (d.msg || []).forEach((m) => { if (/σφάλμα|προειδοποίηση/.test(m.s || "")) add(m.s === "σφάλμα" ? "μήνυμα σφάλματος" : "προειδοποίηση", m.t); });
      (d.al || []).forEach((a) => { if (/σφάλμα|error|αποτυχ|αδύνατ|δεν (είναι|μπορ|επιτρ|βρέθ)|λάθος|invalid|fail/i.test(a.t || "")) add("παράθυρο " + (a.k || "alert"), a.t); });
    }
    if (snap && !snap.err) { (snap.errs || []).forEach((t) => add("μήνυμα σφάλματος", t)); if (snap.errPage) add("σελίδα σφάλματος", (snap.title || "") + " · " + (snap.heads || []).slice(0, 3).join(" · ")); }
    else if (snap && snap.err) add("bot", "δεν διαβάστηκε η σελίδα: " + snap.err);
    const seen = new Set(); return E.filter((e) => { const k = e.type + "|" + e.text; if (seen.has(k)) return false; seen.add(k); return true; });
  }
  // συμπαγής περιγραφή αιτημάτων μιας ενέργειας
  function netOf(d) {
    if (!d) return [];
    const L = (d.req || []).map((r) => (r.m || "GET") + " " + r.p + (r.src ? " [" + r.src + (r.ev ? "·" + r.ev : "") + "]" : "") + (r.k && r.k.length ? " {" + r.k.slice(0, 8).join(",") + (r.k.length > 8 ? ",…" : "") + "}" : "") + " → " + (r.st || "?") + (r.upd && r.upd.length ? " ⟳" + r.upd.slice(0, 4).join(",") : "") + (r.ms != null ? " " + r.ms + "ms" : "") + (r.sz ? " " + Math.round(r.sz / 102.4) / 10 + "KB" : ""))
      .concat((d.perf || []).map((r) => "(φόρτωση) " + r.p + " → " + (r.st || "?") + " " + (r.ms || 0) + "ms"));
    if (d.nav) L.unshift("ΣΕΛΙΔΑ " + d.nav.p + " → " + (d.nav.st || "?") + " " + (d.nav.ms || 0) + "ms" + (d.nav.type && d.nav.type !== "navigate" ? " (" + d.nav.type + ")" : ""));
    return [...new Set(L)].slice(0, 14);
  }
  const msgsOf = (d) => !d ? [] : [...new Set((d.msg || []).map((m) => "[" + (m.s || "ενημέρωση") + "] " + mask(m.t).slice(0, 200)).concat((d.al || []).map((a) => "[παράθυρο " + (a.k || "alert") + "] " + mask(a.t).slice(0, 200))))].slice(0, 8);

  // ---------- υπογραφή/διαφορές σελίδας ----------
  function sigParts(s) {
    if (!s || s.err) return null;
    return { path: s.path || "", heads: (s.heads || []).slice(0, 12), fields: (s.fields || []).map((f) => (f.id || "") + "¦" + (f.l || "") + "¦" + (f.t || "") + (f.req ? "*" : "") + (f.on != null ? "¦" + f.on : "")),
      buttons: (s.buttons || []).slice(), tables: (s.tables || []).map((t) => (t.h || []).join(",")), tabs: (s.tabs || []).slice() };
  }
  function pageSig(s) { const p = sigParts(s); return p ? hash(JSON.stringify(p)) : ""; }
  function diffPage(a, b) {
    const A = sigParts(a), B = sigParts(b), out = []; if (!A || !B) return out;
    const d = (ka, la, f) => { const sa = new Set(A[ka]), sb = new Set(B[ka]); B[ka].forEach((x) => { if (!sa.has(x)) out.push("＋ " + la + " " + f(x)); }); A[ka].forEach((x) => { if (!sb.has(x)) out.push("－ " + la + " " + f(x)); }); };
    if (A.path !== B.path) out.push("διαδρομή " + A.path + " → " + B.path);
    const ff = (x) => { const p = x.split("¦"); return "«" + (p[1] || p[0]) + "» (" + (p[0] || "χωρίς id") + ", " + p[2] + ")"; };
    d("fields", "πεδίο", ff); d("buttons", "κουμπί", (x) => "«" + x + "»"); d("tabs", "καρτέλα", (x) => "«" + x + "»"); d("tables", "πίνακας", (x) => "[" + x.slice(0, 80) + "]"); d("heads", "τίτλος", (x) => "«" + x + "»");
    return out.slice(0, 10);
  }

  // ---------- συγχώνευση αποτελέσματος σάρωσης στον χάρτη ----------
  function merge(store, out, meta) {
    const now = out.at || Date.now(), M = store && store.v === 2 ? store : { v: 2, sys: out.sys, first: now, runs: [], pages: {}, menu: [], skipped: [], changes: [] };
    M.sys = out.sys; M.upd = now; meta = meta || {};
    const chg = [];
    if ((out.menu || []).length) { const old = new Set((M.menu || []).map((x) => x.t)), nw = new Set(out.menu.map((x) => x.t));
      if (old.size) { out.menu.forEach((x) => { if (!old.has(x.t)) chg.push({ at: now, key: "⌂ μενού", what: ["＋ στοιχείο «" + x.t + "»"] }); }); if (!out.cut) (M.menu || []).forEach((x) => { if (!nw.has(x.t)) chg.push({ at: now, key: "⌂ μενού", what: ["－ στοιχείο «" + x.t + "»"] }); }); }
      M.menu = out.menu.map((x) => ({ t: x.t, kind: x.kind, skip: !!x.skip })); }
    if ((out.skipped || []).length) M.skipped = [...new Set((M.skipped || []).concat(out.skipped))].slice(0, 200);
    let nNew = 0, nChg = 0, clicks = 0;
    for (const pg of out.pages || []) {
      const P = M.pages[pg.key] || (M.pages[pg.key] = { first: now, n: 0, chg: [], probe: {} });
      P.n++; P.last = now; P.kind = pg.kind || P.kind; clicks++;
      if (pg.err) { P.err = pg.err; P.errAt = now; continue; }
      delete P.err;
      if (pg.snap && !pg.snap.err) { const sg = pageSig(pg.snap);
        // P.imp = η σελίδα ήρθε από ΠΑΛΙΑ σάρωση (εισαγωγή, παλιά μορφή απογραφής) → η πρώτη νέα σάρωση την αντικαθιστά χωρίς να μετρήσει «αλλαγή»
        if (!P.sig) nNew++; else if (P.sig !== sg && !P.imp && !meta.imp) { const w = diffPage(P.snap, pg.snap); if (w.length) { nChg++; const c = { at: now, what: w }; P.chg = (P.chg || []).concat([c]).slice(-5); chg.push({ at: now, key: pg.key, what: w }); } }
        P.sig = sg; P.snap = pg.snap; if (meta.imp) P.imp = 1; else delete P.imp; }
      if (pg.new) P.nav = pg.new; if (pg.net && pg.net.length) P.net = pg.net; if (pg.msgs && pg.msgs.length) P.msgs = [...new Set((P.msgs || []).concat(pg.msgs))].slice(-12);
      if (pg.ms != null) P.ms = P.ms ? Math.round((P.ms * 2 + pg.ms) / 3) : pg.ms;
      if (pg.btns) P.btns = pg.btns; if (pg.pt) P.pt = 1; else delete P.pt;
      for (const pr of pg.probe || []) { if (!pr || !pr.b || pr.b === "↺") continue; clicks++;
        const o = P.probe[pr.b] || (P.probe[pr.b] = { first: now, n: 0 }); o.n++; o.last = now;
        const res = JSON.stringify([pr.path || "", pr.dlg || [], pr.fields ? pr.fields.map((f) => f.id + f.l) : [], pr.btns || [], pr.err || ""]);
        if (o.res && o.res !== hash(res)) chg.push({ at: now, key: pg.key + " › [" + pr.b + "]", what: ["το κουμπί ανοίγει/δείχνει κάτι διαφορετικό από την προηγούμενη φορά"] });
        o.res = hash(res);
        ["path", "dlg", "fields", "btns", "net", "err", "leave", "dlgs"].forEach((k) => { if (pr[k] !== undefined && pr[k] !== null && !(Array.isArray(pr[k]) && !pr[k].length)) o[k] = pr[k]; else if (k !== "net") delete o[k]; });
        const mm = (pr.msg || []).map((t) => mask(t)).concat(pr.msgs || []); if (mm.length) o.msg = [...new Set((o.msg || []).concat(mm))].slice(-8);
        if (pr.ms != null) o.ms = pr.ms; }
    }
    M.changes = (M.changes || []).concat(chg).slice(-80);
    const pagesOk = Object.values(M.pages).filter((p) => p.snap).length;
    M.runs = (M.runs || []).concat([{ at: now, job: meta.job || 0, bot: meta.bot || "", ver: out.ver || "", pages: (out.pages || []).length, clicks, errs: (out.errors || []).length, nw: nNew, chg: nChg, cut: !!out.cut, secs: meta.secs || 0, from: meta.from || 0, imp: meta.imp ? 1 : undefined }]).slice(-20);
    M.stat = { pages: pagesOk, total: Object.keys(M.pages).length, probes: Object.values(M.pages).reduce((a, p) => a + Object.keys(p.probe || {}).length, 0) };
    return { M, nNew, nChg, clicks, chg };
  }

  // ---------- αρχείο χάρτη (Markdown) ----------
  function renderMap(M, botNames) {
    const sys = M.sys, L = [], bn = botNames || {};
    L.push("# Χάρτης σελίδων — " + (SYS_NAME[sys] || sys));
    L.push("");
    L.push("> ΑΥΤΟΜΑΤΟ ΑΡΧΕΙΟ — το γράφει το bot μετά από κάθε σάρωση (`sitemap`, νύχτα 00–07 εκτός γενικής εφημερίας). Μη το διορθώνεις με το χέρι.");
    L.push("> Πηγή: `oncall_labs` → `sysmap|" + sys + "` (δεδομένα) / `sysmap|" + sys + "|md` (αυτό το κείμενο). Μόνο δομή — καμία τιμή πεδίου, κανένα στοιχείο ασθενή.");
    L.push("> Τελευταία ενημέρωση: **" + dd(M.upd) + "** · σελίδες " + ((M.stat || {}).pages || 0) + "/" + ((M.stat || {}).total || 0) + " · κουμπιά που δοκιμάστηκαν " + ((M.stat || {}).probes || 0));
    L.push("");
    L.push("## Σαρώσεις (τελευταίες)");
    L.push("| Πότε | Εργασία | Υπολογιστής | Έκδοση | Σελίδες | Κλικ | Νέες | Άλλαξαν | Σφάλματα | Διάρκεια |"); L.push("|---|---|---|---|---|---|---|---|---|---|");
    (M.runs || []).slice(-8).reverse().forEach((r) => L.push("| " + dd(r.at) + " | #" + r.job + " | " + esc(bn[r.bot] || r.bot || "—") + " | " + r.ver + " | " + r.pages + (r.cut ? " (συνεχίζεται)" : "") + (r.imp ? " (εισαγωγή παλιάς σάρωσης)" : "") + " | " + r.clicks + " | " + r.nw + " | " + r.chg + " | " + r.errs + " | " + (r.secs || 0) + "″ |"));
    L.push("");
    if ((M.changes || []).length) { L.push("## ⚠ Τι άλλαξε στο σύστημα (νεότερα πάνω)");
      M.changes.slice(-25).reverse().forEach((c) => L.push("- " + dd(c.at) + " · **" + esc(c.key) + "**: " + c.what.map(esc).join(" · "))); L.push(""); }
    if ((M.menu || []).length) { L.push("## Μενού αρχικής"); L.push(M.menu.map((x) => (x.skip ? "⛔ " : "") + x.t + (x.kind && x.kind !== "menu" ? " (" + x.kind + ")" : "")).join(" · ")); L.push("");
      L.push("⛔ = δεν πατιέται ποτέ από τη σάρωση (εγγραφή/αποστολή/εκτύπωση/αποσύνδεση)."); L.push(""); }
    const keys = Object.keys(M.pages).sort((a, b) => (a === "⌂" ? -1 : b === "⌂" ? 1 : a.localeCompare(b, "el")));
    for (const k of keys) { const P = M.pages[k], s = P.snap;
      L.push("## " + (SYS_FILE[sys] || sys) + " › " + k);
      if (P.err && !s) { L.push("- ✗ δεν άνοιξε: " + esc(P.err) + " (" + dd(P.errAt) + ")"); L.push(""); continue; }
      if (!s) { L.push("- (χωρίς στιγμιότυπο)"); L.push(""); continue; }
      L.push("- Διαδρομή: αρχική → " + k.split(" › ").join(" → ") + " · URL `" + s.path + "`" + ((s.q || []).length ? " ?" + s.q.join("&") : "") + " · τίτλος «" + esc(s.title) + "»" + (P.ms != null ? " · " + P.ms + "ms" : ""));
      if ((s.heads || []).length) L.push("- Τίτλοι: " + s.heads.slice(0, 14).map(esc).join(" · "));
      if ((s.tabs || []).length) L.push("- Καρτέλες: " + s.tabs.map(esc).join(" · "));
      if (P.err) L.push("- ⚠ τελευταία φορά ΔΕΝ άνοιξε: " + esc(P.err) + " (" + dd(P.errAt) + ")");
      if ((s.fields || []).length) { L.push("- Πεδία (" + s.fields.length + "):"); L.push(""); L.push("  | id | ετικέτα | είδος | υποχρ. | επιλογές/μορφή |"); L.push("  |---|---|---|---|---|");
        s.fields.forEach((f) => L.push("  | `" + esc(f.id || "—") + "` | " + esc(f.l || "—") + " | " + esc(f.t) + (f.ro ? " (μόνο ανάγνωση)" : "") + " | " + (f.req ? "✱" : "") + " | " + esc((f.opts ? (f.on != null && f.on > f.opts.length ? f.on + " επιλογές: " : "") + f.opts.join(" ∙ ") + (f.on > f.opts.length ? " …" : "") : f.on != null ? f.on + " επιλογές (ονόματα — δεν καταγράφονται)" : "") + (f.max ? " μέγ. " + f.max + " χαρ." : "") + (f.ph ? " «" + f.ph + "»" : "")) + " |")); L.push(""); }
      const bt = s.btn2 || (s.buttons || []).map((t) => ({ t }));
      if (bt.length) L.push("- Κουμπιά: " + bt.map((b) => "«" + esc(nameMask(b.t)) + "»" + (b.id ? " `" + esc(b.id) + "`" : "") + (b.dis ? " (ανενεργό)" : "") + ((P.btns || []).includes(b.t + " ⛔") ? " ⛔" : "")).join(" · "));
      if ((s.tables || []).length) s.tables.forEach((t) => L.push("- Πίνακας" + (t.id ? " `" + esc(t.id) + "`" : "") + ": " + t.h.map(esc).join(" | ") + " · " + t.rows + " γραμμές" + (t.pager ? " · σελιδοποίηση" + (t.rpp ? " (" + t.rpp.join("/") + ")" : "") : "")));
      if ((s.frames || []).length) L.push("- Πλαίσια (iframe): " + s.frames.map(esc).join(" · "));
      if ((P.net || []).length) { L.push("- Αιτήματα όταν ανοίγει:"); P.net.forEach((n) => L.push("  - `" + esc(n) + "`")); }
      if ((P.msgs || []).length) { L.push("- Μηνύματα που εμφανίστηκαν:"); P.msgs.forEach((m) => L.push("  - " + esc(m))); }
      if ((P.nav || []).length) L.push("- Νέα στοιχεία πλοήγησης εδώ: " + P.nav.map(esc).join(" · "));
      const pk = Object.keys(P.probe || {});
      if (pk.length) { L.push("- Κάθε ασφαλές κουμπί → τι κάνει:");
        pk.forEach((b) => { const o = P.probe[b]; let t = "  - **«" + esc(nameMask(b)) + "»** → ";
          if (o.err) t += "✗ " + esc(o.err);
          else { const bits = []; if (o.path) bits.push("πάει στη σελίδα `" + esc(o.path) + "`");
            if ((o.dlgs || []).length) o.dlgs.forEach((d) => bits.push("ανοίγει παράθυρο «" + esc(d.t || "χωρίς τίτλο") + "»" + ((d.f || []).length ? " (πεδία: " + d.f.map(esc).join(", ") + ")" : "") + ((d.b || []).length ? " [κουμπιά: " + d.b.map(esc).join(", ") + "]" : "")));
            else if ((o.dlg || []).length) bits.push("ανοίγει παράθυρο: " + o.dlg.map((x) => esc(mask(x)).slice(0, 110)).join(" ‖ "));
            if ((o.msg || []).length) bits.push("μήνυμα: " + o.msg.map((x) => "«" + esc(x) + "»").join(" · "));
            if (o.leave) bits.push("⚠ ερώτηση «μη αποθηκευμένα»");
            if (!bits.length) bits.push("καμία ορατή αλλαγή");
            t += bits.join(" · "); }
          if (o.ms != null) t += " · " + o.ms + "ms";
          L.push(t); (o.net || []).slice(0, 6).forEach((n) => L.push("    - `" + esc(n) + "`")); }); }
      if (P.pt) L.push("- 🧍 Σελίδα με ανοιχτό ασθενή/επίσκεψη: δοκιμάζονται ΜΟΝΟ κουμπιά ανάγνωσης (Αναζήτηση / Εμφάνιση / φίλτρα).");
      if ((P.btns || []).some((x) => / ↑$/.test(x))) L.push("- Κουμπιά κεφαλίδας (δοκιμάζονται μία φορά, στην αρχική ⌂): " + P.btns.filter((x) => / ↑$/.test(x)).map((x) => "«" + esc(x.replace(/ ↑$/, "")) + "»").join(" · "));
      if ((P.btns || []).some((x) => / ⛔$/.test(x))) L.push("- ⛔ Δεν πατήθηκαν (απαγορευμένα): " + P.btns.filter((x) => / ⛔$/.test(x)).map((x) => "«" + esc(nameMask(x.replace(/ ⛔$/, ""))) + "»").join(" · "));
      if ((P.chg || []).length) L.push("- Ιστορικό αλλαγών: " + P.chg.map((c) => dd(c.at) + " " + c.what.map(esc).join("; ")).join(" ‖ "));
      L.push("- Επαληθεύτηκε: " + dd(P.last) + " · " + P.n + " φορές · πρώτη " + dd(P.first));
      L.push(""); }
    if ((M.skipped || []).length) { L.push("## ⛔ Στοιχεία μενού που ΔΕΝ ανοίγονται από τη σάρωση"); L.push(M.skipped.map(esc).join(" · ")); L.push(""); }
    return L.join("\n");
  }

  // ---------- μητρώο σφαλμάτων ανά σύστημα ----------
  // items: [{src:'scan'|'job', kind, text, where, by, type, at, job, ver, bot, n?}]
  function mergeErr(store, sys, items, now) {
    now = now || Date.now(); const S = store && store.v === 1 ? store : { v: 1, sys, first: now, items: {} }; S.sys = sys; S.upd = now; let nw = 0;
    // οι εγγραφές «από εργασίες» ξαναχτίζονται ΚΑΘΕ φορά από το παράθυρο των 30 ημερών (ό,τι βγήκε από το παράθυρο φεύγει)· σάρωση/κενά συσσωρεύονται
    if ((items || []).some((x) => x.src === "job" || x.rebuild)) Object.keys(S.items).forEach((k) => { if (S.items[k].src === "job") { S.items[k]._old = 1; } });
    for (const it of items || []) { const key = errKey(it.text); if (!key) continue; const id = hash((it.src === "job" ? "j|" + (it.kind || "") : "s|" + (it.type || "")) + "|" + key);
      let e = S.items[id]; if (e) delete e._old; if (!e) { e = S.items[id] = { src: it.src, kind: it.kind || "", type: it.type || "", key, text: mask(it.text).slice(0, 400), n: 0, first: it.first || it.at || now, where: [], bots: [] }; nw++; }
      if (it.total != null) e.n = it.total; else e.n += it.n || 1;
      if (it.wheres) e.where = it.wheres.slice(-6);   // από εργασίες: πλήθος = όσα μετρήθηκαν στο παράθυρο (όχι άθροισμα σε κάθε ενημέρωση)
      e.last = Math.max(e.last || 0, it.at || now); if (it.first && it.first < e.first) e.first = it.first;
      if (it.job) e.job = it.job; if (it.ver) e.ver = it.ver; if (it.status) e.status = it.status;
      const w = (it.where || "") + (it.by ? " › [" + it.by + "]" : ""); if (w && e.where.indexOf(w) < 0 && e.where.length < 6) e.where.push(w);
      if (it.bot && e.bots.indexOf(it.bot) < 0 && e.bots.length < 6) e.bots.push(it.bot);
      e.how = handlerOf(e.text) || handlerOf(e.key) || ""; }
    Object.keys(S.items).forEach((k) => { if (S.items[k]._old) delete S.items[k]; });
    // όριο: κρατάμε τα 400 πιο πρόσφατα
    const ids = Object.keys(S.items); if (ids.length > 400) ids.sort((a, b) => (S.items[a].last || 0) - (S.items[b].last || 0)).slice(0, ids.length - 400).forEach((k) => delete S.items[k]);
    return { S, nw };
  }
  // γραμμές oncall_jobs → items ανά σύστημα
  function jobItems(rows) {
    const by = {}; ERR_SYS.forEach((s) => (by[s] = {}));
    for (const r of rows || []) { let note = String(r.note || "").replace(/\s*·?\s*⏱.*$/s, "").trim(); if (!note) continue;
      // εργασία που ΔΕΝ απέτυχε: κρατάμε μόνο τα κομμάτια με προειδοποίηση (⚠/✗/❌)· αλλιώς δεν είναι σφάλμα
      if (r.status !== "failed" && /(probe|map|cat|cat2|grep|test|torture|diag|warm)$/.test(r.kind || "")) continue;   // αποτελέσματα δοκιμών/χαρτογράφησης, όχι σφάλματα
      if (r.status !== "failed") { note = note.split(/\s+·\s+|\n+/).filter((x) => /⚠|✗|❌/.test(x)).join(" · "); if (!note) continue; }
      const sys = sysOfJob(r.kind, note), key = r.kind + "|" + errKey(note), at = Date.parse(r.created_at || r.at || 0) || 0;
      const o = by[sys][key] || (by[sys][key] = { src: "job", kind: r.kind, text: note, total: 0, first: at, at: 0, status: r.status });
      o.total++; if (at && at < o.first) o.first = at; if (at >= o.at) { o.at = at; o.job = r.id; o.ver = r.ver || o.ver; o.bot = r.bot || o.bot; o.status = r.status; o.text = note; } }
    const out = {}; ERR_SYS.forEach((s) => (out[s] = Object.values(by[s]))); return out;
  }
  // κενά λειτουργίας υπολογιστών → items (ένα ανά υπολογιστή+αιτία)
  function gapItems(rows, names, since) {
    const by = {};
    for (const r of rows || []) { const d = r.data || {}, bot = d.bot || String(r.name_key || "").split("|").pop(), nm = (names || {})[bot] || bot;
      for (const g of d.gaps || []) { if (!g || !g.to || g.to < (since || 0)) continue; const text = "Υπολογιστής " + nm + ": χωρίς σήμα ζωής — " + String(g.why || "άγνωστη αιτία"), k = bot + "|" + g.why;
        const o = by[k] || (by[k] = { src: "gap", type: "κενό λειτουργίας", text, total: 0, first: g.from, at: 0, bot, wheres: [], ver: g.ver });
        o.total++; if (g.from < o.first) o.first = g.from; if (g.to > o.at) { o.at = g.to; o.ver = g.ver; }
        o.wheres.push(dd(g.from) + "–" + dd(g.to).slice(6) + " (" + (g.mins || Math.round((g.to - g.from) / 60000)) + "′" + (g.sys && g.sys.ram ? ", ελεύθερη μνήμη " + Math.round(100 * g.sys.free / g.sys.ram) + "%, ανοιχτός " + (g.sys.upH || "?") + " ώρες" : "") + ")"); } }
    return Object.values(by);
  }
  function renderErr(S, botNames) {
    const sys = S.sys, L = [], bn = botNames || {}, all = Object.values(S.items || {});
    const open = all.filter((e) => !e.how), part = all.filter((e) => /^◐/.test(e.how || "")), week = Date.now() - 7 * 864e5;
    L.push("# Αρχείο σφαλμάτων — " + (SYS_NAME[sys] || sys));
    L.push("");
    L.push("> ΑΥΤΟΜΑΤΟ ΑΡΧΕΙΟ — ενημερώνεται μόνο του: κάθε πρωί (06:30, εργασία `errbook`) από τις αποτυχημένες/προς έλεγχο εργασίες των τελευταίων 30 ημερών και μετά από κάθε νυχτερινή σάρωση.");
    L.push("> Πηγή: `oncall_labs` → `syserr|" + sys + "` / `syserr|" + sys + "|md`. Τα ονόματα και οι αριθμοί έχουν αφαιρεθεί («…», «όνομα», #).");
    L.push("> Τελευταία ενημέρωση: **" + dd(S.upd) + "** · " + all.length + " διαφορετικά σφάλματα · χωρίς χειρισμό: **" + open.length + "** · μερικός χειρισμός: " + part.length + " · ενεργά την τελευταία εβδομάδα: " + all.filter((e) => (e.last || 0) > week).length);
    L.push("");
    L.push("Χειρισμός: ✓ = το bot το αντιμετωπίζει · ◐ = μερικώς · ☐ = ΧΩΡΙΣ χειρισμό (να μπει στο `docs/ΠΛΑΝΟ.md`).");
    L.push("");
    const tbl = (title, list, max) => { if (!list.length) return; L.push("## " + title + " (" + list.length + ")"); L.push("");
      L.push("| Σφάλμα (αυτούσιο) | Πού / εργασία | Πότε βγαίνει | Φορές | Πρώτη → τελευταία | Χειρισμός bot |"); L.push("|---|---|---|---|---|---|");
      list.sort((a, b) => (b.last || 0) - (a.last || 0)).slice(0, max || 200).forEach((e) => L.push("| " + esc(e.text.slice(0, 300)) + " | " + (e.src === "job" ? "εργασία `" + esc(e.kind) + "`" + (e.job ? " (τελ. #" + e.job + (e.ver ? ", bot " + e.ver : "") + ")" : "") : e.src === "gap" ? "υπολογιστής · " + esc(e.type) + (e.ver ? " (bot " + e.ver + ")" : "") : "σάρωση · " + esc(e.type)) + " | " + (e.src === "job" ? (e.status === "failed" ? "η εργασία απέτυχε" : e.status === "review" ? "έμεινε «για έλεγχο»" : "η εργασία ολοκληρώθηκε ΜΕ προειδοποίηση") + ((e.bots || []).length ? " · " + e.bots.map((b) => bn[b] || b).join(", ") : "") : esc((e.where || []).join(" ‖ ") || "—")) + " | " + e.n + " | " + dd(e.first) + " → " + dd(e.last) + " | " + (e.how ? esc(e.how) : "☐ ΠΛΑΝΟ — χωρίς ειδικό χειρισμό") + " |")); L.push(""); };
    const act = Date.now() - 5 * 864e5;
    tbl("🔴 ☐ Χωρίς χειρισμό — ΕΝΕΡΓΑ (φάνηκαν τις τελευταίες 5 ημέρες) — από εργασίες", open.filter((e) => e.src === "job" && (e.last || 0) >= act));
    tbl("⚪ ☐ Χωρίς χειρισμό — παλαιότερα (δεν ξαναφάνηκαν ≥5 ημέρες· πιθανόν λύθηκαν με νεότερη έκδοση) — από εργασίες", open.filter((e) => e.src === "job" && (e.last || 0) < act), 60);
    tbl("☐ Χωρίς χειρισμό — από τη σάρωση (μηνύματα/αιτήματα/JavaScript)", open.filter((e) => e.src !== "job" && e.src !== "gap"));
    tbl("◐ Μερικός χειρισμός", part);
    tbl("✓ Με χειρισμό", all.filter((e) => /^✓/.test(e.how || "")));
    if (!all.length) L.push("_Κανένα σφάλμα καταγεγραμμένο ακόμα._");
    return L.join("\n");
  }
  // σύνοψη για το αποτέλεσμα της εργασίας (το πλήρες πάει στον χάρτη)
  function summary(out, mg) {
    return { sys: out.sys, at: out.at, ver: out.ver, compact: 1, pages: (out.pages || []).length, ok: (out.pages || []).filter((x) => x.snap && !x.snap.err).length, clicks: mg.clicks, nw: mg.nNew, chg: mg.nChg,
      probedTo: out.probedTo, cut: out.cut, left: out.left, menu: (out.menu || []).length, skipped: (out.skipped || []).length, errs: out.errs || [],
      errors: (out.errors || []).slice(0, 25), changes: (mg.chg || []).slice(0, 25), bad: (out.pages || []).filter((x) => x.err).slice(0, 15).map((x) => ({ key: x.key, err: x.err })) };
  }

  G.SMX = { blockedBy, uniformPages, NOISE_HOST, SYS_NAME, SYS_FILE, ERR_SYS, mask, nameMask, errKey, hash, sysOfJob, handlerOf, errorsOf, netOf, msgsOf, pageSig, diffPage, merge, renderMap, mergeErr, jobItems, gapItems, renderErr, summary };
})(typeof self !== "undefined" ? self : globalThis);
