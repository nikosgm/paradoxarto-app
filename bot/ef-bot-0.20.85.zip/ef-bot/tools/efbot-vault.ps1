﻿# ef-bot vault helper (Chrome native messaging host "gr.efbot.vault")
# Protects/unprotects a small key with Windows DPAPI (CurrentUser scope). Nothing is stored here.
# Protocol: 4-byte little-endian length + UTF-8 JSON, one request per launch.
$ErrorActionPreference = "Stop"
$stdin  = [Console]::OpenStandardInput()
$stdout = [Console]::OpenStandardOutput()
function ReadN([int]$n) {
  $b = New-Object byte[] $n; $o = 0
  while ($o -lt $n) { $r = $stdin.Read($b, $o, $n - $o); if ($r -le 0) { exit 0 }; $o += $r }
  return ,$b
}
function Reply($obj) {
  $j = [Text.Encoding]::UTF8.GetBytes(($obj | ConvertTo-Json -Compress))
  $stdout.Write([BitConverter]::GetBytes([int]$j.Length), 0, 4)
  $stdout.Write($j, 0, $j.Length)
  $stdout.Flush()
}
try {
  $len = [BitConverter]::ToInt32((ReadN 4), 0)
  if ($len -le 0 -or $len -gt 65536) { Reply @{ ok = $false; err = "bad length" }; exit 0 }
  $msg = [Text.Encoding]::UTF8.GetString((ReadN $len)) | ConvertFrom-Json
  Add-Type -AssemblyName System.Security
  $ent = [Text.Encoding]::UTF8.GetBytes("ef-bot-vault-v1")
  $scope = [Security.Cryptography.DataProtectionScope]::CurrentUser
  switch ([string]$msg.op) {
    "ping"      { Reply @{ ok = $true; v = 1; user = [Environment]::UserName } }
    "protect"   { $d = [Convert]::FromBase64String([string]$msg.data); Reply @{ ok = $true; data = [Convert]::ToBase64String([Security.Cryptography.ProtectedData]::Protect($d, $ent, $scope)) } }
    "unprotect" { $d = [Convert]::FromBase64String([string]$msg.data); Reply @{ ok = $true; data = [Convert]::ToBase64String([Security.Cryptography.ProtectedData]::Unprotect($d, $ent, $scope)) } }
    "update"    {
      # ξαναξεκινά το πρόγραμμα αυτόματων ενημερώσεων του ef-bot, ΜΟΝΟ αν δεν τρέχει ήδη (καμία άλλη εντολή δεν εκτελείται)
      $pf = Join-Path $PSScriptRoot "updater-path.txt"
      if (-not (Test-Path -LiteralPath $pf)) { Reply @{ ok = $false; err = "δεν είναι γνωστός ο φάκελος του ef-bot (τρέξτε μία φορά το efbot-update.bat)" }; break }
      $bat = ([IO.File]::ReadAllText($pf)).Trim()
      if (-not ($bat -match 'efbot-update\.bat$') -or -not (Test-Path -LiteralPath $bat)) { Reply @{ ok = $false; err = "λάθος διαδρομή προγράμματος ενημέρωσης" }; break }
      $run = @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -match 'efbot-update\.ps1' }).Count
      if ($run -gt 0) { Reply @{ ok = $true; already = $true }; break }
      $cl = "cmd.exe /c start `"ef-bot`" /min `"$bat`""
      $r = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = $cl; CurrentDirectory = $env:TEMP }
      if ($r.ReturnValue -ne 0) { Reply @{ ok = $false; err = "δεν ξεκίνησε (κωδικός $($r.ReturnValue))" }; break }
      Reply @{ ok = $true; started = $true }
    }
    { $_ -eq "hidewin" -or $_ -eq "showwin" } {
      # Κρύβει/δείχνει τα παράθυρα του bot (τίτλος με σήμανση) — ούτε στη γραμμή εργασιών. Μόνο παράθυρα του chrome.exe.
      Add-Type -TypeDefinition @"
using System; using System.Text; using System.Collections.Generic; using System.Runtime.InteropServices;
public static class EfWin {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc f, IntPtr l);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  public static List<long> Find(string m) { var r = new List<long>(); EnumWindows(delegate (IntPtr h, IntPtr l) { var sb = new StringBuilder(512); GetWindowText(h, sb, 512); if (sb.ToString().Contains(m)) r.Add(h.ToInt64()); return true; }, IntPtr.Zero); return r; }
}
"@
      $hs = @()
      if ($msg.h) { $hs = @($msg.h | ForEach-Object { [long]$_ }) }
      elseif (([string]$msg.marker).Length -ge 6) { $hs = @([EfWin]::Find([string]$msg.marker)) }
      $done = @()
      foreach ($h in $hs) {
        $pid0 = [uint32]0; [EfWin]::GetWindowThreadProcessId([IntPtr]$h, [ref]$pid0) | Out-Null
        $pn = (Get-Process -Id $pid0 -ErrorAction SilentlyContinue).ProcessName
        if ($pn -ne "chrome") { continue }
        [EfWin]::ShowWindow([IntPtr]$h, $(if ([string]$msg.op -eq "hidewin") { 0 } else { 6 })) | Out-Null
        $done += $h
      }
      Reply @{ ok = $true; n = $done.Count; h = $done }
    }
    "sysinfo"   {
      # ΜΟΝΟ ανάγνωση: φόρτος του υπολογιστή (για διάγνωση «κολλάει»)
      $os = Get-CimInstance Win32_OperatingSystem; $cpu = (Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average
      $P = @(Get-Process -ErrorAction SilentlyContinue)
      $grp = { param($n) $x = @($P | Where-Object { $_.ProcessName -eq $n }); @{ n = $x.Count; mb = [int](($x | Measure-Object WorkingSet64 -Sum).Sum / 1MB); cpu = [int](($x | Measure-Object CPU -Sum).Sum) } }
      $top = @($P | Sort-Object WorkingSet64 -Descending | Select-Object -First 8 | ForEach-Object { @{ p = $_.ProcessName; mb = [int]($_.WorkingSet64 / 1MB); cpu = [int]$_.CPU } })
      $dk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'" -ErrorAction SilentlyContinue
      Reply @{ ok = $true; diskFreeGb = $(if ($dk) { [int]($dk.FreeSpace / 1GB) } else { -1 }); diskGb = $(if ($dk) { [int]($dk.Size / 1GB) } else { 0 }); cpu = [int]$cpu; ramMb = [int]($os.TotalVisibleMemorySize / 1024); freeMb = [int]($os.FreePhysicalMemory / 1024); upH = [int](((Get-Date) - $os.LastBootUpTime).TotalHours); chrome = (& $grp "chrome"); ps = (& $grp "powershell"); top = $top; cores = [Environment]::ProcessorCount }
    }
    default     { Reply @{ ok = $false; err = "unknown op" } }
  }
} catch {
  try { Reply @{ ok = $false; err = $_.Exception.Message } } catch {}
}
exit 0
