﻿# 🗂 «Αρχείο Ασθενών» (server βάσης κλινικής) — λειτουργίες για το βοηθητικό ef-bot (καλείται από το efbot-vault.ps1).
# Χωριστό αρχείο: ένα λάθος εδώ δεν επηρεάζει τις άλλες λειτουργίες του βοηθητικού. Επιστρέφει ΕΝΑ hashtable.
param($Msg)
$ErrorActionPreference = "Stop"
$root = Join-Path $env:LOCALAPPDATA "PdxArchive"; $app = Join-Path $root "app"
function DbShortcut {
  # εικονίδιο «Αρχείο Ασθενών»: ως κανονική εφαρμογή (Νίκος CT Viewer --archive)· αλλιώς Edge σε μορφή εφαρμογής
  $ws = New-Object -ComObject WScript.Shell
  $dl = Join-Path ([Environment]::GetFolderPath("Desktop")) "Αρχείο Ασθενών.lnk"
  $nct = Join-Path $env:LOCALAPPDATA "NikosCTViewer\app"; $exe = Join-Path $nct "NikosCTViewer.exe"
  if (-not (Test-Path -LiteralPath $exe)) { $f = Get-ChildItem -LiteralPath $nct -Recurse -Filter "NikosCTViewer.exe" -ErrorAction SilentlyContinue | Select-Object -First 1; if ($f) { $exe = $f.FullName } }
  $ico = Join-Path (Split-Path -Parent $exe) "resources\app\archive.ico"
  if ((Test-Path -LiteralPath $exe) -and (Test-Path -LiteralPath $ico)) {
    $sc = $ws.CreateShortcut($dl); $sc.TargetPath = $exe; $sc.Arguments = "--archive"; $sc.WorkingDirectory = (Split-Path -Parent $exe); $sc.IconLocation = "$ico,0"; $sc.Save()
    $pl = Join-Path ([Environment]::GetFolderPath("Programs")) "Αρχείο Ασθενών.lnk"; $sc = $ws.CreateShortcut($pl); $sc.TargetPath = $exe; $sc.Arguments = "--archive"; $sc.WorkingDirectory = (Split-Path -Parent $exe); $sc.IconLocation = "$ico,0"; $sc.Save()
    return "εικονίδιο: εφαρμογή (Νίκος CT Viewer --archive)"
  }
  $cfg = Get-Content -LiteralPath (Join-Path $root "config.json") -Raw | ConvertFrom-Json
  $edge = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
  if (-not $edge) { return "⚠ ούτε Νίκος CT Viewer 1.0.8+ ούτε Edge για το εικονίδιο" }
  $sc = $ws.CreateShortcut($dl); $sc.TargetPath = $edge
  $sc.Arguments = "--app=http://127.0.0.1:8780/app?k=" + [uri]::EscapeDataString([string]$cfg.key) + " --user-data-dir=""" + (Join-Path $root "edge") + """"
  $sc.IconLocation = "$edge,0"; $sc.Save()
  return "εικονίδιο: Edge (ο Νίκος CT Viewer δεν έχει ακόμα την 1.0.8)"
}
function DbInstall {
  # εγκατάσταση/ενημέρωση στον %LOCALAPPDATA%\PdxArchive\app — τα δεδομένα (archive.db, dicom\, config.json) ΔΕΝ αγγίζονται
  $st = New-Object System.Collections.ArrayList
  try {
    $db = "https://paradoxarto.urol.workers.dev/dbapp"
    $info = Invoke-RestMethod -Uri ("$db/version.json?t=" + [DateTimeOffset]::Now.ToUnixTimeSeconds()) -UseBasicParsing -TimeoutSec 30
    [void]$st.Add("διαθέσιμη " + $info.version)
    New-Item -ItemType Directory -Path $root -Force | Out-Null
    $tmp = Join-Path $env:TEMP ("pdxdb-" + [guid]::NewGuid().ToString("N")); New-Item -ItemType Directory -Path $tmp -Force | Out-Null
    try {
      $zip = Join-Path $tmp "app.zip"; $out = [IO.File]::Create($zip); $t0 = Get-Date
      try { foreach ($pt in $info.parts) { $pf = Join-Path $tmp "part"; Invoke-WebRequest -Uri "$db/$pt" -OutFile $pf -UseBasicParsing -TimeoutSec 300 | Out-Null; $bb = [IO.File]::ReadAllBytes($pf); $out.Write($bb, 0, $bb.Length) } } finally { $out.Close() }
      [void]$st.Add(("κατέβηκε σε {0:N0}″" -f ((Get-Date) - $t0).TotalSeconds))
      $h = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLower(); if ($h -ne ([string]$info.sha256).ToLower()) { throw "λάθος sha256" }
      $new = Join-Path $tmp "x"; Add-Type -AssemblyName System.IO.Compression.FileSystem; [IO.Compression.ZipFile]::ExtractToDirectory($zip, $new)
      if (-not (Test-Path -LiteralPath (Join-Path $new "node.exe"))) { throw "λείπει το node.exe από το πακέτο" }
      # σταμάτημα του παλιού server: πρώτα «stop.flag» για να μην τον ξαναξεκινήσει ο φύλακας
      if (Test-Path -LiteralPath $app) { Set-Content -LiteralPath (Join-Path $app "stop.flag") -Value "1" }
      $procs = @(Get-CimInstance Win32_Process -Filter "Name='node.exe' OR Name='wscript.exe'" -ErrorAction SilentlyContinue | Where-Object { ([string]$_.ExecutablePath) -like "*\PdxArchive\app\*" -or ([string]$_.CommandLine) -like "*PdxArchive\app\start.vbs*" })
      foreach ($p in $procs) { try { Stop-Process -Id $p.ProcessId -Force -ErrorAction Stop; [void]$st.Add("σταμάτησε " + $p.Name) } catch {} }
      Start-Sleep -Seconds 1
      if (Test-Path -LiteralPath $app) { try { Remove-Item -LiteralPath $app -Recurse -Force -ErrorAction Stop } catch { Rename-Item -LiteralPath $app -NewName ("app-old-" + (Get-Date).Ticks) -ErrorAction Stop; [void]$st.Add("ο παλιός φάκελος κλείδωνε → μετονομάστηκε") } }
      Move-Item -LiteralPath $new -Destination $app
      [void]$st.Add("εγκαταστάθηκε " + $info.version)
    } finally { Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue }
    # 💿 8/11: ρόλος υπολογιστή — «satellite» (CD τοπικά → κάθε βράδυ στο δίκτυο → σβήσιμο μετά την επιβεβαίωση του κεντρικού)
    # ΜΟΝΟ αν δοθεί ρητά· ο κεντρικός (Παράθυρο) μένει όπως είναι (χωρίς ρόλο = κεντρικός)
    if (@("satellite", "main") -contains [string]$Msg.role) {
      $cf = Join-Path $root "config.json"
      $o = if (Test-Path -LiteralPath $cf) { Get-Content -LiteralPath $cf -Raw -Encoding UTF8 | ConvertFrom-Json } else { New-Object PSObject }
      $o | Add-Member -NotePropertyName role -NotePropertyValue ([string]$Msg.role) -Force
      if ([string]$Msg.pc) { $o | Add-Member -NotePropertyName pcName -NotePropertyValue ([string]$Msg.pc) -Force }
      [IO.File]::WriteAllText($cf, ($o | ConvertTo-Json -Depth 10), (New-Object Text.UTF8Encoding $false))
      [void]$st.Add("ρόλος: " + [string]$Msg.role + $(if ([string]$Msg.pc) { " (" + [string]$Msg.pc + ")" } else { "" }))
    }
    # εκκίνηση με τα Windows (φάκελος «Εκκίνηση» του χρήστη) και τώρα
    $ws = New-Object -ComObject WScript.Shell
    $vbs = Join-Path $app "start.vbs"; $wscript = Join-Path $env:WINDIR "System32\wscript.exe"
    $sl = Join-Path ([Environment]::GetFolderPath("Startup")) "Αρχείο Ασθενών (server).lnk"
    $sc = $ws.CreateShortcut($sl); $sc.TargetPath = $wscript; $sc.Arguments = '"' + $vbs + '"'; $sc.WorkingDirectory = $app; $sc.WindowStyle = 7; $sc.Save()
    Start-Process -FilePath $wscript -ArgumentList ('"' + $vbs + '"') -WorkingDirectory $app | Out-Null
    $hh = $null; for ($i = 0; $i -lt 20 -and -not $hh; $i++) { Start-Sleep -Milliseconds 750; try { $hh = Invoke-RestMethod -Uri "http://127.0.0.1:8780/health" -UseBasicParsing -TimeoutSec 3 } catch {} }
    if (-not $hh) { return @{ ok = $false; err = "ο server δεν ξεκίνησε (δείτε PdxArchive\server.log)"; steps = @($st) } }
    [void]$st.Add("server σε λειτουργία · " + $hh.patients + " ασθενείς")
    [void]$st.Add((DbShortcut))
    return @{ ok = $true; steps = @($st); patients = $hh.patients; studies = $hh.studies }
  } catch { return @{ ok = $false; err = $_.Exception.Message; steps = @($st) } }
}
function DbCall {
  # αίτημα στον ΤΟΠΙΚΟ server (μόνο 127.0.0.1, μόνο /api/… και /health) με το κλειδί του — για tablet/κινητό μέσω bot
  try {
    $path = [string]$Msg.path; if ($path -notmatch '^/(api/[\w/\-?=&.%]+|health)$') { return @{ ok = $false; err = "μη επιτρεπτή διαδρομή" } }
    $method = ([string]$Msg.method).ToUpper(); if (@("GET", "POST", "DELETE") -notcontains $method) { $method = "GET" }
    $cfg = Get-Content -LiteralPath (Join-Path $root "config.json") -Raw | ConvertFrom-Json
    $hd = @{ "x-pdx-key" = [string]$cfg.key; "x-pdx-user" = ("bot:" + [string]$Msg.who) }
    $body = $null; if ($null -ne $Msg.body) { $body = [Text.Encoding]::UTF8.GetBytes(($Msg.body | ConvertTo-Json -Depth 8 -Compress)) }
    try {
      $r = Invoke-WebRequest -Uri ("http://127.0.0.1:8780" + $path) -Method $method -Headers $hd -Body $body -ContentType "application/json; charset=utf-8" -UseBasicParsing -TimeoutSec 60
      $txt = [Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray())
      return @{ ok = $true; status = [int]$r.StatusCode; json = $txt }
    } catch {
      $resp = $_.Exception.Response; $code = 0; $txt = ""
      if ($resp) { $code = [int]$resp.StatusCode; try { $sr = New-Object IO.StreamReader($resp.GetResponseStream(), [Text.Encoding]::UTF8); $txt = $sr.ReadToEnd() } catch {} }
      if ($code) { return @{ ok = $true; status = $code; json = $txt } }
      return @{ ok = $false; err = "ο server δεν απαντά: " + $_.Exception.Message }
    }
  } catch { return @{ ok = $false; err = $_.Exception.Message } }
}
switch ([string]$Msg.op) {
  "dbinstall" { DbInstall }
  "dbcall"    { DbCall }
  "dbkey"     { try { $cfg = Get-Content -LiteralPath (Join-Path $root "config.json") -Raw | ConvertFrom-Json; @{ ok = $true; key = [string]$cfg.key; port = 8780 } } catch { @{ ok = $false; err = $_.Exception.Message } } }   # 8/11: μία φορά → το bot μιλά απευθείας στο 127.0.0.1 (όχι powershell ανά αίτημα ≈12″)
  "dbshortcut" { try { @{ ok = $true; steps = @((DbShortcut)) } } catch { @{ ok = $false; err = $_.Exception.Message } } }
  default     { @{ ok = $false; err = "unknown db op" } }
}
