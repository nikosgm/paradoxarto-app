importScripts("engine.js?v=" + chrome.runtime.getManifest().version, "vault.js?v=" + chrome.runtime.getManifest().version, "epres.js?v=" + chrome.runtime.getManifest().version, "defaults.js?v=" + chrome.runtime.getManifest().version, "pdxcur.js?v=" + chrome.runtime.getManifest().version, "kmail.js?v=" + chrome.runtime.getManifest().version);
const V = self.EFVault;
const E = self.EFEngine;
// ⏱ όριο χρόνου σε ΚΑΘΕ αίτημα του service worker προς το Medilabi (60″): πριν, ένα κολλημένο αίτημα σταματούσε όλους τους
// ελέγχους εργαστηριακών του υπολογιστή μέχρι επανεκκίνηση. Μόνο αν το αίτημα δεν έχει ήδη δικό του signal.
{ const f0 = self.fetch.bind(self);
  self.fetch = (input, init) => { try { const u = String(typeof input === "string" ? input : (input && input.url) || "");
    if (/\/Medilabi\//i.test(u) && !(init && init.signal) && typeof AbortSignal !== "undefined" && AbortSignal.timeout) init = { ...(init || {}), signal: AbortSignal.timeout(60000) }; } catch (e) {}
    return f0(input, init); }; }
// ✕ Σταμάτημα από το Παραδόχαρτο: όσο τρέχει μια εντολή, ελέγχεται κάθε 4″ αν ακυρώθηκε· τότε κάθε επόμενη αναμονή
// (E.sleep) και κάθε επόμενο βήμα διαδικασίας σταματούν, και το «ακυρώθηκε» δεν αντικαθίσταται από αποτέλεσμα.
let jobAbortId = 0;
// 🪦 εντολές που σταμάτησαν (όριο χρόνου/ακύρωση): ΔΕΝ σβήνονται — όποιος κώδικας τρέχει ακόμα γι' αυτές σταματά στο επόμενο βήμα
self.efDeadJobs = new Set();
// 🎯 στόχευση σε υπολογιστή: payload.only = id υπολογιστή (b + 10–16 χαρακτήρες). Το medlabs έχει only = λίστα ασθενών, τα logins/selftest = συστήματα.
const onlyBotOf = (p) => { const o = p && p.only; return typeof o === "string" && /^b[a-z0-9]{10,16}$/.test(o) ? o : ""; };
// 📜 ιστορικό προσπαθειών: κάθε μεταφορά/επανάληψη κρατά το σφάλμα της (πριν σβηνόταν από την επόμενη)
const attemptsAdd = (p, bot, note) => [...((p && p.attempts) || []), { bot: String(bot || "").slice(-5), v: chrome.runtime.getManifest().version, at: Date.now(), note: String(note || "").slice(0, 400) }].slice(-6);
// ⚡ «Instant»: ΚΑΘΕ σταθερή αναμονή ≥300ms μέσα σε εργασία γίνεται έξυπνη — τελειώνει μόλις η σελίδα (η καρτέλα που
// χειρίστηκε τελευταία το bot) ΑΝΤΙΔΡΑΣΕΙ (αλλαγή DOM / αίτημα / νέα σελίδα) και ΗΣΥΧΑΣΕΙ 150ms. Αν δεν αντιδράσει καθόλου,
// κρατά τον παλιό χρόνο → οι βρόχοι αναμονής (π.χ. «περίμενε σύνδεση έως 60×2″») δεν κονταίνουν. Ποτέ πιο αργό από πριν.
let bgLastTab = 0, bgSmartSaved = 0;
{ const ex0 = chrome.scripting.executeScript.bind(chrome.scripting);
  chrome.scripting.executeScript = (o, ...r) => { try { if (o && o.target && o.target.tabId) bgLastTab = o.target.tabId; } catch (e) {} return ex0(o, ...r); }; }
async function bgSmartSleep(ms, sleep0) {
  const t0 = Date.now(), tab = bgLastTab;
  await sleep0(Math.min(ms, 120));
  let calm = 0;
  while (Date.now() - t0 < ms) {
    const r = await chrome.scripting.executeScript({ target: { tabId: tab, allFrames: true }, args: [t0], func: (t0) => {
      try {
        if (!window.__efMut) { window.__efMut = Date.now(); new MutationObserver(() => { window.__efMut = Date.now(); }).observe(document.documentElement || document, { subtree: true, childList: true, attributes: true, characterData: true }); }
        let busy = document.readyState !== "complete";
        try { if (window.PrimeFaces && PrimeFaces.ajax && PrimeFaces.ajax.Queue && !PrimeFaces.ajax.Queue.isEmpty()) busy = true; } catch (e) {}
        try { if (window.jQuery && jQuery.active > 0) busy = true; } catch (e) {}
        return { busy, act: busy || window.__efMut > t0, q: Date.now() - window.__efMut };
      } catch (e) { return null; }
    } }).catch(() => null);
    const fr = (r || []).map((x) => x && x.result).filter(Boolean);
    if (!fr.length) { await sleep0(Math.max(0, ms - (Date.now() - t0))); return; }   // καρτέλα χάθηκε/άλλαξε: απλή αναμονή
    const act = fr.some((x) => x.act), quiet = fr.every((x) => !x.busy && x.q >= 150);
    if (act && quiet) { if (++calm >= 2) break; } else calm = 0;
    // Τίποτα δεν άλλαξε και τίποτα δεν φορτώνει για 600ms: η σελίδα είναι ήδη έτοιμη → όχι αναμονή «στα τυφλά» ως το τέλος
    if (!act && quiet && Date.now() - t0 >= 600) break;
    await sleep0(70);
  }
  const sv = Math.max(0, ms - (Date.now() - t0)); bgSmartSaved += sv; try { bgTime.saved += sv; } catch (e) {}
}
{ const _sleep0 = E.sleep; E.sleep = (ms) => (((() => { try { return jobRunningId; } catch (e) { return 0; } })() && +ms >= 300 && bgLastTab) ? bgSmartSleep(+ms, _sleep0) : _sleep0(ms)).then(() => { if (jobAbortId) throw new Error("ακυρώθηκε από το Παραδόχαρτο"); }); }

// Άνοιγμα του πλευρικού πάνελ με κλικ στο εικονίδιο ή με Alt+Shift+E
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

// ---------------------------------------------------------------------------
// Μηνύματα από τα κουμπιά μέσα στην εφαρμογή
// ---------------------------------------------------------------------------
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg.type === "emrInput") { emrInputNote(sender.tab).catch(() => {}); return; }
  if (msg.type === "launch" && sender.tab && msg.app) {
    // Από το Παραδόχαρτο: το πάνελ ανοίγει αμέσως (μέσα στο κλικ), μετά πάμε στην καρτέλα του φακέλου
    chrome.sidePanel.open({ windowId: sender.tab.windowId }).catch(() => {});
    launchFromApp(msg.app, sender.tab);
  } else if (msg.type === "launch" && sender.tab) {
    // Πρέπει να κληθεί αμέσως (μέσα στο κλικ του χρήστη), πριν από οποιοδήποτε await
    chrome.sidePanel.open({ tabId: sender.tab.id }).catch(() => {});
    chrome.storage.local.set({
      efbotLaunch: { wfId: msg.wfId || null, view: msg.view || null, tabId: sender.tab.id, ts: Date.now() },
    });
  } else if (msg.type === "comorbPaste" && sender.tab) {
    comorbPaste(msg, sender.tab).then(reply, () => reply({ filled: false }));
    return true;
  } else if (msg.type === "comorbWake") {
    clearTimeout(comorbWakeT); comorbWakeT = setTimeout(() => comorbAutoTick(false).catch(() => {}), 4000);
  } else if (msg.type === "comorbAutoNow") {
    comorbAutoTick(true).then((msg) => reply({ msg }), (e) => reply({ msg: "σφάλμα: " + e.message }));
    return true;
  } else if (msg.type === "openUrl" && sender.tab) {
    openQuickLink(msg.url, sender.tab);
  } else if (msg.type === "monitorNow") {
    monitorTick(true);
    reply({ ok: true });
  } else if (msg.type === "alertsAck") {
    clearAlerts().then(() => reply({ ok: true }));
    return true;
  }
});

// Διαγνώσεις από τον Ατομικό Φάκελο Υγείας → ανοιχτό παράθυρο 🩺 Συννοσηρότητες του Παραδόχαρτου (ίδιος Chrome)
async function comorbPaste(msg, from) {
  let host = ""; try { host = new URL(from.url).host; } catch (e) {}
  if (host !== "doctor.ehealthrecord.gov.gr") return { filled: false };
  const text = String(msg.text || "").slice(0, 20000);
  const { efbot } = await chrome.storage.local.get("efbot");
  const hosts = [...APP_HOSTS, ...String(efbot?.settings?.appHosts || "").split(/[\s,;]+/).filter(Boolean)];
  const tabs = await chrome.tabs.query({ url: hosts.map((h) => `https://${h}/*`) }).catch(() => []);
  for (const t of tabs) {
    try {
      const [r] = await chrome.scripting.executeScript({ target: { tabId: t.id }, world: "MAIN", args: [text],
        func: (text) => {
          const ov = document.getElementById("comorbOverlay");
          if (!ov) return null;
          if (typeof window.pdxComorbAppend === "function") return window.pdxComorbAppend(text, "Ατομικό Φάκελο Υγείας");
          const ta = ov.querySelector("[data-in]"); if (!ta) return null;
          ta.value = (ta.value.trim() ? ta.value.replace(/\s+$/, "") + "\n" : "") + text;
          ta.dispatchEvent(new Event("input", { bubbles: true }));
          return { name: "" };
        } });
      if (r?.result) {
        await chrome.tabs.update(t.id, { active: true }).catch(() => {});
        await chrome.windows.update(t.windowId, { focused: true }).catch(() => {});
        return { filled: true, name: String(r.result.name || "").slice(0, 80) };
      }
    } catch (e) {}
  }
  return { filled: false };
}

// Εξιτήριο από το Παραδόχαρτο. Δεχόμαστε μόνο από τις γνωστές διευθύνσεις της εφαρμογής.
const APP_HOSTS = ["paradoxarto.urol.workers.dev", "paradoxarto.pages.dev", "nikosgm.github.io", "paradoxarto1.netlify.app"];   // 6/11: νέα φιλοξενία GitHub Pages
const APP_URL = "https://paradoxarto.urol.workers.dev/";   // ανοίγει εδώ όταν δεν υπάρχει καρτέλα της εφαρμογής
// Λίστα κωδικών ICD-10 από το Παραδόχαρτο: δεχόμαστε μόνο ό,τι μοιάζει με κωδικό (π.χ. I10, E11.9), χωρίς διπλούς, έως 40
function icdList(x) {
  const a = Array.isArray(x) ? x.map((o) => (o && typeof o === "object" ? o.code : o)) : String(x || "").split(/[\s,;]+/);
  return [...new Set(a.map((c) => String(c || "").trim().toUpperCase()).filter((c) => /^[A-Z]\d\d(\.\d{1,2})?$/.test(c)))].slice(0, 40);
}
const EMR_URL = "https://apps.e-ygeia.gov.gr/*";
const EMR_HOME = "https://apps.e-ygeia.gov.gr/emr-ui/views/home.xhtml";
async function launchFromApp(app, from) {
  const { efbot } = await chrome.storage.local.get("efbot");
  const hosts = [...APP_HOSTS, ...String(efbot?.settings?.appHosts || "").split(/[\s,;]+/).filter(Boolean)];
  let host = "";
  try { host = new URL(from.url).host; } catch (e) {}
  if (!hosts.includes(host)) return;
  const clean = (x, n) => String(x || "").slice(0, n);
  const data = { name: clean(app.name, 120), text: clean(app.text, 20000), therapist: clean(app.therapist, 40), therapistName: "", extraDx: icdList(app.extraDx).join("\n") };
  // Το Παραδόχαρτο κρατά τον θεράποντα ως συντομογραφία (π.χ. «Αδ») και το επώνυμο στις ρυθμίσεις του (π.χ. «Αδαμάκη»)
  if (data.therapist) {
    try {
      const [r] = await chrome.scripting.executeScript({ target: { tabId: from.id }, world: "MAIN", args: [data.therapist],
        func: (c) => { try { return String(((typeof DISCHARGE_CFG !== "undefined" && DISCHARGE_CFG.therapists) || {})[c] || ""); } catch (e) { return ""; } } });
      data.therapistName = clean(r?.result, 60);
    } catch (e) {}
  }
  // Καρτέλα του φακέλου, ή της σελίδας σύνδεσης του (login.e-ygeia.gov.gr) όταν έχει λήξει η σύνδεση
  // «Δικό του παράθυρο»: το bot δουλεύει σε παράθυρο ανώνυμης περιήγησης (ξεχωριστή σύνδεση στον φάκελο),
  // ώστε ο χρήστης να δουλεύει ελεύθερα στον δικό του φάκελο χωρίς να αλλάζει ο «τρέχων ασθενής» του bot.
  const wantIncog = !!efbot?.settings?.botIncog;
  const incog = wantIncog && await chrome.extension.isAllowedIncognitoAccess().catch(() => false);
  // κοινό παράθυρο του bot ανοιχτό: ο γιατρός στον υπολογιστή ΔΕΝ δουλεύει μέσα στη σύνδεση του bot
  const shL = !incog ? await sharedGet() : null;
  if (shL && !jobsBusy && !comorbBusy) await sharedLogout("άνοιγμα από το Παραδόχαρτο στον υπολογιστή");
  const shW = shL && (await sharedGet())?.winId;
  let emr = (await chrome.tabs.query({ url: [EMR_URL, "https://login.e-ygeia.gov.gr/*"] })).filter((t) => !!t.incognito === incog && t.windowId !== shW)[0];
  if (!emr) {
    if (incog) {
      const win = await chrome.windows.create({ url: EMR_HOME, incognito: true, focused: false, state: "minimized" }).catch(() => null);
      emr = win?.tabs?.[0] || null;
    } else {
      // Δεν υπάρχει ανοιχτός φάκελος: νέα καρτέλα (η σύνδεση γίνεται από το πάνελ)
      emr = await chrome.tabs.create({ url: EMR_HOME, active: true, windowId: from.windowId }).catch(() => null);
    }
    if (emr) await E.waitLoaded(emr.id, 45000, () => false).catch(() => {});
  }
  if (incog) {
    // το πάνελ μένει στο παράθυρο του χρήστη· το παράθυρο του bot δεν έρχεται μπροστά
    await chrome.sidePanel.open({ windowId: from.windowId }).catch(() => {});
  } else if (emr) {
    await chrome.tabs.update(emr.id, { active: true });
    if (emr.windowId !== from.windowId) {
      await chrome.windows.update(emr.windowId, { focused: true }).catch(() => {});
      await chrome.sidePanel.open({ windowId: emr.windowId }).catch(() => {});
    }
  }
  await chrome.storage.local.set({ efbotLaunch: { wfId: "exitirio", app: data, tabId: emr?.id || null, noEmr: !emr, incog, incogDenied: wantIncog && !incog, ts: Date.now() } });
}

// ---------------------------------------------------------------------------
// Αυτόματη ανανέωση: όταν το πρόγραμμα ενημέρωσης (Windows) αντικαταστήσει τα αρχεία στον φάκελο,
// η επέκταση το βλέπει (διαβάζει το manifest.json από τον δίσκο) και ξαναφορτώνεται μόνη της.
// Δεν ανανεώνεται όσο τρέχει διαδικασία.
// ---------------------------------------------------------------------------
async function selfUpdateCheck() {
  try {
    const disk = await (await fetch(chrome.runtime.getURL("manifest.json"), { cache: "no-store" })).json();
    const mine = chrome.runtime.getManifest().version;
    if (!disk.version || disk.version === mine) return false;
    const { efbotLock: l } = await chrome.storage.session.get("efbotLock");
    if (l && Date.now() - l.ts < 8 * 60000) return false; // τρέχει κάτι: ξαναδοκιμάζουμε στον επόμενο έλεγχο
    // ⏳ καμία ενημέρωση πάνω σε εργασία (κύρια/δεύτερη/γρήγορη λωρίδα) ή σε έγκριση που τρέχει (έτσι χάθηκε η #304)
    if (jobRunningId || sideRunningId || fastN > 0) return false;
    { const { efbotApJob: aj } = await chrome.storage.local.get("efbotApJob"); if (aj && Date.now() - (aj.at || 0) < 10 * 60000) return false; }
    await chrome.storage.local.set({ efbotUpdated: { from: mine, to: disk.version, ts: Date.now() }, efbotReinject: disk.version });
    chrome.runtime.reload();
    return true;
  } catch (e) { return false; }
}

// 🙈 Παράθυρα του bot ΑΟΡΑΤΑ (ούτε στη γραμμή εργασιών): σήμανση στον τίτλο της ενεργής καρτέλας → το βοηθητικό των Windows
// τα κρύβει (ShowWindow SW_HIDE). Όλα τα ανώνυμα παράθυρα + όσα άνοιξε το bot. Η σελίδα συνεχίζει να δουλεύει κανονικά.
const WIN_MARK = "[efbot-hidden]";
const _winCreate = chrome.windows.create.bind(chrome.windows);
chrome.windows.create = async (o) => { const w = await _winCreate(o); if (w && w.id != null) { try { const { efbotOwnWins: a = [] } = await chrome.storage.session.get("efbotOwnWins"); await chrome.storage.session.set({ efbotOwnWins: [...new Set([...a, w.id])].slice(-30) }); } catch (e) {} setTimeout(() => botHideWindows().catch(() => {}), 2500); } return w; };
let hideBusy = false;
async function botHideWindows() {
  if (hideBusy) return; hideBusy = true;
  try {
    const { efbotNoHide } = await chrome.storage.local.get("efbotNoHide"); if (efbotNoHide && Date.now() - efbotNoHide < 15 * 60000) return;
    const { efbotOwnWins: own = [], efbotHidWins: hid = {} } = await chrome.storage.session.get(["efbotOwnWins", "efbotHidWins"]);
    const wins = await chrome.windows.getAll({ populate: true }).catch(() => []);
    const alive = new Set(wins.map((w) => w.id)); for (const k of Object.keys(hid)) if (!alive.has(+k)) delete hid[k];
    // 7/11: μετά από επανεκκίνηση των Windows το Chrome ξανανοίγει τα παράθυρα του bot (νέα id, δεν είναι πια «δικά μας») →
    // για 5′ από την εκκίνηση κρύβονται ΚΑΙ τα παράθυρα που έχουν ΜΟΝΟ σελίδες του bot (Παραδόχαρτο/ΝΠΣ/ΑΗΦΥ/e-prescription/Medilabi)
    const { efbotBootAt = 0 } = await chrome.storage.session.get("efbotBootAt");
    const botOnly = (w) => (w.tabs || []).length > 0 && (w.tabs || []).every((t) => { const u = String(t.url || t.pendingUrl || ""); return !u || /^chrome:\/\/newtab/.test(u) || APP_HOSTS.some((h) => u.includes(h)) || CLIN_HOSTS.test(u) || /laiko|emr-ui|172\.16\./i.test(u); });
    const todo = wins.filter((w) => (w.incognito || own.includes(w.id) || (Date.now() - efbotBootAt < 5 * 60000 && botOnly(w))) && !hid[w.id] && w.type === "normal");
    if (!todo.length) { await chrome.storage.session.set({ efbotHidWins: hid }); return; }
    for (const w of todo) {
      const t = (w.tabs || []).find((x) => x.active); if (!t) continue;
      await chrome.scripting.executeScript({ target: { tabId: t.id }, args: [WIN_MARK], func: (m) => { if (!document.title.startsWith(m)) document.title = m + " " + document.title; } }).catch(() => {});
    }
    await new Promise((r) => setTimeout(r, 400));
    const r = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "hidewin", marker: WIN_MARK }).catch((e) => ({ ok: false, err: e.message }));
    if (r && r.ok && r.n) for (const w of todo) hid[w.id] = (r.h || []);
    await chrome.storage.session.set({ efbotHidWins: hid, efbotHideRes: { at: Date.now(), ok: !!(r && r.ok), n: (r && r.n) || 0, err: (r && r.err) || "" } });
    // ο τίτλος ξαναγίνεται κανονικός (το παράθυρο μένει κρυφό)
    for (const w of todo) { const t = (w.tabs || []).find((x) => x.active); if (t) chrome.scripting.executeScript({ target: { tabId: t.id }, args: [WIN_MARK], func: (m) => { if (document.title.startsWith(m)) document.title = document.title.slice(m.length + 1); } }).catch(() => {}); }
  } finally { hideBusy = false; }
}
// να φανεί ξανά (π.χ. χρειάζεται σύνδεση με το χέρι): όλα τα κρυμμένα
async function botShowWindows() {
  const { efbotHidWins: hid = {} } = await chrome.storage.session.get("efbotHidWins");
  const h = [...new Set(Object.values(hid).flat())];
  if (h.length) await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "showwin", h }).catch(() => {});
  await chrome.storage.session.set({ efbotHidWins: {} });
}
// ⏰ χρονόμετρο ΜΟΝΟ αν δεν υπάρχει ήδη (ή άλλαξε η περίοδος). Πριν, κάθε «ξύπνημα» του service worker το ξαναδημιουργούσε
// και μηδένιζε την αντίστροφη μέτρηση → τα 5΄/15΄/60΄ δεν χτυπούσαν ποτέ (π.χ. καμία ξαναδοκιμή συννοσηροτήτων από 4/11 05:16).
function alarmEnsure(name, o) { chrome.alarms.get(name).then((a) => { if (!a || a.periodInMinutes !== o.periodInMinutes) chrome.alarms.create(name, o); }).catch(() => chrome.alarms.create(name, o)); }
alarmEnsure("efbot-hidewin", { delayInMinutes: 0.2, periodInMinutes: 0.5 });
chrome.runtime.onStartup.addListener(() => { chrome.storage.session.set({ efbotBootAt: Date.now() }).catch(() => {}); for (const ms of [1500, 4000, 9000, 20000]) setTimeout(() => botHideWindows().catch(() => {}), ms); });
chrome.windows.onCreated.addListener((w) => { if (w && w.type === "normal") setTimeout(() => botHideWindows().catch(() => {}), 1200); });   // κρύψιμο αμέσως (όχι σε 30″)
chrome.alarms.onAlarm.addListener((a) => { if (a.name === "efbot-hidewin") botHideWindows().catch(() => {}); });
// 7/11: το Netlify καταργείται — όποια καρτέλα Παραδόχαρτου είναι ακόμα στο netlify πάει στη νέα διεύθυνση (ίδια σελίδα/hash)
async function netlifyMigrate() {
  try { const ts = await chrome.tabs.query({ url: "https://paradoxarto1.netlify.app/*" });
    for (const t of ts) { const u = new URL(t.url); await chrome.tabs.update(t.id, { url: "https://paradoxarto.urol.workers.dev" + u.pathname.replace(/\/index\.html$/, "/") + u.search + u.hash }).catch(() => {}); }
    return ts.length; } catch (e) { return 0; } }
alarmEnsure("efbot-netlify", { delayInMinutes: 0.3, periodInMinutes: 30 });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === "efbot-netlify") netlifyMigrate(); });
chrome.runtime.onStartup.addListener(() => netlifyMigrate());

// 🖨 Μετά την καταχώρηση το Medilabi ανοίγει αναδυόμενο PrintHtml.aspx (εκτύπωση A4). Τα barcode φεύγουν ήδη στον Zebra
// (localhost:8000/printorder) → το παράθυρο A4 κλείνει αμέσως, ΜΟΝΟ όταν ανοίγει από τα παράθυρα του bot (όχι του γιατρού).
const isImgTest = (t) => { const u = String(t || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase(); return /^[ΑA]\/[ΑA]|ΑΚΤΙΝΟΓΡ|ΑΚΤΙΝΟΣΚ|^XR\b|^CT\b|ΑΞΟΝΙΚ|ΤΟΜΟΓΡΑΦ|ΥΠΕΡΗΧ|^U\/?S\b|TRIPLEX|DOPPLER|MRI|ΜΑΓΝΗΤ|ΣΠΙΝΘΗΡ|SPECT|ΠΥΕΛΟΓΡ|ΚΥΣΤΕΟΓΡ|ΟΥΡΗΘΡΟΓΡ/.test(u); };
let printA4Want = null, printA4Busy = new Set();
// 🖨 A4: παίρνει το HTML της σελίδας εκτύπωσης και το στέλνει στο βοηθητικό Windows → τυπώνεται χωρίς παράθυρο στον εκτυπωτή A4
// (όχι Zebra/ετικέτες/PDF). Αν το βοηθητικό δεν μπορεί: η σελίδα μένει ανοιχτή με το παράθυρο εκτύπωσης του Chrome.
async function botPrintA4(tabId) {
  if (printA4Busy.has(tabId)) return; printA4Busy.add(tabId);
  try {
    let html = "";
    for (let i = 0; i < 30 && !html; i++) { await E.sleep(500); const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: async () => {
      if (document.readyState !== "complete" || !document.body || document.body.innerText.trim().length < 20) return "";
      // εικόνες (barcode/λογότυπο) και στυλ μέσα στη σελίδα: το προφίλ εκτύπωσης δεν έχει τη σύνδεση του Medilabi
      const d2u = (b) => new Promise((ok) => { const fr = new FileReader(); fr.onload = () => ok(fr.result); fr.onerror = () => ok(""); fr.readAsDataURL(b); });
      const doc = document.documentElement.cloneNode(true);
      { const c0 = [...document.querySelectorAll("canvas")], c1 = [...doc.querySelectorAll("canvas")]; c1.forEach((c, i) => { try { const im = document.createElement("img"); im.src = c0[i].toDataURL(); im.style.cssText = c0[i].style.cssText; im.width = c0[i].width; im.height = c0[i].height; c.replaceWith(im); } catch (e) {} }); }
      for (const im of doc.querySelectorAll("img[src]")) { try { const b = await (await fetch(new URL(im.getAttribute("src"), location.href), { credentials: "include" })).blob(); const u = await d2u(b); if (u) im.setAttribute("src", u); } catch (e) {} }
      for (const l of doc.querySelectorAll("link[rel~=stylesheet][href]")) { try { const t = await (await fetch(new URL(l.getAttribute("href"), location.href), { credentials: "include" })).text(); const st = document.createElement("style"); st.textContent = t; l.replaceWith(st); } catch (e) {} }
      doc.querySelectorAll("script").forEach((x) => x.remove());
      return "<!doctype html>" + doc.outerHTML.replace(/<head([^>]*)>/i, '<head$1><meta charset="utf-8"><base href="' + location.href.replace(/"/g, "") + '">');
    } }).catch(() => [null]); html = (r && r.result) || ""; }
    if (!html) throw new Error("η σελίδα εκτύπωσης δεν φόρτωσε");
    const { efbot: st } = await chrome.storage.local.get("efbot").catch(() => ({}));
    const want = (st && st.settings && st.settings.a4Printer) || "";
    const r = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "printhtml", html, printer: want }).catch((e) => ({ ok: false, err: e.message }));
    printA4Log = { at: Date.now(), ok: !!(r && r.ok), printer: (r && r.printer) || "", err: (r && r.err) || "" };
    if (r && r.ok) { await chrome.tabs.remove(tabId).catch(() => {}); notify("🖨 Παραπεμπτικό απεικονιστικής", "Στάλθηκε στον εκτυπωτή " + (r.printer || "")); return; }
    await chrome.scripting.executeScript({ target: { tabId }, func: () => setTimeout(() => window.print(), 300) }).catch(() => {});
    const t = await chrome.tabs.get(tabId).catch(() => null); if (t) { await chrome.windows.update(t.windowId, { focused: true, state: "normal" }).catch(() => {}); await chrome.tabs.update(tabId, { active: true }).catch(() => {}); }
    notify("🖨 Πατήστε «Εκτύπωση»", "Δεν βρέθηκε έτοιμος εκτυπωτής A4 αυτόματα: " + ((r && r.err) || ""));
  } catch (e) { printA4Log = { at: Date.now(), ok: false, err: String(e && e.message || e) }; }
  finally { printA4Busy.delete(tabId); }
}
let printA4Log = null;
async function botClosePrintPopup(tabId, url) {
  if (!/\/common\/PrintHtml\.aspx/i.test(url || "")) return;
  const t = await chrome.tabs.get(tabId).catch(() => null); if (!t) return;
  const w = await chrome.windows.get(t.windowId).catch(() => null);
  const { efbotOwnWins: own = [] } = await chrome.storage.session.get("efbotOwnWins").catch(() => ({}));
  let opBot = false;
  if (t.openerTabId) { const o = await chrome.tabs.get(t.openerTabId).catch(() => null); if (o) { const ow = await chrome.windows.get(o.windowId).catch(() => null); opBot = !!(ow && (ow.incognito || own.includes(ow.id))); } }
  if (!((w && (w.incognito || own.includes(w.id))) || opBot)) return;
  if (printA4Want && Date.now() < printA4Want.until) { printA4Want.until = Date.now() + 20000; return botPrintA4(tabId); }
  await chrome.tabs.remove(tabId).catch(() => {});
  try { const { efbotPrintClosed: n = 0 } = await chrome.storage.session.get("efbotPrintClosed"); await chrome.storage.session.set({ efbotPrintClosed: n + 1 }); } catch (e) {}
}
chrome.tabs.onCreated.addListener((t) => { botClosePrintPopup(t.id, t.pendingUrl || t.url).catch(() => {}); });
chrome.tabs.onUpdated.addListener((id, ch) => { if (ch.url) botClosePrintPopup(id, ch.url).catch(() => {}); });

// 📡 ΖΩΝΤΑΝΟΣ; ΚΑΤ' ΕΠΙΚΛΗΣΗ (ping/pong), ΟΧΙ περιοδικό σήμα: κανάλι Realtime «efbot-ping» στη σελίδα του Παραδόχαρτου.
// Ping → κάθε σελίδα ρωτά ΤΟ ΙΔΙΟ ΤΟ bot (service worker) → pong με {bot, cur, side, v}. Παγωμένο bot = δεν απαντά.
// 🚑 Ανάληψη: εργασία «running» άλλου υπολογιστή πάνω από το όριο του είδους της → ping· αν ο κάτοχος δεν απαντήσει σε 3″,
// ή απαντήσει ότι ΔΕΝ την τρέχει, ή την τρέχει >2× το όριο → ξαναμπαίνει αμέσως για άλλο bot. Στο «running» κανένα τελικό κουμπί.
const JOB_LIMIT_S = { npsdx: 420, medcat2: 260, medlabs: 180, order: 120, orderprep: 90, medqprobe: 150, medcat: 240, discharge: 180, consult: 150, rx: 240, rxname: 120, ehrlabs: 240, ehrdx: 240, comorb: 300, evoradimg: 150, evoradfind: 120, clinicview: 240, emrlistprobe: 120, emrnetprobe: 150, bxpdf: 120, medbx: 180, logins: 300, epaccs: 900, npsprogmap: 480, selftest: 600, bxscan: 1200, imgmap: 900, imgget: 900, fsls: 180, fsfind: 180, fsclaude: 600, orsubmit: 120, stt: 600, imgdir: 180 };
chrome.alarms.clear("efbot-hb").catch(() => {});   // το περιοδικό σήμα της 0.18.27 καταργήθηκε
// 🧭 ΣΥΝΤΟΝΙΣΤΗΣ: ο υπολογιστής με τη «μίσθωση» μοιράζει τις νέες εργασίες. Ρωτά ΟΛΑ τα bot (ping, 1,5″) τι κάνουν
// (ποια εργασία, ποιον ασθενή έχουν ανοιχτό, αν έχουν έτοιμη φόρμα, αν βλέπουν τα αρχεία) και γράφει payload.assign = ο
// καταλληλότερος. Οι άλλοι παίρνουν ΜΟΝΟ ό,τι τους ανατέθηκε· αν ο αποδέκτης δεν την πάρει σε 12″, ξαναμοιράζεται.
// Χωρίς συντονιστή (έπεσε) → μετά από 8″ την παίρνει όποιος είναι ελεύθερος, όπως πριν. Καμία περιοδική εγγραφή.
// ✋ «κράτηση»: όσο ένα bot έχει φόρμα σε έλεγχο, περιμένουν οι εργασίες με καρτέλες (όχι αρχεία/σαρώσεις· με μόνο rx/ref σε έλεγχο, μόνο οι e-prescription)
const HOLD_FREE = /^(fsls|fsfind|fsclaude|orsubmit|stt|imgdir|imgget|imgmap|bxscan|medbx|bxpdf|medmsgprobe|ctremote|pdxdb|pdxsync|kmail)$/, HOLD_EPK = /^(rx|ep|ref|selftest|logins|cred|botcfg|selfupdate)/;
const heldFor = (b, j) => !!(b && +b.held > 0 && !HOLD_FREE.test(j.kind) && !(+b.heldRx > 0 && !HOLD_EPK.test(j.kind)));
let holdNow = 0, holdNowRx = false;
const NPS_KINDS = /^(npsepmap|order|orderprep|discharge|consult|consultcat|clinicview|emrlistprobe|emrnetprobe|medqprobe|medcat|medcat2|medprof|npsenrich|npslistdiag|npslist|comorb|ehrdocs|npsmap|npsdxmap|npsprogmap|npsdx|npspat)$/;
async function coordTick(jobs) {
  if (!(await leaseHeld().catch(() => false))) return;
  const now = Date.now();
  // 8/11: παραγγελία/προετοιμασία με «εκτύπωση σε» → την παίρνει ΚΑΤΕΥΘΕΙΑΝ ο υπολογιστής εκτύπωσης (mine)· ο συντονιστής δεν κάνει ping (1,5″) γι' αυτήν
  const cand = jobs.filter((j) => j.status === "new" && !(FAST_LANE.test(j.kind) || (j.kind === "medlabs" && ((j.payload || {}).only || []).length))  && !(+((j.payload || {}).notBefore || 0) > now) && !(/^(order|orderprep)$/.test(j.kind) && (j.payload || {}).printAt));
  if (!cand.length) return;
  const pongs = await botPingAll(1500); if (!pongs || !pongs.length) return;
  const me = await botId();
  const bots = pongs.filter((x) => x.hosp && x.ready);
  if (!bots.length) return;
  const by = {}; for (const b of bots) by[b.bot] = b;
  const SIDE0 = /^(fsls|fsfind|imgdir|imgget|imgmap)$/;
  const busyFor = (b, j) => !b || (SIDE0.test(j.kind) ? !!(b.side && b.side !== j.id) : (!!(b.cur && b.cur !== j.id) || +b.tick > 4000 || heldFor(b, j)));
  // 🧭 ΑΜΕΣΗ ανακατανομή (όχι αναμονή): χωρίς ανάθεση, ή ο αποδέκτης δεν απαντά / είναι απασχολημένος, ή δεν την πήρε σε 3″
  const todo = cand.filter((j) => { const p = j.payload || {}; return !p.assign || busyFor(by[p.assign], j) || now - +(p.assignAt || 0) > 3000; });
  if (!todo.length) return;
  const load = {}; for (const b of bots) load[b.bot] = (b.cur ? 1 : 0) + (+b.tick > 4000 ? 1 : 0);
  const SIDE = /^(fsls|fsfind|imgdir|imgget|imgmap)$/;
  for (const j of todo) {
    const p = j.payload || {}, av = p.avoid || [], nm = String(j.name || "");
    let best = null, bs = -1e9;
    // 🖨 «εκτύπωση σε» (Γωνιακός/Μεσαίος/Πόρτα): η παραγγελία γίνεται ΜΟΝΟ σε εκείνον τον υπολογιστή (εκεί βγαίνει το barcode)·
    // αν δεν απαντά για 25″, σε όποιον άλλον (σημειώνεται στο αποτέλεσμα)
    const pinned = p.printAt && /^(order|orderprep)$/.test(j.kind) ? String(p.printAt) : "";
    const pinOk = pinned && bots.some((b) => b.bot === pinned);
    const pinSeen = pinned && Date.now() - (pongSeen.get(pinned) || 0) < 10 * 60000;   // 6/11: νεκρός κωδικός (επανεγκατάσταση) → καμία αναμονή
    if (pinned && !pinOk && pinSeen && now - Date.parse(j.created_at) < 25000) continue;
    const ob = onlyBotOf(p);
    for (const b of bots) {
      if (ob && b.bot !== ob) continue;   // 🎯 μόνο ο υπολογιστής που ζητήθηκε
      if (av.includes(b.bot)) continue;
      if (pinOk && b.bot !== pinned) continue;
      if (Array.isArray(p.epSkip) && p.epSkip.length && /^(rx|ref|rxname|ep\w+|epres\w*)$/.test(j.kind) && Array.isArray(b.epU) && !b.epU.some((u) => !p.epSkip.includes(String(u).toLowerCase()))) continue;   // 🔑 έχει μόνο λογαριασμούς που απορρίφθηκαν ήδη
      if (p.epUser && /^(rx|ref|rxname)$/.test(j.kind) && Array.isArray(b.epU) && !b.epU.some((u) => String(u).toLowerCase() === String(p.epUser).toLowerCase())) continue;   // 👤 δεν έχει αυτόν τον λογαριασμό e-prescription
      if (p.assign === b.bot && now - +(p.assignAt || 0) > 3000 && bots.length > 1 && !((j.kind === "order" || j.kind === "orderprep") && (b.prep === nm || b.prepBusy === nm))) continue;   // δεν την πήρε: σε άλλον (εκτός αν ετοιμάζει τη φόρμα της)
      let sc = 0;
      if (SIDE.test(j.kind)) { if (!b.fs) continue; sc += b.side ? -80 : 40; }
      else {
        sc -= 1000 * (load[b.bot] || 0);
        if (heldFor(b, j)) sc -= 3000;   // ✋ φόρμα σε έλεγχο εκεί: η ουρά του περιμένει την έγκριση → μόνο αν δεν υπάρχει άλλος
        if (b.side) sc -= 600;
        // 🪶 λίγη ελεύθερη μνήμη (π.χ. υπολογιστής 4 GB) → όχι βαριές δουλειές εκεί, αν υπάρχει άλλος
        if (/^(bxscan|clinicview|comorb|ehrlabs|ehrdx|logins|selftest)$/.test(j.kind) && ((+b.free >= 0 && +b.free < 700) || (+b.ram > 0 && +b.ram <= 4200))) sc -= 700;
        else if (+b.free >= 0 && +b.free < 400) sc -= 300;   // ψάχνει τώρα στον φάκελο απεικονιστικών (βαρύ για τον υπολογιστή) → άλλος, αν υπάρχει
        sc -= 400 * Math.min(3, +b.bad || 0);   // πρόσφατες αποτυχίες σύνδεσης/κολλήματα σε αυτόν τον υπολογιστή   // απασχολημένος: μόνο αν ΟΛΟΙ είναι απασχολημένοι   // η ουρά του κολλημένη σε άλλη δουλειά (έλεγχοι/στατιστικά) — όχι εκεί
        if ((j.kind === "order" || j.kind === "orderprep") && (b.prep === nm || b.prepBusy === nm)) sc += 2500;   // έχει/ετοιμάζει ΤΗ φόρμα αυτού του ασθενή: εκεί, ακόμα κι αν είναι απασχολημένος (με την ετοιμασία της)   // έχει/ετοιμάζει τη φόρμα αυτού του ασθενή
        if (NPS_KINDS.test(j.kind) && b.last === nm) sc += 60;   // ο ασθενής είναι ήδη ανοιχτός εκεί
        // 🔥 πρόσφατη σύνδεση ΝΠΣ (<10′) → πιθανότατα χωρίς ξανά login· παλιά/ποτέ → μόνο αν δεν υπάρχει άλλος
        if (NPS_KINDS.test(j.kind)) sc += (+b.warm >= 0 && +b.warm < 10 * 60000) ? 150 : (+b.warm >= 0 && +b.warm < 30 * 60000) ? 50 : -150;
        if (b.prepBusy === nm && j.kind === "order") sc += 200;
        // ⚡ 8/11: υπολογιστής με ΕΤΟΙΜΗ φόρμα παραγγελίας (άλλου ασθενή/άλλης δουλειάς) → όχι εκεί, αν υπάρχει άλλος (αλλιώς χάνεται η φόρμα: +15″ στην παραγγελία)
        if ((b.prep || b.prepBusy) && !((j.kind === "order" || j.kind === "orderprep") && (b.prep === nm || b.prepBusy === nm))) sc -= NPS_KINDS.test(j.kind) ? 2000 : 300;
      }
      sc += Math.random() * 5;
      if (sc > bs) { bs = sc; best = b; }
    }
    if (!best) continue;
    if (best.bot === p.assign && heldFor(best, j)) continue;   // ✋ μόνος διαθέσιμος και περιμένει έγκριση: καμία ξανα-εγγραφή σε κάθε κύκλο
    const p2 = { ...p, assign: best.bot, assignAt: Date.now() };
    const r = await jobsInApp(async (id, p2) => { try { const x = await sb6.from("oncall_jobs").update({ payload: p2 }).eq("id", id).eq("status", "new").select("id"); return { ok: (x.data || []).length }; } catch (e) { return { err: 1 }; } }, [j.id, p2]).catch(() => null);
    if (r && r.ok) { j.payload = p2; if (!SIDE.test(j.kind)) load[best.bot] = (load[best.bot] || 0) + 1; if (best.bot === me) { if (jobsBusy) jobsAgain = true; else setTimeout(() => jobsTick(true), 50); } else setTimeout(() => coordWake().catch(() => {}), 3300); }
  }
}
// ο συντονισμός ΔΕΝ περιμένει την ουρά του ίδιου υπολογιστή (αν τρέχει μεγάλη εργασία): ξεχωριστή, ελαφριά διαδρομή
let coordBusy = false;
async function coordWake() {
  if (coordBusy || !leaseOk) return; coordBusy = true;
  try {
    const r = await jobsInApp(async () => { try { if (typeof sb6 === "undefined") return { skip: true }; const x = await sb6.from("oncall_jobs").select("id,name_key,name,room,kind,payload,status,created_at,updated_at").eq("status", "new").order("id").limit(30); return { jobs: x.data || [] }; } catch (e) { return { err: 1 }; } }, []).catch(() => null);
    if (r && r.jobs && r.jobs.length) await coordTick(r.jobs);
  } catch (e) {} finally { coordBusy = false; }
}
async function botPingAll(ms) {
  const want = [...pongSeen.values()].filter((t) => Date.now() - t < 10 * 60000).length;   // 6/11: τέλος μόλις απαντήσουν όλοι οι γνωστοί (όχι πάντα 1,5″)
  const r = await jobsInApp(async (ms, want) => { try { if (typeof window.__efbotPingAll !== "function") return { skip: true }; window.__efbotPingWant = want; return { pongs: await window.__efbotPingAll(ms) }; } catch (e) { return { err: String(e) }; } }, [ms || 3000, want]).catch(() => null);
  if (r && Array.isArray(r.pongs)) for (const x of r.pongs) if (x && x.bot) pongSeen.set(x.bot, Date.now());
  return r && Array.isArray(r.pongs) ? r.pongs : null;
}
const pongSeen = new Map();
const SW_T0 = Date.now();   // 8/11: μετά από επανεκκίνηση το pongSeen είναι άδειο → «άγνωστος» ≠ «εκτός» για 10′
async function reclaimCheck(running) {
  if (!running || !running.length) return;
  const me = await botId();
  // ⚡ γρήγορες εργασίες (παραγγελία κ.λπ.): αν ο κάτοχος δεν προχώρησε ΚΑΝΕΝΑ βήμα για 30″ → αμέσως σε άλλο bot (όχι στα 120″)
  const QUICK = /^(order|orderprep|consult|discharge|rxname)$/;
  // 💓 σήμα ζωής της εργασίας (payload.hb, κάθε 20″ από τον κάτοχο) πριν από το updated_at: ζωντανή εργασία δεν ξαναμοιράζεται
  const seen = (j) => Math.max(+((j.payload || {}).hb) || 0, Date.parse(j.updated_at) || 0);
  const over = running.filter((j) => { const p = j.payload || {}, a = (Date.now() - seen(j)) / 1000; return p.bot && p.bot !== me && (a > (JOB_LIMIT_S[j.kind] || 240) || (QUICK.test(j.kind) && a > 90)); });
  if (!over.length) return;
  const pongs = await botPingAll(3000); if (!pongs) return;   // χωρίς κανάλι: δεν μαντεύουμε
  const by = {}; for (const x of pongs) if (x && x.bot) by[x.bot] = x;
  const moved = [];
  for (const j of over) {
    const p = j.payload || {}, own = p.bot, pg = by[own], age = (Date.now() - seen(j)) / 1000, lim = JOB_LIMIT_S[j.kind] || 240;
    const why = !pg ? "ο υπολογιστής " + own.slice(-5) + " δεν απαντά" : (QUICK.test(j.kind) && pg.cur === j.id && +pg.idle > 90000 && !(+p.hb && Date.now() - +p.hb < 90000) && +(p.reclaimed || 0) < 2) ? "ο " + own.slice(-5) + " κόλλησε " + Math.round(pg.idle / 1000) + "″" + (pg.mark ? " μετά το «" + pg.mark + "»" : " στην αρχή") : (pg.cur !== j.id && pg.side !== j.id) ? "ο " + own.slice(-5) + " δεν την τρέχει πια" : age > 2 * lim ? "κόλλησε >" + Math.round(age) + "″ στον " + own.slice(-5) : "";
    if (!why) continue;
    const ob = onlyBotOf(p);
    const r = await jobsInApp(async (id, p, why, ob, att) => { try {
      if (ob) { await sb6.from("oncall_jobs").update({ status: "failed", payload: { ...p, attempts: att }, note: "🎯 για τον " + ob.slice(-5) + ": " + why + " — δεν μεταφέρεται σε άλλον", updated_at: new Date().toISOString() }).eq("id", id).eq("status", "running"); return { ok: 0 }; }
      if (+(p.reclaimed || 0) >= 2) { await sb6.from("oncall_jobs").update({ status: "failed", note: "⚠ κόλλησε σε 3 υπολογιστές — στείλτε ξανά", updated_at: new Date().toISOString() }).eq("id", id).eq("status", "running"); return { ok: 0 }; }
      const p2 = { ...p, attempts: att, reclaimed: +(p.reclaimed || 0) + 1, avoid: [...new Set([...(p.avoid || []), p.bot])] }; delete p2.bot; delete p2.retried;
      const x = await sb6.from("oncall_jobs").update({ status: "new", payload: p2, note: "🚑 " + why + " — πέρασε σε άλλο bot", updated_at: new Date().toISOString() }).eq("id", id).eq("status", "running").select("id");
      return { ok: (x.data || []).length };
    } catch (e) { return { err: String(e) }; } }, [j.id, p, why, ob, attemptsAdd(p, own, "🚑 " + why)]).catch(() => null);
    if (r && r.ok) moved.push(j.id);
  }
  if (moved.length) setTimeout(() => jobsTick(true), 300);
}
// 👀 Μετά από παραγγελία: ο ασθενής ελέγχεται στο Medilabi ΚΑΘΕ 2′ (μόνο αυτός) για 8 ώρες, ή μέχρι να βγουν όλα —
// τα αποτελέσματα έρχονται σχεδόν αμέσως, όχι στον επόμενο γενικό κύκλο των 10′. Μόνο ένα bot (κάτοχος μίσθωσης).
alarmEnsure("efbot-labwatch", { delayInMinutes: 0.5, periodInMinutes: 0.5 });   // ⚡ 30″ (το ελάχιστο του Chrome): μόνο όσοι περιμένουν αποτέλεσμα, 1 αίτημα HTTP ο καθένας
chrome.alarms.onAlarm.addListener(async (a) => {
  if (a.name !== "efbot-labwatch") return;
  try {
    const { efbotLabWatch: w = {} } = await chrome.storage.local.get("efbotLabWatch");
    const now = Date.now(); let live = Object.entries(w).filter(([, t]) => t > now).map(([n]) => n);
    // όσοι δεν έχουν πια εκκρεμή ομάδα εξετάσεων βγαίνουν από τη λίστα
    const st = (await chrome.storage.session.get("efbotLabs")).efbotLabs || { patients: {} };
    live = live.filter((n) => { const p = st.patients && st.patients[Medilabi_norm(n)]; return !p || !p.checked || Object.values(p.groups || {}).some((x) => x === "pending") || now - p.checked > 30 * 60000; });
    const keep = {}; for (const n of live) keep[n] = w[n]; if (Object.keys(keep).length !== Object.keys(w).length) await chrome.storage.local.set({ efbotLabWatch: keep });
    if (!live.length || labsBusyStale() || !(await isHospitalBot()) || !(await leaseHeld().catch(() => true))) return;
    await labsTick(true, live);
  } catch (e) {}
});
alarmEnsure("efbot-selfupdate", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === "efbot-selfupdate") selfUpdateCheck(); });
selfUpdateCheck();
// Μετά την ανανέωση: το νέο script μπαίνει στις ανοιχτές καρτέλες (Παραδόχαρτο, φάκελος), χωρίς F5
async function reinject() {
  for (const t of await chrome.tabs.query({ url: ["http://*/*", "https://*/*"] }))
    chrome.scripting.executeScript({ target: { tabId: t.id, allFrames: true }, files: ["content.js"] }).catch(() => {});
}
chrome.runtime.onInstalled.addListener((d) => { if (d.reason === "update" || d.reason === "install") reinject(); });
// Το onInstalled δεν έρχεται πάντα μετά από αυτόματη ανανέωση: ελέγχουμε και το σημάδι που αφήνει η ίδια η ανανέωση
chrome.storage.local.get("efbotReinject").then(({ efbotReinject: r }) => {
  if (r) { chrome.storage.local.remove("efbotReinject"); reinject(); }
});

// Γρήγορη διεύθυνση από το μενού: αν είναι ήδη ανοιχτή, πηγαίνει εκεί· αλλιώς ανοίγει νέα καρτέλα
async function openQuickLink(url, from) {
  let u;
  try { u = new URL(url); } catch (e) { return; }
  if (!/^https?:$/.test(u.protocol)) return;
  const all = await chrome.tabs.query({});
  const have = all.find((t) => (t.url || "").startsWith(u.href));
  if (have) {
    await chrome.tabs.update(have.id, { active: true });
    await chrome.windows.update(have.windowId, { focused: true }).catch(() => {});
  } else {
    await chrome.tabs.create({ url: u.href, windowId: from.windowId });
  }
}

// ---------------------------------------------------------------------------
// Παρακολούθηση νέων εργαστηριακών
// ---------------------------------------------------------------------------
// Ρυθμίσεις (γράφει το πάνελ):  efbotMonCfg   = { on, interval, wfId, tabId, match, tests, list, showAm, salt }
// Κατάσταση (γράφει μόνο εδώ):  efbotMonState = { seen:{ΑΜ:[hash…]}, status:{ΑΜ:{ts,state,msg}}, cursor, fails, lastTs, lastMsg }
// Νέα αποτελέσματα (session):   efbotAlerts   = [{ key, ts, lines }]  — σβήνουν όταν κλείσει ο Chrome
// Στη μόνιμη αποθήκευση δεν μπαίνουν τιμές εξετάσεων, μόνο αποτυπώματα (hash) των γραμμών.
const ALARM = "efbot-monitor";
const BUDGET_MS = 3.5 * 60000; // ένας κύκλος δεν κρατά πάνω από ~3,5 λεπτά (όριο του service worker)

async function ensureAlarm() {
  const { efbotMonCfg: cfg } = await chrome.storage.local.get("efbotMonCfg");
  const have = await chrome.alarms.get(ALARM);
  if (!cfg?.on) { if (have) await chrome.alarms.clear(ALARM); return; }
  const period = Math.max(1, parseInt(cfg.interval) || 10);
  if (!have || have.periodInMinutes !== period)
    await chrome.alarms.create(ALARM, { delayInMinutes: 0.5, periodInMinutes: period });
}
ensureAlarm();
chrome.runtime.onInstalled.addListener(ensureAlarm);
chrome.runtime.onStartup.addListener(ensureAlarm);
chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch.efbotMonCfg) ensureAlarm(); });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === ALARM) monitorTick(false); });

const normLine = (l) => l.toLowerCase().replace(/\s+/g, " ").trim();
async function hashLine(salt, line) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(salt + "|" + normLine(line)));
  return [...new Uint8Array(buf)].slice(0, 8).map((b) => b.toString(16).padStart(2, "0")).join("");
}
function parseList(text) {
  return String(text || "").split(/\r?\n/).map((x) => x.trim()).filter(Boolean)
    .map((line) => ({ line, key: line.split(";")[0].trim() })).filter((p) => p.key);
}
async function findLabTab(cfg) {
  if (cfg.tabId) {
    const t = await chrome.tabs.get(cfg.tabId).catch(() => null);
    if (t && E.isWeb(t)) return t;
  }
  if (cfg.match) {
    const want = cfg.match.toLowerCase();
    const all = await chrome.tabs.query({});
    return all.find((t) => E.isWeb(t) && (t.url || "").toLowerCase().includes(want)) || null;
  }
  return null;
}
const untaught = (w) =>
  w.steps.filter((s) => !s.disabled && !s.target && !["manual", "wait", "copy", "tab", "goto", "skipif"].includes(s.type)).length;

async function setBadge() {
  const { efbotAlerts: a } = await chrome.storage.session.get("efbotAlerts");
  const n = (a || []).length;
  await chrome.action.setBadgeText({ text: n ? String(n) : "" });
  await chrome.action.setBadgeBackgroundColor({ color: "#dc2626" });
}
async function clearAlerts() {
  await chrome.storage.session.remove("efbotAlerts");
  await setBadge();
}
function notify(title, message, sticky) {
  chrome.notifications.create("efbot-" + Date.now(), {
    type: "basic", iconUrl: "icons/icon128.png", title, message, priority: 2, requireInteraction: !!sticky,
  });
}

let ticking = false;
async function monitorTick(force) {
  if (ticking) return;
  ticking = true;
  let locked = false;
  const found = [];
  let st = null;
  const saveSt = () => chrome.storage.local.set({ efbotMonState: st });
  try {
    const store = await chrome.storage.local.get(["efbotMonCfg", "efbotMonState", "efbot"]);
    const cfg = store.efbotMonCfg;
    if (!cfg || (!cfg.on && !force)) return;
    st = store.efbotMonState || {};
    st.seen ||= {}; st.status ||= {}; st.cursor ||= 0; st.fails ||= 0;
    // Αν τρέχει διαδικασία από το πάνελ, δεν παρεμβαίνουμε· δοκιμάζουμε στον επόμενο κύκλο
    locked = await E.lockAcquire("monitor");
    if (!locked) return;

    const efbot = store.efbot || {};
    const settings = efbot.settings || { timeout: 30, delay: 300 };
    const w = (efbot.workflows || []).find((x) => x.id === cfg.wfId);
    const patients = parseList(cfg.list);
    try {
      if (!w) throw new Error("Δεν έχει οριστεί διαδικασία ελέγχου");
      if (untaught(w)) throw new Error(`Η διαδικασία ελέγχου έχει ${untaught(w)} βήματα χωρίς εκμάθηση`);
      if (!patients.length) throw new Error("Η λίστα παρακολούθησης είναι κενή");
      const tab = await findLabTab(cfg);
      if (!tab) throw new Error("Δεν βρέθηκε ανοιχτή καρτέλα εργαστηρίων");
      const win = await chrome.windows.get(tab.windowId);
      if (!force && tab.active && win.focused) {
        st.lastTs = Date.now(); st.lastMsg = "Παραλείφθηκε: η καρτέλα εργαστηρίων είναι σε χρήση";
        return;
      }
      const salt = cfg.salt || "efbot";
      const deadline = Date.now() + BUDGET_MS;
      let cursor = st.cursor % patients.length, done = 0, consecutive = 0, ok = 0;
      while (done < patients.length && Date.now() < deadline) {
        const p = patients[cursor];
        const sess = {
          tabId: tab.id, homeTabId: tab.id, vars: {}, noTabSwitch: true,
          settings: () => settings, isAborted: () => false, log: () => ({ remove() {} }),
          vals: () => ({ ...(w.defaults || {}), ...(efbot.values?.[w.id] || {}), "ποιες_εξετάσεις": cfg.tests || "", ...sess.vars }),
          heartbeat: () => E.lockTouch("monitor"),
        };
        let lines = null, err = null;
        try {
          await E.execPlan(sess, E.plan(w, sess.vals(), E.lineVars(E.BULKVAR, p.line)));
          lines = String(sess.vars["αποτελέσματα"] || "").split("\n").map((x) => x.trim()).filter(Boolean);
        } catch (e) {
          if (e.empty) lines = []; // κανένα αποτέλεσμα ακόμα: έγκυρη κατάσταση
          else err = e;
        }
        if (lines) {
          consecutive = 0; ok++;
          const hs = await Promise.all(lines.map((l) => hashLine(salt, l)));
          const prev = st.seen[p.key];
          if (!prev) {
            st.seen[p.key] = hs;
            st.status[p.key] = { ts: Date.now(), state: "base", msg: `αρχική καταγραφή (${hs.length} γραμμές)` };
          } else {
            const fresh = lines.filter((_, k) => !prev.includes(hs[k]));
            st.seen[p.key] = [...new Set([...prev, ...hs])].slice(-500);
            if (fresh.length) {
              found.push({ key: p.key, lines: fresh });
              st.status[p.key] = { ts: Date.now(), state: "new", msg: `${fresh.length} νέες γραμμές` };
            } else st.status[p.key] = { ts: Date.now(), state: "ok", msg: "καμία αλλαγή" };
          }
        } else {
          consecutive++;
          st.status[p.key] = { ts: Date.now(), state: "error", msg: err.message };
          if (consecutive >= 2) throw new Error("Συνεχόμενες αποτυχίες: " + err.message);
        }
        cursor = (cursor + 1) % patients.length; done++;
        st.cursor = cursor;
        await saveSt();
      }
      st.fails = ok ? 0 : st.fails;
      st.lastTs = Date.now();
      st.lastMsg = `Έλεγχος ${done}/${patients.length}` + (found.length ? ` · νέα για ${found.length}` : "");
    } catch (e) {
      st.fails = (st.fails || 0) + 1;
      st.lastTs = Date.now();
      st.lastMsg = "Σφάλμα: " + e.message;
      // Μετά από 2 κύκλους αποτυχίας (π.χ. έληξε η σύνδεση) σταματά και ειδοποιεί
      if (st.fails >= 2 && !force) {
        const cur = (await chrome.storage.local.get("efbotMonCfg")).efbotMonCfg;
        if (cur) await chrome.storage.local.set({ efbotMonCfg: { ...cur, on: false } });
        notify("Η παρακολούθηση εργαστηρίων σταμάτησε", e.message + "\nΕλέγξτε ότι είστε συνδεδεμένοι στην εφαρμογή εργαστηρίων.", true);
        st.fails = 0;
      }
    }
  } finally {
    try {
      if (st) {
        if (found.length) {
          const { efbotAlerts: old } = await chrome.storage.session.get("efbotAlerts");
          const now = Date.now();
          await chrome.storage.session.set({ efbotAlerts: [...(old || []), ...found.map((f) => ({ ...f, ts: now }))] });
          await setBadge();
          const cfg = (await chrome.storage.local.get("efbotMonCfg")).efbotMonCfg || {};
          notify(
            "Νέα εργαστηριακά",
            cfg.showAm
              ? found.map((f) => `ΑΜ ${f.key}: ${f.lines.length} νέες γραμμές`).join("\n")
              : `${found.length} ${found.length === 1 ? "ασθενής" : "ασθενείς"} με νέα αποτελέσματα`,
            true
          );
        }
        await saveSt();
      }
    } catch (e) {}
    if (locked) await E.lockRelease("monitor");
    ticking = false;
  }
}

// Κλικ στην ειδοποίηση: πάμε στην καρτέλα εργαστηρίων και ζητάμε από το πάνελ να δείξει την παρακολούθηση
chrome.notifications.onClicked.addListener(async (id) => {
  chrome.notifications.clear(id);
  // «ΑΗΦΥ: χρειάζεται σύνδεση» → μπροστά η καρτέλα του ΑΗΦΥ στο παράθυρο του bot, για να συνδεθείτε
  if (id.startsWith("efbot-ehrlogin")) {
    await botShowWindows().catch(() => {}); await chrome.storage.local.set({ efbotNoHide: Date.now() });   // ο χρήστης θέλει να συνδεθεί: φανερό, χωρίς ξανακρύψιμο ως την επόμενη επανεκκίνηση
    const t = (await chrome.tabs.query({ url: "https://doctor.ehealthrecord.gov.gr/*" }).catch(() => []))[0];
    if (t) { await chrome.tabs.update(t.id, { active: true }).catch(() => {}); await chrome.windows.update(t.windowId, { focused: true, state: "normal" }).catch(() => {}); }
    else { const tab = await bgEmrTab(); if (tab && !tab.err) { const e = await bgEhrTab(tab); if (e) await chrome.windows.update(e.windowId, { focused: true, state: "normal" }).catch(() => {}); } }
    return;
  }
  const { efbotMonCfg: cfg } = await chrome.storage.local.get("efbotMonCfg");
  await chrome.storage.local.set({ efbotLaunch: { view: "monitor", ts: Date.now() } });
  try {
    const tab = cfg && (await findLabTab(cfg));
    if (tab) {
      await chrome.windows.update(tab.windowId, { focused: true });
      await chrome.sidePanel.open({ windowId: tab.windowId });
    }
  } catch (e) {}
});

// ===========================================================================
// Εργαστηριακά (Medilabi) για τους ασθενείς του Παραδόχαρτου
// ===========================================================================
// Κάθε Ν λεπτά:
//  1) ονόματα ασθενών από την ανοιχτή καρτέλα του Παραδόχαρτου
//  2) λίστα αναμονής του Medilabi → αντιστοίχιση ονόματος ↔ PatientID (μόνο μοναδικά ταιριάσματα)
//  3) για κάθε ασθενή: κατάσταση εξετάσεων (ελαφριά σελίδα). Όταν μια ομάδα ολοκληρωθεί,
//     κατεβάζουμε ΜΙΑ φορά τα πλήρη αποτελέσματα, κρατάμε τα σημερινά και ειδοποιούμε (με τα παθολογικά).
// Όλα μένουν στη μνήμη της συνεδρίας του Chrome (chrome.storage.session): σβήνουν όταν κλείσει ο Chrome.
const LABS_ALARM = "efbot-labs";
const LABS_BASE = "http://172.16.0.3/Medilabi/WebEMR/";
const labsDefault = () => ({ on: false, interval: 10, notifyAll: false, toApp: true, pushPhone: true, base: LABS_BASE });

async function labsCfg() { return { ...labsDefault(), ...((await chrome.storage.local.get("efbotLabsCfg")).efbotLabsCfg || {}) }; }
async function labsEnsureAlarm() {
  const c = await labsCfg();
  const have = await chrome.alarms.get(LABS_ALARM);
  if (!c.on) { if (have) await chrome.alarms.clear(LABS_ALARM); return; }
  const period = Math.max(2, parseInt(c.interval) || 10);
  if (!have || have.periodInMinutes !== period) await chrome.alarms.create(LABS_ALARM, { delayInMinutes: 0.2, periodInMinutes: period });
}
labsEnsureAlarm();
chrome.runtime.onStartup.addListener(labsEnsureAlarm);
chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch.efbotLabsCfg) labsEnsureAlarm(); });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === LABS_ALARM) labsTick(false); });
chrome.runtime.onMessage.addListener((msg, _s, reply) => {
  if (msg?.cmd === "secretsGet" || msg?.cmd === "secretsSet" || msg?.cmd === "secretsWipe" || msg?.cmd === "vaultStatus") {
    // ΜΟΝΟ από σελίδες της ίδιας της επέκτασης (πάνελ, chrome-extension://…) — ποτέ από content scripts σε ιστοσελίδες (εκεί sender.url = η ιστοσελίδα)
    if (_s?.id !== chrome.runtime.id || !String(_s?.url || "").startsWith(chrome.runtime.getURL(""))) { reply({ ok: false }); return false; }
    const run = msg.cmd === "secretsGet" ? V.get(msg.keys || []) : msg.cmd === "secretsSet" ? V.set(msg.patch || {}) : msg.cmd === "secretsWipe" ? V.wipe() : V.status();
    run.then(reply, (e) => reply({ ok: false, err: e.message })); return true;
  }
  if (msg?.cmd === "credLearnArmed") { Promise.all([credLearnArmed(), credAutoUsers()]).then(([a, u]) => reply({ armed: a, auto: u })); return true; }
  if (msg?.cmd === "pdxCredSave") { pdxCredSave(msg.user, msg.pass, "login").then(reply, () => reply({ ok: false })); return true; }
  if (msg?.cmd === "credLearnSave") { credLearnSave(msg).then(reply, () => reply({ ok: false })); return true; }
  if (msg?.type === "labsNow") { labsTick(true).then(() => reply({ ok: true })); return true; }
  if (msg?.type === "rtState") { rtState = { ok: !!msg.ok, err: msg.err || "", filtered: msg.filtered, at: Date.now() }; return false; }
  if (msg?.type === "efPing") { (async () => { const ss = await chrome.storage.session.get(["efbotOrderPrep", "efbotLastPt", "efbotFsIdx"]).catch(() => ({}));
      return { bot: await botId(), v: chrome.runtime.getManifest().version, cur: jobRunningId || 0, curKind: jobRunningKind || "", idle: jobRunningId ? Date.now() - Math.max(jobRunT0, (bgTime.marks.length ? bgTime.marks[bgTime.marks.length - 1].at : 0)) : 0, mark: jobRunningId && bgTime.marks.length ? bgTime.marks[bgTime.marks.length - 1].l : "", tick: jobsBusy && !jobRunningId ? Date.now() - jobsT0 : 0, bad: envFails.filter((t) => Date.now() - t < 30 * 60000).length, warm: warmEmrAt ? Date.now() - warmEmrAt : -1, side: sideRunningId || 0, held: holdNow ? 1 : 0, heldRx: holdNow && holdNowRx ? 1 : 0, epU: await epresUsersCached(), free: sysMem.free, ram: sysMem.ram, hosp: await isHospitalBot(), ready: await botReady().catch(() => false),
        prep: ss.efbotOrderPrep && Date.now() - ss.efbotOrderPrep.at < 6 * 60000 ? String(ss.efbotOrderPrep.name || "") : "", prepBusy: prepRunningName || "",
        last: ss.efbotLastPt && Date.now() - ss.efbotLastPt.at < 10 * 60000 ? String(ss.efbotLastPt.name || "") : "", fs: !!(ss.efbotFsIdx && ss.efbotFsIdx.ok && ss.efbotFsIdx.roots), lease: !!leaseOk, off: !!botOffC.v, at: Date.now() }; })().then(reply, () => reply(null)); return true; }
  if (msg?.type === "jobsNow" && jobsBusy) coordWake().catch(() => {});
  if (msg?.type === "jobsNow") { self.__efWakeAt = Date.now();
    if ((msg.st === "cancelled" || msg.st === "dismissed") && msg.id && msg.id === sideRunningId) self.efDeadJobs.add(msg.id);   // δεύτερη λωρίδα: σταματά στο επόμενο βήμα
    if ((msg.st === "cancelled" || msg.st === "dismissed") && msg.id && msg.id === jobRunningId) jobsAbortCheck(msg.id);
    else jobsTick(true);
    return false;
  }
});

// ⚡ Απευθείας ξύπνημα: το offscreen κρατά WebSocket Realtime με βραχύβιο access token (μόνο στη μνήμη).
let rtTok = "", rtState = null;
async function rtFeed() {
  try {
    const r = await jobsInApp(async () => { try { if (typeof sb6 === "undefined") return { skip: true }; const s = (await sb6.auth.getSession()).data.session; return s ? { t: s.access_token, exp: s.expires_at } : { skip: true }; } catch (e) { return { skip: true }; } }, []);
    if (!r || !r.t) return null;
    const has = await chrome.runtime.getContexts?.({ contextTypes: ["OFFSCREEN_DOCUMENT"] }).catch(() => []);
    if (!has || !has.length) await chrome.offscreen.createDocument({ url: "offscreen.html", reasons: ["DOM_PARSER"], justification: "Ανάγνωση σελίδων εργαστηρίου και ειδοποίηση νέων εντολών" }).catch(() => {});
    const res = await chrome.runtime.sendMessage({ target: "efbot-offscreen", op: "rt", url: PDX_SB, key: PDX_KEY, token: r.t }).catch(() => null);
    rtTok = r.t;
    return res;
  } catch (e) { return null; }
}
async function offscreenParse(op, html, day) {
  const has = await chrome.runtime.getContexts?.({ contextTypes: ["OFFSCREEN_DOCUMENT"] }).catch(() => []);
  if (!has || !has.length)
    await chrome.offscreen.createDocument({ url: "offscreen.html", reasons: ["DOM_PARSER"], justification: "Ανάγνωση σελίδων εργαστηρίου" }).catch(() => {});
  return chrome.runtime.sendMessage({ target: "efbot-offscreen", op, html, day });
}
// Αυτόματη σύνδεση στο Medilabi (ASP.NET φόρμα Login.aspx) με χρήστη/κωδικό αποθηκευμένα τοπικά (chrome.storage.local, efbotLabsCred).
// Μία προσπάθεια ανά 10': αν ο κωδικός είναι λάθος δεν ξαναδοκιμάζει μέχρι να αλλάξει (για να μην κλειδώσει ο λογαριασμός).
async function medilabiAutoLogin(base) {
  let { efbotLabsCred: c } = await V.get("efbotLabsCred");
  // Εφεδρεία: αν δεν υπάρχει κωδικός στο ειδικό πλαίσιο Medilabi, χρησιμοποιούμε τον λογαριασμό που αποθηκεύτηκε
  // για τη διεύθυνση του Medilabi με «🔑 Μάθε τους κωδικούς» (π.χ. όταν η σελίδα σύνδεσης δεν ήταν ακριβώς Login.aspx).
  if (!c?.user || !c?.pass) {
    try {
      const host = new URL(base).host.toLowerCase();
      const { efbotCredByHost: all = {} } = await V.get("efbotCredByHost");
      const v = all[host], list = Array.isArray(v) ? v.filter((a) => a && a.pass) : (v && v.pass ? [v] : []);
      if (list.length) c = { user: list[0].user, pass: list[0].pass, ts: list[0].ts || 0 };
    } catch (e) {}
  }
  if (!c?.user || !c?.pass) return { ok: false, msg: "συμπληρώστε χρήστη/κωδικό στο πλαίσιο για αυτόματη σύνδεση (ή κάντε «Μάθε τους κωδικούς» σε σύνδεση στο Medilabi)" };
  const sig = c.user + "|" + c.pass.length + "|" + (c.ts || 0);
  const { efbotLabsLoginTry: t } = await chrome.storage.session.get("efbotLabsLoginTry");
  if (t?.bad === sig) return { ok: false, msg: "η αυτόματη σύνδεση απέτυχε — ελέγξτε χρήστη/κωδικό" };
  if (t?.ts && Date.now() - t.ts < 10 * 60000 && t.sig === sig) return { ok: false, msg: "αναμονή πριν τη νέα αυτόματη σύνδεση" };
  await chrome.storage.session.set({ efbotLabsLoginTry: { ts: Date.now(), sig } });
  try {
    const url = base.replace(/WebEMR\/?$/, "") + "Login.aspx";
    const g = await labsGet(url);
    // η φόρμα διαβάζεται όπως είναι (κρυφά πεδία ASP.NET, ονόματα πεδίων, κουμπί) — δεν υποθέτουμε ονόματα
    const f = (await offscreenParse("loginform", g.html))?.form;
    if (!f || !f.user || !f.pass) return { ok: false, msg: "δεν βρέθηκε η φόρμα σύνδεσης του Medilabi" };
    const parts = f.fields.map(([k, v]) => enc1253(k) + "=" + enc1253(v));
    parts.push(enc1253(f.user) + "=" + enc1253(c.user), enc1253(f.pass) + "=" + enc1253(c.pass));
    if (f.btn) parts.push(enc1253(f.btn[0]) + "=" + enc1253(f.btn[1]));
    const res = await fetch(new URL(f.action || g.url || url, g.url || url).href, { method: "POST", credentials: "include", redirect: "follow", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: parts.join("&") });
    const html = new TextDecoder("windows-1253").decode(await res.arrayBuffer());
    if (/type=["']?password/i.test(html)) {
      await chrome.storage.session.set({ efbotLabsLoginTry: { ts: Date.now(), sig, bad: sig } });
      credFailPush("Medilabi", c.user);
      notify("Medilabi: η αυτόματη σύνδεση απέτυχε", "Ελέγξτε χρήστη και κωδικό στα «Εργαστηριακά» του ef-bot.", true);
      return { ok: false, msg: "η αυτόματη σύνδεση απέτυχε — ελέγξτε χρήστη/κωδικό" };
    }
    return { ok: true, msg: "🔑 έγινε αυτόματη σύνδεση " + new Date().toTimeString().slice(0, 5) };
  } catch (e) { return { ok: false, msg: "αυτόματη σύνδεση: " + e.message }; }
}
// windows-1253 για τη φόρμα σύνδεσης (ελληνικά σε όνομα/κωδικό)
function enc1253(str) {
  let out = "";
  for (const ch of String(str)) {
    const c = ch.codePointAt(0);
    if (c < 0x80) { out += encodeURIComponent(ch).replace(/%20/g, "+"); continue; }
    let b;
    if (c >= 0x391 && c <= 0x3a9) b = c - 0x391 + 0xc1;
    else if (c >= 0x3b1 && c <= 0x3ce) b = c - 0x3b1 + 0xe1;
    else b = { 0x386: 0xa2, 0x388: 0xb8, 0x389: 0xb9, 0x38a: 0xba, 0x38c: 0xbc, 0x38e: 0xbe, 0x38f: 0xbf, 0x390: 0xc0, 0x3aa: 0xda, 0x3ab: 0xdb, 0x3ac: 0xdc, 0x3ad: 0xdd, 0x3ae: 0xde, 0x3af: 0xdf, 0x3b0: 0xe0 }[c];
    out += b ? "%" + b.toString(16).toUpperCase().padStart(2, "0") : encodeURIComponent(ch);
  }
  return out;
}
// Λήψη σελίδας με τη σύνδεση του Chrome. Οι σελίδες είναι σε windows-1253 (ελληνικά).
async function labsGet(url) {
  const res = await fetch(url, { credentials: "include", cache: "no-store" });
  const buf = await res.arrayBuffer();
  const head = new TextDecoder("latin1").decode(buf.slice(0, 2048));
  const cs = ((res.headers.get("content-type") || "") + " " + head).match(/charset=["']?([\w-]+)/i)?.[1] || "windows-1253";
  let enc = /utf-?8/i.test(cs) ? "utf-8" : /1253|greek|8859-7/i.test(cs) ? "windows-1253" : cs;
  try { return { url: res.url, html: new TextDecoder(enc).decode(buf) }; } catch (e) { return { url: res.url, html: new TextDecoder("windows-1253").decode(buf) }; }
}
// Ονόματα ασθενών από το Παραδόχαρτο (ανοιχτή καρτέλα). Αν δεν είναι ανοιχτό, κρατάμε την τελευταία λίστα της συνεδρίας.
async function paradoxNames() {
  const tabs = await chrome.tabs.query({ url: APP_HOSTS.map((h) => `https://${h}/*`) });
  for (const t of tabs) {
    try {
      const [r] = await chrome.scripting.executeScript({ target: { tabId: t.id }, world: "MAIN", func: () => {
        try {
          const all = [...Object.values(typeof data !== "undefined" ? data : {}), ...Object.values(typeof extraPatients !== "undefined" ? extraPatients : {})];
          // θάλαμος κάθε ασθενή (για ειδοποιήσεις μόνο στους υπεύθυνους): «*» = φιλοξενία/εκτός θαλάμου → σε όλους
          const rooms = {};
          Object.keys(typeof data !== "undefined" ? data : {}).forEach((k) => { const n = String((data[k] || {}).name || "").trim(); if (n) rooms[n] = k.slice(0, k.lastIndexOf("-")); });
          Object.keys(typeof extraPatients !== "undefined" ? extraPatients : {}).forEach((k) => { const n = String((extraPatients[k] || {}).name || "").trim(); if (n) rooms[n] = "*"; });
          window.__efbotRooms = rooms;
          // ταυτοποίηση (ΑΜΚΑ / ΑΜ / μικρό όνομα από το ΝΠΣ) για την αναζήτηση σε όλο το Medilabi
          const ids = {}; all.forEach((p) => { const n = p && String(p.name || "").trim(); if (n) ids[n] = { amka: /^\d{11}$/.test(String(p.amka || "")) ? String(p.amka) : "", am: /^\d{8}$/.test(String(p.am || "")) ? String(p.am) : "", fname: String(p.fname || "").trim() }; });
          // 8/11: και οι ασθενείς της λίστας ΝΠΣ που δεν είναι σε κρεβάτι (π.χ. παραγγελία από «Ασθενείς ΝΠΣ») — αλλιώς δεν έπαιρναν ποτέ εργαστηριακά
          let nps = []; try { nps = typeof window.pdxNpsBulkList === "function" ? (window.pdxNpsBulkList() || []) : []; } catch (e) {}
          const out = all.map((p) => p && String(p.name || "").trim()).filter(Boolean);
          const have = new Set(out.map((n) => n.toUpperCase()));
          for (const x of nps) { const d = (x && x.d) || {}; const n = String(d.name || "").trim(); if (!n || have.has(n.toUpperCase())) continue; have.add(n.toUpperCase()); out.push(n); rooms[n] = "*";
            ids[n] = { amka: /^\d{11}$/.test(String(d.amka || "")) ? String(d.amka) : "", am: /^\d{8}$/.test(String(d.am || "")) ? String(d.am) : "", fname: "" }; }
          window.__efbotIds = ids;
          return out;
        } catch (e) { return null; }
      } });
      if (Array.isArray(r?.result)) {
        const [rr] = await chrome.scripting.executeScript({ target: { tabId: t.id }, world: "MAIN", func: () => ({ rooms: window.__efbotRooms || {}, ids: window.__efbotIds || {} }) }).catch(() => [null]);
        const rooms = (rr && rr.result && rr.result.rooms) || {}, ids = (rr && rr.result && rr.result.ids) || {};
        await chrome.storage.session.set({ efbotLabsNames: r.result, efbotLabsRooms: rooms, efbotLabsIds: ids });
        return { names: r.result, live: true, rooms, ids };
      }
    } catch (e) {}
  }
  const { efbotLabsNames: n, efbotLabsRooms: rm, efbotLabsIds: ids } = await chrome.storage.session.get(["efbotLabsNames", "efbotLabsRooms", "efbotLabsIds"]);
  return { names: n || [], live: false, rooms: rm || {}, ids: ids || {} };
}
const todayDDMMYY = () => { const d = new Date(); return `${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}/${String(d.getFullYear()).slice(2)}`; };
const surname = (n) => String(n || "").split(/\s+/)[0];

let labsBusy = false, labsBusyAt = 0, labsGen = 0;
// 🧪 «απασχολημένο» που ξέμεινε (κολλημένος έλεγχος) σβήνει μόνο του μετά από 5′
const labsBusyStale = () => { if (labsBusy && labsBusyAt && Date.now() - labsBusyAt > 5 * 60000) labsBusy = false; return labsBusy; };
const CBC_RX = /^\s*(baso|eos|luc|lymph|mch|mchc|mcv|mono|mpv|neut|nrbc|pdw|rbc|rdw|hdw|wbc|hct|hgb|hb|plt)\b|^\s*(ΤΥΠΟΣ ΛΕΥΚΩΝ|ΜΟΡΦΟΛΟΓΙΑ ΕΡΥΘΡΩΝ|Ραβδοπ|Διεγ\.? Λεμφ)|^\s*PCT\s*-\s*Αιμοπεταλ/i;
const CBC_KEEP = /^\s*(wbc|hgb|hb|hct|plt)\b/i;
// επιστρέφει false ΜΟΝΟ όταν ΔΕΝ έτρεξε επειδή τρέχει ήδη άλλος έλεγχος (για να μη δοθεί παλιό μήνυμα ως αποτέλεσμα)
// 🧫 Καλλιέργειες: σύγκριση του πλήρους πίνακα με ό,τι έχει ήδη δει ο bot (μόνιμα, ανά ασθενή). Πρώτη φορά για ασθενή → μόνο καταγραφή.
const CULT_RX = /καλλιεργ|αντιβιογρ|μικροοργαν|αναπτυχθ|μικροβιολογ|culture|gram/;
async function cultNew(name, all) {
  const nz = (x) => String(x || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
  const key = Medilabi_norm(name); let g = "", cur = [];
  for (const r of all.rows || []) {
    if (r.g) { g = r.g; continue; }
    if (!r.t || !(CULT_RX.test(nz(g)) || CULT_RX.test(nz(r.t)))) continue;
    for (const [i, v] of Object.entries(r.v || {})) { const val = String(v || "").trim(); if (!val || /^\[?παραγγ/i.test(val)) continue; cur.push({ k: r.t + "|" + (all.dates[+i] || i) + "|" + val, g, t: r.t, val, d: all.dates[+i] || "" }); }
  }
  const { efbotCultSeen: S = {} } = await chrome.storage.local.get("efbotCultSeen");
  const seen = S[key], first = !seen; const set = new Set((seen && seen.k) || []);
  const neu = cur.filter((x) => !set.has(x.k));
  S[key] = { k: [...new Set([...(seen ? seen.k : []), ...cur.map((x) => x.k)])].slice(-600), at: Date.now() };
  for (const kk of Object.keys(S)) if (Date.now() - (S[kk].at || 0) > 45 * 864e5) delete S[kk];
  await chrome.storage.local.set({ efbotCultSeen: S });
  if (first || !neu.length) return null;
  // περίληψη: δείγμα (από την παρένθεση) + μικροοργανισμός / «αναπτύχθηκε» / αποτέλεσμα· αντιβιόγραμμα → πόσα ανθεκτικά
  const spec = (t) => (/\(([^)]+)\)\s*$/.exec(t) || [])[1] || "";
  const by = {};
  for (const x of neu) { const sp = spec(x.t) || spec(x.g) || "δείγμα"; const o = (by[sp] ||= { org: [], res: [], R: [], n: 0, d: x.d }); o.n++;
    const tt = nz(x.t);
    if (/μικροοργαν|αναπτυχθ|καλλιεργ|gram/.test(tt)) o.org.push(x.val);
    else if (/\((a|r)\)|^a$|^r$|ανθεκτ/i.test(x.val)) o.R.push(x.t.replace(/\s*\([^)]*\)\s*$/, ""));
    else if (!/μεθοδος|αντιβιογρ/.test(tt)) o.res.push(x.val); }
  const txt = Object.entries(by).map(([sp, o]) => sp + ": " + ([...new Set(o.org)].join(", ") || [...new Set(o.res)].slice(0, 2).join(", ") || "νέο αποτέλεσμα") + (o.R.length ? " · ανθεκτικό σε " + o.R.slice(0, 5).join(", ") + (o.R.length > 5 ? "…" : "") : "") + (o.d ? " (" + o.d + ")" : "")).join(" | ");
  return { name, txt: txt.slice(0, 300) };
}
async function labsTick(force, only) {
  if (labsBusyStale()) return false;
  if (!force && !(await isHospitalBot())) return;   // υπολογιστής εκτός νοσοκομείου: δεν φτάνει στο Medilabi
  if (!force && !(await leaseHeld().catch(() => true))) return;   // πολλά bot: την αυτόματη παρακολούθηση την κάνει ΕΝΑΣ (όχι διπλές ειδοποιήσεις)
  labsBusy = true; labsBusyAt = Date.now(); const gen = ++labsGen;
  const st = (await chrome.storage.session.get("efbotLabs")).efbotLabs || { patients: {} };
  const save = () => chrome.storage.session.set({ efbotLabs: st });
  try {
    const cfg = await labsCfg();
    if (!cfg.on && !force) return;
    const base = cfg.base || LABS_BASE;
    const day = todayDDMMYY();
    if (st.day !== day) { st.day = day; st.patients = {}; } // νέα μέρα: νέα καταγραφή
    let { names, live, rooms: roomOf, ids: idOf = {} } = await paradoxNames();
    // 🎯 στοχευμένος έλεγχος (μόνο οι ασθενείς που περιμένουμε αποτέλεσμα): ίδια ροή, λιγότεροι ασθενείς → δευτερόλεπτα
    if (Array.isArray(only) && only.length) { const want = new Set(only.map((x) => Medilabi_norm(x))); let nn = names.filter((n) => want.has(Medilabi_norm(n)));
      if (!nn.length && (await pdxAppRefresh())) { ({ names, live, rooms: roomOf, ids: idOf = {} } = await paradoxNames()); nn = names.filter((n) => want.has(Medilabi_norm(n))); }
      names = nn; if (!names.length) { st.lastTs = Date.now(); st.lastMsg = "ο ασθενής δεν υπάρχει στο Παραδόχαρτο αυτού του υπολογιστή"; return; } }
    if (!names.length) { st.lastTs = Date.now(); st.lastMsg = "Ανοίξτε το Παραδόχαρτο (για τη λίστα ασθενών)"; return; }
    let w = await labsGet(base + "PatientOnlineResults.aspx");
    let pw = await offscreenParse("waiting", w.html);
    let autoMsg = "";
    if (pw?.login || /Login\.aspx/i.test(w.url)) {
      // αυτόματη σύνδεση στο παρασκήνιο με τα στοιχεία που έγραψε ο χρήστης στο πλαίσιο
      const a = await medilabiAutoLogin(base);
      if (a.ok) {
        w = await labsGet(base + "PatientOnlineResults.aspx");
        pw = await offscreenParse("waiting", w.html);
        autoMsg = a.msg;
      } else autoMsg = a.msg;
    }
    if (pw?.login || /Login\.aspx/i.test(w.url)) {
      st.lastTs = Date.now(); st.lastMsg = "Χρειάζεται σύνδεση στο Medilabi" + (autoMsg ? " · " + autoMsg : "");
      if (!st.loginNotified) { notify("Medilabi: χρειάζεται σύνδεση", "Συνδεθείτε στο Medilabi για να συνεχιστεί η παρακολούθηση των εργαστηριακών.", true); st.loginNotified = true; }
      return;
    }
    st.loginNotified = false;
    const list = pw?.list || [];
    if (!list.length) { st.lastTs = Date.now(); st.lastMsg = `Η λίστα του Medilabi ήρθε κενή (σελίδα: ${String(w.url || "").replace(/^.*\//, "").replace(/\?.*/, "")}, ${Math.round((w.html || "").length / 1024)} KB) — ανοίξτε το Medilabi και ξαναδοκιμάστε`; return; }
    const fresh = [], cultFresh = []; st.findN = 0;
    // πρώτα όλες οι αντιστοιχίσεις: αν δύο ασθενείς του Παραδόχαρτου πέφτουν στον ίδιο του Medilabi, κανένας δεν περνά
    const matches = Object.fromEntries(names.map((n) => [n, labsMatch(n, list)]));
    const usedBy = {};
    for (const [n, m] of Object.entries(matches)) if (m.item) (usedBy[m.item.pid] ||= []).push(n);
    for (const [pid, ns] of Object.entries(usedBy)) if (ns.length > 1) for (const n of ns) matches[n] = { hits: ns.length, item: null, surname: matches[n].surname, dup: true, twin: true };
    // ⚡ 4 ασθενείς παράλληλα (πριν ένας-ένας: ~35″ για 26 ασθενείς)
    st.skipped = 0;
    const one = async (name) => {
      const key = Medilabi_norm(name);
      const p = (st.patients[key] ||= { name, groups: {}, rows: [], seen: [] });
      p.name = name;
      const m = matches[name];
      // 🔎 δεν είναι στη λίστα «online» του Medilabi (π.χ. νέα εισαγωγή, άλλος θάλαμος): αναζήτηση σε ΟΛΟ το Medilabi
      // (FindPatient, όπως οι βιοψίες) — μόνο αν βγει ΕΝΑΣ ασθενής της ουρολογικής με αυτό το επώνυμο. Έως 2 ανά γύρο, ανά 20′.
      // 7/11: και όταν το επώνυμο βγάζει πολλούς στη λίστα, αν υπάρχει ΑΜΚΑ/ΑΜ → ακριβής αναζήτηση (πριν: «δεν περάστηκαν»).
      // Μεμονωμένο αίτημα (only): χωρίς όριο 2/γύρο και χωρίς την αναμονή 20′.
      const idk0 = (idOf[name] || {}).amka || (idOf[name] || {}).am || "";
      if (!m.item && !m.twin && (!m.hits || idk0)) {
        st.find ||= {};
        const fk = Medilabi_norm(name), fc = st.find[fk];
        const idk = idk0, solo = !!(only && only.length);
        if (fc && fc.pid && (fc.key || "") === idk) m.item = { pid: fc.pid };
        else if ((solo || !fc || Date.now() - fc.at > 20 * 60000 || (fc.key || "") !== idk) && (st.findN = (st.findN || 0) + 1) <= (solo ? 10 : 3) && typeof JOB_RUNNERS.medbx === "function") {
          try {
            // ταυτοποίηση με σειρά: ΑΜΚΑ (ακριβής αναζήτηση) → ΑΜ στη γραμμή → επώνυμο + μικρό όνομα → μόνο επώνυμο στην ουρολογική
            const id = idOf[name] || {}, sur = bxNz(String(name).trim().split(/\s+/)[0]);
            const fn = bxNz(id.fname || String(name).trim().split(/\s+/)[1] || "");
            const r = await JOB_RUNNERS.medbx({ id: 0, name, payload: { q: id.amka || String(name).trim().split(/\s+/)[0], scope: "all" } });
            const rows = ((r && r.result && r.result.pts) || []).filter((x) => x.pid);
            let c, how;
            if (id.amka) { c = rows; how = "ΑΜΚΑ"; }
            else if (id.am && rows.some((x) => String(x.row).includes(id.am))) { c = rows.filter((x) => String(x.row).includes(id.am)); how = "ΑΜ"; }
            else {
              const bySur = rows.filter((x) => bxNz(x.row).startsWith(sur));
              const byFn = fn.length >= 2 ? bySur.filter((x) => bxNz(x.row).split(" ").slice(1, 3).some((w) => w.startsWith(fn.slice(0, Math.min(fn.length, 4))))) : [];
              if (byFn.length) { c = byFn.filter((x) => /ΟΥΡΟΛΟΓ/.test(bxNz(x.row))).length ? byFn.filter((x) => /ΟΥΡΟΛΟΓ/.test(bxNz(x.row))) : byFn; how = "όνομα"; }
              else { c = bySur.filter((x) => /ΟΥΡΟΛΟΓ/.test(bxNz(x.row))); how = "επώνυμο (ουρολογική)"; }
            }
            const pids = [...new Set(c.map((x) => x.pid))];
            st.find[fk] = { at: Date.now(), pid: pids.length === 1 ? pids[0] : "", n: pids.length, how, key: id.amka || id.am || "" };
            if (pids.length === 1) m.item = { pid: pids[0] };
          } catch (e) { st.find[fk] = { at: Date.now(), pid: "", err: String(e.message || e).slice(0, 60) }; }
        }
      }
      if (!m.item) {
        p.pid = ""; p.dup = m.hits > 1;
        p.msg = m.twin ? `${m.hits} ασθενείς του Παραδόχαρτου με επώνυμο ${String(m.surname || "").toUpperCase()} — δεν περάστηκαν` : m.hits > 1 ? `${m.hits} ασθενείς με επώνυμο ${String(m.surname || "").toUpperCase()} στο Medilabi — δεν περάστηκαν` : "δεν βρέθηκε στη λίστα του Medilabi";
        return;
      }
      p.dup = false;
      p.pid = m.item.pid; p.msg = "";
      // ⚡ η γραμμή του ασθενή στη λίστα δεν άλλαξε, δεν εκκρεμεί καμία εξέταση και ελέγχθηκε <30′ → παράλειψη (πριν: άνοιγμα κάθε φορά)
      const pend = Object.values(p.groups || {}).some((x) => x === "pending");
      if (!force && m.item.sig && p.rowSig === m.item.sig && !pend && p.checked && Date.now() - p.checked < 30 * 60000) { st.skipped = (st.skipped || 0) + 1; return; }
      p.rowSig = m.item.sig || "";
      const e = await labsGet(base + "PatientOnlineResultsExams.aspx?PatientID=" + encodeURIComponent(p.pid));
      const pe = await offscreenParse("exams", e.html);
      const groups = Object.fromEntries((pe?.groups || []).map((x) => [x.group, x.state]));
      const first = !p.checked;
      const newlyDone = Object.entries(groups).filter(([g, s]) => s !== "pending" && (p.groups[g] === "pending" || (!first && !(g in p.groups))));
      // Υπογραφή ΟΛΗΣ της λίστας εξετάσεων (και με διπλές ομάδες, π.χ. δεύτερη γενική αίματος την ίδια μέρα): το
      // Object.fromEntries κρατά μία ανά όνομα, οπότε μια νέα παραγγελία ίδιας ομάδας που ολοκληρώθηκε ανάμεσα σε δύο
      // ελέγχους δεν φαινόταν ποτέ ως «νέα» → τα αποτελέσματα χάνονταν. Τώρα κάθε αλλαγή φέρνει ξανά τον πίνακα.
      const examSig = JSON.stringify((pe?.groups || []).map((x) => x.group + "|" + x.state).sort());
      const examChanged = !!p.examSig && p.examSig !== examSig;
      p.examSig = examSig;
      p.groups = groups; p.checked = Date.now();
      // Πλήρη αποτελέσματα: όταν άλλαξε κάτι, την πρώτη φορά, και σε κάθε περίπτωση κάθε 30' (διορθώσεις/προσθήκες του εργαστηρίου)
      const anyDone = Object.values(groups).some((s) => s !== "pending");
      const stale = Date.now() - (p.allTs || 0) > (parseInt(cfg.fullEveryMin) || 30) * 60000;
      if (newlyDone.length || (first && anyDone) || (examChanged && anyDone) || (anyDone && stale) || force && anyDone && !p.rows.length || (cfg.toApp !== false && !p.allTs)) {
        const r = await labsGet(base + "PatientResults.aspx?PatientID=" + encodeURIComponent(p.pid));
        const pr = await offscreenParse("results", r.html, day);
        p.rows = pr?.rows || [];
        p.allTs = Date.now();
        if (pr?.all?.dates?.length) { const sig = JSON.stringify(pr.all); if (sig !== p.allSig) { p.allPending = pr.all; p.allPendingSig = sig; } }
        if (pr?.all?.dates?.length) { try { const cl = await cultNew(name, pr.all); if (cl) cultFresh.push(cl); } catch (e) {} }
        // μόνο οι τιμές που δεν έχουμε ήδη αναφέρει σήμερα
        const key = (x) => x.test + "|" + x.time + "|" + x.value;
        const newRows = p.rows.filter((x) => !p.seen.includes(key(x)));
        p.seen.push(...newRows.map(key));
        // 🩸 Γενική αίματος: ειδοποίηση/εμφάνιση ΜΟΝΟ για WBC, HGB, HCT, PLT (εντολή χρήστη) — τα υπόλοιπα του αιμοδιαγράμματος σιωπούν
        const showRows = newRows.filter((x) => !CBC_RX.test(String(x.test || "")) || CBC_KEEP.test(String(x.test || "")));
        if (showRows.length) fresh.push({ name, bad: showRows.filter((x) => x.flag), all: showRows, n: showRows.length, first });
      }
        };
    { const q = names.slice(); await Promise.all(Array.from({ length: Math.min(4, q.length) }, async () => { while (q.length) { const nm = q.shift(); try { await one(nm); } catch (e) {} } })); }
    // Αποστολή Ht/WBC/CRP/Cr στη βάση εργαστηριακών του Παραδόχαρτου («📋 Νέα εργαστηριακά»)
    let sentMsg = "", pushMsg = "";
    if (cfg.toApp !== false) {
      // «Τι έχει ήδη σταλεί» ΜΟΝΙΜΑ (chrome.storage.local): επιβιώνει από ενημερώσεις/επανεκκινήσεις της επέκτασης.
      // Πριν ζούσε μόνο στη μνήμη συνεδρίας → κάθε ενημέρωση ξαναγέμιζε τα «📋 Νέα εργαστηριακά» με ήδη περασμένους ασθενείς.
      const { efbotInboxSent: is0 = {} } = await chrome.storage.local.get("efbotInboxSent");
      const inbox = is0.day === isoToday() ? is0 : { day: isoToday(), k: {} };
      inbox.k = inbox.k || {};
      const items = [];
      for (const p of Object.values(st.patients)) {
        if (!p.pid || !(p.rows || []).length || !names.includes(p.name)) continue;
        const v = labsAppValues(p.rows);
        if (!Object.keys(v).length) continue;
        const sig = JSON.stringify(v);
        const key = Medilabi_norm(p.name), prev = inbox.k[key];
        if ((prev && prev.sig === sig) || p.sentSig === sig) continue;
        items.push({ key, name: p.name, prevId: (prev && prev.id) || p.sentId || null, v, sig });
      }
      if (items.length) {
        const r = await labsSendToApp(items, isoToday());
        if (r.ok) {
          for (const it of items) { const res = r.ids[it.key]; if (res) { const p = st.patients[it.key]; if (p) { p.sentSig = it.sig; p.sentId = res; p.sentTs = Date.now(); } inbox.k[it.key] = { sig: it.sig, id: res }; } }
          await chrome.storage.local.set({ efbotInboxSent: inbox });
          const n = Object.keys(r.ids).length; if (n) sentMsg = ` · ${n} στο Παραδόχαρτο`;
          if (r.errs) sentMsg += ` · ${r.errs} αποτυχίες αποστολής`;
        } else sentMsg = " · δεν στάλθηκαν στο Παραδόχαρτο: " + r.err;
      }
    }
    await labsWarnInApp(Object.values(st.patients).filter((p) => p.dup && names.includes(p.name)).map((p) => `${p.name}: ${p.msg}`));
    // Πλήρης πίνακας εργαστηριακών κάθε ασθενή → καρτέλα «Εργαστηριακά» του Παραδόχαρτου
    if (cfg.toApp !== false) {
      const up = Object.values(st.patients).filter((p) => p.allPending && names.includes(p.name) && !p.dup);
      if (up.length) {
        const r = await labsUploadAll(up.map((p) => ({ name_key: Medilabi_norm(p.name), name: p.name, pid: p.pid, data: p.allPending })));
        if (r.ok) { for (const p of up) { p.allSig = p.allPendingSig; delete p.allPending; delete p.allPendingSig; p.allUp = Date.now(); } sentMsg += ` · πίνακες ${up.length}`; }
        else sentMsg += " · πίνακες: " + r.err;
      }
    }
    // Ρυθμίσεις της κλινικής στο Παραδόχαρτο (⚙︎ στα εργαστηριακά): ποιες εξετάσεις ειδοποιούν και με ποια όρια.
    // π.χ. MCV/MCH εκτός ορίων → καμία ειδοποίηση. Παλιό Παραδόχαρτο χωρίς τη συνάρτηση: όλες, όπως πριν.
    if (fresh.some((f) => f.bad.length)) {
      const all = fresh.map((f) => ({ name: f.name, rows: f.all }));
      const fr = await pdxCall("pdxMedLabsNotify", [all]).catch(() => null);
      if (fr && fr.skip && Date.now() - (self.__pdxReloadAt || 0) > 30 * 60000) {
        self.__pdxReloadAt = Date.now();
        const ts = await chrome.tabs.query({ url: APP_HOSTS.map((h) => `https://${h}/*`) }).catch(() => []);
        for (const t of ts) { const w = await chrome.windows.get(t.windowId).catch(() => null); if (!(t.active && w?.focused)) chrome.tabs.reload(t.id).catch(() => {}); }
      }
      if (fr && Array.isArray(fr.r)) fresh.forEach((f, i) => { const idx = fr.r[i]; if (Array.isArray(idx)) f.bad = idx.map((e) => { const j = Array.isArray(e) ? e[0] : e, x = f.all[j]; return x ? { ...x, flag: (Array.isArray(e) && e[1]) || x.flag || "H" } : null; }).filter(Boolean); });
    }
    // Μία φορά ανά τιμή: ό,τι έχει ήδη σταλεί σήμερα δεν ξαναστέλνεται, ούτε μετά από ενημέρωση/επανεκκίνηση της επέκτασης
    // (πριν: η λίστα «είδα» ζούσε μόνο στη μνήμη της συνεδρίας → σε κάθε επανεκκίνηση ξαναέφευγαν όλες οι σημερινές).
    const { efbotLabsSent: sentAll = {} } = await chrome.storage.local.get("efbotLabsSent");
    const sent = sentAll.day === day ? sentAll : { day, k: {} };
    const sk = (n, x) => Medilabi_norm(n) + "|" + x.test + "|" + x.time + "|" + x.value;
    const seedOnly = !sentAll.day;   // πρώτη φορά με αυτή τη μνήμη (μετά την ενημέρωση): μόνο καταγραφή, χωρίς ειδοποιήσεις
    for (const f of fresh) { f.bad = seedOnly ? [] : f.bad.filter((x) => !sent.k[sk(f.name, x)]); if ((f.first || seedOnly) && !f.bad.length) f.n = 0; }
    // Ειδοποίηση: μία για όλους τους ασθενείς με νέα σημερινά αποτελέσματα
    const toNotify = fresh.filter((f) => (!f.first && f.n) || cfg.notifyAll || f.bad.length);
    for (const f of fresh) for (const x of f.all || []) sent.k[sk(f.name, x)] = 1;
    await chrome.storage.local.set({ efbotLabsSent: sent });
    if (toNotify.length) {
      const lines = toNotify.map((f) => `${surname(f.name)}: ${f.bad.length ? f.bad.slice(0, 6).map((b) => `${b.test} ${b.value}${b.flag === "H" ? "↑" : "↓"}`).join(", ") + (f.bad.length > 6 ? "…" : "") : "χωρίς παθολογικές"}`);
      notify(`Εργαστηριακά: νέα σημερινά (${toNotify.length})`, lines.join("\n"), toNotify.some((f) => f.bad.length));
      // push στο κινητό (μέσω Παραδόχαρτου) μόνο για τιμές εκτός ορίων
      const badOnes = toNotify.filter((f) => f.bad.length);
      if (cfg.pushPhone !== false && badOnes.length) {
        const line = (f) => `${surname(f.name)}: ${f.bad.map((b) => `${b.test.replace(/\s*[-(].*$/, "")} ${b.value}${b.flag === "H" ? "↑" : "↓"}`).join(", ")}`;
        // μόνο στους υπεύθυνους του θαλάμου (Ρύθμιση «Οι θάλαμοί μου»)· αν η βάση δεν το υποστηρίζει ακόμα, όπως πριν
        const byRoom = {};
        for (const f of badOnes) (byRoom[(roomOf || {})[f.name] || "*"] ||= []).push(f);
        // ανά κινητό: μόνο οι γραμμές των θαλάμων του (ρύθμιση συσκευής)· κινητό χωρίς θαλάμους → όλα
        const groups = Object.entries(byRoom).map(([room, fs]) => ({ room, body: fs.map(line).join("\n") }));
        const pr = await labsPushPhone("Εργαστηριακά: εκτός ορίων (" + badOnes.length + ")", badOnes.map(line).join("\n"), "labsBad", { groups });
        pushMsg = pr.ok ? ` · 📱 ${pr.n}` : " · 📱 " + pr.err;
      }
      const { efbotLabsAlerts: old } = await chrome.storage.session.get("efbotLabsAlerts");
      await chrome.storage.session.set({ efbotLabsAlerts: [...(old || []), ...toNotify.map((f) => ({ name: f.name, ts: Date.now(), bad: f.bad.length }))].slice(-50) });
      await setBadge();
    }
    // 🧫 8/11 (εντολή χρήστη): νέα αποτελέσματα καλλιεργειών (αιμο-/ουρο-/πύου κ.λπ.) → ειδοποίηση στον υπολογιστή και push στα κινητά
    if (cultFresh.length) {
      const lines = cultFresh.map((c) => surname(c.name) + ": " + c.txt);
      notify("🧫 Καλλιέργειες: νέα αποτελέσματα (" + cultFresh.length + ")", lines.join("\n"), true);
      if (cfg.pushPhone !== false) {
        const byRoom = {}; for (const c of cultFresh) (byRoom[(roomOf || {})[c.name] || "*"] ||= []).push(surname(c.name) + ": " + c.txt);
        const pr = await labsPushPhone("🧫 Καλλιέργειες (" + cultFresh.length + ")", lines.join("\n"), "labsBad", { groups: Object.entries(byRoom).map(([room, l]) => ({ room, body: l.join("\n") })) }).catch((e) => ({ err: e.message }));
        pushMsg += pr && pr.ok ? " · 🧫📱 " + pr.n : " · 🧫 " + ((pr && pr.err) || "");
      }
    }
    st.lastTs = Date.now();
    const found = names.filter((n) => matches[n]?.item).length;
    st.lastMsg = (autoMsg ? autoMsg + " · " : "") + `Βρέθηκαν ${found}/${names.length} στο Medilabi (λίστα ${list.length}${st.skipped ? ", " + st.skipped + " χωρίς αλλαγή" : ""})${live ? "" : " (τελευταία λίστα Παραδόχαρτου)"}` + (toNotify.length ? ` · νέα για ${toNotify.length}` : "") + sentMsg + pushMsg;
  } catch (e) {
    st.lastTs = Date.now(); st.lastMsg = "Σφάλμα: " + e.message;
  } finally {
    await save().catch(() => {});
    if (gen === labsGen) labsBusy = false;
  }
  return true;
}
const isoToday = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; };
// Εξετάσεις του Medilabi → πεδία του Παραδόχαρτου. Κρατά την πιο πρόσφατη σημερινή τιμή.
const LABS_APP_MAP = [["hct", /^HCT\b/i], ["wbc", /^WBC\b/i], ["crp", /^CRP\b/i], ["cr", /^Κρεατινίνη\s*\(Crea\)$/i]];
function labsAppValues(rows) {
  const v = {}, at = {};
  for (const r of rows) {
    const m = LABS_APP_MAP.find(([, re]) => re.test(String(r.test || "").trim()));
    if (!m) continue;
    const val = String(r.value || "").replace(/\s+/g, "").replace(",", ".");
    if (!/^[<>]?\d+(\.\d+)?$/.test(val)) continue;
    if (at[m[0]] && at[m[0]] > (r.time || "")) continue;
    v[m[0]] = val; at[m[0]] = r.time || "";
  }
  return v;
}
// Ανέβασμα του πλήρους πίνακα αποτελεσμάτων (oncall_labs, μία γραμμή ανά ασθενή) μέσα από την καρτέλα του Παραδόχαρτου.
async function labsUploadAll(rows) {
  const tabs = await chrome.tabs.query({ url: APP_HOSTS.map((h) => `https://${h}/*`) }).catch(() => []);
  if (!tabs.length) return { ok: false, err: "κλειστό Παραδόχαρτο" };
  let last = "χωρίς απάντηση";
  for (const t of tabs) {
    try {
      const [r] = await chrome.scripting.executeScript({ target: { tabId: t.id }, world: "MAIN", args: [rows], func: async (rows) => {
        try {
          if (typeof sb6 === "undefined") return { err: "παλιά έκδοση εφαρμογής" };
          const ss = (await sb6.auth.getSession()).data.session;
          if (!ss) return { err: "δεν είστε συνδεδεμένος στο Παραδόχαρτο" };
          const now = new Date().toISOString();
          const r = await sb6.from("oncall_labs").upsert(rows.map((x) => Object.assign({ updated_at: now }, x)), { onConflict: "name_key" });
          if (r.error) return { err: /oncall_labs|relation|schema cache/i.test(r.error.message) ? "λείπει ο πίνακας oncall_labs στη βάση" : r.error.message };
          try { if (window.pdxLabsRefresh) window.pdxLabsRefresh(); } catch (e) {}
          return { ok: true };
        } catch (e) { return { err: String(e && e.message || e) }; }
      } });
      const res = r?.result;
      if (res?.ok) return res;
      if (res?.err) last = res.err;
    } catch (e) { last = e.message; }
  }
  return { ok: false, err: last };
}
// 🔔 Κατηγορίες ειδοποιήσεων (επιλογές ανά κινητό: oncall_labs «pushpref|<hash endpoint>» = {cats:{…:false}, quiet:[από,έως]})
function pushCat(title) {
  const t = String(title || "");
  if (/^Εργαστηριακά: εκτός ορίων/.test(t)) return "labsBad";
  if (/^(⚠|❌|🚑)/u.test(t) || /ΔΕΝ (καταχωρ|ολοκληρ|μπήκαν)|απέτυχε|κόλλησε/.test(t)) return "botFail";
  if (/^[🔒🔑🔐]/u.test(t)) return "system";
  if (/για (έλεγχο|έγκριση)/.test(t)) return "review";   // περιμένει τον γιατρό στο κινητό → ειδοποίηση (ανοίγει το φύλλο ελέγχου)
  return "botDone";
}
const pushSeen = new Map();   // ίδια ειδοποίηση (τίτλος + κείμενο) μόνο ΜΙΑ φορά ανά 10′
async function labsPushPhone(title, body, cat, opt) {
  { const k = String(title) + "|" + String(body).slice(0, 200), now = Date.now();
    for (const [kk, t] of pushSeen) if (now - t > 600000) pushSeen.delete(kk);
    if (pushSeen.has(k)) return { ok: true, dup: true };
  }
  const pushKey = String(title) + "|" + String(body).slice(0, 200);   // σημειώνεται ΜΟΝΟ μετά από επιτυχία (έλεγχος 5/11)
  cat = cat || pushCat(title);
  // 🔕 εντολή χρήστη: ΚΑΜΙΑ ειδοποίηση για ολοκληρωμένες ενέργειες (καταχωρήθηκε/έγινε) — φαίνονται στη σελίδα «Ενέργειες bot».
  // Μένουν: εργαστηριακά εκτός ορίων, αποτυχίες (⚠️), σύστημα (κωδικοί).
  if (cat === "botDone") return { ok: true, n: 0, off: true };
  const tabs = await chrome.tabs.query({ url: APP_HOSTS.map((h) => `https://${h}/*`) }).catch(() => []);
  if (!tabs.length) return { ok: false, err: "κλειστό Παραδόχαρτο" };
  let last = "χωρίς απάντηση";
  for (const t of tabs) {
    try {
      const [r] = await chrome.scripting.executeScript({ target: { tabId: t.id }, world: "MAIN", args: [title, body, cat, opt || null], func: async (title, body, cat, opt) => {
        try {
          if (typeof sb6 === "undefined") return { err: "παλιά έκδοση εφαρμογής" };
          const ss = (await sb6.auth.getSession()).data.session;
          if (!ss) return { err: "δεν είστε συνδεδεμένος στο Παραδόχαρτο" };
          // 6/11: διανομή από τον server σε ΟΛΕΣ τις συσκευές κάθε γιατρού που έχει τον θάλαμο (oncall_push_fanout)· αλλιώς όπως πριν
          try { const fo = await sb6.rpc("oncall_push_fanout", { p_title: title, p_body: String(body), p_cat: cat, p_room: opt && opt.room ? String(opt.room) : null, p_groups: opt && Array.isArray(opt.groups) ? opt.groups : null });
            if (!fo.error) { try { await sb6.functions.invoke("send-reminders", { body: {} }); } catch (e) {} return { ok: true, n: fo.data || 0, fanout: true }; }
            if (!/function|schema cache|not find/i.test(fo.error.message || "")) return { err: fo.error.message }; } catch (e) {}
          let mine = ""; try { mine = localStorage.getItem("pdx_push") || ""; } catch (e) {}
          const q = await sb6.from("oncall_push").select("endpoint");
          if (q.error) return { err: q.error.message };
          let eps = (q.data || []).map((x) => x.endpoint).filter((e) => e && e !== mine);
          if (!eps.length) return { err: "δεν έχουν ενεργοποιηθεί ειδοποιήσεις στο κινητό" };
          // επιλογές του κάθε κινητού: κατηγορία κλειστή ή ώρες ησυχίας (εκτός από τις αποτυχίες/σύστημα που είναι επείγουσες μόνο αν το θέλει)
          try {
            const pr = await sb6.from("oncall_labs").select("name_key,data").like("name_key", "pushpref|%");
            const P = {}; (pr.data || []).forEach((x) => { P[x.name_key.slice(9)] = x.data || {}; });
            const hx = async (e) => [...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(e)))].slice(0, 8).map((b) => b.toString(16).padStart(2, "0")).join("");
            const h = new Date().getHours(), keep = [];
            const rm = (x) => String(x || "").replace(/-\d+$/, "");
            window.__pdxPushBody = {};
            for (const e of eps) {
              const o = P[await hx(e)]; if (!o) { keep.push(e); continue; }
              // 🛏 θάλαμοι ΑΥΤΟΥ του κινητού (ρύθμιση «Οι θάλαμοί μου» ανά συσκευή — όχι του λογαριασμού, που μπορεί να είναι κοινός)
              const myR = Array.isArray(o.rooms) ? o.rooms.map(String) : [];
              if (myR.length && opt) {
                if (opt.room && /^\d/.test(String(opt.room)) && !myR.includes(rm(opt.room))) continue;
                if (Array.isArray(opt.groups)) { const g = opt.groups.filter((x) => x.room === "*" || myR.includes(rm(x.room))); if (!g.length) continue; window.__pdxPushBody[e] = g.map((x) => x.body).join("\n"); }
              }
              if (o.cats && o.cats[cat] === false) continue;
              const qh = Array.isArray(o.quiet) && o.quiet.length === 2 && o.quiet[0] !== o.quiet[1] ? o.quiet : null;
              if (qh && (qh[0] < qh[1] ? (h >= qh[0] && h < qh[1]) : (h >= qh[0] || h < qh[1])) && !(o.quietAllow || []).includes(cat)) continue;
              keep.push(e);
            }
            eps = keep;
          } catch (e) {}
          if (!eps.length) return { ok: true, n: 0, filtered: true };
          const now = new Date().toISOString();
          const PB = window.__pdxPushBody || {};
          const ins = await sb6.from("oncall_reminders").insert(eps.map((endpoint) => ({ endpoint, fire_at: now, title, body: String(PB[endpoint] || body).slice(0, 900) })));
          if (ins.error) return { err: ins.error.message };
          // ⚡ αποστολή ΤΩΡΑ (όχι στον επόμενο γύρο του χρονοπρογραμματιστή, έως 1′ αργότερα)
          try { await sb6.functions.invoke("send-reminders", { body: {} }); } catch (e) {}
          return { ok: true, n: eps.length };
        } catch (e) { return { err: String(e && e.message || e) }; }
      } });
      const res = r?.result;
      if (res?.ok) { pushSeen.set(pushKey, Date.now()); return res; }
      if (res?.err) last = res.err;
    } catch (e) { last = e.message; }
  }
  return { ok: false, err: last };
}
// Προειδοποίηση μέσα στο Παραδόχαρτο για ασθενείς με ίδιο επώνυμο στο Medilabi (δεν περνούν αυτόματα).
async function labsWarnInApp(lines) {
  const tabs = await chrome.tabs.query({ url: APP_HOSTS.map((h) => `https://${h}/*`) }).catch(() => []);
  for (const t of tabs) {
    chrome.scripting.executeScript({ target: { tabId: t.id }, world: "MAIN", args: [lines], func: (lines) => {
      const ID = "efbotLabsWarn", sig = JSON.stringify(lines);
      let b = document.getElementById(ID);
      if (!lines.length) { if (b) b.remove(); return; }
      try { if (sessionStorage.getItem(ID) === sig) return; } catch (e) {} // το έκλεισε ο χρήστης· ξαναδείχνεται μόνο αν αλλάξει κάτι
      if (!b) { b = document.createElement("div"); b.id = ID; document.body.appendChild(b); }
      b.style.cssText = "position:fixed;top:10px;right:10px;z-index:99999;max-width:420px;background:#fff7ed;color:#7c2d12;border:2px solid #f97316;border-radius:10px;padding:10px 12px;font:14px/1.4 system-ui,sans-serif;box-shadow:0 6px 20px rgba(0,0,0,.2)";
      b.innerHTML = "";
      const h = document.createElement("div"); h.style.cssText = "font-weight:700;margin-bottom:4px;display:flex;justify-content:space-between;gap:8px";
      h.append("⚠ Εργαστηριακά: ίδιο επώνυμο");
      const x = document.createElement("button"); x.textContent = "✕"; x.style.cssText = "border:0;background:none;font-size:16px;cursor:pointer;color:inherit";
      x.onclick = () => { try { sessionStorage.setItem(ID, sig); } catch (e) {} b.remove(); };
      h.append(x); b.append(h);
      for (const l of lines) { const d = document.createElement("div"); d.textContent = "• " + l; b.append(d); }
      const f = document.createElement("div"); f.style.cssText = "font-size:12.5px;margin-top:4px;opacity:.85"; f.textContent = "Περάστε τα χειροκίνητα ή γράψτε και το μικρό όνομα στο Παραδόχαρτο.";
      b.append(f);
    } }).catch(() => {});
  }
}
// Γράφει στον πίνακα oncall_lab_inbox μέσα από την καρτέλα του Παραδόχαρτου (με τη σύνδεση του χρήστη εκεί).
// Αν υπάρχει προηγούμενη εγγραφή του ίδιου ασθενή σήμερα (π.χ. ήρθε αργότερα η CRP), αντικαθίσταται.
async function labsSendToApp(items, date) {
  const tabs = await chrome.tabs.query({ url: APP_HOSTS.map((h) => `https://${h}/*`) });
  if (!tabs.length) return { ok: false, err: "κλειστό Παραδόχαρτο" };
  let last = "χωρίς απάντηση";
  for (const t of tabs) {
    try {
      const [r] = await chrome.scripting.executeScript({ target: { tabId: t.id }, world: "MAIN", args: [items, date], func: async (items, date) => {
        try {
          if (typeof sb6 === "undefined") return { err: "παλιά έκδοση εφαρμογής" };
          const ss = (await sb6.auth.getSession()).data.session;
          if (!ss) return { err: "δεν είστε συνδεδεμένος στο Παραδόχαρτο" };
          const ids = {}; let errs = 0;
          for (const it of items) {
            if (it.prevId) await sb6.from("oncall_lab_inbox").delete().eq("id", it.prevId);
            const r = await sb6.from("oncall_lab_inbox").insert(Object.assign({ lab_date: date, name: it.name }, it.v)).select("id").single();
            if (r.error) errs++; else ids[it.key] = r.data.id;
          }
          return { ok: true, ids, errs };
        } catch (e) { return { err: String(e && e.message || e) }; }
      } });
      const res = r?.result;
      if (res?.ok) return res;
      if (res?.err) last = res.err;
    } catch (e) { last = e.message; }
  }
  return { ok: false, err: last };
}
// ===== Ενημέρωση διαδικασιών ΧΩΡΙΣ άνοιγμα του πάνελ =====
// Ίδια λογική με το load()/migrate() του sidepanel.js: νέες διαδικασίες (π.χ. «Φάκελος: ανάγνωση ΑΜΚΑ», «ΑΗΦΥ: διαγνώσεις»),
// νέα βήματα εξιτηρίου, έτοιμοι στόχοι. Έτσι ο υπολογιστής της κλινικής ενημερώνεται μόνος του μετά από κάθε έκδοση,
// χωρίς να χρειάζεται κάποιος να ανοίξει το πάνελ. Όσα έχει μάθει ο χρήστης (🎯) δεν πειράζονται.
const WF_DATA_VERSION = 13;   // = VERSION του sidepanel.js
const WF_NO_TARGET = ["wait", "copy", "tab", "goto"];
async function bgMigrateWorkflows() {
  try {
    if (typeof DEFAULT_WORKFLOWS === "undefined") return false;
    let { efbot: state } = await chrome.storage.local.get("efbot");
    let changed = false;
    if (!state) { state = { workflows: structuredClone(DEFAULT_WORKFLOWS), current: DEFAULT_WORKFLOWS[0].id, values: {}, ver: WF_DATA_VERSION }; changed = true; }
    if (!state.workflows || !state.workflows.length) { state.workflows = structuredClone(DEFAULT_WORKFLOWS); changed = true; }
    if ((state.ver || 1) < WF_DATA_VERSION) {
      const have = new Set(state.workflows.map((w) => w.id));
      const taught = new Map();
      for (const w of state.workflows) for (const st of w.steps) if (st.target && !taught.has(st.label)) taught.set(st.label, st.target);
      for (const d of DEFAULT_WORKFLOWS) {
        if (!d.since || d.since <= (state.ver || 1) || have.has(d.id)) continue;
        const c = structuredClone(d);
        for (const st of c.steps) if (!WF_NO_TARGET.includes(st.type) && taught.has(st.label)) st.target = structuredClone(taught.get(st.label));
        state.workflows.push(c);
      }
      const ex = state.workflows.find((w) => w.id === "exitirio"), dEx = DEFAULT_WORKFLOWS.find((w) => w.id === "exitirio");
      if (ex && dEx) {
        let anchor = ex.steps.length;
        for (const st of [...dEx.steps].reverse()) {
          const at = ex.steps.findIndex((x) => x.label === st.label);
          if (at >= 0) { anchor = at; continue; }
          if (st.type === "skipif" || st.since === 3) ex.steps.splice(anchor, 0, structuredClone(st));
        }
        for (const st of ex.steps) if (st.label === "Ώρα: τώρα") {
          if (st.value === "{ώρα}") st.value = "{ημερομηνία} {ώρα}";
          if (st.fillValue === "{ώρα}") st.fillValue = "{ημερομηνία} {ώρα}";
        }
      }
      if ((state.ver || 1) < 10) {
        for (const d of DEFAULT_WORKFLOWS.filter((x) => x.preset)) {
          const i = state.workflows.findIndex((w) => w.id === d.id), fresh = structuredClone(d);
          if (i < 0) { state.workflows.push(fresh); continue; }
          const old = state.workflows[i], ours = old.steps.every((x) => !x.target || x.target.preset);
          if ((d.id === "exitirio" && (state.ver || 1) < 4) || ours) state.workflows[i] = { ...fresh, name: old.name, collected: old.collected, oldSteps: old.oldSteps || old.steps };
        }
      }
      state.ver = WF_DATA_VERSION; changed = true;
    }
    // διαδικασίες που λείπουν εντελώς (π.χ. σβήστηκαν ή ήρθαν σε έκδοση χωρίς σημάδι since)
    for (const id of ["fakelos_amka", "aihfy_dx"]) {
      if (!state.workflows.some((w) => w.id === id)) { const d = DEFAULT_WORKFLOWS.find((x) => x.id === id); if (d) { state.workflows.push(structuredClone(d)); changed = true; } }
    }
    if (E.patchWorkflows(state)) changed = true;
    if (changed) await chrome.storage.local.set({ efbot: state });
    return changed;
  } catch (e) { console.warn("bgMigrateWorkflows", e); return false; }
}
bgMigrateWorkflows();
chrome.runtime.onInstalled.addListener(() => { bgMigrateWorkflows(); });

// ===== Εργασίες από το κινητό (Παραδόχαρτο → πίνακας oncall_jobs) =====
// Το κινητό γράφει εργασία (παραγγελία εξετάσεων, συνταγογράφηση, κλήση για εκτίμηση). Εδώ τις παραλαμβάνουμε
// μέσα από την ανοιχτή καρτέλα του Παραδόχαρτου. Όσες δεν έχουν ακόμα εκτελεστή μένουν «παραλήφθηκε».
const JOBS_ALARM = "efbot-jobs";
const JOB_KIND = { medplanprobe: "💊 ΝΠΣ: αναζήτηση φαρμάκου (δοκιμή)", evoradsrc: "🔎 Evorad: κώδικας viewer", evoradimg: "🫁 Ακτινογραφία θώρακος", evoradfind: "🩻 Evorad: εξετάσεις ασθενή", botcfg: "⚙️ Ρυθμίσεις bot", emrmedmap: "💊 ΝΠΣ φάρμακα: χαρτογράφηση", evoradprobe: "🩻 Evorad: χαρτογράφηση", findpacs: "🔎 Αναζήτηση Evorad/PACS", rxname: "🔎 ΑΜΚΑ → όνομα (e-prescription)", ehrdocs: "🩻 ΑΗΦΥ απεικονίσεις/γνωματεύσεις", emrmap: "🗺 Χαρτογράφηση φόρμας", cred: "🔐 Κωδικός (κρυπτογραφημένος)", order: "Παραγγελία εξετάσεων", rx: "Συνταγογράφηση", consult: "Κλήση για εκτίμηση", discharge: "Εξιτήριο", comorb: "Συννοσηρότητες → ιστορικό", ehrdx: "Διαγνώσεις από ΑΗΦΥ", ehrlabs: "Εργαστηριακά από ΑΗΦΥ", medlabs: "Εργαστηριακά από Medilabi", logins: "Έλεγχος συνδέσεων" };
const JOB_RUNNERS = {}; // kind → async (job) => ({ status, note }) — προστίθενται όταν ρυθμιστεί κάθε ροή
alarmEnsure(JOBS_ALARM, { periodInMinutes: 0.5 });
// 📁 ευρετήριο αρχείων κλινικής πάντα έτοιμο: ping στο βοηθητικό ανά 15′ (το βοηθητικό ξαναχτίζει στο παρασκήνιο αν είναι >30′)
// → η διεργασία PowerShell μένει ανοιχτή (χωρίς 5–8″ εκκίνηση) και οι αναζητήσεις βρίσκουν φρέσκο ευρετήριο.
alarmEnsure("efbot-fsidx", { delayInMinutes: 1, periodInMinutes: 15 });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === "efbot-fsidx" && typeof fsCall === "function" && (new Date().getHours() >= 22 || new Date().getHours() < 7 || fsPort)) fsCall({ op: "ping" }, 30000).then((r) => { try { chrome.storage.session.set({ efbotFsIdx: { at: Date.now(), ok: !!(r && r.ok), roots: (r && r.roots || []).length } }); } catch (e) {} }).catch(() => {}); });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === JOBS_ALARM) jobsTick(); });
// 🧹 Καρτέλες που ξέμειναν (π.χ. 11 Medilabi μετά από παραγγελίες): ΜΟΝΟ στα παράθυρα του bot, ΜΟΝΟ όταν δεν τρέχει τίποτα,
// κρατά 1 καρτέλα ανά διεύθυνση (την πιο πρόσφατη ή όποια θυμάται το bot) — ποτέ καρτέλες του γιατρού.
let sysMem = { at: 0, free: -1, ram: -1 };
let sysExt = { at: 0 };   // 7/11: ουρές εκτυπωτών, Defender, αυτόματη είσοδος Windows, τελευταία ενημέρωση (κάθε 30′)
// 🌐 6/11: χρόνος απόκρισης των συστημάτων από αυτόν τον υπολογιστή (κάθε 5′, μόνο αίτημα κεφαλίδας, χωρίς σύνδεση/κωδικούς)
let netLat = { at: 0, v: {} };
async function netLatRefresh() {
  if (Date.now() - netLat.at < 5 * 60000 || jobRunningId) return; netLat.at = Date.now();
  let med = ""; try { const t = (await chrome.tabs.query({}).catch(() => [])).find((x) => /\/MedilabiEPSMY\//i.test(x.url || "")); if (t) med = new URL(t.url).origin; } catch (e) {}
  const H = [["Βάση", PDX_SB + "/rest/v1/"], ["ΝΠΣ", "https://apps.e-ygeia.gov.gr/"], ["ΑΗΦΥ", "https://doctor.ehealthrecord.gov.gr/"], ["e-presc", "https://www.e-prescription.gr/"]].concat(med ? [["Medilabi", med + "/MedilabiEPSMY/"]] : []);
  const v = {};
  await Promise.all(H.map(async ([n, u]) => { const t0 = performance.now(); const ac = new AbortController(); const to = setTimeout(() => ac.abort(), 8000);
    try { await fetch(u, { method: "GET", mode: "no-cors", cache: "no-store", credentials: "omit", redirect: "manual", signal: ac.signal }); v[n] = Math.round(performance.now() - t0); } catch (e) { v[n] = -1; } finally { clearTimeout(to); } }));
  // 🕒 ρολόι υπολογιστή vs server (κεφαλίδα Date)· ±2″ ακρίβεια
  let skew = null; try { const t0 = Date.now(); const r = await fetch(PDX_SB + "/rest/v1/", { method: "HEAD", cache: "no-store" }); const d = Date.parse(r.headers.get("date") || ""); if (d) skew = Math.round(((t0 + Date.now()) / 2 - d) / 1000); } catch (e) {}
  netLat = { at: Date.now(), v, skew };
  netAlert(v).catch(() => {});
}
// 🚨 7/11: ειδοποίηση όταν ΝΠΣ/Medilabi/ΑΗΦΥ/e-presc δεν απαντούν από αυτόν τον υπολογιστή για 2 συνεχόμενους ελέγχους (≈10′), 07:00–22:00· και όταν επανέλθουν
const netDown = {};
async function netAlert(v) {
  const h = new Date().getHours(); if (h < 7 || h >= 22) return;
  if (!(v["Βάση"] >= 0)) return;   // χωρίς ίντερνετ καθόλου → δεν φτάνει ούτε η ειδοποίηση
  const me = (await botId()).slice(-5);
  for (const n of ["ΝΠΣ", "Medilabi", "ΑΗΦΥ", "e-presc"]) { if (!(n in v)) continue;
    const d = netDown[n] || (netDown[n] = { c: 0, sent: 0, since: 0 });
    if (v[n] < 0) { d.c++; if (!d.since) d.since = Date.now(); if (d.c === 2 && !d.sent) { d.sent = Date.now(); labsPushPhone("⚠ " + n + " δεν απαντά", "Από τον υπολογιστή …" + me + " εδώ και ~" + Math.max(5, Math.round((Date.now() - d.since) / 60000)) + "′. Οι εργασίες bot που το χρειάζονται θα καθυστερήσουν.").catch(() => {}); } }
    else { if (d.sent) labsPushPhone("✓ " + n + " απαντά ξανά", "Υπολογιστής …" + me + " · διακοπή ~" + Math.max(1, Math.round((Date.now() - d.since) / 60000)) + "′").catch(() => {}); netDown[n] = { c: 0, sent: 0, since: 0 }; }
  }
}
// 🌙 7/11: νυχτερινή επανεκκίνηση Windows (επιλογή ανά υπολογιστή: oncall_config «bot_nightreboot» = {id: "sun"|"need"})
//   "sun" = κάθε Κυριακή 04:00–04:59 · "need" = όποια νύχτα τα Windows περιμένουν επανεκκίνηση για ενημερώσεις ή είναι ανοιχτά ≥7 ημέρες.
//   Ποτέ όσο τρέχει εργασία ή αν κάποιος δούλευε τα τελευταία 30′· μία φορά ανά νύχτα· 2′ προειδοποίηση στην οθόνη.
let nightRbC = { at: 0, v: "" };
async function nightReboot() {
  const now = new Date(); if (now.getHours() !== 4 || jobRunningId) return;
  const day = now.toDateString(); const { efbotNightRb: done = "" } = await chrome.storage.local.get("efbotNightRb").catch(() => ({})); if (done === day) return;
  if (Date.now() - nightRbC.at > 10 * 60000) { const me = await botId(); const r = await jobsInApp(async (me) => { try { if (typeof sb6 === "undefined") return null; const x = await sb6.from("oncall_config").select("value").eq("key", "bot_nightreboot").maybeSingle(); return { v: String(((x.data || {}).value || {})[me] || "") }; } catch (e) { return null; } }, [me]).catch(() => null); if (r) nightRbC = { at: Date.now(), v: r.v }; }
  const mode = nightRbC.v; if (!mode) return;
  if (!sysMem.at || Date.now() - sysMem.at > 15 * 60000) await sysMemRefresh(true);
  const need = sysMem.reboot || (sysMem.bootH || sysMem.upH) >= 24 * 7;   // επανεκκίνηση: από το πραγματικό boot (όχι από το τελευταίο άνοιγμα)
  if (!(mode === "sun" && now.getDay() === 0) && !(need && (mode === "need" || mode === "sun"))) return;
  const idle = await new Promise((res) => { try { chrome.idle.queryState(1800, res); } catch (e) { res("active"); } });
  if (idle === "active") return;
  await chrome.storage.local.set({ efbotNightRb: day }).catch(() => {});
  const r = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "reboot", sec: 120 }).catch((e) => ({ ok: false, err: e.message }));
  nightRbLog = { at: Date.now(), ok: !!(r && r.ok), why: mode === "sun" && now.getDay() === 0 ? "Κυριακή" : sysMem.reboot ? "ενημερώσεις Windows" : "ανοιχτός ≥7 ημέρες", err: r && !r.ok ? String(r.err || "") : "" };
}
let nightRbLog = null;
// 🌙 6/11: φροντίδα μνήμης χωρίς ανθρώπους: (α) όταν η ελεύθερη RAM πέσει κάτω από 12% → συμπίεση μνήμης (το πολύ ανά 20′)
// (β) τη νύχτα (02:00–05:00), μία φορά: «κοίμισμα» καρτελών στο παρασκήνιο + συμπίεση. Ποτέ όσο τρέχει εργασία.
const CLIN_HOSTS = /e-ygeia\.gov\.gr|ehealthrecord\.gov\.gr|e-prescription\.gr|evorad|MedilabiEPSMY|medilab/i;
let memCareAt = 0;
async function memCare() {
  if (jobRunningId || !sysMem.at || !(sysMem.ram > 0)) return;
  const now = new Date(), day = now.toDateString(), night = now.getHours() >= 2 && now.getHours() < 5;
  const { efbotMemNight: memNightDay = "" } = await chrome.storage.session.get("efbotMemNight").catch(() => ({}));
  const low = sysMem.free > 0 && sysMem.free / sysMem.ram < 0.12;
  if (!(low && Date.now() - memCareAt > 20 * 60000) && !(night && memNightDay !== day)) return;
  memCareAt = Date.now();
  if (night && memNightDay !== day) { await chrome.storage.session.set({ efbotMemNight: day }).catch(() => {});
    for (const t of await chrome.tabs.query({}).catch(() => [])) { if (t.active || t.discarded || t.audible || t.incognito || t.pinned) continue; let h = ""; try { h = new URL(t.url || "").host; } catch (e) {} if (APP_HOSTS.includes(h) || CLIN_HOSTS.test(t.url || "")) continue; await chrome.tabs.discard(t.id).catch(() => null); } }
  const r = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "trim" }).catch(() => null);
  memCareLog = { at: Date.now(), why: night ? "νύχτα" : "λίγη μνήμη", n: r && r.n || 0, mb: r && r.freedMb || 0 };
}
let memCareLog = null;
async function sysMemRefresh(force) { if (!force && (Date.now() - sysMem.at < 5 * 60000 || jobRunningId)) return; sysMem.at = Date.now(); const wantExt = force || Date.now() - (sysExt.at || 0) > 30 * 60000; const r = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "sysinfo", ext: wantExt }).catch(() => null); if (r && r.ok && r.ext) sysExt = Object.assign({ at: Date.now() }, r.ext); if (r && r.ok) sysMem = { at: Date.now(), ext: sysExt.at ? sysExt : null, free: +r.freeMb || -1, ram: +r.ramMb || -1, cpu: +r.cpu || 0, upH: +r.upH || 0, bootH: +r.bootH || +r.upH || 0, reboot: !!r.reboot, cores: +r.cores || 0, cr: r.chrome || null, ps: r.ps || null, top: Array.isArray(r.top) ? r.top.slice(0, 6) : [], dfree: r.diskFreeGb == null ? -1 : +r.diskFreeGb, dtot: +r.diskGb || 0 }; }
let tabJanAt = 0;
const orderTabSeen = new Map();   // καρτέλα OrderTests.aspx → πότε φάνηκε πρώτη φορά
chrome.tabs.onUpdated.addListener((id, ch) => { if (ch.url && /OrderTests\.aspx/i.test(ch.url) && !orderTabSeen.has(id)) orderTabSeen.set(id, Date.now()); });
try { chrome.tabs.onRemoved.addListener((id) => { orderTabSeen.delete(id); }); } catch (e) {}
async function tabJanitor() {
  if (Date.now() - tabJanAt < 120000 || jobRunningId || sideRunningId || jobsBusy || fastN) return; tabJanAt = Date.now();
  try {
    const { efbotOwnWins: own = [] } = await chrome.storage.session.get("efbotOwnWins");
    const ss = await chrome.storage.session.get(null).catch(() => ({})), keepIds = new Set();
    const scan = (v, d) => { if (d > 4 || v == null) return; if (typeof v === "number") keepIds.add(v); else if (typeof v === "object") for (const x of Object.values(v)) scan(x, d + 1); };
    scan(ss, 0);
    const wins = await chrome.windows.getAll({ populate: true }).catch(() => []);
    let closed = 0;
    for (const w of wins) {
      if (!(w.incognito || own.includes(w.id)) || (w.tabs || []).length < 2) continue;
      const by = {};
      for (const t of w.tabs) { let h = ""; try { h = new URL(t.url || t.pendingUrl || "").host; } catch (e) {} if (!h) continue; (by[h] = by[h] || []).push(t); }
      for (const L of Object.values(by)) {
        if (L.length < 2) continue;
        L.sort((x, y) => (keepIds.has(y.id) - keepIds.has(x.id)) || (y.active - x.active) || ((y.lastAccessed || y.id) - (x.lastAccessed || x.id)));
        // 🧾 φόρμα παραγγελίας Medilabi (OrderTests.aspx) νεότερη από 25′: ΠΟΤΕ (έκλεινε ενώ περίμενε έγκριση)
        const young = (t) => { if (!/OrderTests\.aspx/i.test(t.url || t.pendingUrl || "")) return false; if (!orderTabSeen.has(t.id)) orderTabSeen.set(t.id, Date.now()); return Date.now() - orderTabSeen.get(t.id) < 25 * 60000; };
        const drop = L.slice(1).filter((t) => !keepIds.has(t.id) && !t.active && !young(t));
        for (const t of drop) { if (w.tabs.length - closed <= 1) break; await chrome.tabs.remove(t.id).catch(() => {}); closed++; }
      }
    }
    if (closed) chrome.storage.session.set({ efbotTabJan: { at: Date.now(), closed } }).catch(() => {});
  } catch (e) {}
}
chrome.alarms.onAlarm.addListener((a) => { if (a.name === JOBS_ALARM) setTimeout(() => { tabJanitor().catch(() => {}); sysMemRefresh().then(() => memCare()).then(() => nightReboot()).catch(() => {}); netLatRefresh().catch(() => {}); }, 5000); });
setTimeout(() => jobsTick(), 3000); // με την εκκίνηση: παραλαβή + στήσιμο ζωντανής συνδρομής
// ⏱ κάθε κλήση στη σελίδα του Παραδόχαρτου έχει όριο (15″ — μεγαλύτερο μόνο όπου ζητηθεί): παγωμένη καρτέλα δεν κρατά πια
// το jobsBusy για πάντα. Η καρτέλα της εφαρμογής δεν «πετιέται» από το Chrome (autoDiscardable:false), όπως οι άλλες του bot.
const appNoDiscard = new Set();
// 🔀 6/11: καρτέλα Παραδόχαρτου σε παλιά διεύθυνση (Netlify/GitHub, αποθηκευμένο αντίγραφο) → ανοίγει την κύρια (APP_HOSTS[0]),
// συνδέεται με τον αποθηκευμένο κωδικό του Παραδόχαρτου ΜΟΝΟ σε αυτή, και μόλις δουλέψει κλείνει τις παλιές (όχι την ενεργή του χρήστη).
let appMigAt = 0;
async function appTabMigrate() {
  if (Date.now() - appMigAt < 4 * 60000 || jobRunningId) return;
  appMigAt = Date.now();
  const hostOf = (t) => { try { return new URL(t.url).host; } catch (e) { return ""; } };
  const all = await chrome.tabs.query({ url: APP_HOSTS.map((h) => `https://${h}/*`) }).catch(() => []);
  const olds = all.filter((t) => hostOf(t) !== APP_HOSTS[0] && !t.incognito);
  if (!olds.length) return;
  let nw = all.find((t) => hostOf(t) === APP_HOSTS[0]);
  const { efbotPdxCred: c } = await V.get("efbotPdxCred").catch(() => ({}));
  const hasC = !!(c && c.user && c.pass);
  if (!nw) {
    if (!hasC) { const { efbotMigNote: mn = 0 } = await chrome.storage.local.get("efbotMigNote"); if (Date.now() - mn > 6 * 3600e3) { await chrome.storage.local.set({ efbotMigNote: Date.now() }); notify("🔀 Παραδόχαρτο σε παλιά διεύθυνση", "Ανοίξτε " + APP_URL + " , συνδεθείτε και κλείστε την παλιά καρτέλα", false); } return; }   // χωρίς κωδικό δεν ανοίγουμε καρτέλα που θα έμενε αποσυνδεδεμένη
    nw = await chrome.tabs.create({ url: APP_URL, active: false, windowId: olds[0].windowId }).catch(() => null);
    if (!nw) return;
    appMigAt = Date.now() - 3 * 60000;   // ξανά σε ~1′ (να φορτώσει)
    return;
  }
  const run = async (func, args) => { const [r] = await chrome.scripting.executeScript({ target: { tabId: nw.id }, world: "MAIN", args, func }).catch(() => [null]); return r && r.result; };
  const st = await run(async () => { try { if (typeof sb6 === "undefined") return { wait: true }; const ss = (await sb6.auth.getSession()).data.session; if (!ss) return { nos: true }; const t = await sb6.from("oncall_jobs").select("id").limit(1); const ks = typeof window.pdxCryptoStatus === "function" ? window.pdxCryptoStatus() : ""; return { ok: !t.error, key: ks }; } catch (e) { return { err: String(e && e.message || e) }; } }, []);
  if (st && st.nos && hasC) {
    await run(async (user, pass) => { try { const email = user.indexOf("@") < 0 ? user.toLowerCase() + "@paradoxarto.app" : user; const x = await sb6.auth.signInWithPassword({ email, password: pass }); if (x.error) return { err: x.error.message }; setTimeout(() => location.reload(), 300); return { ok: true }; } catch (e) { return { err: String(e && e.message || e) }; } }, [c.user, c.pass]);
    appMigAt = Date.now() - 3 * 60000; return;
  }
  if (st && st.ok && st.key !== "On") return;   // 6/11: η νέα καρτέλα δεν έχει ακόμα το κλειδί της κλινικής → οι παλιές ΜΕΝΟΥΝ (αλλιώς χάνονται οι ασθενείς)
  if (st && st.ok) {
    let n = 0; for (const t of olds) if (!t.active) { await chrome.tabs.remove(t.id).catch(() => {}); n++; }
    if (n) bgMark("🔀 Παραδόχαρτο: πέρασε στη " + APP_HOSTS[0] + " (έκλεισαν " + n + " παλιές καρτέλες)");
  }
}
async function jobsInApp(func, args, ms) {
  const hostOf = (t) => { try { return new URL(t.url).host; } catch (e) { return ""; } };
  const tabs = (await chrome.tabs.query({ url: APP_HOSTS.map((h) => `https://${h}/*`) }).catch(() => [])).sort((a, b) => (hostOf(a) === APP_HOSTS[0] ? 0 : 1) - (hostOf(b) === APP_HOSTS[0] ? 0 : 1));   // πρώτα η κύρια διεύθυνση
  for (const t of tabs) {
    if (!appNoDiscard.has(t.id)) { appNoDiscard.add(t.id); try { chrome.tabs.update(t.id, { autoDiscardable: false }).catch(() => {}); } catch (e) {} }
    try {
      const [r] = await Promise.race([chrome.scripting.executeScript({ target: { tabId: t.id }, world: "MAIN", args, func }), new Promise((res) => setTimeout(() => res([null]), ms || 15000))]);
      if (r?.result && !r.result.skip) return r.result;
    } catch (e) {}
  }
  return null;
}

// ===== 🔑 Κωδικοί: «μάθε από τη σύνδεσή μου» + αυτόματη σύνδεση ΑΗΦΥ =====
// Οι κωδικοί που έχει αποθηκευμένους το Chrome ΔΕΝ διαβάζονται από επεκτάσεις. Γι' αυτό: ο χρήστης πατά στο πάνελ
// «Μάθε τους κωδικούς» (ενεργό 15′) και συνδέεται μία φορά όπως πάντα (το Chrome τους συμπληρώνει) — τη στιγμή που
// πατά «Είσοδος» το bot κρατά όνομα και κωδικό ΜΟΝΟ σε αυτόν τον υπολογιστή (chrome.storage.local), ανά διεύθυνση.
// Εκτός αυτού του 15λεπτου δεν κρατιέται τίποτα.
async function credLearnArmed() { const { efbotCredLearn: u } = await chrome.storage.session.get("efbotCredLearn"); return !!u && u > Date.now(); }
// «Δικοί μου» λογαριασμοί (efbot.settings.credAuto): όταν ο ίδιος συνδέεται κανονικά σε αυτόν τον υπολογιστή, ο κωδικός
// ανανεώνεται μόνος του (π.χ. μετά από αλλαγή κωδικού). Λογαριασμοί που δεν είναι στη λίστα: μόνο με «Μάθε τους κωδικούς».
async function credAutoUsers() { const { efbot } = await chrome.storage.local.get("efbot"); return (efbot?.settings?.credAuto || []).map((x) => String(x).trim().toLowerCase()).filter(Boolean); }
async function credLearnSave(m) {
  const armed = await credLearnArmed();
  const host = String(m.host || "").toLowerCase(), user = String(m.user || "").trim(), pass = String(m.pass || "");
  const auto = !armed && user && (await credAutoUsers()).includes(user.toLowerCase());
  if (!armed && !auto) return { ok: false };
  if (!host || !pass) return { ok: false };
  const { efbotCredByHost: all = {} } = await V.get("efbotCredByHost");
  if (auto) {   // ίδιος κωδικός με τον αποθηκευμένο: τίποτα (και καμία ειδοποίηση)
    const v = all[host], l = Array.isArray(v) ? v : v ? [v] : [];
    if (l.some((a) => String(a.user || "").toLowerCase() === user.toLowerCase() && a.pass === pass)) return { ok: true, same: true };
  }
  // Πολλοί λογαριασμοί ανά διεύθυνση (π.χ. ΑΗΦΥ): κρατάμε λίστα. Ο ίδιος χρήστης ενημερώνεται (νέος κωδικός) και πάει μπροστά.
  const same = (a) => String(a.user || "").trim().toLowerCase() === user.toLowerCase();
  let nAcc0 = 0;
  const upd = await V.update("efbotCredByHost", (cur0) => {
    const cur = cur0 && typeof cur0 === "object" ? cur0 : {};
    const list = Array.isArray(cur[host]) ? cur[host].slice() : (cur[host] ? [cur[host]] : []);
    const kept = list.filter((a) => !same(a)); kept.unshift({ user, pass, ts: Date.now() });
    cur[host] = kept.slice(0, 8); nAcc0 = cur[host].length; return cur;
  }).catch((e) => ({ ok: false, err: e.message }));
  if (!upd.ok) { notify("🔑 Η σύνδεση ΔΕΝ αποθηκεύτηκε", upd.err || "σφάλμα κρυπτογράφησης", true); return { ok: false }; }
  all[host] = new Array(nAcc0);
  const patch = {};
  await chrome.storage.session.remove("efbotAhfyBad");   // νέος/αλλαγμένος κωδικός: ξαναδοκιμάζονται όλοι
  const nAcc = all[host].length;
  const what = [];
  // ιατρικός φάκελος (e-ygeia): οι ίδιες ρυθμίσεις με τη χειροκίνητη αποθήκευση
  if (/e-ygeia\.gov\.gr$/.test(host)) {
    const { efbot } = await chrome.storage.local.get("efbot");
    if (efbot) { efbot.settings = efbot.settings || {}; if (user) efbot.settings.emrUser = user; await chrome.storage.local.set({ efbot }); }
    patch.efbotEmrCred = { pass, ts: Date.now() }; await chrome.storage.session.remove("efbotEmrLoginBad");
    what.push("Ιατρικός φάκελος");
  }
  // Medilabi (σελίδα Login.aspx)
  if (/login\.aspx/i.test(m.path || "") || /medilabi/i.test(host)) {
    patch.efbotLabsCred = { user, pass, ts: Date.now() }; await chrome.storage.session.remove("efbotLabsLoginTry");
    what.push("Medilabi");
  }
  if (!what.length) what.push(host);
  const sv = await V.set(patch).catch((e) => ({ ok: false, err: e.message }));
  if (!sv.ok) { notify("🔑 Η σύνδεση ΔΕΝ αποθηκεύτηκε", sv.err || "σφάλμα κρυπτογράφησης", true); return { ok: false }; }
  notify("🔑 Αποθηκεύτηκε η σύνδεση", what.join(", ") + (user ? " · χρήστης " + user : "") + (nAcc > 1 ? " · " + nAcc + " λογαριασμοί για αυτή τη διεύθυνση" : "") + (sv.mode === "dpapi" ? " 🔒 κρυπτογραφημένα" : "") + " — από εδώ και πέρα συνδέεται μόνο του.", false);
  return { ok: true };
}

// 🔑 Κωδικός που σταμάτησε να δουλεύει (π.χ. άλλαξε στο e-prescription): ειδοποίηση στο κινητό, μία φορά τη μέρα ανά λογαριασμό.
// Το bot ΔΕΝ διαβάζει τους κωδικούς του Chrome· ο νέος κωδικός περνά με «Μάθε τους κωδικούς» + μία σύνδεση.
// 🔒 Κρυπτογράφηση κωδικών: μετάβαση στο «χρηματοκιβώτιο» μόλις υπάρξει το βοηθητικό των Windows (έλεγχος το πολύ ανά 10′)
async function vaultMigrateMaybe(force) {
  const { efbotVaultChk: t = 0 } = await chrome.storage.session.get("efbotVaultChk");
  if (!force && Date.now() - t < 10 * 60000) return;
  await chrome.storage.session.set({ efbotVaultChk: Date.now() });
  await V.migrate();
  const st = await V.status();
  await chrome.storage.session.set({ efbotVaultMode: st.mode });
  if (st.mode === "locked") vaultLockedPush();
}
async function vaultLockedPush() {
  const day = new Date().toDateString();
  const { efbotVaultLockSeen: d } = await chrome.storage.local.get("efbotVaultLockSeen");
  if (d === day) return;
  await chrome.storage.local.set({ efbotVaultLockSeen: day });
  notify("🔒 Οι κωδικοί δεν ξεκλειδώνουν", "Το βοηθητικό κρυπτογράφησης των Windows δεν απαντά. Βεβαιωθείτε ότι τρέχει το efbot-update.bat (το ξαναστήνει μόνο του).", true);
  labsPushPhone("🔒 ef-bot: οι κωδικοί δεν ξεκλειδώνουν", "Στον υπολογιστή του bot: να τρέχει το efbot-update.bat. Αν άλλαξε ο λογαριασμός Windows, ξαναμάθετε τους κωδικούς («🔑 Μάθε τους κωδικούς»).").catch(() => {});
}
vaultMigrateMaybe(true).catch(() => {});
let credPushMute = false;   // 🔎 διαγνωστικός έλεγχος λογαριασμών: χωρίς ειδοποιήσεις
async function credFailPush(sys, user, why) {
  if (credPushMute) return;
  if (/λήξει|expired/i.test(String(why || ""))) {   // 8/11: ΛΗΞΗ ισχύος ≠ αλλαγμένος κωδικός (ο ίδιος ο κωδικός είναι σωστός)
    const day = new Date().toDateString(), key = sys + "|" + (user || "") + "|exp";
    const { efbotCredFailSeen: seen = {} } = await chrome.storage.local.get("efbotCredFailSeen");
    if (seen[key] === day) return;
    seen[key] = day; await chrome.storage.local.set({ efbotCredFailSeen: seen });
    labsPushPhone("⏳ " + sys + ": έληξε η ισχύς του κωδικού" + (user ? " του " + user : ""), "Ο κωδικός ΔΕΝ είναι λάθος — το ίδιο το " + sys + " ζητά περιοδική ΑΛΛΑΓΗ («Ο κωδικός πρόσβασής σας έχει λήξει»). Ο γιατρός αυτού του λογαριασμού: e-prescription.gr/password → νέος κωδικός, και μετά Παραδόχαρτο → Ρυθμίσεις → 🔐 Κωδικοί του bot. Ως τότε το bot χρησιμοποιεί τους άλλους λογαριασμούς.").catch(() => {});
    return;
  }
  const day = new Date().toDateString(), key = sys + "|" + (user || "");
  const { efbotCredFailSeen: seen = {} } = await chrome.storage.local.get("efbotCredFailSeen");
  if (seen[key] === day) return;
  seen[key] = day; await chrome.storage.local.set({ efbotCredFailSeen: seen });
  labsPushPhone("🔑 " + sys + ": ο κωδικός" + (user ? " του " + user : "") + " δεν δουλεύει" + (why ? " («" + String(why).slice(0, 60) + "»)" : ""), "Μάλλον άλλαξε: Παραδόχαρτο → Ρυθμίσεις → 🔐 Κωδικοί του bot → νέος κωδικός. Ή στον υπολογιστή του bot: ef-bot → «🔑 Μάθε τους κωδικούς» και μία σύνδεση με τον νέο. Ως τότε το bot δοκιμάζει άλλους αποθηκευμένους λογαριασμούς.").catch(() => {});
}
// ΑΗΦΥ: αν η καρτέλα του bot βρίσκεται σε σελίδα σύνδεσης, γράφει όνομα/κωδικό (της διεύθυνσης όπου βρίσκεται) και πατά «Είσοδος».
// Μία προσπάθεια ανά ρύθμιση κωδικού: αν αποτύχει, δεν ξαναδοκιμάζει (να μην κλειδωθεί ο λογαριασμός).
async function ahfyAutoLogin(tabId) {
  const t0 = Date.now();
  ahfyAutoLogin.lastErr = "";
  const { efbotCredByHost: all = {} } = await V.get("efbotCredByHost");
  if (!Object.keys(all).length && (await V.status()).mode === "locked") { vaultLockedPush(); return { ok: false, err: "οι κωδικοί είναι κλειδωμένοι (λείπει το βοηθητικό κρυπτογράφησης των Windows;)" }; }
  const accountsFor = (host) => { const one = (h) => { const v = all[h]; return Array.isArray(v) ? v.filter((a) => a && a.pass) : (v && v.pass ? [v] : []); }; const seen = new Set(), out = []; for (const a of [...one(host), ...one("*ahfy"), ...one("*epres")]) { const id = String(a.user || "").toLowerCase(); if (!seen.has(id)) { seen.add(id); out.push(a); } } return out; };   // + όσοι ήρθαν από απόσταση («*ahfy»)
  const sigOf = (host, a) => host + "|" + String(a.user || "") + "|" + (a.ts || 0);
  if (!Object.keys(all).length) return { ok: false, err: "δεν έχουν αποθηκευτεί κωδικοί (ef-bot → «Μάθε τους κωδικούς»)" };
  // «Χαλασμένοι» λογαριασμοί (λάθος κωδικός σήμερα): δεν ξαναδοκιμάζονται, για να μην κλειδωθούν. Μηδενίζονται με νέα εκμάθηση.
  let { efbotAhfyBad: badMap = {} } = await chrome.storage.session.get("efbotAhfyBad");
  const probe = async (user, pass) => {
    const [r] = await chrome.scripting.executeScript({ target: { tabId }, args: [user, pass], func: (user, pass) => {
      const vis = (e) => { if (!e) return false; const r = e.getBoundingClientRect(); const cs = getComputedStyle(e); return r.width > 0 && r.height > 0 && cs.display !== "none" && cs.visibility !== "hidden"; };
      const pw = [...document.querySelectorAll("input[type=password]")].find(vis);
      if (!pw) return { state: document.readyState === "complete" ? "other" : "loading" };
      if (pass == null) {
        const err = [...document.querySelectorAll(".error, .errorMessage, .alert, [class*=error], [id*=error], [class*=Error], [class*=invalid]")].filter(vis).map((e) => (e.innerText || "").trim()).filter(Boolean).join(" ").slice(0, 160);
        return { state: "login", err };
      }
      const form = pw.form || document;
      const fields = [...form.querySelectorAll("input:not([type=hidden]):not([type=password]):not([type=checkbox]):not([type=radio]):not([type=submit]):not([type=button])")].filter(vis);
      const userEl = fields.filter((f) => f.compareDocumentPosition(pw) & Node.DOCUMENT_POSITION_FOLLOWING).pop() || fields[0];
      const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
      const fill = (el, v) => { el.focus(); set.call(el, v); for (const ev of ["input", "change", "keyup", "blur"]) el.dispatchEvent(new Event(ev, { bubbles: true })); };
      if (userEl) fill(userEl, user || "");
      fill(pw, pass);
      const btn = [...form.querySelectorAll("button, input[type=submit], [role=button]")].filter(vis).find((b) => /submit/i.test(b.type) || /σύνδεση|συνδεση|είσοδος|εισοδος|login|sign in|log in/i.test(b.innerText || b.value || ""));
      if (btn) btn.click(); else if (pw.form && pw.form.requestSubmit) pw.form.requestSubmit(); else pw.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
      return { state: "submitted" };
    } }).catch(() => [null]);
    return r?.result || { state: "error" };
  };
  let submitted = null, submitAt = 0, host = "", errN = 0;
  while (Date.now() - t0 < 120000) {
    if (await ehrLoggedIn(tabId)) {
      if (submitted) {   // ο λογαριασμός που δούλεψε πάει μπροστά για την επόμενη φορά
        const list = Array.isArray(all[host]) ? all[host] : (all[host] ? [all[host]] : []);
        const i = list.findIndex((a) => sigOf(host, a) === submitted.sig);
        if (i > 0) {   // ξαναδιαβάζουμε πριν γράψουμε (μπορεί να άλλαξε στο μεταξύ από «Μάθε»)
          await V.update("efbotCredByHost", (cur0) => {   // ατομικά: όποιος μπήκε πάει μπροστά
            const cur = cur0 && typeof cur0 === "object" ? cur0 : {};
            const l2 = Array.isArray(cur[host]) ? cur[host].slice() : (cur[host] ? [cur[host]] : []);
            const j = l2.findIndex((a) => sigOf(host, a) === submitted.sig);
            if (j > 0) { const [a] = l2.splice(j, 1); l2.unshift(a); cur[host] = l2; }
            return cur;
          }).catch(() => {});
        }
        delete badMap[submitted.sig]; await chrome.storage.session.set({ efbotAhfyBad: badMap });
      }
      return { ok: true, who: submitted && submitted.user };
    }
    const tab = await chrome.tabs.get(tabId).catch(() => null); if (!tab) return { ok: false, err: "έκλεισε η καρτέλα του ΑΗΦΥ" };
    try { host = new URL(tab.url).host.toLowerCase(); } catch (e) {}
    const pr0 = await probe(null, null), st = pr0.state;
    if (st === "ready" || st === "other") {
      if (await ehrLoggedIn(tabId)) continue;
      let path = ""; try { path = new URL(tab.url).pathname; } catch (e) {}
      // αρχική σελίδα του ΑΗΦΥ («Σύνδεση με κωδικούς») ή άλλη σελίδα του site εκτός εφαρμογής: πριν περίμενε στα τυφλά 120″.
      // Τώρα πηγαίνει στην εφαρμογή, που ανακατευθύνει στη φόρμα σύνδεσης (το πολύ μία φορά ανά 10″).
      const offApp = /ehealthrecord/i.test(host) && !/^\/(doctor\/app|auth)\b/.test(path) && !/login|oauth|code=|callback/i.test(tab.url || "");
      if ((offApp || (!/login|auth|signin|oauth|sso/i.test(tab.url || "") && !/ehealthrecord/i.test(host))) && Date.now() - (ahfyAutoLogin.navAt || 0) > 10000) {
        ahfyAutoLogin.navAt = Date.now(); await chrome.tabs.update(tabId, { url: EHR_HOME }).catch(() => {}); await E.sleep(2500); continue;
      }
      await E.sleep(1500); continue;
    }
    if (st === "loading") { await E.sleep(1200); continue; }
    // η σελίδα δεν δέχεται script (σελίδα σφάλματος δικτύου κ.λπ.): πριν περνούσε ως «login» και δοκίμαζε κωδικούς στο κενό
    // για 120″. Τώρα ξαναφορτώνει την εφαρμογή (το πολύ μία φορά ανά 10″) και σημειώνει τον λόγο.
    if (st === "error") {
      errN++;
      ahfyAutoLogin.lastErr = "η καρτέλα δεν διαβάζεται (" + String(tab.url || "").replace(/[?#].*$/, "").slice(0, 80) + (tab.discarded ? ", παγωμένη" : "") + ")";
      // αμέσως μετά την υποβολή κωδικού η σελίδα αλλάζει: σύντομη αδυναμία είναι φυσιολογική — όχι διακοπή της ανακατεύθυνσης
      if (submitted && Date.now() - submitAt < 20000) { await E.sleep(1200); continue; }
      if (tab.discarded || tab.status === "unloaded") { await tabWake(tabId); await E.sleep(800); continue; }
      if (errN >= 3 && Date.now() - (ahfyAutoLogin.navAt || 0) > 10000) { errN = 0; ahfyAutoLogin.navAt = Date.now(); await chrome.tabs.update(tabId, { url: EHR_HOME }).catch(() => {}); await E.sleep(3000); }
      else await E.sleep(1500);
      continue;
    }
    errN = 0;
    // st === "login"
    if (submitted && Date.now() - submitAt < 20000 && !(pr0 && pr0.err)) { await E.sleep(1200); continue; }   // «λάθος» μόνο με ορατό μήνυμα σφάλματος ή αν δεν απάντησε σε 20″ (πριν 6″: αργή σελίδα = «λάθος κωδικός» και αποκλεισμός λογαριασμού)   // μπορεί να φορτώνει ακόμα
    if (submitted) { badMap[submitted.sig] = Date.now(); await chrome.storage.session.set({ efbotAhfyBad: badMap }); credFailPush("ΑΗΦΥ", submitted.user); submitted = null; }   // γύρισε στη σύνδεση = απέτυχε
    const list = accountsFor(host);
    const next = list.find((a) => !badMap[sigOf(host, a)]);
    if (!next) {
      if (!list.length) return { ok: false, err: "δεν υπάρχει αποθηκευμένος κωδικός για " + host + " (ef-bot → «Μάθε τους κωδικούς»)" };
      return { ok: false, err: "κανένας από τους " + list.length + " λογαριασμούς ΑΗΦΥ δεν μπήκε (λάθος κωδικοί;) — ξαναμάθετε κωδικούς στο ef-bot" };
    }
    const r = await probe(next.user, next.pass);
    if (r.state === "submitted") { submitted = { sig: sigOf(host, next), user: next.user }; submitAt = Date.now(); await E.sleep(4000); continue; }
    await E.sleep(1500);
  }
  return { ok: false, err: "ο ΑΗΦΥ δεν ολοκλήρωσε τη σύνδεση έγκαιρα" + (ahfyAutoLogin.lastErr ? " · " + ahfyAutoLogin.lastErr : "") };
}

// Ελληνικό επώνυμο θεράποντα → ταίριασμα με το username του λογαριασμού e-prescription (λατινικά).
// Ώστε να δοκιμάζεται ΠΡΩΤΟΣ ο κωδικός του θεράποντα του εξιτηρίου.
function epresTranslit(s) {
  const map = { α:"a",ά:"a",β:"v",γ:"g",δ:"d",ε:"e",έ:"e",ζ:"z",η:"i",ή:"i",θ:"th",ι:"i",ί:"i",ϊ:"i",ΐ:"i",κ:"k",λ:"l",μ:"m",ν:"n",ξ:"x",ο:"o",ό:"o",π:"p",ρ:"r",σ:"s",ς:"s",τ:"t",υ:"y",ύ:"y",ϋ:"y",ΰ:"y",φ:"f",χ:"ch",ψ:"ps",ω:"o",ώ:"o" };
  let t = String(s || "").toLowerCase();
  t = t.replace(/ου/g,"ou").replace(/αυ/g,"af").replace(/ευ/g,"ef").replace(/γγ/g,"ng").replace(/γκ/g,"gk").replace(/μπ/g,"b").replace(/ντ/g,"nt").replace(/τσ/g,"ts").replace(/τζ/g,"tz");
  return t.split("").map((c) => map[c] != null ? map[c] : c).join("").replace(/[^a-z]/g, "");
}
// «σκελετός»: πέφτουν τα φωνήεντα και ενοποιούνται i/y, ch→h, για να ταιριάζουν διαφορετικές αποδόσεις
const epresSkel = (s) => epresTranslit(s).replace(/ch/g,"h").replace(/y/g,"i").replace(/[aeiou]/g,"");
// βαθμός ταιριάσματος username↔επώνυμο (0 = καμία σχέση)
function epresNameScore(user, surname) {
  const u = String(user || "").toLowerCase().replace(/[^a-z]/g, "");
  const tr = epresTranslit(surname);
  if (!u || tr.length < 3) return 0;
  if (u.includes(tr)) return 100 + tr.length;            // το username περιέχει όλο το επώνυμο
  for (let n = tr.length - 1; n >= 4; n--) if (u.includes(tr.slice(0, n))) return 40 + n;  // ή την αρχή του
  const su = String(user || "").toLowerCase().replace(/[^a-z]/g, "").replace(/ch/g,"h").replace(/y/g,"i").replace(/[aeiou]/g,""), ss = epresSkel(surname);
  if (ss.length >= 3 && su.includes(ss)) return 20 + ss.length;  // ή ταίριασμα στον σκελετό (χωρίς φωνήεντα)
  return 0;
}

// 💊 e-prescription: σύνδεση με τους αποθηκευμένους λογαριασμούς («Μάθε τους κωδικούς»), όπως στον ΑΗΦΥ:
// μία δοκιμή ανά λογαριασμό (ώστε να μην κλειδωθεί). Όποιος μπει πάει μπροστά για την επόμενη φορά.
// Επιστρέφει και ΠΟΙΟΣ μπήκε: η συνταγή ετοιμάζεται στο όνομα αυτού του λογαριασμού.
const EP_HOME_URL = "https://www.e-prescription.gr/epres/patient";
async function epresLoggedIn(tabId) {
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: () => {
      const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      const pw = [...document.querySelectorAll("input[type=password]")].some(vis);
      return location.host === "www.e-prescription.gr" && /^\/epres(\/|$)/.test(location.pathname) && !pw && !!document.querySelector("a[href='/epres/patient']");
    } });
    return !!r?.result;
  } catch (e) { return false; }
}
// Το Chrome επιτρέπει στον χρήστη να περιορίσει την επέκταση σε «συγκεκριμένους ιστότοπους». Τότε οι σελίδες που λείπουν
// (π.χ. η σελίδα εισόδου του e-prescription σε άλλη διεύθυνση) δεν διαβάζονται. Λέμε ακριβώς τι να αλλάξει.
async function siteAccessWhy(url) {
  try {
    const u = new URL(url); if (!/^https?:$/.test(u.protocol)) return u.protocol === "chrome-error:" ? " (η σελίδα δεν φόρτωσε — δίκτυο;)" : "";
    const ok = await chrome.permissions.contains({ origins: [u.protocol + "//" + u.hostname + "/*"] });   // τα μοτίβα του Chrome δεν δέχονται θύρα
    return ok ? "" : " — το ef-bot ΔΕΝ έχει άδεια για «" + u.host + "». Στον υπολογιστή: chrome://extensions → ef-bot → Λεπτομέρειες → «Πρόσβαση σε ιστότοπους» → «Σε όλους τους ιστότοπους»";
  } catch (e) { return ""; }
}
// Ο Chrome «παγώνει» (discard) καρτέλες που μένουν ώρες στο παρασκήνιο. Σε παγωμένη καρτέλα το executeScript βγάζει
// το παραπλανητικό «Cannot access contents … must request permission». Πριν από κάθε χρήση: ξύπνημα + όχι ξανά πάγωμα.
// 🕶 Όλα τα site του bot (e-prescription, Evorad, …) στο ΙΔΙΟ ανώνυμο παράθυρο με το ΝΠΣ όταν είναι ενεργό το «δικό του παράθυρο»
// (botIncog): έτσι οι συνδέσεις/αποσυνδέσεις του bot δεν αγγίζουν ποτέ τα κανονικά παράθυρα των γιατρών.
async function botIncogOn() {
  const { efbot } = await chrome.storage.local.get("efbot");
  return !!efbot?.settings?.botIncog && await chrome.extension.isAllowedIncognitoAccess().catch(() => false);
}
async function botSiteFind(origin) {
  const inc = await botIncogOn();
  return (await chrome.tabs.query({}).catch(() => [])).find((t) => !!t.incognito === inc && String(t.url || t.pendingUrl || "").startsWith(origin)) || null;
}
async function botSiteTab(origin, url) {
  const inc = await botIncogOn();
  const f = await botSiteFind(origin); if (f) return f;
  if (!inc) return chrome.tabs.create({ url, active: false }).catch(() => null);
  // ανώνυμο παράθυρο του bot: εκείνο με το ΝΠΣ, αλλιώς οποιοδήποτε ανώνυμο, αλλιώς νέο ελαχιστοποιημένο
  const wins = (await chrome.windows.getAll({ windowTypes: ["normal"], populate: true }).catch(() => [])).filter((w) => w.incognito);
  const w = wins.find((x) => (x.tabs || []).some((t) => /e-ygeia|emr-ui/.test(t.url || ""))) || wins[0];
  if (w) return chrome.tabs.create({ windowId: w.id, url, active: false }).catch(() => null);
  const nw = await chrome.windows.create({ url, incognito: true, focused: false, state: "minimized" }).catch(() => null);
  return nw?.tabs?.[0] || null;
}
self.botIncogOn = botIncogOn; self.botSiteFind = botSiteFind; self.botSiteTab = botSiteTab;
async function tabWake(tabId) {
  let t = await chrome.tabs.get(tabId).catch(() => null); if (!t) return null;
  chrome.tabs.update(tabId, { autoDiscardable: false }).catch(() => {});
  if (t.discarded || t.status === "unloaded" || !t.url) {
    await chrome.tabs.reload(tabId).catch(() => {});
    for (let i = 0; i < 40; i++) { await new Promise((r) => setTimeout(r, 400)); t = await chrome.tabs.get(tabId).catch(() => null); if (!t) return null; if (t.status === "complete" && !t.discarded) break; }
  }
  return t;
}
self.tabWake = tabWake;
// Ποιες γνωστές σελίδες ΔΕΝ μπορεί να διαβάσει το bot (περιορισμένη «Πρόσβαση σε ιστότοπους»). Στέλνεται με το σήμα ζωής.
// 🔄 Αυτόματες ενημερώσεις χωρίς άνθρωπο: αν το site έχει νεότερη έκδοση για >4′ (= το efbot-update.bat δεν τρέχει),
// το βοηθητικό των Windows (που το ξεκινά ο ίδιος ο Chrome) ξανανοίγει το πρόγραμμα ενημέρωσης. Το πολύ μία φορά ανά 10′.
let updSeenAt = 0, updNudgeAt = 0;
async function updaterNudge() {
  if (Date.now() - updNudgeAt < 10 * 60000) return;
  let r = null;
  for (const b of ["https://paradoxarto.urol.workers.dev/bot", "https://paradoxarto.pages.dev/bot", "https://nikosgm.github.io/paradoxarto-app/bot", "https://ef-bot-updates.netlify.app"]) { r = await fetch(b + "/version.json?ts=" + Date.now(), { cache: "no-store" }).then((x) => x.ok ? x.json() : null).catch(() => null); if (r && r.version) break; }
  const cur = chrome.runtime.getManifest().version, nv = r && r.version;
  const newer = nv && nv.split(".").map(Number).reduce((d, x, i) => d || (x - (+cur.split(".")[i] || 0)), 0) > 0;
  if (!newer) { updSeenAt = 0; return; }
  if (!updSeenAt) { updSeenAt = Date.now(); return; }
  if (Date.now() - updSeenAt < 4 * 60000) return;
  updNudgeAt = Date.now();
  const res = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "update" }).catch((e) => ({ ok: false, err: e.message }));
  await chrome.storage.local.set({ efbotUpdNudge: { at: Date.now(), want: nv, res } });
}
async function siteAccessMissing() {
  const want = new Set(["https://www.e-prescription.gr/*"]);
  try { const { efbotEvoradUrl: ev } = await chrome.storage.local.get("efbotEvoradUrl"); const u = new URL(ev || "http://172.16.1.26:2080/"); want.add(u.protocol + "//" + u.hostname + "/*"); } catch (e) {}
  try { const { efbotEpLoginHost: h } = await chrome.storage.local.get("efbotEpLoginHost"); if (h) want.add("https://" + h + "/*"); } catch (e) {}
  const out = [];
  for (const o of want) { try { if (!(await chrome.permissions.contains({ origins: [o] }))) out.push(o.replace(/^https?:\/\//, "").replace(/\/\*$/, "")); } catch (e) {} }
  return out;
}
// 🧹 σβήνει ΜΟΝΟ τη σύνδεση του e-prescription στο ΑΝΩΝΥΜΟ παράθυρο του bot (cookies *.e-prescription.gr) και ξαναφορτώνει
// 🔑 8/11: λογαριασμοί e-prescription με ΛΗΓΜΕΝΟ κωδικό (ισχύει μέχρι το τέλος της ημέρας) → παραλείπονται, δοκιμάζεται ο επόμενος
async function epExpiredList() { const { efbotEpExpired: x } = await chrome.storage.session.get("efbotEpExpired").catch(() => ({})); const d = new Date().toDateString(); return x && x.d === d ? (x.u || []) : []; }
async function epExpiredAdd(user) { const u = String(user || "").toLowerCase(); if (!u) return; const d = new Date().toDateString(), l = await epExpiredList(); if (!l.includes(u)) l.push(u); await chrome.storage.session.set({ efbotEpExpired: { d, u: l } }).catch(() => {}); }
// η σελίδα λέει «ο κωδικός έχει λήξει» ενώ ήταν ήδη συνδεδεμένος → σημείωση, αποσύνδεση, σύνδεση με τον ΕΠΟΜΕΝΟ λογαριασμό
async function epExpiredSwitch(tabId) {
  const { efbotEpWho: w } = await chrome.storage.session.get("efbotEpWho").catch(() => ({}));
  const was = (w && w.user) || ""; if (was) { await epExpiredAdd(was); credFailPush("e-prescription", was, "ο κωδικός έχει λήξει").catch(() => {}); }
  await epCookieReset(tabId); await E.sleep(2500);
  const lg = await epresAutoLogin(tabId, "");
  if (lg && lg.ok && lg.who && String(lg.who).toLowerCase() === String(was).toLowerCase()) return { ok: false, err: "ξαναμπήκε ο ίδιος λογαριασμός (" + was + ")" };
  return lg && lg.ok ? { ok: true, who: lg.who || "", was } : { ok: false, err: (lg && lg.err) || "δεν μπήκε άλλος λογαριασμός", was };
}
async function epCookieReset(tabId) {
  const t = await chrome.tabs.get(tabId).catch(() => null); if (!t || !t.incognito) return 0;
  // 🔁 8/11: η εφαρμογή κρατά τη σύνδεση ΚΑΙ στη μνήμη της σελίδας — χωρίς καθάρισμα, ο επόμενος λογαριασμός έβλεπε «η συνεδρία σας έχει λήξει»
  if (/^https:\/\/www\.e-prescription\.gr\//i.test(t.url || "")) await chrome.scripting.executeScript({ target: { tabId }, func: () => { try { localStorage.clear(); } catch (e) {} try { sessionStorage.clear(); } catch (e) {} try { indexedDB.databases && indexedDB.databases().then((l) => l.forEach((d) => d.name && indexedDB.deleteDatabase(d.name))); } catch (e) {} return 1; } }).catch(() => {});
  const st = (await chrome.cookies.getAllCookieStores().catch(() => [])).find((x) => (x.tabIds || []).includes(tabId)); if (!st) return 0;
  let n = 0;
  for (const c of await chrome.cookies.getAll({ storeId: st.id }).catch(() => [])) {
    const d = String(c.domain).replace(/^\./, ""); if (!/(^|\.)e-prescription\.gr$/i.test(d)) continue;
    if (await chrome.cookies.remove({ url: (c.secure ? "https://" : "http://") + d + (c.path || "/"), name: c.name, storeId: st.id }).catch(() => null)) n++;
  }
  await chrome.tabs.update(tabId, { url: EP_HOME_URL }).catch(() => {});
  return n;
}
async function epresAutoLogin(tabId, prefer, opt) {
  const epExpiredU = await epExpiredList();
  const onlyU = String((opt && opt.only) || "").trim().toLowerCase();   // 💊 λογαριασμός που διάλεξε ο γιατρός: ΜΟΝΟ αυτός
  const t0 = Date.now();
  prefer = String(prefer || "").trim();
  const { efbotCredByHost: all = {} } = await V.get("efbotCredByHost");
  let epOnceU = ""; { const { efbotEpOnce: o } = await chrome.storage.session.get("efbotEpOnce"); if (o && Date.now() - o.at < 2 * 3600e3) epOnceU = String(o.user).toLowerCase(); }
  if (!Object.keys(all).length && (await V.status()).mode === "locked") { vaultLockedPush(); return { ok: false, err: "οι κωδικοί είναι κλειδωμένοι (λείπει το βοηθητικό κρυπτογράφησης των Windows;)" }; }
  const accountsFor = (host) => {
    const one = (h) => { const v = all[h]; return Array.isArray(v) ? v.filter((a) => a && a.pass) : (v && v.pass ? [v] : []); };
    const seen = new Set(); let list = [];
    const given = one("*epres");   // 🔑 ΜΟΝΟ οι λογαριασμοί που έδωσε ο γιατρός (🔐 Κωδικοί του bot) — όχι ό,τι «έμαθε» ο browser
    for (const a of (given.length ? given : [...one(host), ...one("*ahfy")])) { const id = String(a.user || "").toLowerCase(); if (!seen.has(id)) { seen.add(id); list.push(a); } }
    const skipU = Array.isArray(curJobP && curJobP.epSkip) ? curJobP.epSkip.map((x) => String(x).toLowerCase()) : [];
    if (epExpiredU.length && !onlyU) list = list.filter((a) => !epExpiredU.includes(String(a.user || "").toLowerCase()));   // 🔑 8/11: «ο κωδικός έχει λήξει» σήμερα
    if (skipU.length && !onlyU) list = list.filter((a) => !skipU.includes(String(a.user || "").toLowerCase()));   // απορρίφθηκαν ήδη σε άλλο υπολογιστή: όχι δεύτερη λάθος προσπάθεια
    if (onlyU) return list.filter((a) => String(a.user || "").toLowerCase() === onlyU);
    if (epOnceU) { list.sort((x, y) => (String(y.user).toLowerCase() === epOnceU) - (String(x.user).toLowerCase() === epOnceU)); prefer = ""; }   // 🔐 επιλογή από το Παραδόχαρτο (μία φορά) // + όσοι ήρθαν από απόσταση
    if (prefer && list.length > 1) {   // ο θεράπων του εξιτηρίου πρώτος (σταθερή σειρά για τους υπόλοιπους)
      list = list.map((a, i) => ({ a, i, sc: epresNameScore(a.user, prefer) }));
      const best = Math.max(...list.map((x) => x.sc));
      list.sort((x, y) => (y.sc) - (x.sc) || x.i - y.i);
      list = list.map((x) => x.a);
      if (best <= 0) prefer = "";   // δεν αναγνωρίστηκε ο θεράπων στα usernames: κανονική σειρά, χωρίς ένδειξη
    }
    return list;
  };
  const sigOf = (host, a) => host + "|" + String(a.user || "") + "|" + (a.ts || 0);
  let { efbotEpresBad: badMap = {} } = await chrome.storage.session.get("efbotEpresBad");
  const probe = async (user, pass) => {
    const [r] = await chrome.scripting.executeScript({ target: { tabId }, args: [user, pass], func: (user, pass) => {
      const vis = (e) => { if (!e) return false; const r = e.getBoundingClientRect(); const cs = getComputedStyle(e); return r.width > 0 && r.height > 0 && cs.display !== "none" && cs.visibility !== "hidden"; };
      const pw = [...document.querySelectorAll("input[type=password]")].find(vis);
      if (!pw) { let d = ""; try { const rt = document.getElementById("root") || document.querySelector("#app,[data-reactroot]"); d = "κείμενο " + String(document.body && document.body.innerText || "").trim().length + " · root " + (rt ? rt.innerHTML.length : -1) + " · «" + String(document.body && document.body.innerText || "").replace(/\s+/g, " ").replace(/\d{5,}/g, "#").trim().slice(0, 80) + "»" + (document.documentElement.getAttribute("data-ef-jserr") ? " · JS: " + document.documentElement.getAttribute("data-ef-jserr").slice(0, 120) : "") + " · " + navigator.userAgent.replace(/^.*Chrome\/(\d+).*$/, "Chrome $1"); } catch (e) {} return { state: document.readyState === "complete" ? "other" : "loading", d }; }
      const errNow = () => [...document.querySelectorAll("[id*=error],[class*=error],[class*=alert],[class*=feedback],[role=alert]")].filter(vis).map((e) => (e.innerText || "").trim()).filter((t) => t && t.length < 200).join(" ").slice(0, 160);
      if (pass == null) return { state: "login", err: errNow(), mark: document.documentElement.getAttribute("data-ef-sub") || "" };
      const form = pw.form || document;
      const fields = [...form.querySelectorAll("input:not([type=hidden]):not([type=password]):not([type=checkbox]):not([type=radio]):not([type=submit]):not([type=button])")].filter(vis);
      const userEl = fields.filter((f) => f.compareDocumentPosition(pw) & Node.DOCUMENT_POSITION_FOLLOWING).pop() || fields[0];
      const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
      const fill = (el, v) => { el.focus(); set.call(el, v); for (const ev of ["input", "change", "keyup", "blur"]) el.dispatchEvent(new Event(ev, { bubbles: true })); };
      if (userEl) fill(userEl, user || "");
      fill(pw, pass);
      const btn = [...form.querySelectorAll("button, input[type=submit], [role=button]")].filter(vis).find((b) => /submit/i.test(b.type) || /σύνδεση|συνδεση|είσοδος|εισοδος|login|sign in|log in/i.test(b.innerText || b.value || ""));
      const errBefore = errNow(), mk = String(Date.now());
      document.documentElement.setAttribute("data-ef-sub", mk);   // 8/11: ίδιο έγγραφο + ίδιο μήνυμα = ΠΑΛΙΟ σφάλμα, όχι νέα απόρριψη
      if (btn) btn.click(); else if (pw.form && pw.form.requestSubmit) pw.form.requestSubmit(); else pw.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
      return { state: "submitted", errBefore, mk };
    } }).catch((e) => { lastErr = e.message; return [null]; });
    return r?.result || { state: "error" };
  };
  let epSessNote = "", submitted = null, submitAt = 0, host = "", nav = 0, lastErr = "", errN = 0, epLast = "", pkmsN = 0, resetN = 0, epNoteAt = Date.now();
  const rejected = [];
  while (Date.now() - t0 < 120000) {
    if (await epresLoggedIn(tabId)) {
      if (submitted) {
        await V.update("efbotCredByHost", (cur0) => {   // ατομικά: όποιος μπήκε πάει μπροστά
          const cur = cur0 && typeof cur0 === "object" ? cur0 : {};
          const l2 = Array.isArray(cur[host]) ? cur[host].slice() : (cur[host] ? [cur[host]] : []);
          const j = l2.findIndex((a) => sigOf(host, a) === submitted.sig);
          if (j > 0) { const [a] = l2.splice(j, 1); l2.unshift(a); cur[host] = l2; }
          return cur;
        }).catch(() => {});
        delete badMap[submitted.sig]; await chrome.storage.session.set({ efbotEpresBad: badMap });
      }
      if (epOnceU && submitted) await chrome.storage.session.remove("efbotEpOnce");
      if (submitted) chrome.storage.session.set({ efbotEpWho: { user: String(submitted.user || "").toLowerCase(), at: Date.now() } }).catch(() => {});
      return { ok: true, who: submitted ? submitted.user : "", preferMatched: !!(prefer && submitted && epresNameScore(submitted.user, prefer) > 0) };
    }
    const tab = await chrome.tabs.get(tabId).catch(() => null); if (!tab) return { ok: false, err: "έκλεισε η καρτέλα του e-prescription" };
    try { host = new URL(tab.url).host.toLowerCase(); } catch (e) {}
    try { const hn = new URL(tab.url).hostname; if (hn && hn !== "www.e-prescription.gr") chrome.storage.local.set({ efbotEpLoginHost: hn }); } catch (e) {}
    const pr0 = await probe(null, null), st = pr0.state;
    try { const u0 = new URL(tab.url); epLast = st + (pr0.d ? " [" + pr0.d + "]" : "") + " @ " + u0.host + u0.pathname.replace(/\d{5,}/g, "#").slice(0, 60) + (submitted ? " · υποβλήθηκε " + Math.round((Date.now() - submitAt) / 1000) + "″ πριν" : "") + " · nav " + nav + epSessNote; } catch (e) {}
    if (jobRunningId && Date.now() - epNoteAt > 15000) { epNoteAt = Date.now(); imgNote(jobRunningId, "⏳ σύνδεση e-prescription " + Math.round((Date.now() - t0) / 1000) + "″ · " + epLast).catch(() => {}); }
    if (st === "loading") { await E.sleep(1200); continue; }
    // η σελίδα δεν διαβάζεται (π.χ. ανακατεύθυνση σε εξέλιξη): περιμένουμε, χωρίς να ξαναφορτώσουμε
    if (st === "error") { if (++errN > 25) { const why = await siteAccessWhy(tab.url); return { ok: false, err: "το e-prescription: η σελίδα εισόδου δεν διαβάζεται από το bot" + (why || " (" + String(lastErr || "άγνωστο").slice(0, 140) + ")") }; } await E.sleep(1500); continue; }
    errN = 0;
    // 🔑 8/11: «Ο κωδικός πρόσβασής σας έχει λήξει» (σελίδα ΧΩΡΙΣ φόρμα) = απόρριψη αυτού του λογαριασμού → καθάρισμα σύνδεσης και
    // ο ΕΠΟΜΕΝΟΣ λογαριασμός (πριν: αναμονή 120″ και αποτυχία, χωρίς να δοκιμαστούν οι άλλοι 3)
    if (st !== "login" && /κωδικ\S*\s+πρόσβασ\S*.{0,40}έχει\s+λήξει|password\s+(has\s+)?expired/i.test(String(pr0.d || "")) && resetN < 4) {
      const who = submitted ? submitted.user : ((await chrome.storage.session.get("efbotEpWho").catch(() => ({}))).efbotEpWho || {}).user || "";
      if (submitted) { badMap[submitted.sig] = Date.now(); await chrome.storage.session.set({ efbotEpresBad: badMap }); epRejectedNow.push(String(submitted.user || "").toLowerCase()); await epExpiredAdd(submitted.user); rejected.push(submitted.user + " («ο κωδικός έχει λήξει»)"); credFailPush("e-prescription", submitted.user, "ο κωδικός έχει λήξει"); submitted = null; }
      else if (who) { for (const a of accountsFor(host)) if (String(a.user || "").toLowerCase() === String(who).toLowerCase()) badMap[sigOf(host, a)] = Date.now(); await chrome.storage.session.set({ efbotEpresBad: badMap }); rejected.push(who + " («ο κωδικός έχει λήξει»)"); }
      resetN++; const n = await epCookieReset(tabId); epLast += " · ληγμένος κωδικός" + (who ? " (" + who + ")" : "") + " → επόμενος λογαριασμός (καθαρισμός " + n + ")";
      nav = 0; await chrome.tabs.update(tabId, { url: EP_HOME_URL }).catch(() => {}); await E.sleep(2500); continue;
    }
    // 🔁 8/11: «Η συνεδρία σας έχει λήξει. Ανανεώστε τη σελίδα…» (σελίδα χωρίς φόρμα) → καθαρισμός σύνδεσης e-prescription και από την αρχή
    if (st !== "login" && /συνεδρία σας έχει λήξει|session (has )?expired/i.test(String(pr0.d || "")) && resetN < 3) {
      // η σύνδεση κρατιέται ΚΑΙ στη μνήμη της σελίδας (localStorage/sessionStorage) → καθάρισμα + πραγματική ανανέωση (όπως λέει το μήνυμα)
      resetN++;
      await chrome.scripting.executeScript({ target: { tabId }, func: () => { try { localStorage.clear(); } catch (e) {} try { sessionStorage.clear(); } catch (e) {} try { indexedDB.databases && indexedDB.databases().then((l) => l.forEach((d) => d.name && indexedDB.deleteDatabase(d.name))); } catch (e) {} return 1; } }).catch(() => {});
      const n = await epCookieReset(tabId); await E.sleep(800); await chrome.tabs.reload(tabId, { bypassCache: true }).catch(() => {});
      epSessNote = " · «η συνεδρία έληξε» → καθαρισμός σελίδας + ανανέωση ×" + resetN + " (" + n + ")"; nav = 0; await E.sleep(3000); continue;
    }
    if (st !== "login") {
      // 🔁 κόλλημα στην επιστροφή σύνδεσης (/pkmsoidc, 11/2026): παλιά/χαλασμένη σύνδεση στο ανώνυμο παράθυρο του bot →
      // σβήνεται ΜΟΝΟ η σύνδεση του e-prescription (cookies e-prescription.gr) και ξεκινά από την αρχή (έως 2 φορές)
      if (/\/pkms/i.test(tab.url || "")) {
        pkmsN++;
        if (pkmsN === 1) { try { const [tx] = await chrome.scripting.executeScript({ target: { tabId }, func: () => String(document.title + " · " + (document.body && document.body.innerText || "")).replace(/\s+/g, " ").replace(/\d{5,}/g, "#").slice(0, 140) }); if (tx && tx.result) epLast += " · σελίδα: «" + tx.result + "»"; } catch (e) {} }
        if (pkmsN >= 3 && resetN < 2 && tab.incognito) { resetN++; pkmsN = 0; const n = await epCookieReset(tabId); epLast += " · καθαρισμός σύνδεσης (" + n + ")"; await E.sleep(2500); continue; }
      } else pkmsN = 0;
      // ούτε συνδεδεμένο ούτε φόρμα: π.χ. αρχική σελίδα με κουμπί «Είσοδος» → πάμε στην εφαρμογή (μας στέλνει στη σύνδεση)
      if (nav < 3 && !/login|auth|signin|oauth|sso/i.test(tab.url || "")) { nav++; await chrome.tabs.update(tabId, { url: EP_HOME_URL }).catch(() => {}); }
      else if (nav < 6) {   // π.χ. αρχική/σελίδα αποσύνδεσης με κουμπί «Είσοδος»: άνοιγμα της φόρμας (ΟΧΙ υποβολή) — πριν περίμενε άπρακτο ως τα 120″
        const [cl] = await chrome.scripting.executeScript({ target: { tabId }, func: () => { const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; }; const a = [...document.querySelectorAll("a, button")].find((x) => vis(x) && /^(Είσοδος|Σύνδεση|Sign in|Log in|Login|Back to Application|Επιστροφή|Ανανέωση|Επανασύνδεση|Συνδεθείτε ξανά)$/i.test((x.innerText || x.value || "").trim())); if (a) { a.click(); return (a.innerText || "").trim().slice(0, 30); } return ""; } }).catch(() => [null]);
        nav++; if (cl && cl.result) epLast += " · πάτησε «" + cl.result + "»";
      }
      await E.sleep(2000); continue;
    }
    if (submitted && Date.now() - submitAt < 20000 && !(pr0 && pr0.err)) { await E.sleep(1200); continue; }
    // 8/11: το μήνυμα σφάλματος ήταν ΗΔΗ στη σελίδα πριν την υποβολή και η σελίδα δεν άλλαξε → παλιό μήνυμα (π.χ. προηγούμενου λογαριασμού): αναμονή, όχι «άλλαξε ο κωδικός»
    if (submitted && Date.now() - submitAt < 20000 && pr0.mark && pr0.mark === submitted.mk && pr0.err === submitted.errBefore) { await E.sleep(1200); continue; }   // «λάθος» μόνο με ορατό μήνυμα σφάλματος ή αν δεν απάντησε σε 20″ (πριν 6″: αργή σελίδα = «λάθος κωδικός» και αποκλεισμός λογαριασμού)
    if (submitted) { badMap[submitted.sig] = Date.now(); await chrome.storage.session.set({ efbotEpresBad: badMap }); epRejectedNow.push(String(submitted.user || "").toLowerCase()); rejected.push(submitted.user + (pr0.err ? " («" + pr0.err.slice(0, 80) + "»)" : "")); credFailPush("e-prescription", submitted.user, pr0.err); submitted = null; }
    const list = accountsFor(host);
    const next = list.find((a) => !badMap[sigOf(host, a)]);
    if (!next) {
      if (!list.length) return { ok: false, err: "το e-prescription ζητά σύνδεση και δεν υπάρχει αποθηκευμένος κωδικός για " + host + " (ef-bot → «🔑 Μάθε τους κωδικούς» και μία σύνδεση στο e-prescription)" };
      return { ok: false, err: "🔑 e-prescription: " + (rejected.length ? "απορρίφθηκε ο κωδικός του " + rejected.join(", ") + " — μάλλον άλλαξε. " : "κανένας από τους " + list.length + " αποθηκευμένους λογαριασμούς δεν μπήκε. ") + "Νέος κωδικός: Ρυθμίσεις → 🔐 Κωδικοί του bot (ΑΗΦΥ / e-prescription)" };
    }
    const r = await probe(next.user, next.pass);
    if (r.state === "submitted") { submitted = { sig: sigOf(host, next), user: next.user, mk: r.mk || "", errBefore: r.errBefore || "" }; submitAt = Date.now(); await E.sleep(4000); continue; }
    await E.sleep(1500);
  }
  return { ok: false, err: "το e-prescription δεν ολοκλήρωσε τη σύνδεση έγκαιρα" + (epLast ? " (τελευταία: " + epLast + ")" : "") };
}

// 🩺 υγεία ΑΥΤΟΥ του υπολογιστή: αποτυχίες «περιβάλλοντος» (σύνδεση/σελίδα/κόλλημα) τα τελευταία 30′ → ο συντονιστής τον αποφεύγει
let envFails = [];
chrome.storage.session.get("efbotEnvFails").then((x) => { envFails = ((x && x.efbotEnvFails) || []).filter((t) => Date.now() - t < 30 * 60000); }).catch(() => {});
const envFail = () => { envFails = [...envFails.filter((t) => Date.now() - t < 30 * 60000), Date.now()].slice(-20); chrome.storage.session.set({ efbotEnvFails: envFails }).catch(() => {}); };
let curJobP = {}, epRejectedNow = [];   // 🔑 payload της τρέχουσας εργασίας + λογαριασμοί e-prescription που απορρίφθηκαν σε αυτήν
let jobRunningTest = false, emrFiltDirty = 0;
let jobRunT0 = 0, jobsT0 = 0, jobsBusy = false, jobsReopenAt = 0, jobsAgain = false, jobsHeavyAt = 0, jobRunningId = 0, jobRunningKind = "", prepRunningName = "";
// ⚡ Ακύρωση από το κινητό: έρχεται με τη ζωντανή συνδρομή· επιβεβαιώνεται από τη βάση πριν σταματήσει η εργασία
async function jobsAbortCheck(id) {
  const st = await jobsInApp(async (id) => { try { if (typeof sb6 === "undefined") return null; const x = await sb6.from("oncall_jobs").select("status").eq("id", id).maybeSingle(); return x && x.data ? x.data.status : null; } catch (e) { return null; } }, [id]).catch(() => null);
  if ((st === "cancelled" || st === "dismissed") && jobRunningId === id) { jobAbortId = id; self.efDeadJobs.add(id); }
}
// ===== Πολλοί υπολογιστές με ef-bot (π.χ. Windows + Mac) =====
// Δουλεύει ΕΝΑΣ τη φορά («μίσθωση» 2,5' στη γραμμή oncall_labs: efbot|lease, ανανεώνεται κάθε λεπτό).
// Αν σβήσει/κοιμηθεί, μετά από 2,5' την παίρνει άλλος. Επιπλέον κάθε εντολή «κλειδώνεται» ατομικά (new → running).
let botIdP = null, leaseOk = false, leaseAt = 0, hospP = null, leaseBackoff = 0;
// Υπολογιστής ΕΚΤΟΣ νοσοκομείου (π.χ. ο Mac): δεν παίρνει εντολές/αυτόματη αναζήτηση και δεν δηλώνει «ξύπνιος»,
// γιατί δεν φτάνει στον ιατρικό φάκελο. Προεπιλογή: Mac = εκτός, Windows = νοσοκομείο. Αλλαγή χειροκίνητα:
// chrome.storage.local.set({efbotHospital: true|false}) από την κονσόλα του bot.
function isHospitalBot() {
  if (!hospP) hospP = chrome.storage.local.get("efbotHospital").then(async ({ efbotHospital }) => {
    if (typeof efbotHospital === "boolean") return efbotHospital;
    const info = await chrome.runtime.getPlatformInfo().catch(() => ({}));
    return info.os !== "mac";
  });
  return hospP;
}
chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch.efbotHospital) { hospP = null; leaseAt = 0; } });
function botId() {
  if (!botIdP) botIdP = chrome.storage.local.get("efbotId").then(async ({ efbotId }) => {
    if (efbotId) return efbotId;
    const id = "b" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
    await chrome.storage.local.set({ efbotId: id }); return id;
  });
  return botIdP;
}
// Έτοιμος υπολογιστής = έχει τουλάχιστον έναν λογαριασμό φακέλου (ΝΠΣ) στο χρηματοκιβώτιο. Νέος υπολογιστής χωρίς κωδικούς
// ΔΕΝ παίρνει τη «μίσθωση» (αλλιώς «έκλεβε» όλες τις εργασίες και αποτύγχανε — 3/11/2026 19:17, δεύτερος υπολογιστής).
let botReadyC = { at: 0, v: true };
async function botReady() {
  if (Date.now() - botReadyC.at < 120000) return botReadyC.v;
  let v = false; try { v = (await emrAccounts()).length > 0; } catch (e) { v = false; }
  botReadyC = { at: Date.now(), v }; return v;
}
// ⏻ Απενεργοποίηση ανά υπολογιστή από το Παραδόχαρτο (Ρυθμίσεις → Υπολογιστές bot): oncall_config «bot_off» = {id: true}.
// Απενεργοποιημένος: δεν παίρνει εργασίες, μίσθωση ή αυτόματες αναζητήσεις. Τελειώνει ΜΟΝΟ εγκρίσεις φορμών που άνοιξε ο ίδιος.
let botOffC = { at: 0, v: false };
async function botOff() {
  if (Date.now() - botOffC.at < 45000) return botOffC.v;
  const me = await botId();
  const r = await jobsInApp(async (me) => { try { if (typeof sb6 === "undefined") return null; const x = await sb6.from("oncall_config").select("value").eq("key", "bot_off").maybeSingle(); if (x.error) return null; const v = (x.data && x.data.value) || {}; return { off: !!v[me] }; } catch (e) { return null; } }, [me]).catch(() => null);
  if (r && typeof r.off === "boolean") { if (r.off !== botOffC.v) leaseAt = 0; botOffC = { at: Date.now(), v: r.off }; }
  return botOffC.v;
}
async function leaseHeld(force) {
  if (!(await isHospitalBot())) { leaseOk = false; return false; }
  if (await botOff().catch(() => false)) { leaseOk = false; return false; }
  if (!(await botReady())) { leaseOk = false; return false; }
  if (Date.now() < leaseBackoff) { leaseOk = false; return false; }   // δεν ήταν έτοιμος: αφήνει τη δουλειά σε άλλον για λίγο
  if (!force && Date.now() - leaseAt < 50000) return leaseOk;
  const me = await botId();
  const r = await jobsInApp(async (me) => {
    try {
      if (typeof sb6 === "undefined") return { skip: true };
      const ss = (await sb6.auth.getSession()).data.session; if (!ss) return { skip: true };
      const read = async () => { const x = await sb6.from("oncall_labs").select("data").eq("name_key", "efbot|lease").maybeSingle(); return (x && x.data && x.data.data) || null; };
      const cur = await read();
      if (cur && cur.by !== me && cur.until > Date.now()) return { ok: false, by: cur.by };
      const w = await sb6.from("oncall_labs").upsert({ name_key: "efbot|lease", name: "ef-bot", pid: null, data: { by: me, until: Date.now() + 150000 }, updated_at: new Date().toISOString() }, { onConflict: "name_key" });
      if (w.error) return { ok: true, note: "χωρίς μίσθωση: " + w.error.message };   // δεν μπλοκάρουμε τη δουλειά για σφάλμα βάσης
      await new Promise((res) => setTimeout(res, 1200));
      const again = await read();
      return { ok: !again || again.by === me };
    } catch (e) { return { ok: true, note: String(e) }; }
  }, [me]);
  if (!r) return leaseOk;   // κλειστό Παραδόχαρτο: κρατάμε την προηγούμενη κατάσταση
  leaseOk = !!r.ok; leaseAt = Date.now();
  return leaseOk;
}
// Αποτυχία από το «περιβάλλον» του υπολογιστή (όχι από τον ασθενή): άλλος υπολογιστής ίσως τα καταφέρει
const JOB_ENV_ERR = /Cannot access contents|σελίδα δεν απαντά|πάνελ του ef-bot|εκμάθηση|συνδεθείτε|σύνδεση στο|ζητά σύνδεση|login|δεν άνοιξε ο φάκελος|δεν απάντησε|κλειστό Παραδόχαρτο|δεν είστε συνδεδεμένος|ERR_|timeout|net::/i;
// χρόνοι: πόσο κράτησε κάθε εντολή και πόσο περίμενε στην ουρά (τελευταίες 40)
async function jobStat(kind, ms, status, totalMs) {
  const { efbotJobStats: a = [] } = await chrome.storage.local.get("efbotJobStats");
  a.push({ k: kind, ms, st: status, wait: Math.max(0, totalMs - ms), at: Date.now() }); while (a.length > 40) a.shift();
  await chrome.storage.local.set({ efbotJobStats: a });
}
async function perfSummary() {
  const { efbotJobStats: j = [], efbotComorbStats: c = [] } = await chrome.storage.local.get(["efbotJobStats", "efbotComorbStats"]);
  const by = {}; for (const x of j) { const b = (by[x.k] ||= { n: 0, ms: 0, wait: 0, fail: 0 }); b.n++; b.ms += x.ms; b.wait += x.wait || 0; if (x.st === "failed") b.fail++; }
  const out = {}; for (const [k, b] of Object.entries(by)) out[k] = { n: b.n, sec: Math.round(b.ms / b.n / 1000), wait: Math.round(b.wait / b.n / 1000), fail: b.fail };
  const avg = (f) => c.length ? Math.round(c.reduce((s, x) => s + (x[f] || 0), 0) / c.length / 1000) : null;
  return { jobs: out, auto: c.length ? { n: c.length, emr: avg("a"), ahfy: avg("b"), open: avg("open"), dx: avg("dx"), labs: avg("labs") } : null };
}
async function jobsClaim(id, payload) {
  const r = await jobsInApp(async (id, payload) => {
    try {
      if (typeof sb6 === "undefined") return { skip: true };
      const x = await sb6.from("oncall_jobs").update({ status: "running", note: "", updated_at: new Date().toISOString(), ...(payload ? { payload } : {}) }).eq("id", id).eq("status", "new").select("id");
      if (x.error) return { ok: false, err: x.error.message };   // ΔΕΝ τρέχει χωρίς δέσμευση (πριν: ok → δύο υπολογιστές στην ίδια εντολή)
      return { ok: (x.data || []).length > 0 };
    } catch (e) { return { ok: false, err: String(e) }; }
  }, [id, payload || null]);
  return !!(r && r.ok);
}
// 🔐 Παραδόχαρτο πάντα συνδεδεμένο στον υπολογιστή του νοσοκομείου: ο κωδικός του Παραδόχαρτου κρατιέται ΜΟΝΟ στο
// χρηματοκιβώτιο (DPAPI) αυτού του υπολογιστή — (α) όταν κάποιος συνδεθεί κανονικά εδώ (το bot τον «μαθαίνει»),
// (β) με κρυπτογραφημένη εντολή «cred» (sys:'pdx') από το κινητό. Αν το Παραδόχαρτο αποσυνδεθεί (π.χ. «αποσύνδεση
// από όλες τις συσκευές» ή λήξη), το bot ξανασυνδέεται μόνο του. Λάθος κωδικός → σταματά μέχρι να έρθει νέος.
let pdxReloginAt = 0;
async function pdxCredSave(user, pass, how) {
  user = String(user || "").trim(); pass = String(pass || "");
  if (!user || !pass || !(await isHospitalBot())) return { ok: false };
  const { efbotPdxCred: old } = await V.get("efbotPdxCred").catch(() => ({}));
  if (old && old.user === user && old.pass === pass) return { ok: true, same: true };
  const r = await V.set({ efbotPdxCred: { user, pass, ts: Date.now(), how } }).catch((e) => ({ ok: false, err: e.message }));
  if (r && r.ok === false) { notify("🔐 Ο κωδικός του Παραδόχαρτου ΔΕΝ αποθηκεύτηκε", r.err || "χρειάζεται το βοηθητικό των Windows", true); return r; }
  await chrome.storage.session.remove("efbotPdxBad");
  notify("🔐 Παραδόχαρτο: κωδικός αποθηκεύτηκε", "Χρήστης " + user + " · το bot θα ξανασυνδέεται μόνο του", false);
  return { ok: true };
}
async function pdxRelogin(diag) {
  if (Date.now() - pdxReloginAt < 3 * 60000) return false;
  pdxReloginAt = Date.now();
  const { efbotPdxBad: bad } = await chrome.storage.session.get("efbotPdxBad");
  if (bad) return false;
  const { efbotPdxCred: c } = await V.get("efbotPdxCred").catch(() => ({}));
  if (!c || !c.user || !c.pass) return false;
  const r = await jobsInApp(async (user, pass) => {
    try {
      if (typeof sb6 === "undefined") return { skip: true };
      const ss = (await sb6.auth.getSession()).data.session;
      if (ss) {   // υπάρχει συνεδρία· αν όμως έχει ακυρωθεί (π.χ. «αποσύνδεση όλων»), καθαρίζεται τοπικά και ξανασυνδέεται
        const t = await sb6.from("oncall_jobs").select("id").limit(1);
        if (!t.error) return { ok: true, already: true };
        try { await sb6.auth.signOut({ scope: "local" }); } catch (e) {}
      }
      const email = user.indexOf("@") < 0 ? user.toLowerCase() + "@paradoxarto.app" : user;
      const x = await sb6.auth.signInWithPassword({ email, password: pass });
      if (x.error) return { err: x.error.message, bad: /invalid|credentials|password/i.test(x.error.message) };
      setTimeout(() => location.reload(), 300);
      return { ok: true };
    } catch (e) { return { err: String(e && e.message || e) }; }
  }, [c.user, c.pass]);
  if (diag || (r && !r.ok)) pdxDiag("relogin:" + (!r ? "notab" : r.ok ? (r.already ? "already" : "ok") : "err " + String(r.err || "").slice(0, 50)));
  if (r && r.bad) { await chrome.storage.session.set({ efbotPdxBad: Date.now() }); notify("🔐 Παραδόχαρτο: ο αποθηκευμένος κωδικός δεν δέχεται", "Συνδεθείτε μία φορά κανονικά σε αυτόν τον υπολογιστή ή στείλτε νέο κωδικό από το κινητό", true); }
  else if (r && r.ok && !r.already) notify("🔐 Παραδόχαρτο: ξανασυνδέθηκε μόνο του", "Χρήστης " + c.user, false);
  return !!(r && r.ok);
}
// 🆘 Κανάλι έκτακτης ανάγκης (όταν το Παραδόχαρτο εδώ είναι αποσυνδεδεμένο και δεν υπάρχει αποθηκευμένος κωδικός):
// διαβάζει χωρίς σύνδεση ΜΟΝΟ ένα κρυπτογραφημένο μήνυμα (rpc efbot_rescue_get) που άνοιγει μόνο με το ιδιωτικό κλειδί
// αυτού του υπολογιστή (χρηματοκιβώτιο DPAPI). Περιέχει τον κωδικό του Παραδόχαρτου → αποθήκευση + επανασύνδεση.
const PDX_SB = "https://evspmufooxgqxhbhydgc.supabase.co", PDX_KEY = "sb_publishable_BOFN2Mb4jDGWcAqaIbNy_Q_FYvsz7y2";
let pdxRescueAt = 0;
// διαγνωστικό ίχνος ΧΩΡΙΣ δεδομένα: μόνο το στάδιο, ως παράμετρος σε ένα αίτημα που καταγράφεται στα logs του server
const pdxDiag = (st) => { try { fetch(PDX_SB + "/rest/v1/?efbotdiag=" + encodeURIComponent(String(st).replace(/[^\w:. -]/g, "").slice(0, 80)), { headers: { apikey: PDX_KEY } }).catch(() => {}); } catch (e) {} };
async function pdxRescue() {
  if (Date.now() - pdxRescueAt < 3 * 60000) return false;
  pdxRescueAt = Date.now();
  try {
    const r = await fetch(PDX_SB + "/rest/v1/rpc/efbot_rescue_get", { method: "POST", headers: { apikey: PDX_KEY, "Content-Type": "application/json" }, body: "{}" });
    if (!r.ok) return false;
    const d = await r.json();
    if (!d || !d.enc || !d.enc.wk) return false;
    const { efbotRescueUsed: used } = await chrome.storage.local.get("efbotRescueUsed");
    if (used && used === d.at) { pdxDiag("rescue:used"); return false; }
    const { efbotXferKey: k } = await V.get("efbotXferKey").catch((e) => { pdxDiag("rescue:vault " + e.message); return {}; });
    if (!k || !k.priv) { pdxDiag("rescue:nokey"); return false; }
    let o;
    try {
      const priv = await crypto.subtle.importKey("jwk", k.priv, { name: "RSA-OAEP", hash: "SHA-256" }, false, ["decrypt"]);
      const raw = new Uint8Array(await crypto.subtle.decrypt({ name: "RSA-OAEP" }, priv, b64d(d.enc.wk)));
      const ak = await crypto.subtle.importKey("raw", raw, "AES-GCM", false, ["decrypt"]);
      o = JSON.parse(new TextDecoder().decode(await crypto.subtle.decrypt({ name: "AES-GCM", iv: b64d(d.enc.iv) }, ak, b64d(d.enc.ct))));
    } catch (e) { pdxDiag("rescue:decrypt " + e.name); return false; }
    if (o.sys !== "pdx" || !o.user || !o.pass || !(o.ts > Date.now() - 2 * 864e5)) { pdxDiag("rescue:content " + o.sys); return false; }
    const sv = await pdxCredSave(o.user, o.pass, "rescue");
    if (!sv.ok) { pdxDiag("rescue:save " + (sv.err || "")); return false; }
    pdxReloginAt = 0;
    const ok = await pdxRelogin(true);
    if (ok) await chrome.storage.local.set({ efbotRescueUsed: d.at });
    return ok;
  } catch (e) { return false; }
}
const SIDE_LANE = /^(fsls|fsfind|imgdir|imgget|imgmap)$/;
// ⚡ ΓΡΗΓΟΡΗ ΛΩΡΙΔΑ: σύντομα αιτήματα HTTP στο Medilabi (αναζήτηση/βιοψίες ενός ασθενή) — χωρίς καρτέλες, χωρίς συντονιστή:
// την παίρνει ΑΜΕΣΩΣ όποιος υπολογιστής τη δει πρώτος (η ανάληψη είναι ατομική), έως 3 παράλληλα, ακόμα κι αν τρέχει άλλη εργασία.
const FAST_LANE = /^(stt|bxfind|bxget|botwho|botctl|bxdiag|bxpdf|sysdiag|medfind|medpt|medordermap|epapilog|epsearch|ehrapilog|epprobe|ctremote|pdxdb|pdxsync|kmail)$/;
const isFast = (j) => FAST_LANE.test(j.kind) || (j.kind === "medlabs" && ((j.payload || {}).only || []).length > 0);
let fastN = 0;
// υπάρχει ΑΛΛΟ bot έτοιμο (για «δεύτερη γνώμη» σε 0 αποτελέσματα); αλλιώς κρατάμε το 0 — όχι 90″ αναμονή + «δεν απάντησε»
async function otherBotReady() { try { const ps = await botPingAll(1500); const me = await botId(); return (ps || []).some((b) => b.hosp && b.ready && b.bot !== me); } catch (e) { return false; } }
async function fastRun(j, run) {
  fastN++; const tRun = Date.now(); let res;
  // 🎤 stt: χωρίς χρονόμετρο (εντολή χρήστη· η μεταγραφή τελειώνει όταν τελειώσει)
  try { res = /^(stt)$/.test(j.kind) ? await run(j) : await Promise.race([run(j), new Promise((r) => setTimeout(() => r({ status: "new", moved: true }), (/^(bxpdf|medlabs|kmail)$/.test(j.kind) || (j.kind === "botctl" && /^(tidy|sys|printers|reboot)$/.test(String((j.payload || {}).op || "")))) ? 70000 : (j.kind === "botctl" && /^(dbinstall|ctinstall)$/.test(String((j.payload || {}).op || ""))) ? 300000 : 25000))]); } catch (e) { res = { status: "failed", note: String(e.message || e) }; } finally { fastN--; }
  // ⏱ γρήγορη εργασία >25″ εδώ = κάτι κόλλησε σε ΑΥΤΟΝ τον υπολογιστή → αμέσως σε άλλον (μία φορά)
  if (res && res.moved) { if (!res.zero) envFail(); const me = await botId(), p = j.payload || {}; if (+(p.hopped || 0) < 1) { await jobsSet(j.id, "new", "⏱ πέρασε σε άλλο bot", { ...p, bot: null, hopped: 1, avoid: [...new Set([...(p.avoid || []), me])] }).catch(() => {}); return; } res = { status: "failed", note: "⏱ " + (j.kind === "kmail" ? "το Kerio" : "το Medilabi") + " δεν απάντησε σε " + (/^(bxpdf|medlabs|kmail)$/.test(j.kind) ? 70 : 25) + "″" }; }
  // 6/11: αποτυχία από τον υπολογιστή (π.χ. Medilabi χωρίς σύνδεση εδώ) → μία φορά σε άλλο bot
  if (res && res.status === "failed" && (res.env || JOB_ENV_ERR.test(res.note || "")) && +((j.payload || {}).hopped || 0) < 1) { const me = await botId(), p = j.payload || {}; await jobsSet(j.id, "new", "↪ " + String(res.note || "").slice(0, 80) + " — σε άλλο bot", { ...p, bot: null, hopped: 1, avoid: [...new Set([...(p.avoid || []), me])] }).catch(() => {}); return; }
  try { jobStat(j.kind, Date.now() - tRun, res.status, Date.now() - new Date(j.created_at).getTime()).catch(() => {}); await jobsSet(j.id, res.status, res.note || "", res.result ? { ...j.payload, result: res.result } : null); } catch (e) {}
}
let sideRunningId = 0;
async function sideRun(j, run) {
  sideRunningId = j.id;
  await chrome.storage.local.set({ efbotRunSide: { id: j.id, kind: j.kind, at: Date.now() } }).catch(() => {});
  const tRun = Date.now(), lim = (JOB_LIMIT_S[j.kind] || 240) * 1000; let res, runP = null;
  try {
    // ⏱ όριο χρόνου όπως στην κύρια λωρίδα: κολλημένο βοηθητικό/δίσκος δεν κρατά τη δεύτερη λωρίδα για πάντα
    runP = Promise.resolve().then(() => run(j));
    res = await Promise.race([runP, new Promise((r) => setTimeout(() => r({ status: "failed", note: "κόλλησε εδώ (>" + Math.round(lim / 1000) + "″) — δεν απάντησε ο φάκελος της κλινικής", stuck: true }), lim))]);
    if (res && res.stuck) { self.efDeadJobs.add(j.id); await Promise.race([runP.catch(() => {}), new Promise((r) => setTimeout(r, 15000))]); }
  } catch (e) { res = { status: "failed", note: String(e.message || e) }; }
  try {
    jobStat(j.kind, Date.now() - tRun, res.status, Date.now() - new Date(j.created_at).getTime()).catch(() => {});
    await jobsSetOut(j.id, res.status, res.note || "", res.wipe ? { wiped: true } : res.result ? { ...j.payload, result: res.result } : null, "efbotRunSide");
    if (res.push && !(j.payload || {}).test) labsPushPhone(res.push[0], res.push[1], null, { room: j.room }).catch(() => {});
  } catch (e) {}
  finally { sideRunningId = 0; }   // ο δείκτης «efbotRunSide» σβήνει ΜΟΝΟ αφού γραφτεί (ή μπει στο efbotOutbox) το αποτέλεσμα
  setTimeout(() => jobsTick(true), 200);
}
// 📮 αποτέλεσμα που δεν γράφτηκε (κλειστό/παγωμένο Παραδόχαρτο στο τέλος της εργασίας): κρατιέται στο chrome.storage.local
// «efbotOutbox» και ξαναδοκιμάζεται σε κάθε κύκλο (έως 30′) — αλλιώς η εργασία έμενε «running» για πάντα.
async function jobsSetOut(id, status, note, payload, mk) {
  const r = await jobsSet(id, status, note, payload).catch(() => null);
  if (!(r && r.ok)) { try { const { efbotOutbox: ob = [] } = await chrome.storage.local.get("efbotOutbox"); await chrome.storage.local.set({ efbotOutbox: [...ob.filter((x) => x.id !== id), { id, status, note, payload: payload || null, at: Date.now() }].slice(-20) }); } catch (e) {} }
  if (mk) await chrome.storage.local.remove(mk).catch(() => {});
  return r;
}
async function outboxFlush() {
  const { efbotOutbox: ob = [] } = await chrome.storage.local.get("efbotOutbox").catch(() => ({}));
  if (!ob || !ob.length) return;
  const me = await botId(), keep = [];
  for (const x of ob) {
    if (Date.now() - (x.at || 0) > 30 * 60000) continue;
    // ΜΟΝΟ αν η εργασία είναι ακόμα «running» σε ΑΥΤΟΝ τον υπολογιστή (όχι αν την πήρε άλλος / ακυρώθηκε)
    const r = await jobsInApp(async (x, me) => { try { if (typeof sb6 === "undefined") return { skip: true };
      const c = await sb6.from("oncall_jobs").select("status,payload").eq("id", x.id).maybeSingle(); if (c.error) return { err: c.error.message };
      if (!c.data || c.data.status !== "running" || ((c.data.payload || {}).bot && c.data.payload.bot !== me)) return { ok: true, gone: true };
      const o = { status: x.status, note: x.note, updated_at: new Date().toISOString() }; if (x.payload) o.payload = x.payload;
      const w = await sb6.from("oncall_jobs").update(o).eq("id", x.id).eq("status", "running"); return w.error ? { err: w.error.message } : { ok: true };
    } catch (e) { return { err: String(e) }; } }, [x, me]).catch(() => null);
    if (!(r && r.ok)) keep.push(x);
  }
  await chrome.storage.local.set({ efbotOutbox: keep }).catch(() => {});
}
const holdNoted = new Set();
// 👯 ίδια εντολή (κλειδί): παραγγελία = ίδιος ασθενής + ίδιες εξετάσεις· έλεγχος Medilabi όλης της κλινικής (χωρίς «only»)·
// εικόνα κλινικής· σάρωση βιοψιών (όχι αναζήτηση). "" = χωρίς έλεγχο διπλών.
function dupKey(j) {
  const p = j.payload || {}, nm = String(j.name_key || j.name || "").trim().toUpperCase();
  if (j.kind === "order") return "order|" + nm + "|" + (j.room || "") + "|" + [...new Set((p.tests || []).map((t) => String((t && (t.name || t.code)) || t).trim().toUpperCase()))].sort().join(",");
  if (j.kind === "medlabs") return (p.only || []).length ? "" : "medlabs";
  if (j.kind === "clinicview") return "clinicview";
  if (j.kind === "bxscan") return p.search ? "" : "bxscan";
  return "";
}
// 🐕 φύλακας ουράς: τρέχει ΜΟΝΟ στον κάτοχο της μίσθωσης, το πολύ 1/λεπτό.
// (α) new/seen πέρα από το όριο αναμονής του είδους → «απέτυχε» με τον λόγο (αν είναι γνωστός) + ειδοποίηση
// (β) review/approve σε υπολογιστή που δεν απαντά >3′ → «απέτυχε» με οδηγία ελέγχου + ειδοποίηση. Δοκιμαστικές (payload.test): μόνο αν είναι πολύ παλιές.
let qwAt = 0, qwSince = 0;
const QW_SCAN = /^(bxscan|imgmap|selftest|logins|medcat2?)$/, QW_SLOW = /^(medlabs|rx|ref|rxname|ep\w*|ehr\w*|med\w*)$/;
const qwBudget = (j) => (isFast(j) || /^(fsls|fsfind|imgdir|imgget)$/.test(j.kind)) ? 3 : QW_SCAN.test(j.kind) ? 20 : (NPS_KINDS.test(j.kind) || QW_SLOW.test(j.kind)) ? 10 : 10;
async function queueWatch(jobs, me) {
  if (Date.now() - qwAt < 60000) return; qwAt = Date.now(); if (!qwSince) qwSince = Date.now();
  const now = Date.now(), t = (x) => Date.parse(x) || 0;
  const late = jobs.filter((j) => { if (!/^(new|seen)$/.test(j.status)) return false; const p = j.payload || {}, since = Math.max(t(j.created_at), t(j.updated_at), +p.notBefore || 0); return now - since > (p.test ? 60 : qwBudget(j)) * 60000; });
  const apr = jobs.filter((j) => /^(review|approve)$/.test(j.status) && (j.payload || {}).bot && j.payload.bot !== me && now - Math.max(t(j.updated_at), t(j.created_at)) > ((j.payload || {}).test ? 60 : 3) * 60000);
  if (!late.length && !apr.length) return;
  const pongs = await botPingAll(3000); if (!pongs) return;   // χωρίς κανάλι ping ΔΕΝ μαντεύουμε (έλεγχος 6/11)
  const setIf = (id, from, note) => jobsInApp(async (id, from, note) => { try { const x = await sb6.from("oncall_jobs").update({ status: "failed", note, updated_at: new Date().toISOString() }).eq("id", id).in("status", from).select("id"); return { ok: (x.data || []).length }; } catch (e) { return { err: 1 }; } }, [id, from, note]).catch(() => null);
  for (const j of late) {
    const p = j.payload || {}, ob = onlyBotOf(p), hb = pongs.filter((b) => b.hosp), rd = hb.filter((b) => b.ready);
    const why = ob && !pongs.some((b) => b.bot === ob) ? "ο υπολογιστής " + ob.slice(-5) + " δεν απαντά" : !hb.length ? "κανένα bot έτοιμο" : !rd.length ? "χρειάζεται σύνδεση" : rd.every((b) => heldFor(b, j)) ? "φόρμα σε έλεγχο" : "";
    const mins = Math.round((now - Math.max(t(j.created_at), t(j.updated_at), +p.notBefore || 0)) / 60000);
    if (rd.length && rd.every((b) => b.held) && mins < 25) continue;   // περιμένει πίσω από φόρμα σε έλεγχο (έως 20′) — δεν είναι κόλλημα
    if (j.kind === "botctl" && p.op === "update" && mins < 24 * 60) continue;   // 7/11: η ενημέρωση περιμένει τον κλειστό υπολογιστή (έως 24 ώρες) — όχι αποτυχία/ειδοποίηση
    const note = "⚠ κανένας υπολογιστής δεν την πήρε σε " + mins + "′" + (why ? " (" + why + ")" : "");
    const r = await setIf(j.id, ["new", "seen"], note);
    if (r && r.ok && !p.quiet && !p.test && !/^(botctl|botwho)$/.test(j.kind)) labsPushPhone("⚠ " + (JOB_KIND[j.kind] || j.kind) + ": δεν ξεκίνησε", (j.name || "") + ": " + note, null, { room: j.room }).catch(() => {});
  }
  for (const j of apr) {
    const b = j.payload.bot; if (now - (pongSeen.get(b) || qwSince) < 3 * 60000) continue;
    const note = "⚠ ο υπολογιστής " + b.slice(-5) + " δεν απαντά — " + (j.status === "approve" ? "ελέγξτε αν καταχωρίστηκε" : "ελέγξτε στο σύστημα");
    const r = await setIf(j.id, [j.status], note);
    if (r && r.ok && !(j.payload || {}).test) labsPushPhone("⚠ " + (JOB_KIND[j.kind] || j.kind) + ": ο υπολογιστής δεν απαντά", (j.name || "") + ": " + note, null, { room: j.room }).catch(() => {});
  }
}
// 🧟 εργασία που έμεινε «running» επειδή το bot ξαναξεκίνησε (ανανέωση/επανεκκίνηση) στη μέση: ξαναμπαίνει ΜΙΑ φορά.
// Ασφαλές: στο «running» κανένα τελικό κουμπί δεν πατιέται (αυτά γίνονται μόνο στο «approve»). Τρέχει στην εκκίνηση και σε
// ΚΑΘΕ κύκλο (πριν: μόνο όταν υπήρχε και άλλη νέα εργασία). Ο δείκτης σβήνει μόνο όταν η βάση απαντήσει.
let zombieBusy = false;
async function zombieRescue() {
  if (zombieBusy) return false; zombieBusy = true; let again = false;
  try {
    for (const mk of ["efbotRunJob", "efbotRunSide"]) try {
      if (mk === "efbotRunJob" ? jobRunningId : sideRunningId) continue;
      const { [mk]: rj } = await chrome.storage.local.get(mk);
      if (!rj || !rj.id) continue;
      const z = await jobsInApp(async (id) => { try { if (typeof sb6 === "undefined") return { skip: true }; const x = await sb6.from("oncall_jobs").select("id,status,payload").eq("id", id).maybeSingle(); return x.error ? { skip: true } : { row: x.data || null }; } catch (e) { return { skip: true }; } }, [rj.id]);
      if (!z) continue;   // η βάση δεν απάντησε: ο δείκτης μένει για τον επόμενο κύκλο
      if ((mk === "efbotRunJob" ? jobRunningId : sideRunningId) === rj.id) continue;
      await chrome.storage.local.remove(mk);
      const row = z.row;
      if (row && row.status === "running" && (!(row.payload || {}).bot || row.payload.bot === (await botId()))) {
        const p = row.payload || {};
        if (p.requeued) await jobsSet(row.id, "failed", "διακόπηκε δύο φορές από επανεκκίνηση του bot — στείλτε ξανά");
        else { await jobsSet(row.id, "new", "🔁 διακόπηκε από επανεκκίνηση του bot — ξανατρέχει μόνη της", { ...p, requeued: 1 }); again = true; }
      }
    } catch (e) {}
  } finally { zombieBusy = false; }
  return again;
}
setTimeout(() => { zombieRescue().then((a) => { if (a) jobsTick(true); }).catch(() => {}); }, 1500);   // μία φορά στην εκκίνηση του service worker
// ⚙ ΡΥΘΜΙΣΕΙΣ ΙΔΙΕΣ ΣΕ ΟΛΑ ΤΑ bot: διαδικασίες/επιλογείς, γενικές ρυθμίσεις, Medilabi, παρακολούθηση, Evorad, μενού.
// Κρυπτογραφημένα με το κλειδί κλινικής στο oncall_labs «efbot|cfg». Νικά η πιο πρόσφατη αλλαγή. ΟΧΙ κωδικοί (αυτοί έχουν
// δικό τους κανάλι), ΟΧΙ ό,τι αφορά μόνο αυτόν τον υπολογιστή (efbotHospital, efbotId, στατιστικά, κατάσταση).
const CFG_KEYS = ["efbotLabsCfg", "efbotMonCfg", "efbotEvoradUrl", "efbotEpLoginHost", "efbotHosts", "efbotMenu"];
async function cfgSnapshot() {
  const all = await chrome.storage.local.get(["efbot", ...CFG_KEYS]);
  const o = {}; for (const k of CFG_KEYS) if (all[k] !== undefined) o[k] = all[k];
  if (all.efbot) { const { current, ...rest } = all.efbot; o.efbot = rest; if (rest.settings) { const { botIncog, ...st } = rest.settings; o.efbot = { ...rest, settings: st }; } }   // 6/11: «δικό του παράθυρο» = ρύθμιση ΑΝΑ υπολογιστή, δεν συγχρονίζεται
  const txt = JSON.stringify(o);
  const h = [...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(txt)))].slice(0, 12).map((b) => b.toString(16).padStart(2, "0")).join("");
  return { o, h };
}
// 🎯 ό,τι έχει μάθει ένας υπολογιστής ΔΕΝ χάνεται: βήμα χωρίς στόχο παίρνει τον στόχο του άλλου (ίδια διαδικασία, ίδια ετικέτα)
function cfgMergeTargets(dst, src) {
  let n = 0;
  for (const w of (dst && dst.workflows) || []) { const o = ((src && src.workflows) || []).find((x) => x.id === w.id); if (!o) continue;
    for (const st of w.steps || []) { if (st.target) continue; const os = (o.steps || []).find((x) => x.label === st.label && x.type === st.type && x.target); if (os) { st.target = os.target; n++; } } }
  for (const o of ((src && src.workflows) || [])) if (dst && Array.isArray(dst.workflows) && !dst.workflows.some((w) => w.id === o.id)) { dst.workflows.push(o); n++; }
  return n;
}
// 6/11: μία φορά — «δικό του παράθυρο» ΝΑΙ (το έσβηνε ο συγχρονισμός ρυθμίσεων από άλλον υπολογιστή)
chrome.storage.local.get(["efbot", "efbotIncogFix611"]).then(async ({ efbot, efbotIncogFix611 }) => { if (efbotIncogFix611 || !efbot) return; efbot.settings = { ...(efbot.settings || {}), botIncog: true }; await chrome.storage.local.set({ efbot, efbotIncogFix611: Date.now() }); }).catch(() => {});
let cfgSyncAt = 0;
async function cfgSyncTick() {
  if (Date.now() - cfgSyncAt < 45000) return; cfgSyncAt = Date.now();
  const me = await botId();
  let { o, h } = await cfgSnapshot();
  const { efbotCfgSync: meta } = await chrome.storage.local.get("efbotCfgSync");
  const remote = await jobsInApp(async () => { try { if (typeof sb6 === "undefined") return { skip: true }; const x = await sb6.from("oncall_labs").select("data").eq("name_key", "efbot|cfg").maybeSingle(); return { d: (x && x.data && x.data.data) || null }; } catch (e) { return { err: 1 }; } }, []).catch(() => null);
  if (!remote || remote.err) return;
  const r = remote.d;
  const push = async () => {
    // πριν ανέβει: ό,τι έχουν μάθει οι άλλοι (και λείπει εδώ) μπαίνει πρώτα και εδώ
    if (r && r.enc && o.efbot) { try { const ck = await imgClinicKey(); const dk = await crypto.subtle.importKey("raw", ck.raw, "AES-GCM", false, ["decrypt"]); const u = b64d(r.enc.d);
      const rem = JSON.parse(new TextDecoder().decode(await crypto.subtle.decrypt({ name: "AES-GCM", iv: u.slice(0, 12) }, dk, u.slice(12))));
      if (cfgMergeTargets(o.efbot, rem.efbot)) { const { efbot: cur } = await chrome.storage.local.get("efbot"); await chrome.storage.local.set({ efbot: { ...o.efbot, settings: { ...(o.efbot.settings || {}), botIncog: (cur && cur.settings && typeof cur.settings.botIncog === "boolean") ? cur.settings.botIncog : true }, current: cur && cur.current } });   /* 7/11: ΔΕΝ σβήνει το «δικό του παράθυρο» */ const again = await cfgSnapshot(); o.efbot = again.o.efbot; h = again.h; } } catch (e) {} }
    const enc = await fsSealJson(o);
    const at = Date.now();
    const w = await jobsInApp(async (data) => { try { const x = await sb6.from("oncall_labs").upsert({ name_key: "efbot|cfg", name: "ef-bot", pid: null, data, updated_at: new Date().toISOString() }, { onConflict: "name_key" }); return { ok: !x.error }; } catch (e) { return { err: 1 }; } }, [{ at, by: me, h, enc }]).catch(() => null);
    if (w && w.ok) await chrome.storage.local.set({ efbotCfgSync: { h, at } });
  };
  const pull = async () => {
    const ck = await imgClinicKey();
    const dk = await crypto.subtle.importKey("raw", ck.raw, "AES-GCM", false, ["decrypt"]);
    const u = b64d(r.enc.d);
    const got = JSON.parse(new TextDecoder().decode(await crypto.subtle.decrypt({ name: "AES-GCM", iv: u.slice(0, 12) }, dk, u.slice(12))));
    const set = {};
    for (const k of CFG_KEYS) if (got[k] !== undefined) set[k] = got[k];
    if (got.efbot) { const { efbot: cur } = await chrome.storage.local.get("efbot"); set.efbot = { ...(cur || {}), ...got.efbot, current: cur && cur.current }; cfgMergeTargets(set.efbot, cur);
      set.efbot.settings = { ...((got.efbot && got.efbot.settings) || {}), botIncog: (cur && cur.settings && typeof cur.settings.botIncog === "boolean") ? cur.settings.botIncog : true }; }   // 6/11: κρατά το τοπικό «δικό του παράθυρο» (προεπιλογή: ναι)
    await chrome.storage.local.set(set);
    const after = await cfgSnapshot();
    await chrome.storage.local.set({ efbotCfgSync: { h: after.h, at: r.at } });
    notify("⚙ Ρυθμίσεις bot ενημερώθηκαν", "Πάρθηκαν οι αλλαγές από άλλον υπολογιστή", false);
  };
  try {
    if (!r || !r.enc) { if (o.efbot && (o.efbot.workflows || []).length) await push(); return; }
    if (!meta) { if (r.h !== h) await pull(); else await chrome.storage.local.set({ efbotCfgSync: { h, at: r.at } }); return; }   // νέος υπολογιστής: ΠΑΙΡΝΕΙ, δεν σβήνει τις καλές ρυθμίσεις
    if (h !== meta.h) { await push(); return; }   // άλλαξε κάτι εδώ
    if (r.at > meta.at && r.h !== h && r.by !== me) await pull();
  } catch (e) {}
}
async function jobsTick(wake) {
  if (jobsBusy) { jobsAgain = true; return; }   // ήρθε εντολή όσο δούλευε: ξανακοιτάζει μόλις τελειώσει (όχι στο επόμενο λεπτό)
  jobsBusy = true; jobsAgain = false; jobsT0 = Date.now();
  try {
    const hosp = await isHospitalBot();
    const heavy = !wake && Date.now() - jobsHeavyAt > 50000;   // 8/11: ΠΟΤΕ στο ξύπνημα από νέα εντολή (κόστιζε 1–3″ πριν την παραλαβή) — μόνο στο περιοδικό (30″)   // ⚡ ξύπνημα: κατευθείαν στην ουρά, χωρίς στατιστικά/ελέγχους
    if (heavy) jobsHeavyAt = Date.now();
    const perf = hosp && heavy ? await perfSummary().catch(() => null) : null;
    if (perf) { try { const L = (await chrome.storage.session.get("efbotLabs")).efbotLabs || {}, C = await labsCfg(); perf.medilabi = { on: !!C.on, every: parseInt(C.interval) || 10, at: L.lastTs || 0, msg: String(L.lastMsg || "").slice(0, 200) }; } catch (e) {} }
    if (heavy) await bgMigrateWorkflows();   // διαδικασίες ενημερωμένες (μετά από ενημέρωση γίνεται και στην εκκίνηση)
    if (perf) { try { await vaultMigrateMaybe(); perf.vault = (await chrome.storage.session.get("efbotVaultMode")).efbotVaultMode || ""; } catch (e) {} }
    if (perf) { try { perf.noaccess = await siteAccessMissing(); } catch (e) {} }
    if (hosp && heavy) updaterNudge().catch(() => {});
    if (hosp && heavy) appTabMigrate().catch(() => {});
    // 6/11: ο λογαριασμός ΝΠΣ του bot ανοίγει σε άλλο τμήμα (π.χ. 3434) → ΚΛΕΙΣΙΜΟ μόνο των ανώνυμων καρτελών ΝΠΣ του bot όταν δεν τρέχει τίποτα·
    // η επόμενη σύνδεση διαλέγει λογαριασμό με «σπίτι» την κλινική (κερδίζει ~5″ ανά εργασία). Ποτέ καρτέλες του χρήστη.
    if (hosp && heavy && !jobRunningId && !sideRunningId && !fastN) await emrPrefCheck().catch(() => {});
    if (hosp && !jobRunningId && !sideRunningId && !fastN) { try { const { efbotEmrRelog: rl } = await chrome.storage.session.get("efbotEmrRelog"); if (rl) { await chrome.storage.session.remove("efbotEmrRelog"); await botIncogReset(); bgMark("🔐 ΝΠΣ: νέα σύνδεση με λογαριασμό της κλινικής"); } } catch (e) {} }
    if (hosp && heavy) { const rs = await rtFeed(); if (perf) perf.rt = { conn: rs ? rs.state : -1, joined: rs ? !!rs.joined : false, filt: rs ? rs.filtered : null, last: rs ? rs.last : 0, st: rtState }; }
    // 🧑‍💻 Ταυτόχρονη δουλειά με άνθρωπο: χρειάζεται δικό του (ανώνυμο) παράθυρο με δική του σύνδεση στον φάκελο
    if (perf) { try {
      const { efbot } = await chrome.storage.local.get("efbot");
      const allowed = await chrome.extension.isAllowedIncognitoAccess().catch(() => false);
      const { efbotEmrCred: ec } = await V.get("efbotEmrCred").catch(() => ({}));
      const accN = (await emrAccounts().catch(() => [])).map((a) => a.user);
      const { efbotEmrPick: pk } = await chrome.storage.session.get("efbotEmrPick");
      try { const { efbotUpdNudge: un } = await chrome.storage.local.get("efbotUpdNudge"); if (un) perf.upd = un; } catch (e) {}
      try { const { efbotMedNav: mn } = await chrome.storage.local.get("efbotMedNav"); if (mn) perf.medNav = mn; const { efbotHideRes: hr } = await chrome.storage.session.get("efbotHideRes"); if (hr) perf.hide = hr; } catch (e) {}
      try { const { efbotCredByHost: cb = {} } = await V.get("efbotCredByHost"); const eu = []; for (const [k, v] of Object.entries(cb)) if ([].concat(cb["*epres"] || []).some((a) => a && a.pass) ? k === "*epres" : /^\*(epres|ahfy)$|prescription/i.test(k)) for (const a of [].concat(v || [])) if (a && a.user && a.pass && !eu.includes(a.user)) eu.push(a.user); perf.epAcc = { users: eu.slice(0, 8) }; } catch (e) {}
      perf.emrAcc = { users: accN.slice(0, 8), last: pk ? { user: pk.user, human: pk.human, note: pk.note, at: pk.at } : null };
      perf.par = { incogAllowed: !!allowed, incogOn: !!efbot?.settings?.botIncog, emrCred: !!(ec && ec.pass && efbot?.settings?.emrUser), idleMin: parseFloat(efbot?.settings?.emrIdleMin) || 5, incogPolicy: (await chrome.storage.local.get("efbotIncogBlocked")).efbotIncogBlocked || 0 };
    } catch (e) {} }
    // 🔐 Με πολλούς υπολογιστές: κλειδί δημοσιεύει ΜΟΝΟ αυτός που έχει τη «μίσθωση» (αυτός παίρνει και τις εντολές),
    // ώστε ο κωδικός από το κινητό να κρυπτογραφείται για τον υπολογιστή που θα τον ανοίξει. Μόλις την πάρει: αμέσως.
    if (hosp && heavy) { const lh = await leaseHeld().catch(() => false); if (lh && !xferLease) xferAt = 0; xferLease = lh; if (lh) xferPublish().catch(() => {}); }
    if (hosp && heavy) botSyncTick().catch(() => {});
    if (hosp && heavy) cfgSyncTick().catch(() => {});
    if (perf) { try { perf.bot = await botId(); perf.lease = !!leaseOk; perf.off = !!botOffC.v; perf.cur = jobRunningId ? { id: jobRunningId, k: jobRunningKind || "" } : null; perf.emrCur = emrCurUser; perf.sys = sysMem.at ? Object.assign({}, sysMem, { net: netLat.at ? netLat.v : null, sk: netLat.at ? netLat.skew : null, nrb: nightRbLog, cv: (navigator.userAgent.match(/Chrome\/(\d+)/) || [])[1] || '', pa4: printA4Log, mc: memCareLog }) : null; } catch (e) {} }
    const pull = () => jobsInApp(async (ver, hosp, perf, heavy) => {
      try {
        if (typeof sb6 === "undefined") return { skip: true };
        const ss = (await sb6.auth.getSession()).data.session;
        if (!ss) return { skip: true };
        // σημάδι «εδώ τρέχει το bot»: αν κάποιος πατήσει «Αποσύνδεση» σε αυτό το Παραδόχαρτο, το κινητό το μαθαίνει
        try { if (hosp) localStorage.setItem("efbot_host", "1"); else localStorage.removeItem("efbot_host"); } catch (e) {}
        // σήμα ζωής (το πολύ 1/λεπτό): το κινητό βλέπει αν ο υπολογιστής του bot είναι ξύπνιος και παραλαμβάνει εντολές
        try {
          if (hosp && heavy && (!window.__efbotHb || Date.now() - window.__efbotHb > 45000)) {
            window.__efbotHb = Date.now();
            sb6.from("oncall_labs").upsert({ name_key: "efbot|alive", name: "ef-bot", pid: null, data: { seen: Date.now(), v: ver, perf, by: String(window.authName || "").replace(/@paradoxarto\.app$/, "").slice(0, 60) }, updated_at: new Date().toISOString() }, { onConflict: "name_key" }).then(() => {}, () => {});
            // 🖥 σήμα ζωής ΑΝΑ υπολογιστή (efbot|hb|<id>): η σελίδα «Υπολογιστές bot» τους βλέπει και χωρίς ping
            if (perf && perf.bot) sb6.from("oncall_labs").upsert({ name_key: "efbot|hb|" + perf.bot, name: "ef-bot", pid: null, data: { seen: Date.now(), v: ver, bot: perf.bot, by: String(window.authName || "").replace(/@paradoxarto\.app$/, "").slice(0, 60), lease: !!perf.lease, off: !!perf.off, acc: ((perf.emrAcc && perf.emrAcc.users) || []).length, vault: String(perf.vault || ""), host: location.host, ck: (() => { try { return typeof window.pdxCryptoStatus === "function" ? String(window.pdxCryptoStatus()) : "?"; } catch (e) { return "err"; } })(),
              ep: ((perf.epAcc && perf.epAcc.users) || []).length, emrUser: String(perf.emrCur || (perf.emrAcc && perf.emrAcc.last && perf.emrAcc.last.user) || ""), med: perf.medilabi ? { at: perf.medilabi.at || 0, msg: String(perf.medilabi.msg || "").slice(0, 80) } : null,
              rt: perf.rt ? { conn: perf.rt.conn, joined: !!perf.rt.joined } : null, upd: perf.upd ? { at: perf.upd.at, ok: !!(perf.upd.res && perf.upd.res.ok), err: String((perf.upd.res && perf.upd.res.err) || "").slice(0, 80), want: perf.upd.want } : null,
              incog: !!(perf.par && perf.par.incogOn), noaccess: perf.noaccess || null, cur: perf.cur || null, sys: perf.sys || null, npt: (() => { try { return typeof data === "object" && data ? Object.keys(data).length : -1; } catch (e) { return -2; } })() }, updated_at: new Date().toISOString() }, { onConflict: "name_key" }).then(() => {}, () => {});
          }
        } catch (e) {}
        // ζωντανή συνδρομή: κάθε νέα εργασία «ξυπνά» το bot αμέσως (το λεπτό μένει ως εφεδρεία)
        try {
          const ch = window.__efbotJobsCh;
          if (!ch || window.__efbotJobsChV !== 2 || ch.state === "closed" || ch.state === "errored" || ch.state === "timed_out") {
            if (ch) { try { sb6.removeChannel(ch); } catch (e) {} }
            const wake = (m) => { const n = (m && m.new) || {}; window.postMessage({ efbotJobsWake: 1, id: n.id || 0, st: n.status || "" }, location.origin); };
            // νέες εντολές + εγκρίσεις/ακυρώσεις (όχι οι ενημερώσεις που γράφει το ίδιο το bot: running/done/failed)
            // αν το φίλτρο απορριφθεί από τον server (σφάλμα συνδρομής), γυρίζει στη συνδρομή χωρίς φίλτρο
            const plain = window.__efbotJobsChBad && Date.now() - window.__efbotJobsChBad < 6 * 3600000;
            let c = sb6.channel("efbot-jobs-v2" + (plain ? "p" : ""));
            if (plain) c = c.on("postgres_changes", { event: "*", schema: "public", table: "oncall_jobs" }, wake);
            else c = c.on("postgres_changes", { event: "INSERT", schema: "public", table: "oncall_jobs" }, wake)
              .on("postgres_changes", { event: "UPDATE", schema: "public", table: "oncall_jobs", filter: "status=in.(new,approve,cancelled,dismissed)" }, wake);
            window.__efbotJobsCh = c.subscribe((s) => { if (!plain && s === "CHANNEL_ERROR") window.__efbotJobsChBad = Date.now(); });
            window.__efbotJobsChV = 2;
            // σε κρυφή καρτέλα το Chrome αραιώνει τα χρονόμετρα· πρόσθετο ping κρατά τη σύνδεση ζωντανή
            try { if (!window.__efbotRtPing) window.__efbotRtPing = setInterval(() => { try { if (sb6.realtime && sb6.realtime.isConnected && !sb6.realtime.isConnected()) sb6.realtime.connect(); } catch (e) {} }, 20000); } catch (e) {}
          }
        } catch (e) {}
        // 📡 κανάλι ping/pong (μία φορά ανά σελίδα): απαντά ΜΟΝΟ αν απαντήσει το ίδιο το bot (μέσω content script → service worker)
        try {
          if (!window.__efbotPingCh || ["closed", "errored", "timed_out"].includes(window.__efbotPingCh.state)) {
            const pend = window.__efbotPend = window.__efbotPend || {};
            const ch = sb6.channel("efbot-ping", { config: { broadcast: { self: true } } });
            ch.on("broadcast", { event: "ping" }, (m) => { const n = m && m.payload && m.payload.n; if (n) window.postMessage({ efbotPing: 1, n }, location.origin); });
            ch.on("broadcast", { event: "pong" }, (m) => { const x = m && m.payload; if (x && x.n && pend[x.n]) pend[x.n].push(x); });
            if (!window.__efbotPongL) { window.__efbotPongL = 1; window.addEventListener("message", (e) => { if (e.source === window && e.data && e.data.efbotPong === 1 && e.data.r) { try { window.__efbotPingCh.send({ type: "broadcast", event: "pong", payload: { n: e.data.n, ...e.data.r } }); } catch (x) {} } }); }
            ch.subscribe();
            window.__efbotPingCh = ch;
            window.__efbotPingAll = async (ms) => { const n = Math.random().toString(36).slice(2, 10); pend[n] = []; try { await window.__efbotPingCh.send({ type: "broadcast", event: "ping", payload: { n } }); } catch (x) {} { const want = +(window.__efbotPingWant || 0), t0 = Date.now(); while (Date.now() - t0 < (ms || 3000)) { await new Promise((r) => setTimeout(r, 80)); if (want && new Set(pend[n].map((x) => x.bot)).size >= want) break; } } const out = pend[n]; delete pend[n]; const u = {}; for (const x of out) if (x.bot) u[x.bot] = x; return Object.values(u); };
          }
        } catch (e) {}
        const r = await sb6.from("oncall_jobs").select("id,name_key,name,room,kind,payload,status,created_at,updated_at").in("status", ["new", "approve", "review", "seen", "running"]).order("id").limit(60);
        if (r.error) return { err: r.error.message };
        return { jobs: r.data || [] };
      } catch (e) { return { err: String(e && e.message || e) }; }
    }, [chrome.runtime.getManifest().version, hosp, perf, heavy]);
    let got = await pull(); const TK = self.__efTk = { p: Date.now() - jobsT0 };
    // καμία ανοιχτή καρτέλα Παραδόχαρτου: ανοίγει στο παρασκήνιο (το πολύ ανά 5'), αλλιώς οι εντολές του κινητού δεν φτάνουν
    if (!got && hosp && Date.now() - jobsReopenAt > 5 * 60000) { jobsReopenAt = Date.now(); if (await pdxEnsureTab()) got = await pull(); }
    if (hosp && (!got || (got.err && /jwt|expired|refresh|session|401|unauthor/i.test(got.err))) && (await pdxRelogin() || await pdxRescue())) { await E.sleep(6000); got = await pull(); }
    // μετά από επανασύνδεση: σβήνεται το μήνυμα έκτακτης ανάγκης από τη βάση
    if (got && hosp) { const { efbotRescueUsed: u, efbotRescueWiped: w } = await chrome.storage.local.get(["efbotRescueUsed", "efbotRescueWiped"]); if (u && u !== w) { const ok = await jobsInApp(async () => { try { if (typeof sb6 === "undefined") return { skip: true }; const x = await sb6.from("oncall_config").delete().eq("key", "efbot_rescue"); return { ok: !x.error }; } catch (e) { return { err: 1 }; } }, []); if (ok && ok.ok) await chrome.storage.local.set({ efbotRescueWiped: u }); } }
    // (σήμα ζωής ανά υπολογιστή: πλέον κατ' επίκληση με ping/pong — βλ. botPingAll)
    let runningAll = [];
    if (got && got.jobs) { const running = runningAll = got.jobs.filter((x) => x.status === "running"); got.jobs = got.jobs.filter((x) => x.status !== "running"); if (hosp && running.length) { reclaimCheck(running).catch(() => {});
      // ξανακοιτάζω ΑΚΡΙΒΩΣ όταν μια γρήγορη εργασία άλλου bot κλείνει 31″ (όχι στον επόμενο κύκλο των 30″)
      const me0 = await botId(); for (const x of running) { const a = Date.now() - Date.parse(x.updated_at); if (/^(order|orderprep|consult|discharge|rxname)$/.test(x.kind) && (x.payload || {}).bot !== me0 && a < 31000) setTimeout(() => jobsTick(true), 31500 - a); } } }
    if (got && !got.err && hosp) { await outboxFlush().catch(() => {}); TK.o = Date.now() - jobsT0; if (await zombieRescue().catch(() => false)) jobsAgain = true; TK.z = Date.now() - jobsT0; }
    if (!got || got.err || !got.jobs?.length) { holdNow = 0; return; }
    // 🤖🤖 ΠΟΛΛΑ bot: κάθε έτοιμος υπολογιστής νοσοκομείου παίρνει ό,τι είναι ελεύθερο (το κλείδωμα new→running είναι ατομικό).
    // Η «μίσθωση» μένει μόνο για τη δημοσίευση κλειδιού/κωδικών. Ρύθμιση efbotSoloLease=true → όπως παλιά (ένας τη φορά).
    const me = await botId();
    { const { efbotSoloLease } = await chrome.storage.local.get("efbotSoloLease"); if (efbotSoloLease) { if (!(await leaseHeld())) return; } else if (!hosp || !(await botReady())) return; }
    const lOk = await leaseHeld().catch(() => false); TK.r = Date.now() - jobsT0;
    if (await botOff().catch(() => false)) { got.jobs = got.jobs.filter((x) => (x.status === "approve" && x.payload && x.payload.bot === me) || (/^(botwho|botctl|selftest|eptorture|ctremote|pdxdb|pdxsync)$/.test(x.kind) && x.payload && x.payload.only === me)); if (!got.jobs.length) { holdNow = 0; return; } }   // ⏻ απενεργοποιημένος
    // εγκρίσεις/έλεγχοι: ΜΟΝΟ ο υπολογιστής που άνοιξε τη φόρμα (payload.bot)· παλιές χωρίς bot → αυτός με τη μίσθωση
    const mine = (j) => (j.payload && j.payload.bot) ? j.payload.bot === me : lOk;

    // «παραλήφθηκε» = ήρθε όταν δεν υπήρχε ακόμα εκτελεστής. Αν τώρα υπάρχει: πρόσφατη (<12 ώρες) → εκτελείται,
    // παλιά → κλείνει με σημείωση (αλλιώς έμενε «παραλήφθηκε» για πάντα). Χωρίς εκτελεστή ακόμα: μένει ως έχει.
    for (const j of got.jobs.filter((x) => x.status === "seen")) {
      if (!JOB_RUNNERS[j.kind]) continue;
      if (Date.now() - new Date(j.created_at).getTime() < 12 * 3600000) j.status = "new";
      else await jobsSet(j.id, "dismissed", "παλιά εντολή (πριν υπάρξει η αυτόματη εκτέλεση) — στείλτε ξανά αν χρειάζεται");
    }
    got.jobs = got.jobs.filter((x) => x.status !== "seen");
    // (🧟 επανεκκίνηση στη μέση εργασίας: βλ. zombieRescue — τρέχει πιο πάνω, πριν από κάθε έξοδο)
    // 🐕 φύλακας ουράς (ΜΟΝΟ ο κάτοχος της μίσθωσης, 1/λεπτό): καμία εργασία «νέα» για πάντα, καμία «σε έλεγχο» με νεκρό bot
    if (lOk) queueWatch(got.jobs.concat(runningAll), me).catch(() => {});
    // 👯 διπλές εντολές (ίδια παραγγελία/ίδιος έλεγχος) όσο η πρώτη δεν έχει τελειώσει: η νεότερη κλείνει, συνεχίζει η πρώτη
    try {
      const live = got.jobs.concat(runningAll).filter((x) => /^(new|running)$/.test(x.status));
      for (const j of got.jobs.filter((x) => x.status === "new")) {
        const k = dupKey(j); if (!k) continue;
        const old = live.find((x) => x.id < j.id && x.status !== "dismissed" && dupKey(x) === k);
        if (!old) continue;
        const w = await jobsInApp(async (id, note) => { try { const x = await sb6.from("oncall_jobs").update({ status: "dismissed", note, updated_at: new Date().toISOString() }).eq("id", id).eq("status", "new").select("id"); return { ok: (x.data || []).length }; } catch (e) { return { err: 1 }; } }, [j.id, "διπλή εντολή — συνεχίζει η #" + old.id]).catch(() => null);
        if (w && w.ok) j.status = "dismissed";
      }
      got.jobs = got.jobs.filter((x) => x.status !== "dismissed");
    } catch (e) {}
    // διπλές εντολές για τον ίδιο ασθενή (π.χ. πατήθηκε πολλές φορές όσο ο υπολογιστής κοιμόταν): κρατάμε την πιο πρόσφατη
    const DEDUP = ["ehrlabs", "ehrdx"], last = {};
    for (const j of got.jobs) if (j.status === "new" && DEDUP.includes(j.kind)) { const key = j.kind + "|" + String(j.name || "").trim().toUpperCase() + "|" + (j.room || ""); if (last[key]) { await jobsSet(last[key].id, "cancelled", "διπλή εντολή — εκτελείται η πιο πρόσφατη"); last[key].status = "cancelled"; } last[key] = j; }
    // 1) εγκρίσεις από το κινητό (status «approve»)
    for (const j of got.jobs.filter((x) => x.status === "approve" && mine(x))) {
      // έγκριση που ΔΙΑΚΟΠΗΚΕ από επανεκκίνηση/ενημέρωση του bot: η φόρμα χάθηκε → καθαρό μήνυμα, ΟΧΙ δεύτερη προσπάθεια (κίνδυνος διπλής καταχώρησης)
      { const { efbotApJob: aj } = await chrome.storage.local.get("efbotApJob"); if (aj && aj.id === j.id) { const w0 = await jobsSet(j.id, "failed", "⚠ η έγκριση διακόπηκε (επανεκκίνηση του bot ή δεν γράφτηκε το αποτέλεσμα) — ελέγξτε " + (j.kind === "rx" ? "στο e-prescription (Συνταγές της επίσκεψης)" : j.kind === "ref" ? "στο e-prescription (Παραπεμπτικά της επίσκεψης)" : "στο Medilabi") + " αν καταχωρήθηκε και, αν όχι, στείλτε ξανά"); if (w0 && w0.ok) await chrome.storage.local.remove("efbotApJob").catch(() => {}); labsPushPhone("⚠ " + (JOB_KIND[j.kind] || j.kind) + ": η έγκριση διακόπηκε", (j.name || "") + " — ελέγξτε αν καταχωρήθηκε και ξαναστείλτε").catch(() => {}); continue; } }
      await chrome.storage.local.set({ efbotApJob: { id: j.id, at: Date.now() } }).catch(() => {});
      const ap = JOB_APPROVE[j.kind];
      // ⏱ η έγκριση έχει όριο 2′: αν δεν ολοκληρωθεί, «απέτυχε» με οδηγία ελέγχου — το efbotApJob ΜΕΝΕΙ (κανένα δεύτερο πάτημα)
      const AP_TO = "⚠ η έγκριση δεν ολοκληρώθηκε σε 2′ — ΕΛΕΓΞΤΕ στο e-prescription/Medilabi αν καταχωρίστηκε πριν ξαναστείλετε";
      let res = ap ? await Promise.race([Promise.resolve().then(() => ap(j)).catch((e) => ({ status: "failed", note: e.message })), new Promise((r) => setTimeout(() => r({ status: "failed", note: AP_TO, apTimeout: true, push: ["⚠ " + (JOB_KIND[j.kind] || j.kind) + ": η έγκριση δεν ολοκληρώθηκε", (j.name || "") + " — ελέγξτε αν καταχωρίστηκε πριν ξαναστείλετε"] }), 120000))]) : { status: "failed", note: "δεν υποστηρίζεται έγκριση για αυτή την εργασία" };
      if (res && res.apTimeout) self.efDeadJobs.add(j.id);   // ό,τι τρέχει ακόμα γι' αυτήν σταματά στο επόμενο βήμα
      // 💊 εξιτήριο που εγκρίθηκε και έχει συνημμένη συνταγή (rxAfter): μπαίνει τώρα η εντολή «rx» στην ουρά
      const rxA = j.payload && j.payload.rxAfter;
      if (j.kind === "discharge" && res.status === "approved" && rxA && Array.isArray(rxA.meds) && rxA.meds.length && !j.payload.rxQueued) {
        const ins = await jobsInsert({ name_key: j.name_key || String(j.name || "").toLowerCase(), name: j.name, room: j.room, kind: "rx", payload: { ...rxA, mode: "review", afterDischarge: j.id } });
        res.note = (res.note || "") + (ins && ins.ok ? " · 💊 η συνταγή μπήκε στην ουρά" : " · ⚠ η συνταγή δεν μπήκε στην ουρά (" + String((ins && ins.err) || "χωρίς απάντηση").slice(0, 80) + ") — στείλτε τη από το 💊");
        j.payload.rxQueued = !!(ins && ins.ok);
      }
      // ⚠ το «efbotApJob» σβήνει ΜΟΝΟ αφού γραφτεί το αποτέλεσμα: αν η εγγραφή αποτύχει, η εργασία μένει «approve» και η
      // επόμενη φορά τη βρίσκει με efbotApJob → «διακόπηκε», ΟΧΙ δεύτερο πάτημα (κίνδυνος διπλής καταχώρισης — έλεγχος 5/11)
      const wr = await jobsSet(j.id, res.status, res.note || "", res.result || j.payload.rxQueued ? { ...j.payload, ...(res.result ? { result: res.result } : {}) } : null);
      if (wr && wr.ok && !res.apTimeout) await chrome.storage.local.remove("efbotApJob").catch(() => {});
      if (res.push && !(j.payload || {}).test) labsPushPhone(res.push[0], res.push[1], null, { room: j.room }).catch(() => {});
      { const sh = await sharedGet(); if (sh) await sharedPatch({ ts: Date.now(), hold: res.status === "review" ? sh.hold : 0 }); }
    }
    // 2) μία φόρμα σε έλεγχο κάθε φορά: όσο περιμένει έγκριση, οι νέες εργασίες περιμένουν (έως 20')
    const pending = got.jobs.filter((x) => x.status === "review" && mine(x));
    for (const j of pending) if (Date.now() - new Date(j.updated_at || j.created_at).getTime() > 20 * 60000) { const w = await jobsSet(j.id, "cancelled", "έληξε χωρίς έγκριση (20')"); if (w && w.ok) labsPushPhone("⏱ έληξε χωρίς έγκριση", (JOB_KIND[j.kind] || j.kind) + " · " + (j.name || "") + " — στείλτε ξανά αν χρειάζεται", null, { room: j.room }).catch(() => {}); }
    // εργασίες που ΔΕΝ αγγίζουν καρτέλες (αρχεία κλινικής / απεικονιστικά από τον δίσκο): τρέχουν και όσο μια φόρμα περιμένει έγκριση
    const held = pending.some((j) => Date.now() - new Date(j.updated_at || j.created_at).getTime() <= 20 * 60000);
    // 🧹 Η φόρμα που περίμενε έγκριση (παραγγελία/εξιτήριο…) μένει ανοιχτή στο ΝΠΣ. Μόλις εγκριθεί/ακυρωθεί, κλείνει ΤΩΡΑ
    // που το bot είναι ελεύθερο — όχι στην αρχή της επόμενης εργασίας (κόστιζε ~2″ σε κάθε παραγγελία).
    try {
      const { efbotFormOpen: fo } = await chrome.storage.session.get("efbotFormOpen");
      // ΜΟΝΟ η καρτέλα του bot όπου άνοιξε η φόρμα (tabId της εργασίας) — ποτέ καρτέλα γιατρού
      const tid = (pending.map((j) => +((j.payload || {}).result || {}).tabId).filter(Boolean))[0] || 0;
      if (held && tid && (!fo || fo.tabId !== tid)) await chrome.storage.session.set({ efbotFormOpen: { tabId: tid, at: Date.now() } });
      // 8/11: εντολές με notBefore στο μέλλον ή για ΑΛΛΟΝ υπολογιστή δεν εμποδίζουν το καθάρισμα (πριν: ποτέ δεν γινόταν όσο υπήρχε τέτοια)
      else if (!held && fo && fo.tabId && !got.jobs.some((x) => x.status === "approve" || (x.status === "new" && !(+((x.payload || {}).notBefore || 0) > Date.now()) && !(onlyBotOf(x.payload) && onlyBotOf(x.payload) !== me)))) {
        await chrome.storage.session.remove("efbotFormOpen");
        const et = fo.early ? null : await chrome.tabs.get(fo.tabId).catch(() => null);
        self.__efIdle = { at: Date.now(), early: !!fo.early, url: et ? String(et.url || "").slice(0, 40) : "-" };
        if (et && /^https:\/\/apps\.e-ygeia\.gov\.gr\//.test(et.url || "")) { const cr = await bgEmrClean(et.id).catch((e) => "err"); self.__efIdle.r = cr; }
      }
    } catch (e) {}
    const NOTAB = HOLD_FREE;
    TK.a = Date.now() - jobsT0; if (lOk) { try { await coordTick(got.jobs); } catch (e) {} } TK.c = Date.now() - jobsT0;
    // ⚡ προτεραιότητα: παραγγελίες/συνταγές/εξιτήρια πρώτα, μεγάλες αναζητήσεις τελευταίες
    const PRI = (k) => /^(order|orderprep|rx|ref|rxname|discharge|consult)$/.test(k) ? 0 : /^(bxscan|imgmap|medlabs|clinicview|selftest|logins)$/.test(k) ? 2 : 1;
    // 💊 μόνο συνταγή(ές) περιμένουν έγκριση: περιμένουν ΜΟΝΟ οι εργασίες του e-prescription (ΝΠΣ/Medilabi/ΑΗΦΥ είναι άλλες καρτέλες)
    const heldRx = held && pending.every((j) => /^(rx|ref)$/.test(j.kind)), EPK = HOLD_EPK;
    holdNow = held ? Date.now() : 0; holdNowRx = heldRx;
    // ✋ όσες περιμένουν πίσω από τη φόρμα σε έλεγχο: σημείωση στο κινητό (μία φορά ανά εργασία)
    if (held) for (const x of got.jobs.filter((x) => x.status === "new" && !NOTAB.test(x.kind) && !(heldRx && !EPK.test(x.kind)) && !holdNoted.has(x.id)).slice(0, 10)) {
      const pa = x.payload || {}, ob = onlyBotOf(pa); if (ob ? ob !== me : pa.assign ? pa.assign !== me : !lOk) continue;
      holdNoted.add(x.id);
      jobsInApp(async (id, note) => { try { await sb6.from("oncall_jobs").update({ note }).eq("id", id).eq("status", "new"); return { ok: true }; } catch (e) { return { err: 1 }; } }, [x.id, "περιμένει: φόρμα σε έλεγχο στον " + me.slice(-5)]).catch(() => {});
    }
    if (got.jobs.some((x) => /^(order|orderprep)$/.test(x.kind) && /^(new|running|review|approve)$/.test(x.status))) { self.__ordAct = Date.now(); if (comorbBusy) comorbYield = true; }
    const queue = got.jobs.filter((x) => x.status === "new" && (!held || NOTAB.test(x.kind) || (heldRx && !EPK.test(x.kind)))).sort((a, b) => PRI(a.kind) - PRI(b.kind) || a.id - b.id);
    for (const j of queue) {
      if (+((j.payload || {}).notBefore || 0) > Date.now()) continue;   // περιμένει να ελευθερωθεί ο φάκελος
      { const ob = onlyBotOf(j.payload); if (ob && ob !== me) continue; }   // 🎯 για άλλον υπολογιστή
      // απέτυχε εδώ για λόγο του υπολογιστή → την παίρνει άλλος· αν κανείς δεν την πάρει σε 90″, ξαναδοκιμάζει κι αυτός
      { const av = (j.payload || {}).avoid || []; if (av.includes(me) && Date.now() - new Date(j.updated_at || j.created_at).getTime() < 90000) continue; }
      // ⚡ παραγγελία: πρώτη ευκαιρία (8″) στον υπολογιστή που έχει ήδη έτοιμη τη φόρμα (orderprep)
      // 🧭 ανάθεση από τον συντονιστή: παίρνω μόνο ό,τι μου ανατέθηκε (ή, αν ο συντονιστής σωπαίνει >8″, ό,τι είναι ελεύθερο)
      if (isFast(j) && JOB_RUNNERS[j.kind]) {
        if (fastN >= 3) continue;
        if (typeof (j.payload || {}).only === "string" && j.payload.only !== me) continue;   // για συγκεκριμένο υπολογιστή (το medlabs έχει only = λίστα ασθενών, όχι υπολογιστή)
        if (((j.payload || {}).avoid || []).includes(me) && Date.now() - new Date(j.updated_at || j.created_at).getTime() < 20000) continue;
        j.payload = { ...(j.payload || {}), bot: me };
        if (!(await jobsClaim(j.id, j.payload))) continue;
        fastRun(j, JOB_RUNNERS[j.kind]);
        continue;
      }
      { const pa = j.payload || {}, age = Date.now() - new Date(j.created_at).getTime();
        if (pa.assign && pa.assign !== me && Date.now() - +(pa.assignAt || 0) < 5000) { setTimeout(() => jobsTick(true), Math.max(300, 5300 - (Date.now() - +(pa.assignAt || 0)))); continue; }   // ανατέθηκε αλλού· μόνο αν πέσει ο συντονιστής ξανακοιτάζω στα 5″
        if (pa.printAt && pa.printAt !== me && pa.assign !== me && /^(order|orderprep)$/.test(j.kind) && age < 25000 && (pongSeen.get(pa.printAt) ? Date.now() - pongSeen.get(pa.printAt) < 10 * 60000 : Date.now() - SW_T0 < 10 * 60000)) { setTimeout(() => jobsTick(true), Math.max(500, 25300 - age)); continue; }
        // ⚡ 8/11: παραγγελία/προετοιμασία που «ανήκει» ΕΔΩ (εκτύπωση εδώ ή έτοιμη φόρμα αυτού του ασθενή εδώ) → αμέσως, χωρίς αναμονή συντονιστή (έως 8″)
        let mine = false;
        if (/^(order|orderprep)$/.test(j.kind) && (!pa.assign || pa.assign === me)) {
          if (pa.printAt === me) mine = true;
          else { const { efbotOrderPrep: op0 } = await chrome.storage.session.get("efbotOrderPrep").catch(() => ({})); if (op0 && op0.name === j.name && Date.now() - op0.at < ORDER_PREP_MS) mine = true; }
        }
        if (!mine && !pa.assign && !lOk && age < 8000) { setTimeout(() => jobsTick(true), Math.max(500, 8000 - age)); continue; } }
      const run = JOB_RUNNERS[j.kind];
      // ⚡ 8/11: έτοιμη φόρμα παραγγελίας εδώ → οι δουλειές παρασκηνίου (λίστα ΝΠΣ, στοιχεία κ.λπ.) περιμένουν έως 3′ — αλλιώς η παραγγελία ξεκινά από την αρχή
      if (run && NPS_KINDS.test(j.kind) && !/^(order|orderprep|consult|discharge)$/.test(j.kind) && Date.now() - new Date(j.created_at).getTime() < 180000) {
        const { efbotOrderPrep: op } = await chrome.storage.session.get("efbotOrderPrep").catch(() => ({}));
        if (op && Date.now() - op.at < Math.min(ORDER_PREP_MS, 180000) && op.name !== j.name) { setTimeout(() => jobsTick(true), 6000); continue; }
        if (prepRunningName) { setTimeout(() => jobsTick(true), 6000); continue; }
      }
      // ⚡ 8/11: παραγγελία → ο κύκλος ΑΗΦΥ σταματά· αν η καρτέλα του φακέλου είναι ελεύθερη (ο κύκλος δουλεύει μόνο στον ΑΗΦΥ) η παραγγελία ξεκινά ΑΜΕΣΩΣ
      if (run && comorbBusy && /^(order|orderprep)$/.test(j.kind)) { comorbYield = true; if (comorbNps) { setTimeout(() => jobsTick(true), 400); continue; } }
      else if (run && comorbBusy && NPS_KINDS.test(j.kind)) { comorbYield = true; setTimeout(() => jobsTick(true), 3000); continue; }   // 🚦 ο αυτόματος κύκλος ΑΗΦΥ τελειώνει τον τρέχοντα ασθενή και παραχωρεί
      // 🛤 ΔΕΥΤΕΡΗ ΛΩΡΙΔΑ: αρχεία/απεικονιστικά από τον δίσκο της κλινικής τρέχουν ΠΑΡΑΛΛΗΛΑ με ΝΠΣ/Medilabi (δεν αγγίζουν καρτέλες)
      if (run && SIDE_LANE.test(j.kind)) {
        if (sideRunningId) continue;
        j.payload = { ...(j.payload || {}), bot: me };
        if (!(await jobsClaim(j.id, j.payload))) continue;
        sideRun(j, run);
        continue;
      }
      let res = { status: "failed", note: "αυτό το είδος εργασίας δεν υποστηρίζεται από αυτή την έκδοση του bot" }; let tRunO = 0; const tCb = Date.now(), tT0 = jobsT0, tWk = self.__efWakeAt || 0, tTk = Object.assign({}, self.__efTk || {});
      const say = () => notify(`📥 Από το κινητό: ${JOB_KIND[j.kind] || j.kind}`, `${j.name}${j.room ? " (" + j.room + ")" : ""}${jobSummary(j)}`, false);
      if (!run) say();
      if (run) {
        j.payload = { ...(j.payload || {}), bot: me };
        if (!(await jobsClaim(j.id, j.payload))) continue;   // την πήρε ήδη άλλος υπολογιστής
        if (j.kind !== "orderprep") say();
        const tRun = Date.now(); tRunO = tRun; jobsAgain = true;   // 8/11: μετά από κάθε εργασία ξανακοιτάζει αμέσως (το «ξύπνημα» realtime μπορεί να καθυστερήσει 8–18″)
        if (!NOTAB.test(j.kind) && j.kind !== "order" && j.kind !== "orderprep") await chrome.storage.session.remove("efbotOrderPrep");
        jobAbortId = 0; jobRunningId = j.id; jobRunT0 = Date.now(); jobRunningKind = j.kind; jobRunningTest = !!(j.payload || {}).test; prepRunningName = j.kind === "orderprep" ? String(j.name || "") : "";
        await chrome.storage.local.set({ efbotRunJob: { id: j.id, kind: j.kind, at: Date.now() } }).catch(() => {});
        let hbAt = Date.now(), hbP = null, watchOff = false;
        const watch = setInterval(async () => {
          try {
            const st = await jobsInApp(async (id) => { try { if (typeof sb6 === "undefined") return null; const x = await sb6.from("oncall_jobs").select("status").eq("id", id).maybeSingle(); return x && x.data ? x.data.status : null; } catch (e) { return null; } }, [j.id]);
            if (st === "cancelled" || st === "dismissed" || st === "new") { jobAbortId = j.id; self.efDeadJobs.add(j.id); }   // new = πέρασε σε άλλο bot (κόλλησε εδώ)
            // 💓 σήμα ζωής κάθε 20″: payload.hb + τρέχον βήμα (μία μικρή εγγραφή, ΜΟΝΟ όσο είναι «running» εδώ — ποτέ πάνω στο αποτέλεσμα)
            if (st === "running" && !watchOff && !hbP && Date.now() - hbAt >= 20000) {
              hbAt = Date.now(); const step = bgTime.marks.length ? bgTime.marks[bgTime.marks.length - 1].l : "";
              hbP = jobsInApp(async (id, me, hb, step) => { try { const x = await sb6.from("oncall_jobs").select("status,payload").eq("id", id).maybeSingle(); const p = x.data && x.data.payload; if (!p || x.data.status !== "running" || (p.bot && p.bot !== me)) return { ok: 0 };
                await sb6.from("oncall_jobs").update({ payload: { ...p, hb, step } }).eq("id", id).eq("status", "running"); return { ok: 1 }; } catch (e) { return { err: 1 }; } }, [j.id, me, hbAt, step]).catch(() => null).finally(() => { hbP = null; });
            }
            if (leaseOk) coordWake().catch(() => {});   // συντονιστής απασχολημένος: συνεχίζει να μοιράζει τις νέες
          } catch (e) {}
        }, 2500);
        const lim = (JOB_LIMIT_S[j.kind] || 240) * 1000;
        curJobP = j.payload || {}; epRejectedNow = [];
        let runP = null;
        try {
          runP = run(j); res = await Promise.race([runP, new Promise((r) => setTimeout(() => r({ status: "failed", note: "κόλλησε εδώ (>" + Math.round(lim / 1000) + "″) — δεν απάντησε το σύστημα", stuck: true }), lim))]);
          // ⏹ έληξε: η εργασία ΣΤΑΜΑΤΑ πριν ξεκινήσει η επόμενη (πριν συνέχιζε να πατά στην ίδια καρτέλα). Το επόμενο E.sleep της πετά λάθος.
          if (res && res.stuck) { jobAbortId = j.id; self.efDeadJobs.add(j.id); await Promise.race([runP.catch(() => {}), new Promise((r) => setTimeout(r, 15000))]); if (jobAbortId === j.id) jobAbortId = 0; }
        } catch (e) { res = { status: "failed", note: e.message }; }
        finally { clearInterval(watch); watchOff = true; jobRunningId = 0; jobRunningKind = ""; prepRunningName = ""; jobRunningTest = false; if (emrFiltDirty) { const ft = emrFiltDirty; emrFiltDirty = 0; emrListFilter(ft, { surname: "", inner: true, from: "" }).catch(() => {}); } }   // ο δείκτης «efbotRunJob» μένει μέχρι να γραφτεί το αποτέλεσμα
        if (hbP) await Promise.race([hbP, new Promise((r) => setTimeout(r, 5000))]);
        if (traceTab && TRACE_KINDS.test(j.kind)) { try { const nt = await netDump(traceTab); if (res && nt && nt.length) { res.result = Object.assign({}, res.result || {}, { npsTrace: nt.map((f) => ({ where: f.where, a: f.a.slice(0, 60) })) }); } } catch (e) {} traceTab = 0; }
        if (jobAbortId === j.id) { if (/^(new)$/.test(await jobsInApp(async (id) => { try { const x = await sb6.from("oncall_jobs").select("status").eq("id", id).maybeSingle(); return x.data && x.data.status; } catch (e) { return null; } }, [j.id]).catch(() => null))) envFail();   // μου την πήραν επειδή κόλλησα
          { const tr = bgTime.marks.slice(-12).map((m) => m.l + " " + (m.ms / 1000).toFixed(1)), age = Math.round((Date.now() - tRun) / 1000);
            jobsInApp(async (id, tr, me, age) => { try { const x = await sb6.from("oncall_jobs").select("payload").eq("id", id).maybeSingle(); const p = (x.data && x.data.payload) || {}; p.trace = [...(p.trace || []), { bot: me, s: age, steps: tr }].slice(-4); await sb6.from("oncall_jobs").update({ payload: p }).eq("id", id); } catch (e) {} }, [j.id, tr, me, age]).catch(() => {}); }
          jobAbortId = 0; chrome.storage.local.remove("efbotRunJob").catch(() => {}); notify(`✕ Σταμάτησε: ${JOB_KIND[j.kind] || j.kind}`, `${j.name || ""} — ακυρώθηκε από το Παραδόχαρτο`, false); continue; }
        jobAbortId = 0;
        jobStat(j.kind, Date.now() - tRun, res.status, Date.now() - new Date(j.created_at).getTime()).catch(() => {});
        // Κάποιος δουλεύει τώρα στον φάκελο: η εντολή περιμένει και ξαναδοκιμάζεται σε 3' (έως ~30'), χωρίς ειδοποίηση.
        // Οτιδήποτε άλλο «δεν ήταν έτοιμος» → αποτυχία ΑΜΕΣΩΣ με ειδοποίηση στο κινητό (υπάρχει ένας υπολογιστής νοσοκομείου·
        // το παλιό «ξαναμπαίνει για άλλον υπολογιστή» έμενε «περιμένει» χωρίς να γίνεται τίποτα).
        const waits = +((j.payload || {}).waits || 0);
        if (res.status === "failed" && /κάποιος δουλεύει|κάποιος άρχισε|ανοιχτός σε άλλο παράθυρο/.test(res.note || "") && waits < 10) {
          await jobsSetOut(j.id, "new", "περιμένει: " + String(res.note || "").slice(0, 140) + " — ξαναδοκιμάζει σε 3′", { ...(j.payload || {}), waits: waits + 1, notBefore: Date.now() + 3 * 60000 }, "efbotRunJob");
          continue;
        }
        // 🔑 e-prescription: απορρίφθηκαν ΟΛΟΙ οι λογαριασμοί αυτού του υπολογιστή → σε άλλο bot με άλλους λογαριασμούς
        // (οι απορριφθέντες ταξιδεύουν στο epSkip: κανείς δεν τους ξαναδοκιμάζει, για να μην κλειδωθούν)
        if (res.status === "failed" && /e-prescription/i.test(res.note || "") && /απορρίφθηκε|κανένας από τους/i.test(res.note || "") && +((j.payload || {}).hopped || 0) < 2 && !(j.payload || {}).epUser && !onlyBotOf(j.payload)) {
          const p0 = j.payload || {}, skip = [...new Set([...(p0.epSkip || []), ...epRejectedNow])];
          const p2 = { ...p0, attempts: attemptsAdd(p0, me, res.note), epSkip: skip, hopped: +(p0.hopped || 0) + 1, avoid: [...new Set([...(p0.avoid || []), me])] }; delete p2.bot; delete p2.assign;
          await jobsSetOut(j.id, "new", "🔑 περνά σε υπολογιστή με άλλον λογαριασμό e-prescription (απορρίφθηκε: " + (skip.join(", ") || "?") + ")", p2, "efbotRunJob");
          continue;
        }
        // 🤝 Αποτυχία από τον υπολογιστή (σύνδεση/παράθυρο/ρυθμίσεις/κωδικοί — όχι ο ασθενής): περνά ΑΜΕΣΩΣ σε άλλο bot
        if (res.status === "failed" && +((j.payload || {}).hopped || 0) < 2 && !onlyBotOf(j.payload) && (res.stuck || JOB_ENV_ERR.test(res.note || "") || /ρυθμίσ|κλειδ|αντίγραφο κλειδιού|δεν έχει μάθει|βοηθητικό|ανώνυμο παράθυρο|ΕΧΕΙ ΛΗΞΕΙ/i.test(res.note || "")) && !/λάθος κωδικ|απορρίφθηκε/i.test(res.note || "")) {
          envFail();
          const p2 = { ...(j.payload || {}), attempts: attemptsAdd(j.payload, me, res.note), hopped: +((j.payload || {}).hopped || 0) + 1, avoid: [...new Set([...((j.payload || {}).avoid || []), me])] }; delete p2.bot;
          await jobsSetOut(j.id, "new", "🤝 περνά σε άλλο bot (εδώ: " + String(res.note || "").replace(/·\s*⏱.*$/, "").slice(0, 100) + ")", p2, "efbotRunJob");
          continue;
        }
        // 🔁 Αποτυχία σύνδεσης / σελίδα που δεν φόρτωσε: ΜΙΑ αυτόματη επανάληψη σε 20″ με «καθαρή» καρτέλα πριν πει «απέτυχε».
        // Μόνο για βήματα πριν από έγκριση (καμία εργασία δεν πατά τελικό κουμπί χωρίς έγκριση) — ασφαλές να ξανατρέξει.
        const RETRY_RX = /σύνδεσ|δεν άνοιξε|δεν απάντησε|έγκαιρα|ζητά σύνδεση|Cannot access|No tab|was removed|Frame with ID|login|συνεδρία|δεν φόρτωσε|κόλλησε|δεν φαίνεται η λίστα/i;
        if (res.status === "failed" && !res.noRetry && !/^⚠/.test(res.note || "") && !(j.payload || {}).retried && RETRY_RX.test(res.note || "") && !/λάθος|απορρίφθηκε|κωδικ/i.test(res.note || "")) {
          await chrome.storage.session.remove(["efbotEpTab", "efbotOrderPrep"]).catch(() => {});
          await jobsSetOut(j.id, "new", "🔁 ξαναδοκιμάζει σε 20″ (1η προσπάθεια: " + String(res.note || "").replace(/·\s*⏱.*$/, "").slice(0, 120) + ")", { ...(j.payload || {}), attempts: attemptsAdd(j.payload, me, res.note), retried: 1, notBefore: Date.now() + 20000 }, "efbotRunJob");
          jobsAgain = true;
          continue;
        }
      }
      // ⏱ 8/11: χρονολόγιο (δημιουργία → παραλαβή → τέλος) για τη μέτρηση της ταχύτητας
      // 8/11: φόρμα σε έλεγχο → σημειώνεται ΑΜΕΣΑ ώστε μόλις εγκριθεί/απορριφθεί να κλείσει όσο το bot είναι ελεύθερο (πριν: μόνο αν πρόλαβε κύκλος)
      try { if (run && res.result && typeof res.result === "object") res.result.tl = { c: Date.parse(j.created_at) || 0, nb: +((j.payload || {}).notBefore || 0), wk: tWk, t0: tT0, cb: tCb, cl: tRunO, e: Date.now(), tk: tTk, idle: self.__efIdle || null }; } catch (e) {}
      await jobsSetOut(j.id, res.status, res.note || "", res.wipe ? { wiped: true } : res.result ? { ...j.payload, result: res.result } : null, run ? "efbotRunJob" : "");
      const autoOk = res.status === "review" && await jobAutoOk(j, res).catch(() => false);   // αυτόματη έγκριση → καμία ειδοποίηση «για έγκριση»
      if (res.push && !(j.payload || {}).test && (!autoOk || /^⚠/.test(res.push[0]))) labsPushPhone(res.push[0], res.push[1], null, { room: j.room }).catch(() => {});
      else if (res.status === "failed" && !/^(fsls|fsfind|imgmap|orderprep)$/.test(j.kind) && !(j.payload && j.payload.file)) labsPushPhone(`⚠️ ${JOB_KIND[j.kind] || j.kind}: δεν ολοκληρώθηκε`, `${j.name}: ${res.note || ""}`).catch(() => {});
      { const sh = await sharedGet(); if (sh) await sharedPatch(held ? { ts: Date.now() } : { ts: Date.now(), hold: res.status === "review" && !/^(rx|ref)$/.test(j.kind) ? Date.now() + 21 * 60000 : 0 }); }   // όσο μια φόρμα περιμένει έγκριση, η «κράτηση» μένει
      if (res.status === "review") {
        try { const tid = +((res.result || {}).tabId) || 0; if (tid) await chrome.storage.session.set({ efbotFormOpen: { tabId: tid, at: Date.now() } }); } catch (e) {}
        // ⚡ αυτόματη έγκριση (Ρυθμίσεις → Αυτόματη έγκριση): μόνο όταν όλα μπήκαν σωστά — αλλιώς μένει για έλεγχο από το κινητό
        if (autoOk) { await jobsSet(j.id, "approve", (res.note || "") + "\n⚡ αυτόματη έγκριση (ρύθμιση)"); jobsAgain = true; }
        break; // περιμένουμε την έγκριση πριν την επόμενη
      }
    }
  } finally {
    jobsBusy = false;
    if (jobsAgain) { jobsAgain = false; setTimeout(() => jobsTick(true), 200); }
  }
}
function jobSummary(j) {
  const p = j.payload || {};
  if (j.kind === "order") return ` · ${(p.tests || []).join(", ")} · ${p.when || ""}${p.urgency === "Επείγον" ? " · ΕΠΕΙΓΟΝ" : ""}`;
  if (j.kind === "consult") return ` · ${p.spec || ""}${p.urgency === "Επείγον" ? " · ΕΠΕΙΓΟΝ" : ""} · ${String(p.reason || "").slice(0, 80)}`;
  if (j.kind === "rx") return ` · ${(p.meds || []).map((m) => m.name).join(", ") || "χωρίς φάρμακα"} · ICD ${[].concat(p.icd || "N39").join(", ")} · για έλεγχο`;
  if (j.kind === "ref") return ` · ${(p.exams || []).map((x) => (x && x.name) || x).join(", ") || "χωρίς εξετάσεις"} · ICD ${[].concat(p.icd || []).join(", ")} · για έλεγχο`;
  if (j.kind === "discharge") return " · συμπλήρωση στον φάκελο" + (icdList(p.extraDx).length ? ` · +${icdList(p.extraDx).length} συννοσηρότητες` : "");
  if (j.kind === "comorb") return ` · ${icdList(p.codes).join(", ")}`;
  if (j.kind === "ehrdx") return " · τράβηγμα διαγνώσεων";
  if (j.kind === "ehrlabs") return " · εργαστηριακά για γραφήματα";
  return "";
}
async function jobsInsert(row) {
  const ins = () => jobsInApp(async (row) => {
    try {
      if (typeof sb6 === "undefined") return { skip: true };
      const r = await sb6.from("oncall_jobs").insert(row).select("id").maybeSingle();
      return r.error ? { err: r.error.message } : { ok: true, id: r.data && r.data.id };
    } catch (e) { return { err: String(e) }; }
  }, [row]);
  let r = await ins();
  if (!r && (await pdxEnsureTab())) r = await ins();
  return r || { err: "κλειστό Παραδόχαρτο" };
}
let jobAutoCfg = { at: 0, v: {} };
async function jobAutoOk(j, res) {
  if ((j.payload || {}).test) return false;   // 🧪 δοκιμαστική εργασία: ΠΟΤΕ αυτόματη έγκριση (σταματά στο «για έγκριση», καμία Καταχώρηση)
  // 💊/📋 6/11: απόφαση χρήστη — e-prescription αυτόματα ΜΟΝΟ όταν το ανοίξει ρητά στις Ρυθμίσεις (προεπιλογή: όχι) και όλα μπήκαν καθαρά
  if (!/^(order|rx|ref)$/.test(j.kind)) return false;   // ΜΟΝΟ παραγγελίες εργαστηρίου (απόφαση χρήστη) — ποτέ εξιτήριο/άλλο (έλεγχος 5/11)
  try {
    if (Date.now() - jobAutoCfg.at > 60000) {
      const v = await jobsInApp(async () => { try { if (typeof sb6 === "undefined") return null; const r = await sb6.from("oncall_config").select("value").eq("key", "auto_approve").maybeSingle(); return (r.data && r.data.value) || {}; } catch (e) { return null; } }, []);
      if (v) jobAutoCfg = { at: Date.now(), v };
    }
    if (!jobAutoCfg.v[j.kind] || !JOB_APPROVE[j.kind]) return false;
    if ((j.payload || {}).test) return false;   // ⛔ 8/11: δοκιμαστικές εργασίες ΠΟΤΕ αυτόματη έγκριση
    const r = res.result || {};
    if (j.kind === "order" && ((r.miss || []).length || (r.amb || []).length || !(r.ok || []).length)) return false;
    if (j.kind === "order" && (r.medPt || {}).st !== "ok") return false;   // 🪪 αυτόματα ΜΟΝΟ όταν επιβεβαιώθηκε ο ασθενής στη φόρμα
    const p = j.payload || {};
    if (j.kind === "rx") { if (r.preferMiss || p.repeat || !r.sig || !(r.meds || []).length || (r.meds || []).length !== (p.meds || []).length || /^⚠/.test(String(res.note || ""))) return false; }
    if (j.kind === "ref") { const want = (p.exams || []).length; if (!r.sig || !(r.exams || []).length || (r.exams || []).length < want || ((r.assoc || {}).unset || []).length || /^⚠/.test(String(res.note || ""))) return false; }
    return true;
  } catch (e) { return false; }
}
async function jobsSet(id, status, note, payload) {
  const set = () => jobsInApp(async (id, status, note, payload) => {
    try {
      if (typeof sb6 === "undefined") return { skip: true };
      const o = { status, note, updated_at: new Date().toISOString() };
      if (payload) o.payload = payload;
      // ✕ ακυρωμένη/απορριφθείσα εργασία ΔΕΝ ξαναγράφεται από το bot (πριν: «ξαναδοκιμή»/«πέρασε σε άλλο bot»/επανεκκίνηση την ξανάνοιγαν, #544)
      let q = sb6.from("oncall_jobs").update(o).eq("id", id);
      if (status !== "cancelled" && status !== "dismissed") q = q.not("status", "in", "(cancelled,dismissed)");
      const r = await q;
      return r.error ? { err: r.error.message } : { ok: true };
    } catch (e) { return { err: String(e) }; }
  }, [id, status, note, payload || null]);
  let r = await set();
  // το Παραδόχαρτο έκλεισε όσο δούλευε η εργασία: ανοίγει στο παρασκήνιο, ώστε η εργασία να μη μείνει «σε εξέλιξη»
  if (!r && status !== "running" && (await pdxEnsureTab())) r = await set();
  return r;
}
// ===== Εκτέλεση στο παρασκήνιο, χωρίς το πλαίσιο (εργασίες από το κινητό) =====
// Το bot δουλεύει στο δικό του παράθυρο (ανώνυμης περιήγησης αν επιτρέπεται), χωρίς ποντίκι/πληκτρολόγιο/πρόχειρο,
// ώστε όποιος κάθεται στον υπολογιστή να συνεχίζει τη δουλειά του.
async function bgEmrTab(requireOwn = true) { const r = await bgEmrTab0(requireOwn); bgMark("φάκελος: καρτέλα"); return r; }
async function bgEmrTab0(requireOwn = true) {
  const { efbot } = await chrome.storage.local.get("efbot");
  const incog = !!efbot?.settings?.botIncog && await chrome.extension.isAllowedIncognitoAccess().catch(() => false);
  // Σε κοινόχρηστο υπολογιστή η κοινή σύνδεση μπορεί να είναι άλλου χρήστη. Χωρίς ανώνυμη περιήγηση: «κοινό παράθυρο με φύλαξη»
  // (bgSharedEmrTab) — το bot συνδέεται ΜΟΝΟ του, ποτέ σε σύνδεση που βρήκε, και αποσυνδέεται όταν τελειώσει.
  if (requireOwn && !incog && !efbot?.settings?.__testShared) {
    if (efbot?.settings?.botShared === false) return { err: "χρειάζεται «δικό του παράθυρο» για το bot (Γενικές ρυθμίσεις + «Να επιτρέπεται στην ανώνυμη περιήγηση»)" };
    return await bgSharedEmrTab();
  }
  let t = (await chrome.tabs.query({ url: [EMR_URL, "https://login.e-ygeia.gov.gr/*"] })).filter((x) => !!x.incognito === incog)[0];
  // 🫥 το παράθυρο του bot δουλεύει ελαχιστοποιημένο (δεν ενοχλεί όποιον δουλεύει στον υπολογιστή)
  if (t && incog) { const w = await chrome.windows.get(t.windowId).catch(() => null); if (w && w.state !== "minimized" && !w.focused) await chrome.windows.update(w.id, { state: "minimized" }).catch(() => {}); }
  if (!t) {
    if (incog) { let werr = ""; const win = await chrome.windows.create({ url: EMR_HOME, incognito: true, focused: false, state: "minimized" }).catch((e) => { werr = e.message; return null; }); t = win?.tabs?.[0] || null; if (!t) { chrome.storage.local.set({ efbotIncogBlocked: Date.now() }); return { err: "το Chrome δεν άνοιξε ανώνυμο παράθυρο (" + String(werr || "πολιτική του νοσοκομείου;").slice(0, 100) + ")" }; } }
    else { const win = await chrome.windows.create({ url: EMR_HOME, focused: false, state: "minimized" }).catch(() => null); t = win?.tabs?.[0] || null; }
    // δεν περιμένουμε «φόρτωσε»: ο έλεγχος σύνδεσης που ακολουθεί κοιτάζει τη σελίδα κάθε δευτερόλεπτο
    if (t) await E.sleep(800);
  }
  return t;
}
// ===== Κοινό παράθυρο με φύλαξη (0.16.4) =====
// Όταν το Chrome δεν αφήνει ανώνυμο παράθυρο, το bot δουλεύει σε δικό του κανονικό παράθυρο, που μοιράζεται τα cookies με
// τα υπόλοιπα. Κανόνες, ώστε τίποτα να μη γίνεται στο όνομα άλλου γιατρού και κανείς να μη βρεθεί στον λογαριασμό του bot:
//  1. Αν σε άλλο παράθυρο είναι ανοιχτός ο φάκελος (κάποιος δουλεύει), το bot ΔΕΝ ξεκινά.
//  2. Αν ανοίγοντας το παράθυρό του βρει ήδη συνδεδεμένο φάκελο/ΑΗΦΥ (σύνδεση που δεν έκανε το ίδιο), κλείνει και σταματά.
//  3. Όταν μείνει αδρανές SHARED_IDLE_MS (και δεν περιμένει έγκριση φόρμα), σβήνει τα cookies των σελίδων που άνοιξε
//     (= αποσύνδεση) και κλείνει το παράθυρό του.
const SHARED_IDLE_MS = 5 * 60000, SHARED_ALARM = "efbot-shared-gc";
const SHARED_KEEP = /(^|\.)(netlify\.app|supabase\.co|workers\.dev|pages\.dev|github\.io)$|^\d+\.\d+\.\d+\.\d+$/;   // ποτέ αποσύνδεση από αυτά
let bgEhrErr = "";
async function sharedGet() { return (await chrome.storage.session.get("efbotShared")).efbotShared || null; }
async function sharedPatch(o) { const cur = await sharedGet(); const n = o === null ? null : { ...(cur || {}), ...o }; if (n) await chrome.storage.session.set({ efbotShared: n }); else await chrome.storage.session.remove("efbotShared"); return n; }
const sharedHostOk = (h) => !!h && !SHARED_KEEP.test(h);
async function sharedWin(sh) { if (!sh?.winId) return null; return await chrome.windows.get(sh.winId, { populate: true }).catch(() => null); }
async function bgSharedEmrTab() {
  let sh = await sharedGet();
  let win = await sharedWin(sh);
  if (sh && !win) { await sharedLogout("το παράθυρο του bot έκλεισε"); sh = null; }
  const emrTabs = (await chrome.tabs.query({ url: [EMR_URL, "https://login.e-ygeia.gov.gr/*"] }).catch(() => [])).filter((x) => !x.incognito);
  const human = emrTabs.filter((x) => !win || x.windowId !== win.id);
  // Ανοιχτός φάκελος σε άλλο παράθυρο: αν δεν έχει κίνηση τα τελευταία λεπτά ΚΑΙ ο συνδεδεμένος είναι λογαριασμός που έχει
  // μάθει το bot (= συνάδελφος που συναινεί), το bot «δανείζεται» τη σύνδεση. Αλλιώς δεν μπαίνει.
  if (human.length && !sh?.borrow) {
    const b = await emrBorrowCheck(human);
    if (b.err) return { err: b.err };
    if (b.borrow) {
      if (win) await chrome.windows.remove(win.id).catch(() => {});
      win = await chrome.windows.create({ url: EMR_HOME, focused: false, state: "minimized" }).catch(() => null);
      const bt = win?.tabs?.[0] || null;
      if (!bt) return { err: "δεν άνοιξε παράθυρο για το bot" };
      await sharedPatch(null);
      sh = await sharedPatch({ winId: win.id, tabId: bt.id, emrByBot: true, borrow: b.borrow, humanTabs: human.map((x) => x.id), ehrByBot: false, hosts: [], ts: Date.now(), hold: 0 });
      chrome.alarms.create(SHARED_ALARM, { periodInMinutes: 1 });
      await E.sleep(800);
      return bt;
    }
  }
  if (sh?.borrow) {
    // κίνηση στον φάκελο ενώ δουλεύει το bot με δανεική σύνδεση: σταματά πριν από την επόμενη ενέργεια
    const idle = await emrIdleMs();
    if (idle < 60000) { await sharedLogout("κίνηση στον φάκελο"); return { err: "κάποιος άρχισε να δουλεύει στον φάκελο — το bot σταμάτησε" }; }
    const bt = emrTabs.find((x) => x.windowId === sh.winId) || (await chrome.tabs.create({ windowId: sh.winId, url: EMR_HOME, active: true }).catch(() => null));
    if (!bt) return { err: "δεν άνοιξε καρτέλα για το bot" };
    await sharedPatch({ tabId: bt.id, ts: Date.now() });
    return bt;
  }
  let t = win ? emrTabs.find((x) => x.windowId === win.id) : null;
  if (!t && win) { t = await chrome.tabs.create({ windowId: win.id, url: EMR_HOME, active: true }).catch(() => null); if (t) await E.sleep(800); }
  if (!t) {
    win = await chrome.windows.create({ url: EMR_HOME, focused: false, state: "minimized" }).catch(() => null);
    t = win?.tabs?.[0] || null;
    if (!t) return { err: "δεν άνοιξε παράθυρο για το bot" };
    sh = await sharedPatch({ winId: win.id, tabId: t.id, emrByBot: false, ehrByBot: false, checked: false, hosts: ["apps.e-ygeia.gov.gr"], ts: Date.now(), hold: 0 });
    chrome.alarms.create(SHARED_ALARM, { periodInMinutes: 1 });
    await E.sleep(800);
  } else sh = await sharedPatch({ tabId: t.id, ts: Date.now() });
  return t;
}
// Τελευταία κίνηση (κλικ/πλήκτρο) ανθρώπου σε σελίδα του φακέλου, εκτός από το παράθυρο του bot.
// Μένει στον υπολογιστή (storage.local), ώστε να επιζεί από επανεκκινήσεις της επέκτασης.
async function emrInputNote(tab) {
  if (!tab || tab.incognito) return;
  const sh = await sharedGet(); if (sh && tab.windowId === sh.winId) return;
  await chrome.storage.local.set({ efbotEmrInput: Date.now() });
}
// Η κίνηση καταγράφεται μόνιμα (storage.local), άρα το bot ξέρει και αναδρομικά πότε έγινε το τελευταίο κλικ. Τυφλό σημείο
// είναι μόνο τα δευτερόλεπτα που ξαναφορτώνει η επέκταση: γι' αυτά, μετά από επανεκκίνηση περιμένει 1′ (όχι ολόκληρο το 5λεπτο).
async function emrIdleMs() {
  const { efbotEmrInput: last = 0, efbotBootTs: boot = 0 } = await chrome.storage.local.get(["efbotEmrInput", "efbotBootTs"]);
  const now = Date.now(), sinceBoot = now - boot;
  if (sinceBoot < 60000) return Math.min(now - last, sinceBoot);   // μόλις ξεκίνησε: «κίνηση» πριν από sinceBoot
  return now - last;
}
chrome.runtime.onInstalled.addListener(() => chrome.storage.local.set({ efbotBootTs: Date.now() }));
chrome.runtime.onStartup.addListener(() => chrome.storage.local.set({ efbotBootTs: Date.now() }));
// Ποιος λογαριασμός είναι συνδεδεμένος σε μια σελίδα (φάκελος ή ΑΗΦΥ): το username ή το ελληνικό επώνυμο του λογαριασμού
// κοντά σε «Αποσύνδεση/Χρήστης/Ιατρός». users = λογαριασμοί που έχει μάθει το bot. → {login:true} | {who, seen} | null
async function pageOwner(tabId, users) {
  let r = null;
  try {
    [r] = await chrome.scripting.executeScript({ target: { tabId }, func: () => {
      const vis = (e) => { const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0; };
      const pw = [...document.querySelectorAll("input[type=password]")].some(vis);
      const txt = (document.body?.innerText || "").replace(/\s+/g, " ");
      const near = [];
      const re = /(αποσύνδεση|αποσυνδεση|έξοδος|εξοδος|χρήστης|χρηστης|ιατρός|ιατρος|logout|user)/gi;
      let m; while ((m = re.exec(txt)) && near.length < 12) near.push(txt.slice(Math.max(0, m.index - 90), m.index + 90));
      return { pw, near, head: txt.slice(0, 400), host: location.host };
    } });
  } catch (e) {}
  const x = r?.result; if (!x) return null;
  if (x.pw || /^(login|auth|sso)\./.test(x.host)) return { login: true };
  const hay = [...x.near, x.head].join(" | "), nearTxt = x.near.join(" ");
  const toks = hay.match(/[Α-ΩΆΈΉΊΌΎΏ][Α-ΩΆΈΉΊΌΎΏΪΫα-ωάέήίόύώϊϋΐΰς]{4,}/g) || [];
  for (const u of users) {
    if (u && hay.toLowerCase().includes(u.toLowerCase())) return { who: u, seen: "" };
    if (x.near.length && toks.some((w) => nearTxt.includes(w) && epresNameScore(u, w) >= 100)) return { who: u, seen: "" };
  }
  return { who: "", seen: x.near.length ? "βρέθηκε περιοχή χρήστη" : "χωρίς περιοχή χρήστη" };
}
async function learnedUsers(hostRe, extra) {
  const { efbotCredByHost: all = {} } = await V.get("efbotCredByHost").catch(() => ({}));
  const users = new Set([String(extra || "").trim()]);
  for (const [h, v] of Object.entries(all || {})) if (hostRe.test(h)) for (const a of [].concat(v || [])) if (a && a.user) users.add(String(a.user).trim());
  users.delete("");
  return [...users];
}
// Ποιος είναι συνδεδεμένος στις ανοιχτές καρτέλες του φακέλου; Μόνο λογαριασμοί που έχει μάθει το bot («Μάθε τους κωδικούς»).
async function emrBorrowCheck(tabs) {
  const { efbot } = await chrome.storage.local.get("efbot");
  const idleMin = parseFloat(efbot?.settings?.emrIdleMin) || 5;
  const idle = await emrIdleMs();
  if (idle < idleMin * 60000) return { err: `κάποιος δουλεύει στον φάκελο σε αυτόν τον υπολογιστή (κίνηση πριν από ${Math.max(1, Math.round(idle / 60000))}′) — το bot περιμένει ${idleMin}′ χωρίς κίνηση` };
  const { efbotCredByHost: all = {} } = await V.get("efbotCredByHost").catch(() => ({}));
  const users = new Set([String(efbot?.settings?.emrUser || "").trim()]);
  for (const [h, v] of Object.entries(all || {})) if (/e-ygeia\.gov\.gr$/.test(h)) for (const a of [].concat(v || [])) if (a && a.user) users.add(String(a.user).trim());
  users.delete("");
  if (!users.size) return { err: "ο φάκελος είναι ανοιχτός, αλλά το bot δεν έχει μάθει κανέναν λογαριασμό φακέλου για να ξέρει αν είναι «δικός μας» (ef-bot → 🔑 Μάθε τους κωδικούς)" };
  let who = "", loggedIn = false, anyLogin = false;
  for (const t of tabs) {
    const o = await pageOwner(t.id, users);
    if (!o) continue;
    if (o.login) { anyLogin = true; continue; }
    loggedIn = true;
    if (!o.who) return { err: "ο φάκελος είναι ανοιχτός με λογαριασμό που δεν αναγνωρίζω ως λογαριασμό του bot (" + o.seen + ") — δεν τον χρησιμοποιώ" };
    who = o.who;
  }
  if (loggedIn && who) return { borrow: who };
  if (anyLogin) return { ok: true };   // μόνο σελίδα εισόδου: κανείς συνδεδεμένος, το bot συνδέεται μόνο του
  return { err: "δεν διαβάστηκε η ανοιχτή καρτέλα του φακέλου" };
}
// Κάθε σελίδα που ανοίγει στο παράθυρο του bot σημειώνεται, ώστε στην αποσύνδεση να σβηστούν ΑΚΡΙΒΩΣ αυτά τα cookies
chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  if (!info.url || tab.incognito) return;
  const sh = await sharedGet(); if (!sh || tab.windowId !== sh.winId) return;
  let h = ""; try { h = new URL(info.url).hostname; } catch (e) {}
  if (sharedHostOk(h) && !(sh.hosts || []).includes(h)) await sharedPatch({ hosts: [...(sh.hosts || []), h].slice(0, 30) });
});
// Κάποιος άνοιξε φάκελο/ΑΗΦΥ σε ΑΛΛΟ παράθυρο ενώ το bot είναι συνδεδεμένο: θα έβλεπε τη σύνδεση του bot.
// Αποσύνδεση αμέσως (ή μόλις τελειώσει η εργασία που τρέχει) και ανανέωση της καρτέλας του, που δείχνει πλέον τη σελίδα εισόδου.
chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  if (!info.url || tab.incognito) return;
  const sh = await sharedGet(); if (!sh || sh.borrow || tab.windowId === sh.winId || !(sh.emrByBot || sh.ehrByBot)) return;
  let h = ""; try { h = new URL(info.url).hostname; } catch (e) {}
  if (!h || !(sh.hosts || []).some((x) => sharedBase(x) === sharedBase(h))) return;
  if (jobsBusy || comorbBusy) { await sharedPatch({ intruder: tabId }); return; }
  await sharedLogout("άνοιξε κάποιος τον φάκελο σε άλλο παράθυρο");
  chrome.tabs.reload(tabId).catch(() => {});
});
// cookies της «οικογένειας» του host (π.χ. login.e-ygeia.gov.gr → e-ygeia.gov.gr), ώστε να φεύγει και η σύνδεση SSO
const sharedBase = (h) => { const p = h.split("."); return p.slice(-(/\.(gov|edu|com|org|net)\.gr$/.test(h) ? 3 : 2)).join("."); };
async function sharedLogout(why) {
  const sh = await sharedGet();
  if (!sh) return;
  await chrome.storage.session.remove("efbotShared");
  if (sh.borrow) {
    // η σύνδεση είναι του γιατρού: μένει. Οι καρτέλες του ξαναφορτώνουν την αρχική, ώστε να μη δείχνουν «παλιό» ασθενή
    // (ο τρέχων ασθενής του φακέλου είναι κοινός για όλη τη σύνδεση και το bot μπορεί να τον άλλαξε).
    const tabs = (await chrome.tabs.query({ url: [EMR_URL] }).catch(() => [])).filter((x) => !x.incognito && x.windowId !== sh.winId);
    for (const t of tabs) await chrome.tabs.update(t.id, { url: EMR_HOME }).catch(() => {});
    if (sh.winId) await chrome.windows.remove(sh.winId).catch(() => {});
    chrome.alarms.clear(SHARED_ALARM).catch(() => {});
    sharedLog("τέλος δανεικής σύνδεσης" + (why ? " (" + why + ")" : "")).catch(() => {});
    return;
  }
  if ((sh.emrByBot || sh.ehrByBot) && chrome.cookies) {
    const emrMine = sh.emrByBot && !sh.borrow, ehrMine = sh.ehrByBot && !sh.ehrBorrow;
    const bases = [...new Set((sh.hosts || []).filter(sharedHostOk).map(sharedBase))].filter((b) =>
      b === "e-ygeia.gov.gr" ? emrMine : b === "ehealthrecord.gov.gr" ? ehrMine : (emrMine || ehrMine));
    for (const b of bases) {
      const cs = await chrome.cookies.getAll({ domain: b }).catch(() => []);
      for (const c of cs) {
        if (c.storeId && c.storeId !== "0") continue;   // μόνο το κανονικό προφίλ (όχι ανώνυμη)
        const url = (c.secure ? "https://" : "http://") + c.domain.replace(/^\./, "") + c.path;
        await chrome.cookies.remove({ url, name: c.name, storeId: c.storeId }).catch(() => {});
      }
    }
  }
  if (sh.winId) await chrome.windows.remove(sh.winId).catch(() => {});
  chrome.alarms.clear(SHARED_ALARM).catch(() => {});
  sharedLog("αποσύνδεση/κλείσιμο" + (why ? " (" + why + ")" : "")).catch(() => {});
}
async function sharedLog(msg) { await chrome.storage.session.set({ efbotSharedLast: { msg, ts: Date.now() } }); }
chrome.alarms.onAlarm.addListener(async (a) => {
  if (a.name !== SHARED_ALARM) return;
  const sh = await sharedGet();
  if (!sh) { chrome.alarms.clear(SHARED_ALARM).catch(() => {}); return; }
  if (jobsBusy || comorbBusy) return;
  if (sh.intruder) { const it = sh.intruder; await sharedLogout("άνοιξε κάποιος τον φάκελο σε άλλο παράθυρο"); chrome.tabs.reload(it).catch(() => {}); return; }
  if (sh.borrow && (await emrIdleMs()) < 60000) { await sharedLogout("κίνηση στον φάκελο"); return; }
  if (sh.hold && Date.now() < sh.hold) return;   // φόρμα στον φάκελο περιμένει έγκριση από το κινητό
  if (Date.now() - (sh.ts || 0) < (sh.borrow ? 2 * 60000 : SHARED_IDLE_MS)) return;
  await sharedLogout("αδράνεια");
});
// Πρώτος έλεγχος στο παράθυρο του bot: αν η σελίδα είναι ΗΔΗ συνδεδεμένη, η σύνδεση δεν είναι του bot → έξοδος χωρίς τίποτα
async function sharedForeign(kind, isIn) {
  const sh = await sharedGet();
  await sharedPatch(null);   // ΔΕΝ σβήνουμε cookies: η σύνδεση είναι κάποιου άλλου
  if (sh?.winId) await chrome.windows.remove(sh.winId).catch(() => {});
  chrome.alarms.clear(SHARED_ALARM).catch(() => {});
  sharedLog(kind + ": βρέθηκε ξένη σύνδεση").catch(() => {});
  return "στον Chrome του υπολογιστή υπάρχει ήδη σύνδεση στον " + kind + " που δεν την έκανε το bot — δεν δουλεύει σε ξένη σύνδεση· αποσυνδεθείτε από τον " + kind + " στον υπολογιστή (ή ενεργοποιήστε «δικό του παράθυρο»)";
}
// Παράθυρο του bot για τον ΑΗΦΥ, χωρίς φάκελο (ανώνυμο αν επιτρέπεται, αλλιώς το «κοινό παράθυρο με φύλαξη»)
async function bgEhrHostTab() {
  const { efbot } = await chrome.storage.local.get("efbot");
  const incog = !!efbot?.settings?.botIncog && await chrome.extension.isAllowedIncognitoAccess().catch(() => false);
  if (incog) return await bgEmrTab();
  let sh = await sharedGet(), win = await sharedWin(sh);
  if (sh && !win) { await sharedLogout("το παράθυρο του bot έκλεισε"); sh = null; }
  if (!win) {
    win = await chrome.windows.create({ url: EHR_HOME, focused: false, state: "minimized" }).catch(() => null);
    if (!win) return { err: "δεν άνοιξε παράθυρο για το bot" };
    await sharedPatch({ winId: win.id, tabId: null, emrByBot: false, ehrByBot: false, hosts: ["doctor.ehealthrecord.gov.gr"], ts: Date.now(), hold: 0 });
    chrome.alarms.create(SHARED_ALARM, { periodInMinutes: 1 });
  } else await sharedPatch({ ts: Date.now() });
  return { id: null, windowId: win.id, incognito: false };
}
// 👥 Λογαριασμοί ΝΠΣ του bot: όσοι στάλθηκαν από το 🔐 «ΝΠΣ» ή «μαθεύτηκαν» (έως 8) + ο προεπιλεγμένος.
async function emrAccounts() {
  const st = { ...(await chrome.storage.local.get(["efbot"])), ...(await V.get(["efbotEmrCred", "efbotCredByHost"]).catch(() => ({}))) };
  const out = [], seen = new Set();
  const add = (u, p, ts) => { u = String(u || "").trim(); if (!u || !p || seen.has(u.toLowerCase())) return; seen.add(u.toLowerCase()); out.push({ user: u, pass: p, ts: ts || 0 }); };
  for (const h of ["login.e-ygeia.gov.gr", "apps.e-ygeia.gov.gr"]) { const v = (st.efbotCredByHost || {})[h]; for (const a of [].concat(v || [])) if (a) add(a.user, a.pass, a.ts); }
  if (st.efbotEmrCred && st.efbotEmrCred.pass) add(st.efbot?.settings?.emrUser, st.efbotEmrCred.pass, st.efbotEmrCred.ts);
  return out;
}
// Ποιος είναι συνδεδεμένος στον φάκελο στα ΚΑΝΟΝΙΚΑ παράθυρα (όχι του bot): το όνομα χρήστη του κουμπιού πάνω δεξιά.
async function emrHumanUsers() {
  const tabs = (await chrome.tabs.query({ url: [EMR_URL] }).catch(() => [])).filter((t) => !t.incognito);
  const out = new Set();
  for (const t of tabs.slice(0, 6)) {
    try { const [r] = await chrome.scripting.executeScript({ target: { tabId: t.id }, func: () => { const b = document.getElementById("appForm:dynaButton"); return b ? (b.innerText || b.textContent || "").trim() : ""; } }); if (r && r.result) out.add(String(r.result).trim().toLowerCase()); } catch (e) {}
  }
  return out;
}
let warmEmrAt = 0;   // τελευταία επιτυχής σύνδεση ΝΠΣ (για τον συντονιστή)· + session storage (ο service worker κλείνει)
chrome.storage.session.get("efbotWarm").then((x) => { warmEmrAt = Math.max(warmEmrAt, +(x && x.efbotWarm) || 0); }).catch(() => {});
const warmSet = () => { warmEmrAt = Date.now(); chrome.storage.session.set({ efbotWarm: warmEmrAt }).catch(() => {}); };
chrome.alarms.clear("efbot-warm").catch(() => {});   // ΚΑΝΕΝΑ «κράτημα» σύνδεσης ΝΠΣ (εντολή χρήστη)
// 🔐 Προτιμώμενοι λογαριασμοί ΝΠΣ για τις εργασίες του bot (oncall_config «emr_pref» = ["CHTHEODOROLEAS", …]) — απόφαση χρήστη 6/11
// 6/11: νέα σύνδεση ΝΠΣ με άλλον λογαριασμό = κλείσιμο ΟΛΩΝ των ανώνυμων παραθύρων του bot (αλλιώς η ανώνυμη συνεδρία e-ygeia μένει
// και η «επόμενη σύνδεση» δεν γίνεται ποτέ — έλεγχος ταχύτητας 6/11). Ποτέ κανονικά παράθυρα του χρήστη.
async function botIncogReset() { let n = 0; for (const w of await chrome.windows.getAll().catch(() => [])) if (w.incognito) { await chrome.windows.remove(w.id).catch(() => {}); n++; } return n; }
let emrPrefC = { at: 0, v: [] };
async function emrPref() {
  if (Date.now() - emrPrefC.at < 5 * 60000) return emrPrefC.v;
  const v = await jobsInApp(async () => { try { if (typeof sb6 === "undefined") return null; const r = await sb6.from("oncall_config").select("value").eq("key", "emr_pref").maybeSingle(); if (r.error) return null; return { v: Array.isArray(r.data && r.data.value) ? r.data.value : [] }; } catch (e) { return null; } }, []).catch(() => null);
  if (v) emrPrefC = { at: Date.now(), v: v.v.map(String).filter(Boolean).slice(0, 10) };
  return emrPrefC.v;
}
// όταν δεν τρέχει τίποτα: αν το ΝΠΣ του bot είναι συνδεδεμένο με μη προτιμώμενο λογαριασμό και υπάρχει ελεύθερος προτιμώμενος → νέα σύνδεση
let emrPrefChkAt = 0;
let emrCurUser = "";
async function emrPrefCheck() {
  if (Date.now() - emrPrefChkAt < 2 * 60000) return; emrPrefChkAt = Date.now();
  const PF = (await emrPref()).map((x) => x.toLowerCase()); if (!PF.length) return;
  const { efbotEmrOnce: once } = await chrome.storage.session.get("efbotEmrOnce"); if (once && Date.now() - once.at < 2 * 3600e3) return;   // επιλογή από το Παραδόχαρτο (π.χ. Ουρολογικό Ημέρας)
  const tabs = (await chrome.tabs.query({ url: [EMR_URL] }).catch(() => [])).filter((t) => t.incognito); if (!tabs.length) return;
  let cur = ""; try { const [r] = await chrome.scripting.executeScript({ target: { tabId: tabs[0].id }, func: () => { const b = document.getElementById("appForm:dynaButton"); return b ? (b.innerText || b.textContent || "").trim() : ""; } }); cur = String((r && r.result) || "").toLowerCase(); } catch (e) {}
  emrCurUser = cur || emrCurUser;
  // 6/11: σύγκριση χωρίς κεφαλαία/πεζά (πριν: «CHTHEODOROLEAS» ≠ «chtheodoroleas» → νέα σύνδεση κάθε 2′ όσο ήταν ελεύθερο το bot, έκλεινε έτοιμες φόρμες)
  if (!cur || PF.some((u) => cur.toLowerCase().indexOf(u) >= 0)) return;
  { const { efbotOrderPrep: op } = await chrome.storage.session.get("efbotOrderPrep"); if (op && Date.now() - op.at < ORDER_PREP_MS) return; }   // έτοιμη φόρμα παραγγελίας: όχι τώρα
  const hu = await emrHumanUsers().catch(() => new Set()), accs = await emrAccounts().catch(() => []);
  if (!accs.some((a) => PF.includes(a.user.toLowerCase()) && !hu.has(a.user.toLowerCase()))) return;
  { const { efbotEmrRelogAt: ra = 0 } = await chrome.storage.local.get("efbotEmrRelogAt"); if (Date.now() - ra < 20 * 60000) return; await chrome.storage.local.set({ efbotEmrRelogAt: Date.now() }); }
  await chrome.storage.session.set({ efbotEmrRelog: Date.now() });
}
async function bgEnsureLogin(tabId) { const t0 = Date.now(); const r = await bgEnsureLogin0(tabId); if (r && r.ok) warmSet(); bgMark("φάκελος: σύνδεση" + (Date.now() - t0 > 4000 ? " (ξανά login)" : "")); return r; }
async function bgEnsureLogin0(tabId) {
  const st = { ...(await chrome.storage.local.get(["efbot"])), ...(await V.get("efbotEmrCred")) };
  let user = String(st.efbot?.settings?.emrUser || "").trim(), cred = st.efbotEmrCred;
  // στο δικό του (ανώνυμο) παράθυρο: λογαριασμός ΔΙΑΦΟΡΕΤΙΚΟΣ από όποιον δουλεύει τώρα στον υπολογιστή
  let pickNote = "";
  try {
    const tb = await chrome.tabs.get(tabId).catch(() => null);
    if (tb && tb.incognito) {
      const accs = await emrAccounts(), human = await emrHumanUsers();
      const { efbotEmrBadUsers: badU = {} } = await chrome.storage.session.get("efbotEmrBadUsers");
      const wrong = () => false;
      { const { efbotEmrDeptSwitch: ds = {} } = await chrome.storage.local.get("efbotEmrDeptSwitch"); const DAY = (u) => /^kdouroumis$/i.test(u) || !!ds[String(u).toLowerCase()];
        const PF = (await emrPref()).map((x) => String(x).toLowerCase()), rank = (u) => { const i = PF.indexOf(String(u).toLowerCase()); return i >= 0 ? i - 100 : DAY(u) ? 100 : 0; };
        accs.sort((a, b) => rank(a.user) - rank(b.user)); }   // 6/11: προτιμώμενοι λογαριασμοί ΝΠΣ (oncall_config «emr_pref», π.χ. CHTHEODOROLEAS) πρώτοι   // 6/11: λογαριασμοί με άλλο «σπίτι» (π.χ. 3434) τελευταίοι
      const free = accs.filter((a) => !human.has(a.user.toLowerCase()) && !badU[a.user.toLowerCase()] && !wrong(a));
      let pick = free[0] || accs.find((a) => !badU[a.user.toLowerCase()] && !wrong(a)) || accs.find((a) => !badU[a.user.toLowerCase()]) || null;
      { const { efbotEmrOnce: once } = await chrome.storage.session.get("efbotEmrOnce");
        if (once && Date.now() - once.at < 2 * 3600e3) { const a1 = accs.find((a) => a.user.toLowerCase() === String(once.user).toLowerCase()); if (a1) { pick = a1; pickNote = "επιλογή από το Παραδόχαρτο (μία φορά): " + a1.user; } await chrome.storage.session.remove("efbotEmrOnce"); } }
      if (pick) { user = pick.user; cred = { pass: pick.pass, ts: pick.ts }; }
      if (human.size && pick && human.has(pick.user.toLowerCase())) pickNote = "ίδιος λογαριασμός με αυτόν που είναι ήδη συνδεδεμένος (" + pick.user + ") — στείλτε κι άλλον από το 🔐";
      await chrome.storage.session.set({ efbotEmrPick: { user, human: [...human], n: accs.length, note: pickNote, at: Date.now() } });
    }
  } catch (e) {}
  const sig = cred?.pass ? user + "|" + cred.pass.length + "|" + (cred.ts || 0) : "";
  const { efbotEmrLoginBad: bad } = await chrome.storage.session.get("efbotEmrLoginBad");
  const probe = async (act, pass) => {
    try {
      const [r] = await chrome.scripting.executeScript({ target: { tabId }, args: [act, user, pass || ""], func: (act, user, pass) => {
        const vis = (e) => { if (!e) return false; const r = e.getBoundingClientRect(); const cs = getComputedStyle(e); return r.width > 0 && r.height > 0 && cs.display !== "none" && cs.visibility !== "hidden"; };
        if (document.querySelector("#appForm\\:tabview\\:patientsTable, [id='appForm:patientRightMenu']")) return { state: "ready" };
        const pw = [...document.querySelectorAll("input[type=password]")].find(vis);
        if (!pw) return { state: document.readyState === "complete" ? "other" : "loading" };
        const form = pw.form || document;
        const fields = [...form.querySelectorAll("input:not([type=hidden]):not([type=password]):not([type=checkbox]):not([type=radio]):not([type=submit]):not([type=button])")].filter(vis);
        const userEl = fields.filter((f) => f.compareDocumentPosition(pw) & Node.DOCUMENT_POSITION_FOLLOWING).pop() || fields[0];
        const btn = [...form.querySelectorAll("button, input[type=submit], a.ui-button, [role=button]")].filter(vis).find((b) => /submit/i.test(b.type) || /σύνδεση|συνδεση|είσοδος|εισοδος|login|sign in/i.test(b.innerText || b.value || ""));
        if (act === "creds" && user && pass && userEl && btn) {
          const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
          for (const [el, v] of [[userEl, user], [pw, pass]]) { set.call(el, v); for (const t of ["input", "change", "keyup"]) el.dispatchEvent(new Event(t, { bubbles: true })); }
          btn.click(); return { state: "submitted" };
        }
        const err = [...document.querySelectorAll(".error, .errorMessage, .alert, [class*=error], [id*=error], [class*=Error]")].filter(vis).map((e) => e.innerText.trim()).filter(Boolean).join(" ").slice(0, 160);
        return { state: "login", err };
      } });
      return r?.result || { state: "other" };
    } catch (e) { return { state: "error" }; }
  };
  let at = 0, reloaded = false, otherSince = 0, lastState = "";
  const t0 = Date.now();
  const sh0 = await sharedGet(), shared = !!sh0 && sh0.tabId === tabId;
  while (Date.now() - t0 < 90000) {
    const s = await probe("");
    lastState = s.state;
    // 🔁 σελίδα που δεν είναι ούτε ο φάκελος ούτε φόρμα εισόδου (π.χ. /oam/server/auth_cred_submit, σελίδα σφάλματος,
    // λευκή σελίδα μετά τη σύνδεση) για >15″ → μία φορά ξανά η αρχική του φακέλου (πριν περίμενε μέχρι τα 90″ και αποτύγχανε)
    if (s.state === "other" || s.state === "loading" || s.state === "error") {
      if (!otherSince) otherSince = Date.now();
      if (Date.now() - otherSince > 15000 && !reloaded) {
        reloaded = true; otherSince = 0;
        await chrome.tabs.update(tabId, { url: EMR_HOME }).catch(() => {});
        await E.waitLoaded(tabId, 30000, () => false).catch(() => {});
        continue;
      }
    } else otherSince = 0;
    if (shared && s.state === "ready") {
      const sh = await sharedGet();
      if (!sh?.emrByBot) return { ok: false, err: await sharedForeign("φάκελο") };
      await sharedPatch({ ts: Date.now() });
    }
    if (shared && s.state === "login") { const sh = await sharedGet(); if (!sh?.emrByBot) await sharedPatch({ emrByBot: true, ts: Date.now() }); }
    if (s.state === "ready") return { ok: true };
    if (s.state === "login") {
      if (!sig) return { ok: false, err: "ο φάκελος ζητά σύνδεση — αποθηκεύστε όνομα και κωδικό φακέλου στο ef-bot (Γενικές ρυθμίσεις)" };
      if (bad === sig) return { ok: false, err: "η αυτόματη σύνδεση είχε αποτύχει — ελέγξτε όνομα/κωδικό φακέλου στο ef-bot" };
      if (!at) { at = Date.now(); await probe("creds", cred.pass); await E.sleep(2500); continue; }
      if (Date.now() - at > 12000 && !s.err && !reloaded) {
        // καμία ένδειξη λάθους: πιθανώς η σελίδα δεν ανανεώθηκε μετά τη σύνδεση — ξαναφόρτωση ΧΩΡΙΣ νέα υποβολή κωδικού
        reloaded = true; at = Date.now();
        await chrome.tabs.update(tabId, { url: EMR_HOME }).catch(() => {});
        await E.waitLoaded(tabId, 30000, () => false).catch(() => {});
        continue;
      }
      if (Date.now() - at > 12000) {
        await chrome.storage.session.set({ efbotEmrLoginBad: sig });
        try { const { efbotEmrBadUsers: bu = {} } = await chrome.storage.session.get("efbotEmrBadUsers"); bu[user.toLowerCase()] = Date.now(); await chrome.storage.session.set({ efbotEmrBadUsers: bu }); } catch (e) {}
        credFailPush("Ιατρικός φάκελος", user);
        notify("Φάκελος: η αυτόματη σύνδεση απέτυχε", "Ελέγξτε όνομα χρήστη/κωδικό στο ef-bot. Δεν θα ξαναδοκιμάσει μέχρι να τα αποθηκεύσετε ξανά.", true);
        return { ok: false, err: "η αυτόματη σύνδεση στον φάκελο απέτυχε" + (s.err ? ": " + s.err : " (λάθος στοιχεία;)") };
      }
    }
    await E.sleep(1000);
  }
  // διάγνωση: πού κόλλησε (διεύθυνση + λίγο κείμενο σελίδας, χωρίς αριθμούς)
  let diag = "";
  try {
    const tb = await chrome.tabs.get(tabId).catch(() => null);
    const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: () => (document.title + " · " + (document.body ? document.body.innerText : "")).replace(/\s+/g, " ").replace(/\d{4,}/g, "•").slice(0, 160) }).catch(() => [null]);
    diag = " · σελίδα " + String((tb && tb.url) || "").replace(/^https?:\/\/([^/]+).*?(\/[^?#]*).*$/, "$1$2").slice(0, 80) + " (" + lastState + ")" + (r && r.result ? " «" + r.result + "»" : "");
  } catch (e) {}
  return { ok: false, err: "ο φάκελος δεν άνοιξε έγκαιρα" + diag };
}
function bgMapTherapist(settings, code) {
  if (!code) return "";
  for (const l of String(settings?.therMap || "").split(/\r?\n/)) { const i = l.indexOf(";"); if (i > 0 && l.slice(0, i).trim().toLowerCase() === String(code).trim().toLowerCase()) return l.slice(i + 1).trim(); }
  return "";
}
async function bgRunWorkflow(wfId, extraVals, tabId, { opener: useOpener = true, lock = true } = {}) {
  const { efbot: st } = await chrome.storage.local.get("efbot");
  E.patchWorkflows(st); // ίδιες διορθώσεις με το πάνελ, ακόμα κι αν δεν έχει ανοίξει μετά την ενημέρωση
  const w = (st?.workflows || []).find((x) => x.id === wfId);
  if (!w) throw new Error("Δεν βρέθηκε η διαδικασία " + wfId);
  const opener = st.workflows.find((x) => x.id === (st.settings?.openerId || "anoigma"));
  if (!opener) throw new Error("Δεν βρέθηκε η διαδικασία «Άνοιγμα ασθενή»");
  const keep = w.keep || [];
  const saved = Object.fromEntries(Object.entries((st.values || {})[w.id] || {}).filter(([k]) => keep.includes(k)));
  const v = { ...(w.defaults || {}), ...saved, ...extraVals };
  const who = String(v[E.BULKVAR] || "").trim();
  const base = E.lineVars(E.BULKVAR, who);
  const items = [...(useOpener ? E.plan(opener, v, base).map((it) => ({ ...it, tag: it.tag + " · άνοιγμα ασθενή" })) : []), ...E.plan(w, v, base)];
  const ctx = { tabId, homeTabId: tabId, vars: {}, diag: [], wfName: w.name, t0: Date.now(), box: "bg", vals: () => ({ ...v, ...ctx.vars }), settings: () => ({ timeout: 30, delay: 300, ...(st.settings || {}) }), isAborted: () => !!jobAbortId, log: () => {}, heartbeat: () => E.lockTouch("bg"), noTabSwitch: true };
  let steps = [];
  // lock:false → ο καλών (αυτόματος κύκλος) κρατά ήδη το κλείδωμα «bg» για όλο τον κύκλο
  if (lock && !(await E.lockAcquire("bg"))) throw new Error("το bot είναι απασχολημένο (τρέχει άλλη διαδικασία στο πλαίσιο)");
  try {
    let restarted = false;
    for (;;) try {
      await E.execPlan(ctx, items, { from: 0, onStart: (it) => steps.push(it.s.label), onDone: (it) => { try { bgMark("βήμα: " + String((it && it.s && it.s.label) || "").slice(0, 32)); } catch (e) {} } });
      break;
    } catch (e) {
      if (!e.restart || restarted) { e.lastStep = steps[steps.length - 1] || ""; try { e.diag = (ctx.diag || []).slice(-6).map((d) => JSON.stringify(d).slice(0, 200)); } catch (x) {} throw e; }
      restarted = true; ctx.guard = null;
    }
  } finally { if (lock) E.lockRelease("bg"); }
  return ctx;
}
// Τι γράφει τώρα η φόρμα εξιτηρίου (ό,τι θα αποθηκευτεί): για τη σύνοψη στο κινητό
async function bgReadDischarge(tabId) {
  const res = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: () => {
    const q = (s) => document.querySelector(s);
    const op = q("#appForm\\:medicalOpinionTxtInputDRG");
    if (!op) return null;
    const one = (e) => (e ? e.textContent.replace(/\s+/g, " ").trim() : "");
    const lbl = (id) => one(q("#appForm\\:" + id + "_label"));
    const diagnoses = [...document.querySelectorAll("#appForm\\:diagnosis_table_drg tbody tr")]
      .map((tr) => ({ text: tr.innerText.replace(/\s+/g, " ").trim().slice(0, 200), checked: !!tr.querySelector(".ui-chkbox-box.ui-state-active"), main: !!tr.querySelector(".ui-selectbooleanbutton.ui-state-active, .ui-button.ui-state-active") }))
      .filter((d) => d.text && !/Δεν βρέθηκαν|No records/i.test(d.text));
    const ol = q("#appForm\\:content > nav > ol");
    const patient = ol ? ([...ol.querySelectorAll("li")].map(one).filter((t) => t && t !== "⌂").join(" · ") || one(ol)) : "";
    return { patient, doctor: (q("#appForm\\:doctorInput") || {}).value || "", type: lbl("dischargeType_drg"), outcome: lbl("medicalOutcome_drg"),
      time: (q("#appForm\\:dischargeTimeInput_drg_input") || {}).value || "", diagnoses, opinion: op.value || "" };
  } }).catch(() => []);
  return (res.find((r) => r?.result) || {}).result || null;
}
JOB_RUNNERS.discharge = async (job) => {
  const p = job.payload || {};
  const text = String(p.text || "").slice(0, 20000);
  if (!text.trim()) return { status: "failed", note: "κενό κείμενο εξιτηρίου" };
  const { efbot } = await chrome.storage.local.get("efbot");
  const up = (t) => String(t || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().trim();
  const th = bgMapTherapist(efbot?.settings, p.therapist) || up(p.therapistName);
  const tab = await bgEmrTab();
  if (!tab || tab.err) return { status: "failed", note: tab?.err || "δεν άνοιξε ο φάκελος" };
  const lg = await bgEnsureLogin(tab.id);
  if (!lg.ok) return { status: "failed", note: lg.err };
  const extra = icdList(p.extraDx);
  const vals = { [E.BULKVAR]: job.name, "κείμενο_διάγνωσης": text, "επιπλέον_διαγνώσεις": extra.join("\n") };
  if (th) vals["θεράπων"] = th;
  let ctx, pre = false;
  // ⚡ πρώτα ΑΠΕΥΘΕΙΑΣ άνοιγμα ασθενή (όπως στην παραγγελία) — μετά η διαδικασία ΧΩΡΙΣ τα βήματα «άνοιγμα ασθενή» (κλικ, ~10-30″)
  try { await bgOpenPatient(tab, job.name, efbot); pre = true; bgMark("άνοιγμα ασθενή"); } catch (e) { pre = false; }
  try { ctx = await bgRunWorkflow("exitirio", vals, tab.id, { opener: !pre }); }
  catch (e) { return { status: "failed", note: (e.lastStep ? "«" + e.lastStep + "»: " : "") + e.message }; }
  const form = await bgReadDischarge(tab.id);
  if (!form) return { status: "failed", note: "συμπληρώθηκε, αλλά δεν διαβάστηκε η φόρμα για έλεγχο" };
  const miss = (ctx?.misses || []).filter(Boolean);
  return { status: "review", note: "συμπληρώθηκε — περιμένει έγκριση" + (miss.length ? ` · ⚠ δεν βρέθηκαν στη λίστα ICD: ${miss.join(", ")}` : ""), result: { ...form, tabId: tab.id, filledAt: Date.now() }, push: ["👀 Εξιτήριο για έλεγχο", `${job.name}: ανοίξτε το Παραδόχαρτο για έγκριση`] };
};
// Έγκριση από το κινητό: έλεγχος ότι η φόρμα είναι ίδια με αυτή που είδε ο γιατρός. Το πάτημα «Αποθήκευση» ενεργοποιείται
// μόλις καταγραφεί το κουμπί και τα μηνύματα του φακέλου (ρύθμιση emrSaveSel)· μέχρι τότε η αποθήκευση γίνεται στον υπολογιστή.
// Συννοσηρότητες → οθόνη ιστορικού του ασθενή (διαδικασία «istoriko_synn», που μαθαίνεται μία φορά με 🎯).
// Στο εξιτήριο οι συννοσηρότητες μπαίνουν αλλιώς: τις κρατά το Παραδόχαρτο στον ασθενή και φεύγουν μαζί με το εξιτήριο.
JOB_RUNNERS.comorb = async (job) => {
  const p = job.payload || {};
  const items = (Array.isArray(p.codes) ? p.codes : []).filter((o) => o && icdList([o.code]).length).slice(0, 40);
  const codes = icdList(items);
  if (!codes.length) return { status: "failed", note: "κανένας έγκυρος κωδικός ICD-10" };
  const { efbot } = await chrome.storage.local.get("efbot");
  const w = (efbot?.workflows || []).find((x) => x.id === "istoriko_synn");
  if (!w) return { status: "failed", note: "ανοίξτε μία φορά το πάνελ του ef-bot στον υπολογιστή (ολοκληρώνει την ενημέρωση) και κάντε την εκμάθηση της «Συννοσηρότητες → Ατομικό ιστορικό»" };
  const NOT = ["manual", "skipif", "wait", "copy", "tab", "goto"];
  const todo = w.steps.filter((s) => !s.disabled && !s.target && !NOT.includes(s.type)).length;
  if (todo) return { status: "failed", note: `η «${w.name}» έχει ${todo} βήματα χωρίς εκμάθηση (🎯) — γίνεται μία φορά από τον υπολογιστή` };
  const tab = await bgEmrTab();
  if (!tab || tab.err) return { status: "failed", note: tab?.err || "δεν άνοιξε ο φάκελος" };
  const lg = await bgEnsureLogin(tab.id);
  if (!lg.ok) return { status: "failed", note: lg.err };
  const desc = new Map(items.map((o) => [String(o.code).toUpperCase(), String(o.desc || "").replace(/\s+/g, " ").slice(0, 90)]));
  const vals = { [E.BULKVAR]: job.name, "συννοσηρότητες": codes.join("\n"),
    "συννοσηρότητες_κείμενο": codes.map((c) => c + (desc.get(c) ? " " + desc.get(c) : "")).join("\n") };
  let ctx;
  let preC = false; try { const { efbot: stC } = await chrome.storage.local.get("efbot"); await bgOpenPatient(tab, job.name, stC); preC = true; } catch (e) {}
  try { ctx = await bgRunWorkflow("istoriko_synn", vals, tab.id, { opener: !preC }); }
  catch (e) { return { status: "failed", note: (e.lastStep ? "«" + e.lastStep + "»: " : "") + e.message }; }
  const miss = (ctx?.misses || []).filter(Boolean);
  const ok = codes.length - miss.length;
  if (!(p.test || /^zzz_/.test(String(job.name_key || "")))) await npsdxQueue(null, job.name, codes);   // και στη «Διάγνωση» του ΝΠΣ (ΠΑΘΗΣΗ)
  // Το bot δεν πατά ποτέ «Αποθήκευση»: το λέμε καθαρά στη σημείωση και στην ειδοποίηση
  return { status: "done", note: `συμπληρώθηκαν ${ok}/${codes.length} — ΔΕΝ αποθηκεύτηκε: Αποθήκευση από τον υπολογιστή (παράθυρο του bot)` + (miss.length ? ` · ⚠ δεν βρέθηκαν: ${miss.join(", ")}` : ""),
    push: ["🩺 Συννοσηρότητες στο ιστορικό", `${job.name}: συμπληρώθηκαν ${ok}/${codes.length} — πατήστε Αποθήκευση στον υπολογιστή`] };
};
// ===== Αυτόματες συννοσηρότητες (ΑΗΦΥ) =====
// Για κάθε νέο ασθενή του Παραδόχαρτου: άνοιγμα στον φάκελο με το όνομα (με έλεγχο) → ΑΜΚΑ → doctor.ehealthrecord.gov.gr
// με τον ΑΜΚΑ (λόγος πρόσβασης, έλεγχος ότι ταιριάζει ο ΑΜΚΑ) → κωδικοί της σελίδας διαγνώσεων → Παραδόχαρτο.
// Ο ΑΜΚΑ μένει μόνο στη μνήμη όσο διαρκεί ο έλεγχος ενός ασθενή: δεν αποθηκεύεται, δεν γράφεται σε διάγνωση/ειδοποίηση.
const COMORB_ALARM = "efbot-comorb";
const EHR_HOME = "https://doctor.ehealthrecord.gov.gr/doctor/app/";
alarmEnsure(COMORB_ALARM, { periodInMinutes: 5 });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === COMORB_ALARM) comorbAutoTick(false).catch(() => {}); });
let comorbBusy = false, comorbWakeT = null, comorbYield = false, comorbNps = 0;   // comorbNps: η λωρίδα Α χρησιμοποιεί ΤΩΡΑ την καρτέλα του φακέλου
async function comorbState(t) { await chrome.storage.session.set({ efbotComorbState: t + " · " + new Date().toTimeString().slice(0, 5) }); return t; }
// 6/11: ο ασθενής μπορεί να άλλαξε κρεβάτι (ή η καρτέλα να έχει παλιότερη εικόνα) → βρες το κλειδί του με το όνομα, σε όποια καρτέλα (και παλιές εκδόσεις της εφαρμογής)
// 7/11: η καρτέλα Παραδόχαρτου του υπολογιστή μπορεί να έχει παλιά λίστα (π.χ. 28 αντί για 31 ασθενείς) → ξαναφόρτωμα από τον server
async function pdxAppRefresh() {
  const r = await jobsInApp(() => { try { const ae = document.activeElement; if (document.hasFocus() && ae && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName)) return { busy: 1 }; if (typeof loadFromStorage === "function") { loadFromStorage(); return { ok: 1 }; } return { skip: 1 }; } catch (e) { return { err: String(e && e.message || e) }; } }, [], 10000).catch(() => null);
  if (r && r.ok) await E.sleep(5000);
  return !!(r && r.ok);
}
async function pdxResolveK(k, name, again) {
  const r0 = await pdxResolveK1(k, name);
  if (!again && r0 && !r0.r && !r0.here && (await pdxAppRefresh())) return pdxResolveK1(k, name);
  return r0;
}
async function pdxResolveK1(k, name) {
  const r = await jobsInApp((k, name) => { try {
    const nz = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/ς/g, "σ").replace(/\s+/g, " ").trim();
    const D = typeof data !== "undefined" && data ? data : null, X = typeof extraPatients !== "undefined" && extraPatients ? extraPatients : {};
    if (!D || !Object.keys(D).length) return { skip: true };
    const want = nz(name), cur = String(k).indexOf("extra-") === 0 ? X[k] : D[k];
    if (cur && nz(cur.name) === want) return { r: k };
    const hits = []; [D, X].forEach((src) => Object.keys(src).forEach((kk) => { const x = src[kk]; if (x && x.name && nz(x.name) === want) hits.push(kk); }));
    return { r: hits.length === 1 ? hits[0] : "", n: Object.keys(D).length + Object.keys(X).length, here: !!cur };
  } catch (e) { return { err: String(e && e.message || e) }; } }, [k, name], 15000).catch(() => null);
  return r && typeof r.r === "string" ? r : null;
}
async function pdxCall(fn, args) {
  const call = () => jobsInApp(async (fn, args) => { try { const f = window[fn]; if (typeof f !== "function") return { skip: true }; return { r: await f(...args) }; } catch (e) { return { err: String(e && e.message || e) }; } }, [fn, args], 90000);
  let r = await call();
  // Δεν υπάρχει (έτοιμη) καρτέλα Παραδόχαρτου: κατά τη διάρκεια μιας δουλειάς την ανοίγουμε μόνοι μας στο παρασκήνιο,
  // ώστε να μη χαθεί το αποτέλεσμα αν ο χρήστης έκλεισε το Παραδόχαρτο ενώ το bot δούλευε.
  if (!r && comorbBusy && (await pdxEnsureTab())) r = await call();
  return r;
}
let pdxOpening = null;
async function pdxEnsureTab() {
  if (pdxOpening) return pdxOpening;
  pdxOpening = (async () => {
    const ready = async (tabId) => {
      try {
        const [x] = await chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", func: async () => {
          try {
            if (typeof sb6 === "undefined" || typeof window.pdxComorbAutoApply !== "function") return false;
            const ss = (await sb6.auth.getSession()).data.session; if (!ss) return "login";
            return Object.keys((typeof data !== "undefined" && data) || {}).length + Object.keys((typeof extraPatients !== "undefined" && extraPatients) || {}).length > 0;
          } catch (e) { return false; }
        } });
        return x?.result;
      } catch (e) { return false; }
    };
    let t = (await chrome.tabs.query({ url: APP_HOSTS.map((h) => `https://${h}/*`) }).catch(() => [])).find((x) => !x.incognito);
    if (!t) {
      // σε κανονικό (όχι ανώνυμο) παράθυρο: εκεί είναι η σύνδεση του Παραδόχαρτου· χωρίς να έρθει μπροστά
      const wins = (await chrome.windows.getAll({ windowTypes: ["normal"] }).catch(() => [])).filter((w) => !w.incognito);
      if (wins.length) t = await chrome.tabs.create({ windowId: wins[0].id, url: APP_URL, active: false }).catch(() => null);
      else { const w = await chrome.windows.create({ url: APP_URL, focused: false, state: "minimized" }).catch(() => null); t = w?.tabs?.[0] || null; }
      if (t) chrome.tabs.update(t.id, { pinned: true }).catch(() => {});
    }
    if (!t) return false;
    for (let i = 0; i < 40; i++) {
      const r = await ready(t.id);
      if (r === true) return true;
      if (r === "login") {   // χωρίς σύνδεση στο Παραδόχαρτο το bot δεν παίρνει εντολές: ειδοποίηση εδώ, το πολύ μία ανά ώρα
        const { efbotPdxLoginNote: n = 0 } = await chrome.storage.session.get("efbotPdxLoginNote");
        if (Date.now() - n > 3600e3) { await chrome.storage.session.set({ efbotPdxLoginNote: Date.now() }); notify("Παραδόχαρτο: χρειάζεται σύνδεση", "Ο bot δεν μπορεί να παίρνει εντολές από τα κινητά μέχρι να συνδεθεί κάποιος στο Παραδόχαρτο σε αυτόν τον υπολογιστή (η καρτέλα είναι καρφιτσωμένη).", true); }
        return false;
      }
      await E.sleep(1000);
    }
    return false;
  })();
  try { return await pdxOpening; } finally { pdxOpening = null; }
}
// 💤 Η καρτέλα του ΑΗΦΥ σε ελαχιστοποιημένο παράθυρο «παγώνει» από τον Chrome (εξοικονόμηση μνήμης): τότε κανένα script δεν
// μπαίνει («Cannot access contents of the page») και η σύνδεση έμενε 120″ στο κενό. Όπως στο e-prescription/Evorad: tabWake.
async function bgEhrTab(emrTab) {
  const t = await bgEhrTab0(emrTab);
  if (!t || !t.id) return t;
  return (await tabWake(t.id)) || t;
}
async function bgEhrTab0(emrTab) {
  bgEhrErr = "";
  const all = await chrome.tabs.query({ url: "https://doctor.ehealthrecord.gov.gr/*" }).catch(() => []);
  const sh = await sharedGet();
  if (sh && emrTab && !emrTab.incognito && emrTab.windowId === sh.winId) {
    // κοινό παράθυρο: μόνο η καρτέλα ΑΗΦΥ του bot· αν κάποιος έχει ανοιχτό ΑΗΦΥ αλλού, ή η σύνδεση δεν είναι του bot, σταματά
    if (all.some((x) => !x.incognito && x.windowId !== sh.winId)) { bgEhrErr = "ο ΑΗΦΥ είναι ανοιχτός σε άλλο παράθυρο στον υπολογιστή — το bot δεν μπαίνει στην κοινή σύνδεση"; return null; }
    let t = all.find((x) => x.windowId === sh.winId);
    if (!t) {
      t = await chrome.tabs.create({ windowId: sh.winId, url: EHR_HOME, active: false }).catch(() => null);
      if (t) await E.waitLoaded(t.id, 30000, () => false).catch(() => {});
    }
    if (t && !sh.ehrByBot && !sh.ehrBorrow) {
      // λίγος χρόνος για ανακατεύθυνση στη σελίδα εισόδου· αν μείνει συνδεδεμένος, η σύνδεση είναι κάποιου άλλου
      let foreign = false;
      for (let i = 0; i < 6; i++) { if (await ehrLoggedIn(t.id)) { foreign = true; break; } await E.sleep(1000); }
      if (foreign) {
        const users = await learnedUsers(/ehealthrecord\.gov\.gr$|e-prescription\.gr$|^\*(ahfy|epres)$/);
        const o = users.length ? await pageOwner(t.id, users) : null;
        const { efbot } = await chrome.storage.local.get("efbot");
        const idleMin = parseFloat(efbot?.settings?.emrIdleMin) || 5;
        if (o && o.who && (await emrIdleMs()) >= idleMin * 60000) await sharedPatch({ ehrBorrow: o.who });
        else { bgEhrErr = await sharedForeign("ΑΗΦΥ"); return null; }
      } else await sharedPatch({ ehrByBot: true });
    }
    await sharedPatch({ ts: Date.now() });
    return t;
  }
  let t = all.find((x) => !!x.incognito === !!emrTab.incognito && x.windowId === emrTab.windowId) || all.find((x) => !!x.incognito === !!emrTab.incognito);
  if (!t) { t = await chrome.tabs.create({ windowId: emrTab.windowId, url: EHR_HOME, active: false }).catch(() => null); if (t) await E.waitLoaded(t.id, 30000, () => false).catch(() => {}); }
  return t;
}
function untaughtSteps(w) { return (w?.steps || []).filter((s) => !s.disabled && !s.optional && !s.target && !["manual", "skipif", "wait", "copy", "tab", "goto"].includes(s.type)).length; }
async function comorbAutoTick(manual) {
  if (comorbBusy) return "τρέχει ήδη";
  const { efbot } = await chrome.storage.local.get("efbot");
  if (!efbot?.settings?.comorbAuto && !manual) return "";
  if (!efbot?.settings?.comorbAuto) return comorbState("ενεργοποιήστε πρώτα την επιλογή");
  await ehrKeepAlive();
  // το jobsBusy κρατά όλο τον έλεγχο της ουράς (κάθε 30″), όχι μόνο πραγματική εργασία → περιμένουμε να τελειώσει ο έλεγχος
  for (let i = 0; i < 45 && jobsBusy && !jobRunningId && !sideRunningId; i++) await E.sleep(1000);
  if (jobRunningId || sideRunningId) return comorbState("περιμένει: τρέχει εργασία από το κινητό");
  // ⚡ 8/11: γύρω από παραγγελίες (έτοιμη φόρμα, παραγγελία στην ουρά ή πρόσφατη) ο αυτόματος κύκλος ΑΗΦΥ ΔΕΝ ξεκινά — έκλεβε 10″+ από την παραγγελία
  if (!manual) { const { efbotOrderPrep: op } = await chrome.storage.session.get("efbotOrderPrep").catch(() => ({}));
    if ((op && Date.now() - op.at < ORDER_PREP_MS) || prepPollUntil > Date.now() || Date.now() - (self.__ordAct || 0) < 3 * 60000) return comorbState("περιμένει: παραγγελία σε εξέλιξη"); }
  if (!manual && !(await leaseHeld())) return comorbState("την αυτόματη αναζήτηση την κάνει τώρα άλλος υπολογιστής με ef-bot");
  const notReady = comorbNotReady(efbot);
  if (notReady) return comorbState(notReady);
  const got = await pdxCall("pdxComorbAutoList", []);
  if (!got) return comorbState("ανοίξτε το Παραδόχαρτο σε αυτόν τον Chrome (συνδεδεμένο)");
  if (got.err) return comorbState("Παραδόχαρτο: " + got.err);
  let todo = (got.r || []).slice(0, manual ? 8 : 6);
  if (!todo.length) return comorbState("κανένας νέος ασθενής" + await comorbStatsText());
  // ένα κλείδωμα για όλο τον κύκλο (οι δύο λωρίδες δουλεύουν σε διαφορετικές καρτέλες του παραθύρου του bot)
  if (!(await E.lockAcquire("bg"))) return comorbState("περιμένει: τρέχει άλλη διαδικασία του bot");
  comorbBusy = true; comorbYield = false;
  let ok = 0, fail = 0, stopped = "";
  try {
    // Όσοι έχουν ΑΜΚΑ στο Παραδόχαρτο δεν χρειάζονται τον φάκελο. Αν ο φάκελος δεν είναι διαθέσιμος (π.χ. δουλεύει κάποιος),
    // συνεχίζουμε μόνο με αυτούς.
    const hasAmka = (p) => /^\d{11}$/.test(String(p.amka || ""));
    let tab = todo.every(hasAmka) ? await bgEhrHostTab() : await bgEmrTab();
    if ((!tab || tab.err) && todo.some(hasAmka) && !todo.every(hasAmka)) { todo = todo.filter(hasAmka); tab = await bgEhrHostTab(); }
    if (!tab || tab.err) { const r = { err: tab?.err || "δεν άνοιξε ο φάκελος", stopAll: true }; await comorbEnvProblem(r); return comorbState("⏸ " + r.err); }
    // Λωρίδα Α (φάκελος νοσοκομείου): ΑΜΚΑ για τον επόμενο ασθενή, όσο η λωρίδα Β δουλεύει στον ΑΗΦΥ τον προηγούμενο.
    // Ο ΑΜΚΑ μένει μόνο στη μνήμη, μέχρι να τον πάρει η λωρίδα Β.
    const amkaOf = new Map(); // k → Promise<{amka, fromManual, ms} | {err…}>
    let stopA = false;
    const laneA = (async () => {
      for (const p of todo) {
        let done; amkaOf.set(p.k, new Promise((r) => (done = r)));
        if (stopA || comorbYield) { done({ skip: true }); continue; }
        comorbNps++; try { done(await comorbAmka(p, tab, { lock: false }).catch((e) => ({ err: e.message }))); } finally { comorbNps--; }
      }
    })();
    // Λωρίδα Β (ΑΗΦΥ): διαγνώσεις + εργαστηριακά, με τη σειρά
    for (const p of todo) {
      while (!amkaOf.has(p.k)) await E.sleep(100);
      const a = await amkaOf.get(p.k);
      if (a.skip) continue;
      if (comorbYield) { stopped = "έδωσε προτεραιότητα σε αίτημα από το Παραδόχαρτο"; stopA = true; continue; }
      const t0 = Date.now();
      const res = a.err ? a : await comorbEhr(p, a, tab, { lock: false }).catch((e) => ({ err: e.message }));
      // Πρόβλημα περιβάλλοντος (σύνδεση, παράθυρο, φάκελος): δεν χρεώνεται στον ασθενή — ξαναδοκιμάζει μόλις διορθωθεί
      if (res.err && res.stopAll) { stopA = true; await comorbEnvProblem(res); stopped = res.err; break; }
      if (res.err) { fail++; await pdxCall("pdxComorbAutoMark", [p.k, p.name, { status: res.retry ? "retry" : "fail", note: String(res.err).slice(0, 160) }]); }
      else { ok++; await comorbStat({ a: a.ms || 0, ...(res.ms || {}), b: Date.now() - t0 }); if (res.c) await npsdxQueue(p.k, p.name); }
    }
    stopA = true; await laneA;
  } finally { comorbBusy = false; E.lockRelease("bg"); }
  if (/σύνδεση|παράθυρο|φάκελος/.test(stopped)) return comorbState("⏸ " + stopped);
  const more = (got.r || []).length > todo.length;
  if (more || comorbYield) { clearTimeout(comorbWakeT); comorbWakeT = setTimeout(() => comorbAutoTick(false).catch(() => {}), comorbYield ? 60000 : 3000); }
  return comorbState(`ΑΗΦΥ: ${ok} ✓${fail ? `, ${fail} ✗ (λόγος στο 🩺 του ασθενή)` : ""}${stopped ? " · " + stopped : ""}${more ? " · συνεχίζει με τους υπόλοιπους" : ""}` + await comorbStatsText());
}
// ---- μέτρηση: χρόνος ανά βήμα (τελευταίοι 30 ασθενείς) ----
async function comorbStat(m) {
  const { efbotComorbStats: a = [] } = await chrome.storage.local.get("efbotComorbStats");
  a.push({ at: Date.now(), ...m }); while (a.length > 30) a.shift();
  await chrome.storage.local.set({ efbotComorbStats: a });
}
async function comorbStatsText() {
  const { efbotComorbStats: a = [] } = await chrome.storage.local.get("efbotComorbStats");
  if (!a.length) return "";
  const avg = (k) => Math.round(a.reduce((s, x) => s + (x[k] || 0), 0) / a.length / 1000);
  return ` · μέσος χρόνος ανά ασθενή (${a.length}): φάκελος ${avg("a")}″, ΑΗΦΥ ${avg("b")}″ (άνοιγμα ${avg("open")}″, διαγνώσεις ${avg("dx")}″, εργαστηριακά ${avg("labs")}″)`;
}
// Τι λείπει για να τρέξει (κοινό για τον αυτόματο κύκλο και για το «🤖 Τράβηγμα» από το Παραδόχαρτο)
function comorbNotReady(efbot) {   // (οι διαδικασίες ενημερώνονται μόνες τους: bgMigrateWorkflows, και ξανά στο jobsTick)
  const wA = (efbot?.workflows || []).find((x) => x.id === "fakelos_amka"), wB = (efbot?.workflows || []).find((x) => x.id === "aihfy_dx");
  if (!wA || !wB) return "ανοίξτε μία φορά το πάνελ του ef-bot (ενημέρωση διαδικασιών)";
  if (untaughtSteps(wB)) return "χρειάζεται εκμάθηση (🎯) στην «ΑΗΦΥ: διαγνώσεις με ΑΜΚΑ»";
  if (!wB.steps.some((s) => !s.disabled && s.type === "check" && s.target)) return "η «ΑΗΦΥ: διαγνώσεις» θέλει ενεργό βήμα «Έλεγχος» ΑΜΚΑ";
  if (!String((efbot.values?.aihfy_dx || {})["λόγος_πρόσβασης"] || wB.defaults?.["λόγος_πρόσβασης"] || "").trim()) return "γράψτε τον «Λόγο πρόσβασης» στην «ΑΗΦΥ: διαγνώσεις» (Εκτέλεση)";
  return "";
}
// Είναι συνδεδεμένη η καρτέλα του ΑΗΦΥ; (στη διεύθυνση της εφαρμογής, χωρίς φόρμα κωδικού)
async function ehrLoggedIn(tabId) {
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: () => {
      const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      const pw = [...document.querySelectorAll("input[type=password]")].some(vis);
      return { ok: location.host === "doctor.ehealthrecord.gov.gr" && /^\/doctor\/app/.test(location.pathname) && !pw, ready: document.readyState === "complete" };
    } });
    return !!r?.result?.ok;
  } catch (e) { return false; }
}
// Κρατά ζωντανή τη σύνδεση στον ΑΗΦΥ όσο είναι ενεργές οι αυτόματες συννοσηρότητες (κάθε 5'): ένα αίτημα στον server
// και μια «κίνηση» στη σελίδα, ώστε να μη λήγει από αδράνεια. Δεν πατά τίποτα, δεν αλλάζει σελίδα.
async function ehrKeepAlive() {
  const tabs = await chrome.tabs.query({ url: "https://doctor.ehealthrecord.gov.gr/*" }).catch(() => []);
  let any = false;
  for (const t of tabs) {
    if (!(await ehrLoggedIn(t.id))) continue;
    any = true;
    await chrome.scripting.executeScript({ target: { tabId: t.id }, func: () => {
      try { fetch(location.origin + "/doctor/app/", { credentials: "include", cache: "no-store" }).catch(() => {}); } catch (e) {}
      for (const ty of ["mousemove", "keydown"]) { try { document.dispatchEvent(new (ty === "keydown" ? KeyboardEvent : MouseEvent)(ty, { bubbles: true })); } catch (e) {} }
    } }).catch(() => {});
  }
  if (any) await chrome.storage.session.remove("efbotEhrLoginAsk");
  return any;
}
// Σύνδεση έληξε / παράθυρο κλειστό: μία ειδοποίηση ανά επεισόδιο· με το κλικ ανοίγει η καρτέλα για σύνδεση
async function comorbEnvProblem(res) {
  const { efbotEhrLoginAsk: asked } = await chrome.storage.session.get("efbotEhrLoginAsk");
  if (asked) return;
  await chrome.storage.session.set({ efbotEhrLoginAsk: Date.now() });
  chrome.notifications.create("efbot-ehrlogin-" + Date.now(), { type: "basic", iconUrl: "icons/icon128.png", priority: 2, requireInteraction: true,
    title: "Αυτόματες συννοσηρότητες σε παύση", message: res.err + (res.login ? " — πατήστε εδώ, συνδεθείτε μία φορά και συνεχίζει μόνο του." : "") });
}
// 🪟 ΑΗΦΥ: ενημερωτικά αναδυόμενα (ανακοινώσεις κ.λπ.) σκεπάζουν το πεδίο ΑΜΚΑ. Κλείνει ΜΟΝΟ παράθυρα χωρίς πεδία/επιλογές,
// με το ✕ τους ή Esc — ποτέ κουμπί αποδοχής/υποβολής.
async function ehrDialogClear(tabId) {
  for (let k = 0; k < 3; k++) {
    const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: () => {
      const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      const dl = [...document.querySelectorAll(".p-dialog, [role=dialog]")].filter(vis);
      if (!dl.length) return { n: 0 };
      let closed = 0;
        // 6/11 (απόφαση χρήστη: «Είμαστε θεράποντες — να πατάει πάντα θεράπων»): «Όροι Χρήσης / Καταγραφή Πρόσβασης… επιβεβαιώστε ότι είστε ο θεράπων ιατρός»
        // → τικ ΜΟΝΟ στο κουτάκι του θεράποντα + κουμπί επιβεβαίωσης. Ποτέ σε παράθυρο με OTP/κωδικό/πεδίο κειμένου.
        const att = (d) => { const t = String(d.innerText || "").replace(/\s+/g, " ");
          if (!/(Καταγραφ[ήη]ς?\s+Πρόσβασης|θεράπων\s+ιατρ|Όροι\s+Χρήσης)/i.test(t) || /OTP|κωδικ[όο]ς\s+μιας|SMS/i.test(t)) return false;
          if (d.querySelector("input[type=text]:not([readonly]), input[type=password], textarea")) return false;
          const boxes = [...d.querySelectorAll("p-checkbox, .p-checkbox, input[type=checkbox], [role=checkbox]")];
          const lab = (b) => String((b.closest("label, .p-field-checkbox, .field-checkbox, div") || b).innerText || "");
          const want = boxes.filter((b) => /θεράπων|ενημερώθηκα|αποδέχομαι|επιβεβαιώνω/i.test(lab(b))); const use = want.length ? want : boxes.length === 1 ? boxes : [];
          for (const b of use) { const inp = b.matches("input") ? b : b.querySelector("input[type=checkbox]"); const on = inp ? inp.checked : /p-highlight|p-checkbox-checked/.test(b.className + " " + ((b.querySelector(".p-checkbox-box") || {}).className || "")) || b.getAttribute("aria-checked") === "true";
            if (!on) (b.querySelector(".p-checkbox-box") || b).click(); }
          const ok = [...d.querySelectorAll("button")].find((x) => /^(Επιβεβαίωση|Συνέχεια|Αποδοχή|Αποδέχομαι|OK|ΟΚ|Εντάξει|Υποβολή)$/i.test(String(x.innerText || "").trim()) && !x.disabled);
          if (ok) { setTimeout(() => ok.click(), 250); return true; } return false; };
      for (const d of dl) {
        if (att(d)) { closed++; continue; }
        if (d.querySelector("input:not([type=hidden]):not([type=checkbox]):not([type=radio]), textarea, select, p-dropdown, p-calendar")) continue;   // «μην το ξαναδείξεις» (checkbox) δεν κάνει το παράθυρο φόρμα   // φόρμα (π.χ. λόγος πρόσβασης): δεν αγγίζεται
        const x = d.querySelector(".p-dialog-header-close, [aria-label=Close], [aria-label=Κλείσιμο], .p-dialog-header-icon");
        if (x) { x.click(); closed++; } else { d.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })); document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })); closed++; }
      }
      return { n: dl.length, closed };
    } }).catch(() => [null]);
    const o = r && r.result; if (!o || !o.n || !o.closed) return o || null;
    await E.sleep(600);
  }
  return null;
}
// 🔌 ΑΗΦΥ απευθείας (JSON, ίδια σύνδεση/cookies της σελίδας — κανένας κωδικός/token δεν αγγίζεται): ehrId από τα αιτήματα
// που έκανε ήδη η σελίδα για τον ανοιχτό ασθενή → LisResultsHeaders (παραπεμπτικά) → LisResultsDetails (τιμές).
// Έλεγχος ασφαλείας: ο ΑΜΚΑ των παραπεμπτικών πρέπει να είναι του ασθενή που ζητήθηκε. Μόνο ανάγνωση.
async function ehrLabsApi(tabId, amka, skip) {
  const t0 = Date.now();
  const [r] = await chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", args: [String(amka || ""), Array.isArray(skip) ? skip : []], func: async (amka, skip) => {
    const ids = performance.getEntriesByType("resource").map((e) => { try { return new URL(e.name).searchParams.get("ehrId"); } catch (x) { return null; } }).filter(Boolean);
    const ehrId = ids[ids.length - 1]; if (!ehrId) return { err: "δεν βρέθηκε ανοιχτός ασθενής (ehrId)" };
    const B = "/doctor/api/lis/";
    const AH = (window.__efAh && window.__efAh.h) || {}; const HD = { accept: "application/json" }; for (const [k, v] of Object.entries(AH)) HD[k] = v;
    const get = async (path, q) => { const r = await fetch(B + path + "?" + new URLSearchParams(q), { credentials: "include", headers: HD }); if (!r.ok) throw new Error(path + " HTTP " + r.status); return r.json(); };
    const heads = [];
    for (let pg = 1; pg <= 20; pg++) { const o = await get("LisResultsHeaders", { ehrId, pageNo: pg, pageSize: 50 }); heads.push(...(o.items || [])); if (!o.items || !o.items.length || heads.length >= (o.totalItems || 0)) break; }
    if (heads.length && amka && heads.some((h) => /^\d{11}$/.test(String(h.amka || "")) && String(h.amka) !== amka)) return { err: "ο ΑΜΚΑ των παραπεμπτικών δεν ταιριάζει με τον ασθενή — σταμάτησε", mismatch: true };
    const sk = new Set(skip), todo = heads.filter((h) => h.compositionId && !sk.has("api:" + h.compositionId));
    const rows = [], sigs = []; let i = 0;
    const one = async () => { while (i < todo.length) { const h = todo[i++]; const o = await get("LisResultsDetails", { ehrId, compositionId: h.compositionId });
      for (const it of o.items || []) {
        const iso = String(it.resultDate || h.resultDate || "").slice(0, 10); if (!/^\d{4}-\d\d-\d\d$/.test(iso)) continue;
        const res = String(it.analyteResult == null ? "" : it.analyteResult).trim(); if (!res) continue;
        const m = /^([<>≤≥]=?)?\s*(-?\d+(?:[.,]\d+)?)\s*(.*)$/.exec(res);
        const flag = /ABOVE|HIGH/i.test(it.flag || "") ? "H" : /BELOW|LOW/i.test(it.flag || "") ? "L" : "";
        const name = String(it.indicatorDesc || it.examinationDesc || it.analyteName || "").trim(), ref = String(it.referenceRangeGuidance || "").slice(0, 40), lo = String(it.loincCode || "");
        if (m) rows.push([iso, name, lo, parseFloat(m[2].replace(",", ".")), String(it.units || m[3] || "").trim().slice(0, 24), ref, flag, m[1] ? res.slice(0, 40) : ""]);
        else rows.push([iso, name, lo, null, "", ref, flag, res.slice(0, 40)]);
      }
      sigs.push("api:" + h.compositionId); } };
    await Promise.all([one(), one(), one()]);
    return { ok: true, rows, sigs, orders: heads.length, read: todo.length };
  } }).catch((e) => [{ result: { err: e.message } }]);
  const out = (r && r.result) || { err: "δεν απάντησε" };
  out.ms = Date.now() - t0;
  return out;
}
// σύγκριση «σκιάς»: ίδιες τιμές (ημερομηνία+τιμή) σε παλιό και νέο τρόπο;
function labsCompare(ui, api) {
  const k = (r) => r[0] + "|" + (r[3] == null ? String(r[7] || "").toLowerCase() : r[3]);
  const A = new Set((api || []).map(k)), U = new Set((ui || []).map(k));
  let both = 0; for (const x of U) if (A.has(x)) both++;
  const names = {}; for (const r of ui || []) { const m = (api || []).find((a) => a[0] === r[0] && a[3] != null && a[3] === r[3]); if (m && Object.keys(names).length < 40 && !names[r[1]]) names[r[1]] = m[1]; }
  return { ui: U.size, api: A.size, both, onlyUi: U.size - both, onlyApi: A.size - both, names };
}
// ΑΗΦΥ → εργαστηριακά του ανοιχτού ασθενή: μενού «Εργαστηριακές Εξετάσεις» (και κρυφό) → όλα τα παραπεμπτικά → Παραδόχαρτο
async function ehrLabsPull(ehrTabId, p) {
  // 🔌 σκιά: πρώτα ο απευθείας τρόπος (μόνο ανάγνωση, δεν αποθηκεύει τίποτα) — συγκρίνεται με τον κανονικό στο τέλος
  let shadow = null;
  // σκιά ΑΠΕΝΕΡΓΟΠΟΙΗΜΕΝΗ (έλεγχος 5/11): έπαιρνε το ehrId από παλιές εγγραφές της σελίδας → μπορούσε να διαβάσει άλλον ασθενή
  if (false && p.amka) shadow = await ehrLabsApi(ehrTabId, p.amka, []).catch((e) => ({ err: e.message }));
  const allRows = [];
  const res0 = await ehrLabsPullUi(ehrTabId, p, allRows);
  if (shadow) { res0.api = shadow.err ? { err: String(shadow.err).slice(0, 120), ms: shadow.ms } : { ms: shadow.ms, orders: shadow.orders, rows: shadow.rows.length, cmp: labsCompare(allRows, shadow.rows) }; }
  return res0;
}
async function ehrLabsPullUi(ehrTabId, p, allRows) {
  const onLabs = async () => /\/doctor\/app\/examinations\/lisorders/.test((await chrome.tabs.get(ehrTabId).catch(() => ({}))).url || "");
  if (!(await onLabs())) {
    await chrome.scripting.executeScript({ target: { tabId: ehrTabId }, func: () => { const a = document.querySelector('a[href="/doctor/app/examinations/lisorders"]'); if (a) a.click(); return !!a; } }).catch(() => {});
    for (let i = 0; i < 20 && !(await onLabs()); i++) await E.sleep(500);
    if (!(await onLabs())) return { err: "δεν άνοιξαν οι «Εργαστηριακές Εξετάσεις»" };
    await bgSettle(ehrTabId, 1500);
  }
  // Σταδιακά: κάθε ~6″ ό,τι νέο διαβάστηκε πάει στο Παραδόχαρτο (συγχώνευση με τα παλιά). Τα παραπεμπτικά που διαβάστηκαν
  // σημειώνονται (ανά ασθενή, στον υπολογιστή), ώστε την επόμενη φορά να διαβάζονται μόνο τα νέα — και αν κοπεί, συνεχίζει.
  // κλειδί = η «νοσηλεία» του ασθενή στο Παραδόχαρτο (νέα εισαγωγή με ίδιο όνομα/κρεβάτι → νέο κλειδί → όλα από την αρχή)
  const lk = await pdxCall("pdxAhfyLabsKey", [p.k, p.name]).catch(() => null);
  let memKey = lk && typeof lk.r === "string" && lk.r ? lk.r : "";
  const { efbotEhrOrders: mem0 = {} } = await chrome.storage.local.get("efbotEhrOrders");
  const known = memKey && mem0[memKey] && Date.now() - (mem0[memKey].t || 0) < 20 * 864e5 ? mem0[memKey].s || [] : [];
  const keepSigs = async (sigs) => {
    if (!sigs.length || !memKey) return;
    const { efbotEhrOrders: mem = {} } = await chrome.storage.local.get("efbotEhrOrders");
    const cur = new Set((mem[memKey] && mem[memKey].s) || []); sigs.forEach((x) => cur.add(x));
    mem[memKey] = { s: [...cur].slice(-600), t: Date.now() };
    for (const [k, v] of Object.entries(mem)) if (Date.now() - (v.t || 0) > 20 * 864e5) delete mem[k];   // παλιοί ασθενείς
    await chrome.storage.local.set({ efbotEhrOrders: mem });
  };
  let sent = 0, sentSig = 0, saved = 0, savedTests = 0, savedPts = 0, saveErr = "";
  const flush = async () => {
    const pr = await chrome.tabs.sendMessage(ehrTabId, { cmd: "ehrLabsProg", from: sent, sfrom: sentSig }, { frameId: 0 }).catch(() => null);
    if (!pr || pr.none) return null;
    if (pr.rows?.length) {
      if (allRows) allRows.push(...pr.rows);
      const sv = await pdxCall("pdxAhfyLabsSave", [p.k, p.name, pr.rows, { merge: true }]);
      if (!sv || sv.err || sv.r?.err) { saveErr = sv?.err || sv?.r?.err || "δεν απάντησε"; return pr; }
      saved++; savedTests = sv.r.tests || savedTests; savedPts = sv.r.points || savedPts;
      if (!memKey) { const k2 = await pdxCall("pdxAhfyLabsKey", [p.k, p.name]).catch(() => null); if (k2 && typeof k2.r === "string") memKey = k2.r; }
    }
    sent = pr.n || sent;
    if (pr.sigs?.length) { await keepSigs(pr.sigs); sentSig = pr.ns || sentSig; }
    return pr;
  };
  const run = chrome.tabs.sendMessage(ehrTabId, { cmd: "ehrLabs", max: 300, skip: known }, { frameId: 0 }).catch((e) => ({ err: e.message }));
  let r = null;
  for (;;) {
    r = await Promise.race([run, E.sleep(6000).then(() => null)]);
    if (r) break;
    await flush().catch(() => {});
  }
  await flush().catch(() => {});   // ό,τι έμεινε
  if (!r || r.err) return saved ? { ok: true, tests: savedTests, points: savedPts, orders: sentSig, partial: true } : { err: "εργαστηριακά: " + (r?.err || "η σελίδα δεν απάντησε") };
  // Κενό αποτέλεσμα: ΜΟΝΟ αν ο ΑΗΦΥ λέει ρητά «δεν υπάρχουν». Σελίδα που δεν φόρτωσε δεν σβήνει παλιά δεδομένα.
  if (!(r.rows || []).length && !saved) {
    if (r.state === "rows" && (r.skipped || known.length)) return { ok: true, tests: 0, points: 0, orders: 0, upToDate: true };   // όλα είχαν ήδη διαβαστεί
    if (r.state !== "empty")
      return { err: r.state === "notable" ? "δεν εμφανίστηκε ο πίνακας των εργαστηριακών" : r.orders ? "τα παραπεμπτικά άνοιξαν αλλά δεν διαβάστηκαν τιμές" : "τα παραπεμπτικά δεν φόρτωσαν εγκαίρως — ξαναδοκιμάστε" };
    const sv = await pdxCall("pdxAhfyLabsSave", [p.k, p.name, [], { merge: true }]);
    if (!sv || sv.err || sv.r?.err) return { err: "Παραδόχαρτο: " + (sv?.err || sv?.r?.err || "δεν απάντησε") };
    return { ok: true, tests: sv.r.tests || 0, points: 0, orders: 0 };
  }
  if (saveErr && !saved) return { err: "Παραδόχαρτο: " + saveErr };
  return { ok: true, tests: savedTests, points: savedPts, orders: r.orders || 0, skipped: r.skipped || 0 };
}
// 1) ΑΜΚΑ. Αν υπάρχει ήδη στο Παραδόχαρτο (γραμμένος με το χέρι), ο φάκελος του νοσοκομείου δεν ανοίγεται καθόλου:
//    ο έλεγχος ονόματος στον ΑΗΦΥ (ehrNameCheck) εξασφαλίζει ότι είναι ο σωστός ασθενής. Αλλιώς από τον φάκελο,
//    όπου το «Άνοιγμα ασθενή» ελέγχει ότι άνοιξε ο σωστός με το όνομα.
async function comorbAmka(p, tab, { lock = true } = {}) {
  const t0 = Date.now();
  const manual = /^\d{11}$/.test(String(p.amka || "")) ? String(p.amka) : "";
  if (manual) return { amka: manual, fromManual: true, ms: 0 };
  const { efbot } = await chrome.storage.local.get("efbot");
  const wA = (efbot?.workflows || []).find((x) => x.id === "fakelos_amka");
  const taught = !!(wA && !untaughtSteps(wA));
  const lg = await bgEnsureLogin(tab.id);
  if (!lg.ok) return { err: lg.err, retry: true, stopAll: true };
  let emrErr = "";
  // 🔎 χωρίς εκμάθηση: άνοιγμα ασθενή με έλεγχο ονόματος (όπως στο εξιτήριο) → ΑΜΚΑ δίπλα στην ετικέτα «ΑΜΚΑ» της σελίδας.
  // Δεκτός ΜΟΝΟ αν υπάρχει ΕΝΑΣ 11ψήφιος με σωστό ψηφίο ελέγχου· ξαναελέγχεται με το όνομα στον ΑΗΦΥ.
  if (!taught) {
    try { const { efbot: stA } = await chrome.storage.local.get("efbot"); await bgOpenPatient(tab, p.name, stA); bgMark("άνοιγμα ασθενή (ΑΜΚΑ)"); }
    catch (e) { return { err: "φάκελος: " + (e.lastStep ? "«" + e.lastStep + "»: " : "") + e.message + " — γράψτε τον ΑΜΚΑ στο 🩺 του ασθενή", retry: !e.mismatch }; }
    const rd = await emrAmkaRead(tab.id);
    if (rd.amka) return { amka: rd.amka, fromManual: false, ms: Date.now() - t0, how: "label" };
    return { err: "δεν διαβάστηκε ΑΜΚΑ στον φάκελο (" + rd.why + ") — γράψτε τον ΑΜΚΑ στο 🩺 του ασθενή στο Παραδόχαρτο", retry: true };
  }
  try {
    // ⚡ όπως στο εξιτήριο: πρώτα το πλήρες άνοιγμα ασθενή (λίστα, κλινική, απευθείας άνοιγμα) — πριν, από τον 2ο ασθενή και μετά
    // η λίστα ήταν κρυμμένη και η αναζήτηση περίμενε 30–60″ («φάκελος: καρτέλα»)
    let preA = false; try { const { efbot: stA } = await chrome.storage.local.get("efbot"); await bgOpenPatient(tab, p.name, stA); preA = true; bgMark("άνοιγμα ασθενή (ΑΜΚΑ)"); } catch (e) {}
    const ctxA = await bgRunWorkflow("fakelos_amka", { [E.BULKVAR]: p.name }, tab.id, { lock, opener: !preA });
    const am = String(ctxA.vars?.["αμκα"] || "").match(/(?<!\d)\d{11}(?!\d)/g) || [];
    if (am.length === 1) return { amka: am[0], fromManual: false, ms: Date.now() - t0 };
    emrErr = am.length ? "βρέθηκαν πολλοί 11ψήφιοι αριθμοί στο σημείο του ΑΜΚΑ (ξαναμάθετε το 🎯)" : "δεν υπάρχει ΑΜΚΑ στον φάκελο";
  } catch (e) { emrErr = "φάκελος: " + (e.lastStep ? "«" + e.lastStep + "»: " : "") + e.message; if (e.mismatch) return { err: emrErr }; }
  return { err: emrErr + " — γράψτε τον ΑΜΚΑ στο 🩺 του ασθενή στο Παραδόχαρτο", retry: !/ξαναμάθετε/.test(emrErr) };
}
// ΝΠΣ: ΑΜΚΑ του ΑΝΟΙΧΤΟΥ ασθενή από την ετικέτα «ΑΜΚΑ»/«Α.Μ.Κ.Α.» (σε όλα τα frames). Επιστρέφει {amka} ή {why: δομή χωρίς ψηφία}.
async function emrAmkaRead(tabId) {
  const res = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: () => {
    const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    const LBL = /Α\.?\s?Μ\.?\s?Κ\.?\s?Α\.?|AMKA/i, NUM = /(?<!\d)\d{11}(?!\d)/g;
    const found = new Set(), shapes = [];
    const w = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT);
    for (let n; (n = w.nextNode()); ) {
      const t = n.nodeValue || ""; if (!LBL.test(t)) continue;
      const el = n.parentElement; if (!el || !vis(el)) continue;
      // ίδιο κείμενο μετά την ετικέτα → επόμενο στοιχείο/κελί → γονέας (έως 2 επίπεδα, μικρό κείμενο)
      const after = t.slice(t.search(LBL)); const c1 = after.match(NUM) || [];
      let c2 = []; const nx = el.nextElementSibling || (el.closest("td,th") && el.closest("td,th").nextElementSibling); if (nx) c2 = (String(nx.innerText || nx.value || "")).match(NUM) || [];
      const inp = nx && (nx.matches("input") ? nx : nx.querySelector && nx.querySelector("input")); if (inp && inp.value) c2 = c2.concat(String(inp.value).match(NUM) || []);
      let c3 = []; let pe = el.parentElement; for (let k = 0; k < 2 && pe; k++, pe = pe.parentElement) { const tx = String(pe.innerText || ""); if (tx.length < 200) { c3 = tx.match(NUM) || []; if (c3.length) break; } }
      const c = c1.length ? c1 : c2.length ? c2 : c3; c.forEach((x) => found.add(x));
      shapes.push((el.tagName + (el.id ? "#" + el.id.replace(/\d{3,}/g, "#") : "") + (nx ? ">" + nx.tagName : "") + ":" + c1.length + "/" + c2.length + "/" + c3.length).slice(0, 60));
    }
    return { found: [...found], shapes: shapes.slice(0, 6) };
  } }).catch((e) => [{ result: { err: e.message } }]);
  const all = new Set(), shapes = []; let err = "";
  for (const f of res || []) { const r = f && f.result; if (!r) continue; if (r.err) err = r.err; (r.found || []).forEach((x) => all.add(x)); shapes.push(...(r.shapes || [])); }
  const luhn = (v) => { let sum = 0; for (let i = 0; i < 11; i++) { let n = +v[10 - i]; if (i % 2 === 1) { n *= 2; if (n > 9) n -= 9; } sum += n; } return sum % 10 === 0; };
  const ok = [...all].filter(luhn);
  if (ok.length === 1) return { amka: ok[0] };
  return { why: (ok.length > 1 ? ok.length + " διαφορετικοί ΑΜΚΑ" : all.size ? "αριθμός χωρίς σωστό ψηφίο ελέγχου" : shapes.length ? "ετικέτα χωρίς αριθμό" : "δεν βρέθηκε ετικέτα ΑΜΚΑ") + (shapes.length ? " · " + shapes.join(" | ") : "") + (err ? " · " + err.slice(0, 60) : "") };
}
// 2–5) ΑΗΦΥ: άνοιγμα με τον ΑΜΚΑ (λόγος, έλεγχος ΑΜΚΑ), διαγνώσεις → Παραδόχαρτο, εργαστηριακά → Παραδόχαρτο
// ⚡ ΑΗΦΥ ΑΠΕΥΘΕΙΑΣ (κανονικός δρόμος από 0.20.22· αν αποτύχει → η οθόνη όπως πριν). Ίδια σύνδεση/κεφαλίδες με την εφαρμογή.
// ΑΜΚΑ → ασθενής (έλεγχος ΑΜΚΑ + ονόματος) → πρόσβαση: αν δεν υπάρχει, αίτημα με λόγο «Θεράπων ιατρός» (AttendingDoctor — οδηγία
// του χρήστη: σε όλους· ΠΟΤΕ OTP στον ασθενή) → «Όλες οι διαγνώσεις» + χρόνιες → εργαστηριακά (παραπεμπτικά + τιμές).
let ehrDirectLast = null;
async function ehrDirectOn() { try { const { efbotEhrDirect: v } = await chrome.storage.local.get("efbotEhrDirect"); return v !== false; } catch (e) { return true; } }
async function ehrDirect(tabId, amka, name, o = {}) {
  const t0 = Date.now();
  const [r] = await chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", args: [String(amka || ""), String(name || ""), !!o.dx, !!o.labs, !!o.fromManual, !!o.img], func: async (amka, name, wantDx, wantLabs, fromManual, wantImg) => { try {
    const AH = (window.__efAh && window.__efAh.h) || {}; const H = { accept: "application/json" }; for (const [k, v] of Object.entries(AH)) H[k] = v;
    const T = {}; const t0 = performance.now(); const lap = (k) => { T[k] = Math.round(performance.now() - t0); };
    const get = async (path, q) => { const r = await fetch(path + "?" + new URLSearchParams(q), { credentials: "include", headers: H }); let j = null; try { j = await r.json(); } catch (e) {} return { st: r.status, j }; };
    const pt = await get("/doctor/api/patient/GetPatientByAmka", { amka }); lap("patient");
    if (pt.st !== 200 || !pt.j || pt.j.patientId == null) return { err: "αναζήτηση ασθενή HTTP " + pt.st };
    if (String(pt.j.amka || "") !== amka) return { err: "ο ΑΜΚΑ της απάντησης δεν ταιριάζει — σταμάτησε", mismatch: true };
    if (pt.j.deathDate) return { err: "ο ασθενής εμφανίζεται ως θανών στον ΑΗΦΥ — δεν γίνεται πρόσβαση", mismatch: true };
    // έλεγχος ονόματος (ένα κοινό κομμάτι ≥3 γραμμάτων ανάμεσα στο όνομα του Παραδόχαρτου και του ΑΗΦΥ)
    const nz = (x) => String(x || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().split(/[^\p{L}]+/u).filter((t) => t.length >= 3);
    // ΜΟΝΟ πεδία ονόματος του ίδιου του ασθενή (ΟΧΙ πατρώνυμο/μητρώνυμο) · ταίριασμα ≥2 λέξεων όταν υπάρχουν (έλεγχος 5/11)
    const their = nz(Object.entries(pt.j).filter(([k, v]) => typeof v === "string" && /^(name|fullName|surname|lastName|firstName|givenName|familyName)$/i.test(k)).map(([, v]) => v).join(" "));
    const mine = nz(name);
    const hit = (t) => their.some((x) => x === t || (t.length >= 4 && x.length >= 4 && (x.startsWith(t.slice(0, 4)) && t.startsWith(x.slice(0, 4)))));
    const need = Math.min(2, mine.length, their.length);
    const nameOk = !their.length || !mine.length ? null : mine.filter(hit).length >= need;
    // ⛔ ΠΡΙΝ από οποιοδήποτε αίτημα πρόσβασης: λάθος όνομα → τέλος (καμία καταγραφή πρόσβασης σε ξένο φάκελο)
    if (nameOk === false) return { err: "ο ΑΜΚΑ ανήκει σε άλλο όνομα στον ΑΗΦΥ — δεν ζητήθηκε πρόσβαση", mismatch: true, nameOk };
    if (nameOk == null && fromManual) return { err: "δεν διαβάστηκε όνομα για έλεγχο του ΑΜΚΑ — δεν ζητήθηκε πρόσβαση", mismatch: true, nameOk };
    const pid = pt.j.patientId;
    let cs = await get("/doctor/api/consent/Status", { patientId: pid }); lap("consent");
    let ehrId = cs.st === 200 && cs.j && cs.j.hasConsent ? cs.j.ehrId : null, asked = false;
    if (!ehrId) {
      // αίτημα ΜΟΝΟ όταν ο ΑΗΦΥ λέει ρητά «χωρίς πρόσβαση» (όχι σε σφάλμα/άγνωστη απάντηση) · αποτυχία → ΤΕΛΟΣ, χωρίς την οθόνη (δεν πάμε σε OTP)
      if (!(cs.st === 200 && cs.j && cs.j.hasConsent === false)) return { err: "έλεγχος πρόσβασης ΑΗΦΥ: HTTP " + cs.st, noFallback: true };
      const rq = await get("/doctor/api/consent/RequestConsent", { patientId: pid, reason: "AttendingDoctor" }); lap("request"); asked = true;
      if (rq.j && rq.j.hasConsent && rq.j.ehrId) ehrId = rq.j.ehrId;
      else return { err: "πρόσβαση «Θεράπων ιατρός»: HTTP " + rq.st + (rq.j && rq.j.canHaveOtpConsent ? " (ζητά OTP του ασθενή — δεν στάλθηκε)" : ""), noFallback: true, asked };
    }
    const out = { ok: true, nameOk, asked, T };
    // 📄 6/11: απεικονίσεις (RIS/PACS) + αρχεία — ΧΑΡΤΟΓΡΑΦΗΣΗ: μόνο ονόματα πεδίων, πλήθος, μήκος κειμένων· όχι περιεχόμενο
    if (wantImg) {
      const shape = (j) => { const items = Array.isArray(j) ? j : (j && (j.items || j.data || j.results || j.list)) || []; const it0 = items[0] || null;
        const kinds = it0 ? Object.fromEntries(Object.entries(it0).map(([k, v]) => [k, v == null ? "null" : typeof v === "string" ? (/^\d{4}-\d\d-\d\d/.test(v) ? "date" : "s" + Math.min(9999, v.length)) : Array.isArray(v) ? "arr" + v.length : typeof v === "object" ? "obj:" + Object.keys(v).slice(0, 12).join(",") : typeof v])) : null;
        return { n: items.length, total: j && (j.totalItems ?? j.total ?? null), top: j && !Array.isArray(j) ? Object.keys(j).slice(0, 15) : ["(array)"], kinds }; };
      const tries = [["ris", "/doctor/api/imagingExams/GetImagingRisPacsByFilterPaged", { ehrId, pageNo: 1, pageSize: 20 }],
        ["files", "/doctor/api/ahfyview/GetFilesWithTags", { ehrId }],
        ["digit", "/doctor/api/digitizedmedicalrecords/GetDigitizedMedicalRecords", { ehrId }],
        ["enc", "/doctor/api/encounter/GetEncounterDetailsPaged", { ehrId, pageNo: 1, pageSize: 10 }]];
      out.img = {};
      for (const [k, path, q] of tries) { try { const r = await get(path, q); out.img[k] = { st: r.st, ...(r.j ? shape(r.j) : {}) }; } catch (e) { out.img[k] = { err: String(e.message || e).slice(0, 80) }; } }
      lap("img"); return out;
    }
    if (wantDx) {
      const lines = new Map(); let total = null;
      // ΡΗΤΑ πεδία (11/2026): «Όλες» → diagnosis_code / problem_diagnosis_name · χρόνιες → icd10Code / icd10Desc. ΠΟΤΕ First_Name/Last_Name.
      const pick = (it, ks) => { for (const k of ks) { const v = it && it[k]; if (typeof v === "string" && v.trim()) return v.trim(); } return ""; };
      const codeOf = (it) => { const c = pick(it, ["diagnosis_code", "icd10Code", "diagCode", "groupParentIcd10Code"]).toUpperCase(); return /^[A-Z]\d{2}(\.\d{1,2})?$/.test(c) ? c : ""; };
      const descOf = (it) => pick(it, ["problem_diagnosis_name", "icd10Desc"]).replace(/\s+/g, " ").slice(0, 160);   // ΟΧΙ ελεύθερο κείμενο γιατρού (μπορεί να έχει ονόματα)
      const add = (items) => { for (const it of items || []) { const c = codeOf(it); if (!c) continue; const l = (c + " " + descOf(it)).trim(); if (!lines.has(c) || lines.get(c) === c) lines.set(c, l); } };
      for (let pg = 1; pg <= 20; pg++) { const d = await get("/doctor/api/diagnosis/GetDiagnosisByFilterPaged", { ehrId, pageNo: pg, pageSize: 100 });
        if (d.st !== 200 || !d.j) return { err: "διαγνώσεις HTTP " + d.st }; total = d.j.totalItems ?? total; add(d.j.items); if (!(d.j.items || []).length || (d.j.items || []).length < 100) break; }
      const ch = await get("/doctor/api/diagnosis/GetDiagnosisChronicPaged", { ehrId }); if (ch.st === 200 && ch.j) add(ch.j.items);
      lap("dx"); out.lines = [...lines.values()]; out.dxTotal = total;
      out.dxKeys = []; // ονόματα πεδίων μόνο αν δεν βρέθηκε κανένας κωδικός (για διάγνωση)
      if (!out.lines.length && total) { const d = await get("/doctor/api/diagnosis/GetDiagnosisByFilterPaged", { ehrId, pageNo: 1, pageSize: 1 }); out.dxKeys = d.j && d.j.items && d.j.items[0] ? Object.keys(d.j.items[0]).slice(0, 30) : []; }
    }
    if (wantLabs) {
      const heads = [];
      for (let pg = 1; pg <= 20; pg++) { const o = await get("/doctor/api/lis/LisResultsHeaders", { ehrId, pageNo: pg, pageSize: 50 }); if (o.st !== 200 || !o.j) return { err: "εργαστηριακά HTTP " + o.st }; heads.push(...(o.j.items || [])); if (!o.j.items || !o.j.items.length || heads.length >= (o.j.totalItems || 0)) break; }
      // Έλεγχος ότι τα παραπεμπτικά είναι του ίδιου φακέλου: το πεδίο «amka» εδώ είναι εσωτερικός κωδικός (GUID, 11/2026), όχι ΑΜΚΑ.
      // → κάθε παραπεμπτικό: ίδιο ehrId με αυτό της πρόσβασης· αν το «amka» μοιάζει με ΑΜΚΑ (11 ψηφία/κρυμμένα) → ίδια ορατά ψηφία· αλλιώς όλα ίδια μεταξύ τους.
      const isAm = (v) => /^[\d*•xX]{11}$/.test(v) || /^\d{9,11}$/.test(v);
      const same = (x) => { if (x == null || x === "") return true; const v = String(x).trim(); if (!isAm(v)) return true; if (/^\d+$/.test(v)) return v.padStart(11, "0") === amka;
        return [...v].every((ch, k) => !/\d/.test(ch) || ch === amka[k]); };
      const ids = new Set(heads.map((h) => String(h.amka == null ? "" : h.amka)).filter((v) => v && !isAm(v)));
      const badH = heads.find((h) => !same(h.amka) || (h.ehrId && String(h.ehrId) !== String(ehrId)));
      if (badH || ids.size > 1) { const v = String(badH ? badH.amka : [...ids][1]); return { err: "τα παραπεμπτικά δεν είναι όλα του ίδιου φακέλου — σταμάτησε (μορφή «" + v.replace(/\d/g, "d").replace(/[a-f]/gi, "a").slice(0, 14) + "»" + (badH && badH.ehrId && String(badH.ehrId) !== String(ehrId) ? ", άλλο ehrId" : "") + (ids.size > 1 ? ", " + ids.size + " διαφορετικοί κωδικοί" : "") + ")", mismatch: true }; }
      const rows = []; let i = 0, bad = 0;
      const todo = heads.filter((h) => h.compositionId);
      const one = async () => { while (i < todo.length) { const h = todo[i++]; const o = await get("/doctor/api/lis/LisResultsDetails", { ehrId, compositionId: h.compositionId }); if (o.st !== 200 || !o.j) { bad++; continue; }
        for (const it of o.j.items || []) {
          const iso = String(it.resultDate || h.resultDate || "").slice(0, 10); if (!/^\d{4}-\d\d-\d\d$/.test(iso)) continue;
          const res = String(it.analyteResult == null ? "" : it.analyteResult).trim(); if (!res) continue;
          const m = /^([<>≤≥]=?)?\s*(-?\d+(?:[.,]\d+)?)\s*(.*)$/.exec(res);
          const flag = /ABOVE|HIGH/i.test(it.flag || "") ? "H" : /BELOW|LOW/i.test(it.flag || "") ? "L" : "";
          const nm = String(it.indicatorDesc || it.examinationDesc || it.analyteName || "").trim(), ref = String(it.referenceRangeGuidance || "").slice(0, 40), lo = String(it.loincCode || "");
          if (m) rows.push([iso, nm, lo, parseFloat(m[2].replace(",", ".")), String(it.units || m[3] || "").trim().slice(0, 24), ref, flag, m[1] ? res.slice(0, 40) : ""]);
          else rows.push([iso, nm, lo, null, "", ref, flag, res.slice(0, 40)]);
        } } };
      await Promise.all([one(), one(), one(), one()]);
      lap("labs"); out.rows = rows; out.orders = heads.length; out.badOrders = bad;
    }
    return out;
  } catch (e) { return { err: "σφάλμα κώδικα: " + e.message }; } } }).catch((e) => [{ result: { err: e.message } }]);
  const out = (r && r.result) || { err: "δεν απάντησε" };
  out.ms = Date.now() - t0;
  return out;
}
async function comorbEhr(p, a, tab, opts = {}) {
  const wantDx = opts.dx !== false, wantLabs = opts.labs !== false, lock = opts.lock !== false;
  let amka = a.amka;
  const fromManual = !!a.fromManual, ms = {};
  // ΑΜΚΑ από τον φάκελο (ο ασθενής ανοίχτηκε με έλεγχο ονόματος): κρατιέται στην εγγραφή του ασθενή, ώστε κάθε επόμενη
  // «Ενημέρωση» να πηγαίνει κατευθείαν στον ΑΗΦΥ. Σβήνεται μαζί με την εγγραφή στο εξιτήριο.
  if (!fromManual && amka) pdxCall("pdxComorbAmkaSave", [p.k, p.name, amka]).catch(() => {});
  let t = Date.now();
  const lap = (k) => { ms[k] = Date.now() - t; t = Date.now(); };
  try {
    const ehr = await bgEhrTab(tab);
    if (!ehr) return { err: bgEhrErr || "δεν άνοιξε ο Ατομικός Φάκελος Υγείας", retry: true, stopAll: true };
    if (!(await ehrLoggedIn(ehr.id))) { const lg = await ahfyAutoLogin(ehr.id); if (!lg.ok) return { err: "ο ΑΗΦΥ ζητά σύνδεση στο παράθυρο του bot · " + String(lg.err || "").slice(0, 160), retry: true, stopAll: true, login: true }; }
    await ehrDialogClear(ehr.id);
    // ⚡ απευθείας (≈1″ αντί για λεπτά)· σε σφάλμα (εκτός από λάθος ασθενή) → ο δρόμος της οθόνης όπως πριν
    let directErr = "";
    if (opts.docs) { const d = await ehrDirect(ehr.id, amka, p.name, { img: true }).catch((e) => ({ err: e.message })); lap("direct");
      if (d.mismatch || d.noFallback || !d.ok) return { err: "ΑΗΦΥ: " + (d.err || "δεν απάντησε"), retry: false };
      return { ok: true, docs: { api: d.img }, ms }; }
    if (!opts.docs && (await ehrDirectOn())) {
      const d = await ehrDirect(ehr.id, amka, p.name, { dx: wantDx, labs: wantLabs || !wantDx, fromManual }).catch((e) => ({ err: e.message }));
      lap("direct");
      if (d.mismatch) return { err: "ΑΗΦΥ: " + d.err, retry: false };
      if (d.noFallback) return { err: "ΑΗΦΥ: " + d.err, retry: true };   // πρόσβαση: όχι στην οθόνη (εκεί υπάρχει OTP)
      if (d.ok && d.nameOk === false) return { err: "ο ΑΜΚΑ ανήκει σε άλλο όνομα στον ΑΗΦΥ — ελέγξτε τον ΑΜΚΑ (δεν έγινε τίποτα)", retry: false };
      if (d.ok && fromManual && d.nameOk == null) directErr = "δεν διαβάστηκε όνομα για έλεγχο";
      else if (d.ok && (wantLabs || !wantDx) && d.orders && !(d.rows || []).length) directErr = "εργαστηριακά: " + d.orders + " παραπεμπτικά χωρίς τιμές";
      else if (d.ok && wantDx && !d.lines.length && d.dxTotal) directErr = "διαγνώσεις χωρίς κωδικούς (πεδία: " + (d.dxKeys || []).join(",") + ")";
      else if (d.ok) {
        let c = 0, u = 0;
        if (wantDx) { const ap = await pdxCall("pdxComorbAutoApply", [p.k, p.name, d.lines.slice(0, 200)]);
          if (!ap || ap.err || ap.r?.err) return { err: "Παραδόχαρτο: " + (ap?.err || ap?.r?.err || "δεν απάντησε"), retry: true };
          c = ap.r?.c || 0; u = ap.r?.u || 0; }
        let labs = null;
        if (wantLabs || !wantDx) {
          if (d.badOrders && !d.rows.length) labs = { err: "εργαστηριακά: " + d.badOrders + " παραπεμπτικά δεν διαβάστηκαν" };
          else {
            let tests = 0, sv = null;
            const rows = d.rows || [];
            for (let i = 0; i < Math.max(1, rows.length); i += 400) { sv = await pdxCall("pdxAhfyLabsSave", [p.k, p.name, rows.slice(i, i + 400), { merge: true }]); if (!sv || sv.err || sv.r?.err) break; tests = sv.r.tests || tests; }
            labs = !sv || sv.err || sv.r?.err ? { err: "Παραδόχαρτο: " + (sv?.err || sv?.r?.err || "δεν απάντησε") } : { ok: true, tests, points: rows.length, orders: d.orders, direct: true };
          }
        }
        if (!wantDx) return labs && labs.err ? { err: labs.err, retry: true } : { ok: true, c: 0, u: 0, labs, ms, direct: true };
        return { ok: true, c, u, labs, ms, direct: true, asked: d.asked };
      } else directErr = d.err || "άγνωστο";
    }
    if (directErr) ehrDirectLast = { at: Date.now(), err: String(directErr).slice(0, 160) };
    try { await bgRunWorkflow("aihfy_dx", { "αμκα": amka }, ehr.id, { opener: false, lock }); }
    catch (e) {
      const login = /login|auth|signin|oauth/i.test((await chrome.tabs.get(ehr.id).catch(() => ({}))).url || "");
      if (login || !(await ehrLoggedIn(ehr.id))) { const lg = await ahfyAutoLogin(ehr.id); if (!lg.ok) return { err: "ο ΑΗΦΥ ζητά σύνδεση στο παράθυρο του bot · " + String(lg.err || "").slice(0, 160), retry: true, stopAll: true, login: true }; }
      return { err: "ΑΗΦΥ: " + (e.lastStep ? "«" + e.lastStep + "»: " : "") + String(e.message).replace(/\d{11}/g, "•••") + (directErr ? " · απευθείας: " + String(directErr).replace(/\d{11}/g, "•••").slice(0, 120) : ""), retry: !e.mismatch };
    }
    lap("open");
    if (fromManual) { const chk = await ehrNameCheck(ehr.id, amka, p.name); if (chk) return chk; }
    // μόνο εργαστηριακά (κουμπί «🤖 Ενημέρωση» στα 📈): χωρίς διαγνώσεις
    if (opts.docs) { const dm = await ehrDocsProbe(ehr.id, p.name); lap("docs"); return dm.err ? { err: dm.err, retry: true } : { ok: true, docs: dm, ms }; }
    if (!wantDx) {
      const lb = await ehrLabsPull(ehr.id, { ...p, amka }); lap("labs");
      return lb.err ? { err: lb.err, retry: true } : { ok: true, c: 0, u: 0, labs: lb, ms };
    }
    // 2α) πρέπει να είμαστε στη σελίδα «Διαγνώσεις». Αν όχι (π.χ. το κλικ δεν έπιασε), ένα ακόμη κλικ στον σύνδεσμο.
    const onDx = async () => /\/doctor\/app\/clinical\/diagnosis/.test((await chrome.tabs.get(ehr.id).catch(() => ({}))).url || "");
    if (!(await onDx())) {
      await chrome.scripting.executeScript({ target: { tabId: ehr.id }, func: () => { const x = document.querySelector('a[href="/doctor/app/clinical/diagnosis"]'); if (x) x.click(); return !!x; } }).catch(() => {});
      for (let i = 0; i < 10 && !(await onDx()); i++) await E.sleep(500);
      if (!(await onDx())) return { err: "ΑΗΦΥ: δεν άνοιξε η σελίδα «Διαγνώσεις» μετά το άνοιγμα του ασθενή", retry: true };
      await E.sleep(1000);
    }
    // 3) κωδικοί της σελίδας: περιμένουμε έως ~12" να εμφανιστούν (η σελίδα φορτώνει με καθυστέρηση)
    let lines = [], seenText = 0;
    for (let i = 0; i < 12; i++) {
      const r = await chrome.tabs.sendMessage(ehr.id, { cmd: "ehrDx" }, { frameId: 0 }).catch(() => null);
      if (r?.lines?.length) { lines = r.lines; break; }
      seenText = r?.text || 0;
      await E.sleep(1000);
    }
    if (!lines.length) return { err: seenText ? "η σελίδα διαγνώσεων δεν έδειξε κωδικούς ICD-10 (κανένα ιστορικό ή άλλη μορφή σελίδας)" : "η σελίδα διαγνώσεων δεν φόρτωσε", retry: true };
    // 4) Παραδόχαρτο: ταξινόμηση εκεί· ελέγχει ξανά ότι ο ασθενής με αυτό το όνομα είναι ακόμα στο ίδιο κρεβάτι
    const ap = await pdxCall("pdxComorbAutoApply", [p.k, p.name, lines.slice(0, 200)]);
    if (!ap || ap.err || ap.r?.err) return { err: "Παραδόχαρτο: " + (ap?.err || ap?.r?.err || "δεν απάντησε"), retry: true };
    lap("dx");
    // 5) στην ίδια πρόσβαση: και τα εργαστηριακά (για τα γραφήματα 📈). Αποτυχία εδώ δεν ακυρώνει τις διαγνώσεις.
    let labs = null;
    if (wantLabs) { labs = await ehrLabsPull(ehr.id, { ...p, amka }).catch((e) => ({ err: e.message })); lap("labs"); }
    return { ok: true, c: ap.r?.c || 0, u: ap.r?.u || 0, labs, ms };
  } finally { amka = ""; a.amka = ""; }
}
// 🩻 ΑΗΦΥ: χαρτογράφηση «Απεικονιστικές εξετάσεις» / «Γνωματεύσεις» (μόνο δομή: μενού, επικεφαλίδες στηλών,
// πλήθος γραμμών, κουμπιά — ΚΑΜΙΑ τιμή κελιού, κανένα όνομα/αριθμός ≥5 ψηφίων). Δεν πατά τίποτα εκτός από συνδέσμους μενού.
async function ehrDocsProbe(tabId, name) {
  const avoid = String(name || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().split(/\s+/).filter((w) => w.length >= 3);
  const snap = async () => (await chrome.scripting.executeScript({ target: { tabId }, args: [avoid], func: (avoid) => {
    const nz = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase();
    const bad = (t) => !t || /\d{5,}/.test(t) || avoid.some((w) => nz(t).includes(w));
    const clip = (t) => { t = String(t || "").replace(/\s+/g, " ").trim().slice(0, 60); return bad(t) ? "" : t; };
    const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    const links = [...document.querySelectorAll('a[href^="/doctor/app/"]')].map((a) => ({ h: a.getAttribute("href").replace(/\d{5,}/g, "#"), x: clip(a.innerText || a.title) })).filter((x) => x.x || x.h);
    const heads = [...document.querySelectorAll("h1,h2,h3,h4,.mat-card-title,.card-title,legend")].filter(vis).map((e) => clip(e.innerText)).filter(Boolean).slice(0, 15);
    const tables = [...document.querySelectorAll("table, mat-table, [role=table], .p-datatable")].filter(vis).map((t) => ({ th: [...t.querySelectorAll("th, [role=columnheader], mat-header-cell")].map((h) => clip(h.innerText)).filter(Boolean).slice(0, 15), rows: t.querySelectorAll("tbody tr, mat-row, [role=row]").length }));
    const btns = [...document.querySelectorAll("main button, main a, .content button, .content a, mat-card button, table button, table a")].filter(vis).map((b) => clip(b.innerText || b.title || b.getAttribute("aria-label"))).filter(Boolean);
    const empty = /δεν\s+(υπάρχουν|βρέθηκαν)|κανένα\s+αποτέλεσμα|no\s+(data|records)/i.test(document.body.innerText || "");
    return { u: location.pathname.replace(/\d{5,}/g, "#"), links, heads, tables, btns: [...new Set(btns)].slice(0, 40), empty };
  } }).catch((e) => [{ result: { err: e.message } }]))[0]?.result || {};
  const home = await snap();
  if (home.err) return { err: "ΑΗΦΥ: " + home.err };
  const menu = (home.links || []).filter((l, i, a) => a.findIndex((y) => y.h === l.h) === i);
  const want = menu.filter((l) => /απεικον|ακτινολογ|imaging|radiolog|\bris\b|risorder|γνωματ|opinion|referral|πορισμ|εκθεσ|ιατρικ[αά]\s+σημει|εξιτηρ|έγγραφ|εγγραφ|documents|reports/i.test(nz2(l.x + " " + l.h))).slice(0, 6);
  const pages = [];
  for (const l of want) {
    const before = (await chrome.tabs.get(tabId).catch(() => ({}))).url || "";
    await chrome.scripting.executeScript({ target: { tabId }, args: [l.h], func: (h) => { const a = [...document.querySelectorAll('a[href^="/doctor/app/"]')].find((x) => x.getAttribute("href").replace(/\d{5,}/g, "#") === h); if (a) a.click(); return !!a; } }).catch(() => {});
    for (let i = 0; i < 16; i++) { await E.sleep(500); const u = (await chrome.tabs.get(tabId).catch(() => ({}))).url || ""; if (u && u !== before) break; }
    await E.sleep(2500);
    const sp = await snap(); delete sp.links;
    pages.push({ link: l, page: sp });
  }
  return { menu: menu.slice(0, 60), pages };
}
function nz2(s) { return String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase(); }
// Για τις εργασίες από το Παραδόχαρτο (ένας ασθενής): ΑΜΚΑ και ΑΗΦΥ στη σειρά
async function comorbOne(p, opts = {}) {
  // ΑΜΚΑ ήδη στο Παραδόχαρτο: ο φάκελος δεν χρειάζεται καθόλου — μόνο παράθυρο για τον ΑΗΦΥ
  const tab = /^\d{11}$/.test(String(p.amka || "")) ? await bgEhrHostTab() : await bgEmrTab();
  if (!tab || tab.err) return { err: tab?.err || "δεν άνοιξε ο φάκελος", retry: true, stopAll: true };
  const t0 = Date.now();
  const a = await comorbAmka(p, tab);
  if (a.err) return a;
  const t1 = Date.now();
  const res = await comorbEhr(p, a, tab, opts);
  if (!res.err) await comorbStat({ a: t1 - t0, ...(res.ms || {}), b: Date.now() - t1 });
  if (!res.err && res.c && opts.dx !== false && !opts.docs) await npsdxQueue(p.k, p.name);
  return res;
}
// ΑΜΚΑ γραμμένος με το χέρι: το όνομα στην κάρτα του ασθενή στον ΑΗΦΥ πρέπει να ταιριάζει με το Παραδόχαρτο
async function ehrNameCheck(tabId, amka, name) {
  const nz = (x) => String(x || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().split(/[^\p{L}]+/u).filter((t) => t.length >= 3);
  const c = await chrome.tabs.sendMessage(tabId, { cmd: "ehrCard", amka }, { frameId: 0 }).catch(() => null);
  const card = new Set(nz(c?.text));
  if (!card.size) return { err: "ΑΜΚΑ από το Παραδόχαρτο: δεν διαβάστηκε όνομα στον ΑΗΦΥ για έλεγχο — δεν έγινε τίποτα", retry: true };
  if (!nz(name).some((t) => card.has(t))) return { err: "ο ΑΜΚΑ που γράφτηκε στο Παραδόχαρτο ανήκει σε άλλο όνομα στον ΑΗΦΥ — ελέγξτε τον ΑΜΚΑ (δεν έγινε τίποτα)" };
  return null;
}
// «🤖 Τράβηγμα από ΑΗΦΥ» για έναν ασθενή, από το Παραδόχαρτο (υπολογιστή ή κινητό) μέσω της ουράς εργασιών.
// Δουλεύει και χωρίς την αυτόματη επιλογή· ξαναψάχνει ακόμα κι αν ο ασθενής έχει ήδη ελεγχθεί.
JOB_RUNNERS.ehrdx = async (job) => {
  const { efbot } = await chrome.storage.local.get("efbot");
  const nr = comorbNotReady(efbot);
  if (nr) return { status: "failed", note: nr };
  if (comorbBusy) comorbYield = true; // ο αυτόματος κύκλος σταματά μετά τον ασθενή που δουλεύει τώρα
  for (let i = 0; i < 90 && comorbBusy; i++) await E.sleep(2000);
  if (comorbBusy) return { status: "failed", note: "το bot είναι απασχολημένο — ξαναδοκιμάστε σε λίγο" };
  comorbBusy = true;
  let res;
  const rk = await pdxResolveK(job.room, job.name); const K = rk && rk.r ? rk.r : job.room;
  const am = await pdxCall("pdxComorbAmka", [K, job.name]);
  try { res = await comorbOne({ k: K, name: job.name, amka: am?.r || "" }).catch((e) => ({ err: e.message })); }
  finally { comorbBusy = false; comorbYield = false; clearTimeout(comorbWakeT); comorbWakeT = setTimeout(() => comorbAutoTick(false).catch(() => {}), 5000); }   // συνέχεια του αυτόματου κύκλου
  if (res.err) {
    if (res.stopAll) await comorbEnvProblem(res);
    else await pdxCall("pdxComorbAutoMark", [job.room, job.name, { status: res.retry ? "retry" : "fail", note: String(res.err).slice(0, 160) }]);
    return { status: "failed", note: res.err };
  }
  const lb = res.labs;
  const how = res.direct ? " · ⚡ απευθείας " + Math.round((res.ms?.direct || 0) / 100) / 10 + "″" + (res.asked ? " (πρόσβαση «Θεράπων ιατρός»)" : "") : (ehrDirectLast && Date.now() - ehrDirectLast.at < 600000 ? " · οθόνη (απευθείας: " + ehrDirectLast.err + ")" : "");
  return { status: "done", note: `ΑΗΦΥ: ${res.c} χρόνια μπήκαν${res.u ? `, ${res.u} αμφίβολα στο 🩺` : ""}` + (lb ? (lb.err ? ` · ⚠ ${lb.err}` : ` · 📈 ${lb.tests} εξετάσεις`) : "") + how,
    push: ["🩺 Ήρθαν από τον ΑΗΦΥ", `${job.name}: ${res.c} χρόνια${res.u ? `, ${res.u} αμφίβολα` : ""}${lb && !lb.err ? `, ${lb.tests} εξετάσεις` : ""}`] };
};
// «🤖 Ενημέρωση» στα 📈 Εργαστηριακά ΑΗΦΥ: μόνο εργαστηριακά
// 🧪 «Φέρε τώρα» από το κινητό: ένας πλήρης έλεγχος Medilabi, με το αποτέλεσμα (ή τον λόγο που δεν έγινε) ως σημείωση
JOB_RUNNERS.medlabs = async (job) => {
  // ⚡ κατ' επίκληση: άνοιξε ασθενή στο κινητό → ΜΟΝΟ αυτός (1 αίτημα HTTP, δευτερόλεπτα)
  const only = ((job && job.payload && job.payload.only) || []).map(String).filter(Boolean);
  for (let i = 0; i < (only.length ? 50 : 60) && labsBusyStale(); i++) await E.sleep(1000);   // γρήγορη λωρίδα: μέσα στα 70″
  const ran = await labsTick(true, only.length ? only : undefined);
  if (ran === false) return { status: "failed", note: "🧪 Medilabi απασχολημένο (τρέχει άλλος έλεγχος) — ξαναδοκιμάστε" };
  if (only.length) { try { const { efbotLabWatch: w = {} } = await chrome.storage.local.get("efbotLabWatch"); for (const n of only) w[n] = Math.max(+w[n] || 0, Date.now() + 2 * 3600e3); await chrome.storage.local.set({ efbotLabWatch: w }); } catch (e) {} }
  const st = (await chrome.storage.session.get("efbotLabs")).efbotLabs || {};
  const msg = String(st.lastMsg || "χωρίς απάντηση");
  // «🔑 έγινε αυτόματη σύνδεση» = ΕΠΙΤΥΧΙΑ (πριν μετρούσε ως αποτυχία → ψεύτικο «απέτυχε» + διπλή επανάληψη)
  const bad = /Σφάλμα|Ανοίξτε|κενή|δεν στάλθηκαν|απέτυχε|χρειάζεται σύνδεση|δεν συνδέθηκε/i.test(msg) || (/σύνδεση/i.test(msg.replace(/έγινε αυτόματη σύνδεση/gi, "")) && !/Βρέθηκαν \d+/.test(msg));
  return { status: bad ? "failed" : "done", note: "🧪 " + msg.slice(0, 240) };
};
// 📄 6/11: ΑΗΦΥ — χαρτογράφηση σελίδων με πορίσματα/έγγραφα (μόνο δομή: μενού, επικεφαλίδες, στήλες πινάκων, πλήθος γραμμών·
// ΧΩΡΙΣ περιεχόμενο ασθενή). Βάση για την ανάγνωση πορισμάτων απεικονίσεων.
JOB_RUNNERS.ehrdocs = async (job) => {
  const { efbot } = await chrome.storage.local.get("efbot");
  const nr = comorbNotReady(efbot); if (nr) return { status: "failed", note: nr };
  if (comorbBusy) comorbYield = true;
  for (let i = 0; i < 90 && comorbBusy; i++) await E.sleep(2000);
  if (comorbBusy) return { status: "failed", note: "το bot είναι απασχολημένο — ξαναδοκιμάστε σε λίγο" };
  comorbBusy = true; let res;
  try { const rk = await pdxResolveK(job.room, job.name); const K = rk && rk.r ? rk.r : job.room; const am = await pdxCall("pdxComorbAmka", [K, job.name]);
    res = await comorbOne({ k: K, name: job.name, amka: am?.r || "" }, { dx: false, docs: true }).catch((e) => ({ err: e.message })); }
  finally { comorbBusy = false; comorbYield = false; clearTimeout(comorbWakeT); comorbWakeT = setTimeout(() => comorbAutoTick(false).catch(() => {}), 5000); }
  if (res.err) return { status: "failed", note: "📄 " + res.err };
  const d = res.docs || {}, A = d.api || {}; return { status: "done", note: "📄 ΑΗΦΥ: " + Object.entries(A).map(([k, v]) => k + " " + (v.st || "?") + (v.n != null ? "/" + v.n : "")).join(" · "), result: { docs: d } };
};
JOB_KIND.ehrdocs = "📄 ΑΗΦΥ: σελίδες πορισμάτων (χαρτογράφηση)";
JOB_LIMIT_S.ehrdocs = 240;
JOB_RUNNERS.ehrlabs = async (job) => {
  const { efbot } = await chrome.storage.local.get("efbot");
  const nr = comorbNotReady(efbot);
  if (nr) return { status: "failed", note: nr };
  if (comorbBusy) comorbYield = true;
  for (let i = 0; i < 90 && comorbBusy; i++) await E.sleep(2000);
  if (comorbBusy) return { status: "failed", note: "το bot είναι απασχολημένο — ξαναδοκιμάστε σε λίγο" };
  comorbBusy = true;
  const rk = await pdxResolveK(job.room, job.name); const K = rk && rk.r ? rk.r : job.room;
  if (rk && !rk.r) { comorbBusy = false; return { status: "failed", note: "Παραδόχαρτο: δεν βρέθηκε «" + job.name + "» στους " + rk.n + " ασθενείς αυτού του υπολογιστή" }; }
  const am = await pdxCall("pdxComorbAmka", [K, job.name]);
  let res;
  try { res = await comorbOne({ k: K, name: job.name, amka: am?.r || "" }, { dx: false }).catch((e) => ({ err: e.message })); }
  finally { comorbBusy = false; comorbYield = false; clearTimeout(comorbWakeT); comorbWakeT = setTimeout(() => comorbAutoTick(false).catch(() => {}), 5000); }   // συνέχεια του αυτόματου κύκλου
  if (res.err) { if (res.stopAll) await comorbEnvProblem(res); return { status: "failed", note: res.err }; }
  return { status: "done", note: `📈 ${res.labs?.tests || 0} εξετάσεις, ${res.labs?.points || 0} τιμές από ${res.labs?.orders || 0} παραπεμπτικά` + (res.direct ? " · ⚡ απευθείας " + Math.round((res.ms?.direct || 0) / 100) / 10 + "″" : (ehrDirectLast && Date.now() - ehrDirectLast.at < 600000 ? " · οθόνη (απευθείας: " + ehrDirectLast.err + ")" : "")),
    push: ["📈 Εργαστηριακά ΑΗΦΥ", `${job.name}: ${res.labs?.tests || 0} εξετάσεις, ${res.labs?.points || 0} τιμές`] };
};
// 🗺 ΑΗΦΥ: χαρτογράφηση απευθείας αιτημάτων — ΜΟΝΟ ανάγνωση κώδικα της σελίδας (JS αρχεία της εφαρμογής).
// Κανένας ασθενής δεν ανοίγει, κανένα κουμπί δεν πατιέται. Από τα αιτήματα που έκανε ήδη η σελίδα κρατά ΜΟΝΟ διαδρομή + ονόματα παραμέτρων (όχι τιμές).
JOB_RUNNERS.ehrapimap = async (job) => {
  for (let i = 0; i < 60 && comorbBusy; i++) await E.sleep(2000);
  if (comorbBusy) return { status: "failed", note: "το bot είναι απασχολημένο με τον ΑΗΦΥ — ξαναδοκιμάστε σε λίγο" };
  comorbBusy = true;
  try {
    const host = await bgEhrHostTab();
    if (!host || host.err) return { status: "failed", note: host?.err || "δεν άνοιξε παράθυρο για το bot" };
    const ehr = await bgEhrTab(host);
    if (!ehr) return { status: "failed", note: bgEhrErr || "δεν άνοιξε ο Ατομικός Φάκελος Υγείας" };
    if (!(await ehrLoggedIn(ehr.id))) {
      const lg = await ahfyAutoLogin(ehr.id).catch((e) => ({ ok: false, err: e.message }));
      if (!lg.ok) {
        // μορφή της σελίδας σύνδεσης (ΜΟΝΟ δομή: διεύθυνση χωρίς παραμέτρους, τύποι/ονόματα πεδίων, τίτλοι, κουμπιά — καμία τιμή)
        const [sp] = await chrome.scripting.executeScript({ target: { tabId: ehr.id }, func: () => {
          const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
          const T = (e) => String((e && (e.innerText || e.value || e.getAttribute("aria-label"))) || "").replace(/\s+/g, " ").trim().replace(/\d{4,}/g, "#").slice(0, 80);
          return { host: location.host, path: location.pathname.replace(/\d{5,}/g, "#"),
            inputs: [...document.querySelectorAll("input, select, textarea")].filter(vis).map((i) => ({ t: i.type || i.tagName.toLowerCase(), n: i.name || i.id || "", ac: i.autocomplete || "", ph: T({ innerText: i.placeholder }) })).slice(0, 15),
            heads: [...document.querySelectorAll("h1,h2,h3,label,.kc-feedback-text,.alert,#kc-page-title")].filter(vis).map(T).filter(Boolean).slice(0, 15),
            btns: [...document.querySelectorAll("button, input[type=submit], a.btn")].filter(vis).map(T).filter(Boolean).slice(0, 10) };
        } }).catch((e) => [{ result: { err: e.message } }]);
        const pg = (sp && sp.result) || {};
        // και η διεύθυνση της καρτέλας κατά τον Chrome (π.χ. σελίδα σφάλματος δικτύου, όπου το script δεν μπαίνει)
        const tb = await chrome.tabs.get(ehr.id).catch((e) => ({ err: e.message }));
        let tu = ""; try { const u = new URL(tb.url || tb.pendingUrl || ""); tu = u.protocol + "//" + u.host + u.pathname.replace(/\d{5,}/g, "#"); } catch (e) { tu = String(tb.url || tb.err || "").slice(0, 80); }
        pg.tab = { url: tu, status: tb.status, title: String(tb.title || "").replace(/\d{4,}/g, "#").slice(0, 80), incognito: tb.incognito };
        return { status: "failed", note: "ΑΗΦΥ σύνδεση: " + (lg.err || "χωρίς λόγο") + " · καρτέλα " + tu + " «" + pg.tab.title + "»" + (pg.err ? " · script: " + String(pg.err).slice(0, 80) : "") + " · πεδία: " + (pg.inputs || []).map((i) => i.t + (i.n ? ":" + i.n : "")).join(", "), result: { login: lg, page: pg, at: Date.now() } };
      }
    }
    await bgSettle(ehr.id, 1500).catch(() => {});
    const GREP = [].concat(job.payload?.grep || []).map(String).slice(0, 8);
    const [r] = await chrome.scripting.executeScript({ target: { tabId: ehr.id }, world: "MAIN", args: [GREP], func: async (GREP) => {
      const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      const mask = (s) => String(s || "").replace(/\d{5,}/g, "#");
      // 🔎 στοχευμένη αναζήτηση στον κώδικα (payload.grep: κανονικές εκφράσεις) — π.χ. οι τιμές του «λόγου πρόσβασης»
      const GR = GREP.map((g) => { try { return new RegExp(g, "gi"); } catch (e) { return null; } }).filter(Boolean), grep = [];
      // 1) αιτήματα που έγιναν ήδη: διαδρομή + ονόματα παραμέτρων
      const seen = {};
      for (const e of performance.getEntriesByType("resource")) {
        try { const u = new URL(e.name); if (u.origin !== location.origin) continue; if (/\.(js|css|png|svg|woff2?|ttf|ico|jpg|gif)$/i.test(u.pathname)) continue;
          const k = mask(u.pathname) + (u.search ? "?" + [...u.searchParams.keys()].join("&") : ""); seen[k] = (seen[k] || 0) + 1; } catch (x) {}
      }
      // 2) κώδικας της εφαρμογής: διευθύνσεις αιτημάτων + λίγο κείμενο γύρω τους (μόνο κώδικας)
      const srcs = [...new Set([...document.scripts].map((s) => s.src).filter((s) => s && new URL(s).origin === location.origin))];
      const files = [], hits = {}, ctx = [];
      // (το «?» στο τέλος: οι παραγόμενοι clients γράφουν baseUrl + "/lis/LisResultsHeaders?" + παράμετροι)
      const RE = /["'`]((?:\/?doctor)?\/?api\/[A-Za-z0-9_\/\-{}$.]{2,140}|\/[A-Za-z0-9_\-]{2,40}\/(?:[A-Za-z0-9_\-{}$]{2,60}\/?){1,5})\??["'`]/g;
      const KEY = /amka|ehrId|patient|Patient|access|Access|reason|Reason|lis|Lis|diagnos|Diagnos|search|Search|consent|Consent|emergency|Emergency/;
      const lazy = new Set();
      const scan = async (url) => {
        let t = ""; try { const rr = await fetch(url, { credentials: "include" }); if (!rr.ok) { files.push({ f: url.split("/").pop(), http: rr.status }); return; } t = await rr.text(); } catch (e) { files.push({ f: url.split("/").pop(), err: String(e.message || e) }); return; }
        files.push({ f: url.split("/").pop(), kb: Math.round(t.length / 1024) });
        // lazy chunks (Angular): αριθμοί/ονόματα chunk → αρχεία .js στον ίδιο φάκελο
        for (const m of t.matchAll(/["'`]([A-Za-z0-9_\-]{1,40}\.[0-9a-f]{8,20}\.js)["'`]/g)) lazy.add(new URL(m[1], url).href);
        // νεότερο Angular (esbuild): import("./chunk-QSGGRKE7.js")
        for (const m of t.matchAll(/["'`](?:\.\/)?(chunk-[A-Za-z0-9_\-]{4,20}\.js)["'`]/g)) lazy.add(new URL(m[1], url).href);
        for (const m of t.matchAll(RE)) {
          const p = m[1]; if (/\.(js|css|png|svg|html)$/i.test(p) || /^\/(node_modules|assets)\//.test(p)) continue;
          hits[p] = (hits[p] || 0) + 1;
          if (hits[p] === 1 && (KEY.test(p) || /api\//.test(p)) && ctx.length < 400) ctx.push({ p, c: mask(t.slice(Math.max(0, m.index - 220), m.index + p.length + 260)).replace(/\s+/g, " ") });
        }
        // μορφή «controller/Ενέργεια» (π.χ. lis/LisResultsHeaders, patient/SearchPatient): η βάση /doctor/api/ μπαίνει αλλού
        for (const m of t.matchAll(/["'`]\/?([a-z][A-Za-z0-9]{1,30}\/[A-Z][A-Za-z0-9]{2,60})["'`]/g)) {
          const p = "api:" + m[1]; hits[p] = (hits[p] || 0) + 1;
          if (hits[p] === 1 && ctx.length < 700 && /patient|amka|access|reason|lis|diagnos|search|consent|emergency|ehr|break|encounter|referral|prescri/i.test(m[1])) ctx.push({ p, c: mask(t.slice(Math.max(0, m.index - 260), m.index + m[1].length + 300)).replace(/\s+/g, " ") });
        }
        for (const g of GR) for (const m of t.matchAll(g)) { if (grep.length >= 60) break; const i = m.index; if (grep.some((x) => x.f === url.split("/").pop() && Math.abs(x.i - i) < 400)) continue;
          grep.push({ g: g.source.slice(0, 40), f: url.split("/").pop(), i, c: mask(t.slice(Math.max(0, i - 500), i + 700)).replace(/\s+/g, " ") }); }
        // σημεία με ΑΜΚΑ/ehrId/λόγο πρόσβασης ακόμα κι αν η διεύθυνση χτίζεται με μεταβλητές
        for (const m of t.matchAll(/(?:amka|ehrId|accessReason|reasonId|reasonCode|breakGlass|emergencyAccess)\b/g)) {
          if (ctx.length >= 520) break; const i = m.index; if (ctx.some((x) => x.i && Math.abs(x.i - i) < 300)) continue;
          ctx.push({ k: m[0], i, f: url.split("/").pop(), c: mask(t.slice(Math.max(0, i - 260), i + 260)).replace(/\s+/g, " ") });
        }
      };
      for (const s of srcs) await scan(s);
      // runtime/main αναφέρουν lazy chunks: διαβάζονται κι αυτά (έως 40)
      // τα κομμάτια φορτώνουν κι άλλα κομμάτια: σάρωση μέχρι να μη βρεθεί νέο (έως 150 αρχεία)
      const done = new Set(srcs);
      for (let pass = 0; pass < 6; pass++) {
        const next = [...lazy].filter((x) => !done.has(x)); if (!next.length || done.size >= 150) break;
        for (const s of next.slice(0, 150 - done.size)) { done.add(s); await scan(s); }
      }
      // 3) ανοιχτά παράθυρα/μάσκες τώρα (δομή μόνο)
      const dlg = [...document.querySelectorAll(".p-dialog, [role=dialog], .p-dialog-mask, .p-component-overlay, .cdk-overlay-pane")].filter(vis).map((d) => ({
        cls: String(d.className || "").slice(0, 120), title: mask((d.querySelector(".p-dialog-title, .p-dialog-header, h1,h2,h3") || {}).innerText || "").slice(0, 80),
        inputs: [...d.querySelectorAll("input, textarea, select, p-dropdown")].map((x) => x.type || x.tagName.toLowerCase()).slice(0, 10),
        btns: [...d.querySelectorAll("button")].map((b) => mask(b.innerText || b.getAttribute("aria-label") || "").trim().slice(0, 40)).filter(Boolean).slice(0, 10) }));
      for (const x of ctx) delete x.i;
      for (const x of grep) delete x.i;
      return { ok: true, grep, url: mask(location.pathname), seen, files, hits: Object.entries(hits).sort((a, b) => b[1] - a[1]).slice(0, 500), ctx, dlg };
    } }).catch((e) => [{ result: { err: e.message } }]);
    const o = (r && r.result) || { err: "δεν απάντησε" };
    if (o.err) return { status: "failed", note: "ΑΗΦΥ: " + o.err };
    const api = o.hits.filter(([p]) => /api[\/:]/.test(p));
    return { status: "done", note: `🗺 ΑΗΦΥ: ${o.files.length} αρχεία κώδικα · ${api.length} διευθύνσεις api · ${o.ctx.length} σημεία κώδικα · ${Object.keys(o.seen).length} αιτήματα σελίδας · ${o.dlg.length} παράθυρα ανοιχτά${GREP.length ? " · 🔎 " + o.grep.length + " ευρήματα" : ""}`, result: { ...o, at: Date.now() } };
  } finally { comorbBusy = false; }
};
JOB_KIND.ehrapimap = "🗺 ΑΗΦΥ: χαρτογράφηση απευθείας αιτημάτων";
JOB_LIMIT_S.ehrapimap = 300;
// 💊 Συνταγή στο e-prescription (epres.js): ετοιμάζεται και σταματά πριν την «Καταχώριση»
// 💊 έχει μάθει ο υπολογιστής τον λογαριασμό e-prescription; / ποιον έβαλε τελευταίο το bot
async function epresUsers() { try { const { efbotCredByHost: cb = {} } = await V.get("efbotCredByHost"); const eu = []; for (const [k, v] of Object.entries(cb)) if ([].concat(cb["*epres"] || []).some((a) => a && a.pass) ? k === "*epres" : /^\*(epres|ahfy)$|prescription/i.test(k)) for (const a of [].concat(v || [])) if (a && a.user && a.pass && !eu.includes(a.user)) eu.push(a.user); return eu; } catch (e) { return []; } }
let epUC = { at: 0, v: [] };
async function epresUsersCached() { if (Date.now() - epUC.at > 120000) epUC = { at: Date.now(), v: (await epresUsers()).slice(0, 12) }; return epUC.v; }
const epresHasUser = async (u) => (await epresUsers()).some((x) => String(x).toLowerCase() === String(u || "").trim().toLowerCase());
const epresLastWho = async () => { const { efbotEpWho: w } = await chrome.storage.session.get("efbotEpWho"); return w && Date.now() - w.at < 12 * 3600e3 ? w.user : ""; };
// 🗺 e-prescription: χαρτογράφηση φόρμας παραπεμπτικού — ΜΟΝΟ ανάγνωση (ανοίγει, καταγράφει, «Ακύρωση»· ποτέ Καταχώριση)
JOB_RUNNERS.epresmap = (job) => self.EFEpres.map(job, { sleep: E.sleep, epresAutoLogin, epresLoggedIn });
JOB_KIND.epresmap = "🗺 e-prescription: χαρτογράφηση παραπεμπτικών";
JOB_RUNNERS.epresrefmap = (job) => self.EFEpres.refmap(job, { sleep: E.sleep, epExpiredSwitch, epresAutoLogin, epresLoggedIn });
JOB_KIND.epresrefmap = "🗺 e-prescription: φόρμα παραπεμπτικού (δοκιμή)";
JOB_LIMIT_S.epresrefmap = 240;
JOB_RUNNERS.epapiprobe = (job) => self.EFEpres.apiprobe(job, { sleep: E.sleep, epresAutoLogin, epresLoggedIn });
JOB_KIND.epapiprobe = "🔌 e-prescription: έλεγχος απευθείας αιτημάτων";
// 🗺 e-prescription: χάρτης κλήσεων που έκανε η ΙΔΙΑ η εφαρμογή (epres-hook.js, μόνο μνήμη) — από ΟΛΕΣ τις καρτέλες e-prescription
// του υπολογιστή. Μόνο δομή: μέθοδος, διαδρομή, κωδικός συναλλαγής, ονόματα πεδίων· καμία τιμή. Δεν πατά, δεν ανοίγει τίποτα.
JOB_RUNNERS.epapilog = async (job) => {
  const tabs = await chrome.tabs.query({ url: "https://www.e-prescription.gr/*" }).catch(() => []);
  const all = {};
  let n = 0;
  for (const t of tabs) {
    const [r] = await chrome.scripting.executeScript({ target: { tabId: t.id }, world: "MAIN", func: () => (window.__efEp && window.__efEp.log) || [] }).catch(() => [{ result: [] }]);
    for (const e of (r && r.result) || []) { n++; const k = e.m + " " + e.p + " " + (e.tc || ""); const x = all[k] || (all[k] = { m: e.m, p: e.p, tc: e.tc || "", unit: !!e.unit, st: {}, req: e.req || [], res: e.res || [], n: 0, ms: 0 }); x.n++; x.st[e.st || 0] = (x.st[e.st || 0] || 0) + 1; x.ms = Math.max(x.ms, e.ms || 0); if ((e.req || []).length > x.req.length) x.req = e.req; if ((e.res || []).length > x.res.length) x.res = e.res; }
  }
  const calls = Object.values(all).sort((a, b) => b.n - a.n);
  return { status: "done", note: `🗺 e-prescription: ${tabs.length} καρτέλες · ${n} κλήσεις · ${calls.length} διαφορετικές` + (calls.length ? " · " + calls.slice(0, 6).map((c) => c.m + " " + c.p.split("?")[0].replace(/^\/epres\/api/, "")).join(" | ") : " (η καταγραφή γεμίζει όσο δουλεύει κάποιος στο e-prescription μετά την 0.20.14)"), result: { calls, tabs: tabs.length, at: Date.now() } };
};
JOB_KIND.epapilog = "🗺 e-prescription: χάρτης κλήσεων";
// 🔌 e-prescription ΑΠΕΥΘΕΙΑΣ, ΜΟΝΟ ΑΝΑΓΝΩΣΗ (πίσω από διακόπτη, δοκιμή): αναζήτηση φαρμάκου / ICD10 / εξέτασης με τις ΙΔΙΕΣ
// κεφαλίδες και τις ΙΔΙΕΣ ρυθμίσεις που χρησιμοποίησε η εφαρμογή (epres-hook: S.h + S.tpl). Δεν γράφει τίποτα στο e-prescription.
// payload: { what: "med"|"icd"|"exam", q: "κείμενο", examinationGroupId? }
const epField = (x, re) => { if (!x || typeof x !== "object") return ""; for (const [k, v] of Object.entries(x)) { if (!re.test(k)) continue; if (v != null && typeof v !== "object") return String(v).slice(0, 80); if (v && typeof v === "object" && !Array.isArray(v)) { const d = v.description || v.name || v.title || v.value; if (d != null && typeof d !== "object") return String(d).slice(0, 80); } } return ""; };
const EP_SEARCH = {
  // 💊 + συσκευασία/μορφή/περιεκτικότητα αν τις δίνει η απάντηση (ονόματα πεδίων άγνωστα ακόμα → αναζήτηση με το όνομα του κλειδιού, έως 1 επίπεδο)
  med: { p: "/epres/api/masterdata/v1/medicine/search", kw: "keyword", tc: "Search medicine", list: "medicines", pick: (x) => ({ id: x.id, name: x.commercialName, eof: x.eofCode, form: epField(x, /form|μορφ/i), str: epField(x, /strength|περιεκτ|potency/i), pack: epField(x, /pack|συσκευ|package|content/i) }) },
  icd: { p: "/epres/api/masterdata/v1/icd10/search", kw: "codeOrTitle", tc: "Search ICD10", list: "icd10List", pick: (x) => ({ id: x.id, code: x.code, name: x.title }) },
  exam: { p: "/epres/api/doctor/referral/v1/exam/search", kw: "keyword", tc: "Doctor:Search Examinations", list: "examinations", pick: (x) => ({ id: x.id, name: x.description || x.name || "", group: x.examinationGroup && x.examinationGroup.name }) },
};
// 8/11: πρότυπα όταν η καρτέλα δεν έχει κάνει ακόμα αναζήτηση με το χέρι (από τις κλήσεις που κατέγραψε η ίδια η εφαρμογή)
const EP_TPL_DEF = {
  "/epres/api/masterdata/v1/medicine/search": { mode: "Commercial", page: "1", dhpcMode: "2", pageSize: "20", limitedByProtocol: "true", keyword: null },
  "/epres/api/masterdata/v1/icd10/search": { page: "1", pageSize: "20", isConsumable: "false", limitedByProtocol: "true", codeOrTitle: null },
};
// κλήση στο API του e-prescription μέσα σε συνδεδεμένη καρτέλα. over: παράμετροι που αντικαθιστούν το πρότυπο
async function epApiGet(tabId, d, q, over, age, grp) {
  const [r] = await chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", args: [d.p, d.kw, d.tc, q, grp || null, age, over || {}, EP_TPL_DEF[d.p] || null], func: async (path, kw, tc, q, grp, age, over, def) => {
    const S = window.__efEp; if (!S || !S.h || !S.h["x-authorization"]) return { skip: "χωρίς σύνδεση στην καρτέλα" };
    const tpl = (S.tpl || {})[path] || def; if (!tpl) return { skip: "η εφαρμογή δεν έχει κάνει ακόμα αυτή την αναζήτηση σε αυτή την καρτέλα (χρειάζεται μία φορά με το χέρι)" };
    const u = new URL(path, location.origin);
    for (const [k, v] of Object.entries(tpl)) { if (k === kw) u.searchParams.set(k, q); else if (k === "examinationGroupId" && grp) u.searchParams.set(k, grp); else if (k === "patientAge") u.searchParams.set(k, age); else if (v != null) u.searchParams.set(k, v); }
    for (const [k, v] of Object.entries(over)) u.searchParams.set(k, String(v));
    if (!u.searchParams.has(kw)) u.searchParams.set(kw, q);
    const h = { accept: "application/json" }; for (const [k, v] of Object.entries(S.h)) h[k] = v;
    h["x-sender-transaction-code"] = tc; try { h["x-request-id"] = crypto.randomUUID(); } catch (e) {}
    const t0 = performance.now(); const res = await fetch(u.toString(), { credentials: "include", headers: h }); const ms = Math.round(performance.now() - t0);
    let j = null; try { j = await res.json(); } catch (e) {}
    const tot = j && (j.totalElements ?? j.total ?? j.totalCount ?? j.count ?? (j.page && j.page.totalElements));
    return { st: res.status, ms, j, sent: [...u.searchParams.keys()], tot, def: !(S.tpl || {})[path] };
  } }).catch((e) => [{ result: { skip: e.message } }]);
  return (r && r.result) || { skip: "δεν απάντησε" };
}
// καρτέλα e-prescription με σύνδεση: υπάρχουσα, αλλιώς ανοίγει (καρτέλα του bot) + αυτόματη σύνδεση· περιμένει ΔΥΝΑΜΙΚΑ να εμφανιστεί το κλειδί
async function epSearchTab() {
  const ok = async (id) => { const [r] = await chrome.scripting.executeScript({ target: { tabId: id }, world: "MAIN", func: () => !!(window.__efEp && window.__efEp.h && window.__efEp.h["x-authorization"]) }).catch(() => [{ result: false }]); return !!(r && r.result); };
  for (const t of await chrome.tabs.query({ url: "https://www.e-prescription.gr/*" }).catch(() => [])) if (await ok(t.id)) return t;
  const t = await self.EFEpres.epTab(); if (!t || t.err) return { err: (t && t.err) || "δεν άνοιξε το e-prescription" };
  if (!(await epresLoggedIn(t.id))) { const lg = await epresAutoLogin(t.id, "", {}).catch((e) => ({ ok: false, err: e.message })); if (lg && lg.ok === false) return { err: "σύνδεση e-prescription: " + (lg.err || "απέτυχε") }; }
  // η εφαρμογή στέλνει τις πρώτες κλήσεις της μόλις φορτώσει → τότε φαίνεται το κλειδί (όσο αλλάζει η σελίδα, περιμένουμε)
  let last = ""; for (let i = 0; i < 400; i++) { if (await ok(t.id)) return t; const x = await chrome.tabs.get(t.id).catch(() => null); if (!x) return { err: "η καρτέλα έκλεισε" };
    const sig = x.status + "|" + x.url; if (sig !== last) { last = sig; i = Math.min(i, 300); } await E.sleep(150); }
  return { err: "το e-prescription άνοιξε αλλά δεν έστειλε ακόμα το κλειδί σύνδεσης" };
}
JOB_RUNNERS.epsearch = async (job) => {
  const p = job.payload || {}, d = EP_SEARCH[p.what || "med"];
  if (!d || !String(p.q || "").trim()) return { status: "failed", note: "epsearch: λείπει what/q" };
  const q = String(p.q).trim().slice(0, 60), age = +p.age > 0 ? String(Math.round(+p.age)) : "50";
  let tabs = await chrome.tabs.query({ url: "https://www.e-prescription.gr/*" }).catch(() => []), o = null, tab = null;
  for (const t of tabs) { const x = await epApiGet(t.id, d, q, null, age, p.examinationGroupId); if (!x.skip) { o = x; tab = t; break; } }
  if (!o) { const t = await epSearchTab(); if (t.err) return { status: "failed", env: true, note: "🔌 e-prescription: " + t.err };
    tab = t; o = await epApiGet(t.id, d, q, null, age, p.examinationGroupId); if (o.skip) return { status: "failed", env: true, note: "🔌 e-prescription: " + o.skip }; }
  if (o.st !== 200) return { status: "failed", note: `🔌 e-prescription απευθείας: HTTP ${o.st} (${o.ms}ms) · παράμετροι ${(o.sent || []).join("&")}`, result: { st: o.st, sent: o.sent } };
  let arr = (o.j && (o.j[d.list] || (Array.isArray(o.j) ? o.j : null))) || [], extra = "";
  // 💉 φάρμακα: τίποτα με τους περιορισμούς πρωτοκόλλου → χωρίς περιορισμό, μετά με δραστική ουσία (εμβόλια, σκευάσματα εκτός πρωτοκόλλου)
  if (!arr.length && (p.what || "med") === "med") {
    for (const ov of [{ limitedByProtocol: "false" }, { mode: "Inn", limitedByProtocol: "false" }, { dhpcMode: "0", limitedByProtocol: "false" }]) {
      const x = await epApiGet(tab.id, d, q, ov, age); const a = (x && x.st === 200 && x.j && (x.j[d.list] || (Array.isArray(x.j) ? x.j : null))) || [];
      if (a.length) { arr = a; extra = " (με " + Object.entries(ov).map(([k, v]) => k + "=" + v).join(",") + ")"; break; } }
  }
  const items = arr.slice(0, 20).map(d.pick);
  return { status: "done", note: `🔌 e-prescription απευθείας «${q}»: ${arr.length} αποτελέσματα σε ${o.ms}ms${extra}${o.def ? " · πρότυπο: προεπιλογή" : ""}` + (items.length ? " · " + items.slice(0, 4).map((x) => x.code ? x.code + " " + x.name : x.name).join(" | ") : ""), result: { items, ms: o.ms, n: arr.length } };
};
// 📚 8/11: ΚΑΤΑΛΟΓΟΣ φαρμάκων e-prescription για ΑΜΕΣΗ αναζήτηση στο Παραδόχαρτο (μόνο ανάγνωση, κανένας ασθενής).
// payload.probe: μόνο μέτρηση (λίγες κλήσεις)· αλλιώς σάρωση με προθέματα 2 γραμμάτων (αν το API δέχεται) → oncall_labs «epcat|med».
JOB_RUNNERS.epcat = async (job) => {
  const p = job.payload || {}, d = EP_SEARCH.med, t0 = Date.now();
  const tab = await epSearchTab(); if (tab.err) return { status: "failed", env: true, note: "📚 e-prescription: " + tab.err };
  const list = (x) => (x && x.st === 200 && x.j && (x.j[d.list] || (Array.isArray(x.j) ? x.j : null))) || [];
  if (p.probe) {
    const out = [];
    for (const [q, ov] of [["a", { pageSize: 500 }], ["ab", { pageSize: 500 }], ["abc", { pageSize: 500 }], ["boostrix", {}], ["boostrix", { limitedByProtocol: "false" }], ["triaxis", { limitedByProtocol: "false" }], ["prevenar", {}], ["shingrix", {}], ["tetanus", { mode: "Inn", limitedByProtocol: "false" }]]) {
      const x = await epApiGet(tab.id, d, q, ov); out.push({ q, ov, st: x.st, n: list(x).length, tot: x.tot, ms: x.ms, keys: x.j && !Array.isArray(x.j) ? Object.keys(x.j).slice(0, 12) : [], first: list(x).slice(0, 3).map((m) => m.commercialName) });
    }
    return { status: "done", note: "📚 δοκιμή: " + out.map((o) => o.q + (o.ov.limitedByProtocol === "false" ? "*" : "") + (o.ov.mode ? "/" + o.ov.mode : "") + "→" + o.st + ":" + o.n + (o.tot != null ? "/" + o.tot : "")).join(" · "), result: { out, at: Date.now() } };
  }
  // σάρωση: προθέματα (λατινικά + αριθμοί), μεγάλες σελίδες, όλες οι σελίδες· μοναδικά ανά id
  const AL = "abcdefghijklmnopqrstuvwxyz0123456789".split(""), min = Math.max(1, Math.min(3, +p.min || 2)), ps = Math.max(20, Math.min(1000, +p.pageSize || 500));
  const pre = min === 1 ? AL : min === 2 ? AL.flatMap((a) => AL.map((b) => a + b)) : AL.flatMap((a) => AL.flatMap((b) => AL.map((c) => a + b + c)));
  const by = new Map(); let calls = 0, errs = 0;
  for (const q of pre) {
    for (let pg = 1; pg <= 40; pg++) {
      const x = await epApiGet(tab.id, d, q, { pageSize: ps, page: pg, limitedByProtocol: "false" }); calls++;
      if (!x || x.skip || x.st !== 200) { errs++; break; }
      const L = list(x); for (const m of L) { if (m && m.id != null && !by.has(m.id)) by.set(m.id, [String(m.commercialName || "").trim(), String(m.eofCode || ""), m.id, epField(m, /form|μορφ/i) || "", epField(m, /pack|συσκευ|package|content/i) || ""]); }
      if (L.length < ps) break;
    }
    if (Date.now() - t0 > (JOB_LIMIT_S.epcat - 40) * 1000) break;
  }
  const items = [...by.values()].filter((x) => x[0]).sort((a, b) => a[0].localeCompare(b[0]));
  if (!items.length) return { status: "failed", note: "📚 κατάλογος: 0 φάρμακα (" + calls + " κλήσεις, " + errs + " σφάλματα)" };
  const r = await jobsInApp(async (items) => { try { const x = await sb6.from("oncall_labs").upsert({ name_key: "epcat|med", name: "Κατάλογος φαρμάκων e-prescription", pid: null, data: { v: Date.now(), n: items.length, items }, updated_at: new Date().toISOString() }, { onConflict: "name_key" }); return x && x.error ? x.error.message : "ok"; } catch (e) { return e.message; } }, [items]).catch((e) => e.message);
  return { status: "done", note: "📚 κατάλογος φαρμάκων: " + items.length + " συσκευασίες · " + calls + " κλήσεις · " + Math.round((Date.now() - t0) / 1000) + "″ · αποθήκευση: " + r, result: { n: items.length, calls, errs } };
};
JOB_KIND.epcat = "📚 e-prescription: κατάλογος φαρμάκων (μόνο ανάγνωση)";
JOB_LIMIT_S.epcat = 900;
JOB_KIND.epsearch = "🔌 e-prescription: απευθείας αναζήτηση (δοκιμή)";
// 🔎 e-prescription: ποιος είναι συνδεδεμένος / μονάδες / ενεργή επίσκεψη — ΜΟΝΟ ονόματα πεδίων + κατάσταση (καμία τιμή)
JOB_RUNNERS.epprobe = async () => {
  const tabs = await chrome.tabs.query({ url: "https://www.e-prescription.gr/*" }).catch(() => []);
  for (const t of tabs) {
    await tabWake(t.id).catch(() => {});
    const [r] = await chrome.scripting.executeScript({ target: { tabId: t.id }, world: "MAIN", func: async () => {
      const S = window.__efEp; if (!S || !S.h || !S.h["x-authorization"]) return { skip: true };
      const keysOf = (o, d = 0) => { if (!o || typeof o !== "object" || d > 2) return []; if (Array.isArray(o)) return o.length ? keysOf(o[0], d).map((k) => "[]." + k) : ["[]"]; return Object.keys(o).slice(0, 40).flatMap((k) => o[k] && typeof o[k] === "object" && d < 2 ? [k, ...keysOf(o[k], d + 1).map((x) => k + "." + x)] : [k]).slice(0, 80); };
      const get = async (path, tc) => { const h = { accept: "application/json" }; for (const [k, v] of Object.entries(S.h)) h[k] = v; if (tc) h["x-sender-transaction-code"] = tc; try { h["x-request-id"] = crypto.randomUUID(); } catch (e) {}
        const t0 = performance.now(); const r = await fetch(path, { credentials: "include", headers: h }); let j = null; try { j = await r.json(); } catch (e) {} return { st: r.status, ms: Math.round(performance.now() - t0), keys: keysOf(j), n: Array.isArray(j) ? j.length : undefined, ct: String(r.headers.get("content-type") || "").slice(0, 40), op: j && typeof j.operation === "string" ? j.operation.replace(/\d{5,}/g, "#").slice(0, 100) : undefined, msg: j && typeof j.message === "string" ? j.message.replace(/\d{5,}/g, "#").slice(0, 120) : undefined, hk: Object.keys(h) }; };
      return { unitHdr: !!S.h["x-sender-unit-id"], me: await get("/epres/api/auth/v1/token/secure/generate/me"), units: await get("/epres/api/doctor/v1/units?isActive=true", "Doctor:Retrieve Doctor Units"), active: await get("/epres/api/doctor/visit/v1/active", "Doctor:Retrieve Active Visit") };
    } }).catch((e) => [{ result: { err: e.message } }]);
    const o = (r && r.result) || {};
    if (o.skip) continue;
    if (o.err) return { status: "failed", note: "🔎 e-prescription: " + o.err };
    const f = (x) => x ? x.st + " (" + x.ms + "ms)" : "—";
    return { status: "done", note: `🔎 e-prescription: me ${f(o.me)} · μονάδες ${f(o.units)}${o.units?.n != null ? " ×" + o.units.n : ""} · ενεργή επίσκεψη ${f(o.active)} · κεφαλίδα μονάδας ${o.unitHdr ? "ναι" : "όχι"}`, result: { ...o, at: Date.now() } };
  }
  return { status: "failed", note: "🔎 e-prescription: καμία καρτέλα με σύνδεση (" + tabs.length + " καρτέλες)" };
};
JOB_KIND.epprobe = "🔎 e-prescription: έλεγχος κατάστασης (μόνο ανάγνωση)";
// 🔎 e-prescription: αναζήτηση στον ΚΩΔΙΚΑ της εφαρμογής (αρχεία .js του ίδιου site) — μόνο ανάγνωση, κανένας ασθενής, κανένα κλικ.
// payload.grep: κανονικές εκφράσεις (έως 8) → λίγο κείμενο κώδικα γύρω από κάθε εύρημα. Και τα πρότυπα αναζήτησης (S.tpl) της σελίδας.
JOB_RUNNERS.epgrep = async (job) => {
  const GREP = [].concat(job.payload?.grep || []).map(String).slice(0, 8);
  const tabs = await chrome.tabs.query({ url: "https://www.e-prescription.gr/*" }).catch(() => []);
  if (!tabs.length) return { status: "failed", note: "🔎 e-prescription: καμία καρτέλα" };
  const t = tabs[0]; await tabWake(t.id).catch(() => {});
  const [r] = await chrome.scripting.executeScript({ target: { tabId: t.id }, world: "MAIN", args: [GREP], func: async (GREP) => {
    const mask = (s) => String(s || "").replace(/\d{6,}/g, "#");
    const GR = GREP.map((g) => { try { return new RegExp(g, "gi"); } catch (e) { return null; } }).filter(Boolean);
    const q = [...new Set([...document.scripts].map((s) => s.src).filter((s) => s && new URL(s).origin === location.origin))], done = new Set(), grep = [], files = [];
    while (q.length && done.size < 200) { const u = q.shift(); if (done.has(u)) continue; done.add(u);
      let t = ""; try { const rr = await fetch(u, { credentials: "include" }); if (!rr.ok) continue; t = await rr.text(); } catch (e) { continue; }
      files.push(u.split("/").pop());
      for (const m of t.matchAll(/["'`]((?:\/epres)?\/_next\/static\/[A-Za-z0-9_\-\/.\[\]]+?\.js)["'`]|["'`](static\/chunks\/[A-Za-z0-9_\-\/.\[\]]+?\.js)["'`]/g)) { const p = m[1] || ("/epres/_next/" + m[2]); try { q.push(new URL(p, location.origin).href); } catch (e) {} }
      for (const m of t.matchAll(/["'`]((?:\.{0,2}\/)?(?:[\w\-]+\/)*[\w\-]+[.\-][0-9a-zA-Z_\-]{6,}\.js)["'`]/g)) { try { const x = new URL(m[1], u); if (x.origin === location.origin) q.push(x.href); } catch (e) {} }
      for (const g of GR) for (const m of t.matchAll(g)) { if (grep.length >= 60) break; const i = m.index; if (grep.some((x) => x.f === u && Math.abs(x.i - i) < 400)) continue; grep.push({ g: g.source.slice(0, 40), f: u, i, c: mask(t.slice(Math.max(0, i - 500), i + 700)).replace(/\s+/g, " ") }); }
    }
    for (const x of grep) { delete x.i; x.f = x.f.split("/").pop(); }
    return { files: files.length, grep, tpl: (window.__efEp && window.__efEp.tpl) || {} };
  } }).catch((e) => [{ result: { err: e.message } }]);
  const o = (r && r.result) || { err: "δεν απάντησε" };
  if (o.err) return { status: "failed", note: "🔎 e-prescription: " + o.err };
  return { status: "done", note: `🔎 e-prescription: ${o.files} αρχεία κώδικα · ${o.grep.length} ευρήματα · ${Object.keys(o.tpl).length} πρότυπα αναζήτησης`, result: { ...o, at: Date.now() } };
};
JOB_KIND.epgrep = "🔎 e-prescription: αναζήτηση στον κώδικα";
JOB_LIMIT_S.epgrep = 240;
// 🗺 ΑΗΦΥ: χάρτης κλήσεων της ΙΔΙΑΣ της εφαρμογής (ahfy-hook.js, μόνο μνήμη) — μόνο δομή + αν στέλνει Authorization (ναι/όχι, ΟΧΙ το κλειδί)
JOB_RUNNERS.ehrapilog = async (job) => {
  const tabs = await chrome.tabs.query({ url: "https://doctor.ehealthrecord.gov.gr/*" }).catch(() => []);
  const all = {}, tpl = {}; let n = 0, auth = false, hk = [];
  for (const t of tabs) {
    await tabWake(t.id).catch(() => {});
    const [r] = await chrome.scripting.executeScript({ target: { tabId: t.id }, world: "MAIN", func: () => { const S = window.__efAh; return S ? { log: S.log || [], tpl: S.tpl || {}, auth: !!S.h.authorization, hk: Object.keys(S.h) } : { none: true }; } }).catch(() => [{ result: { none: true } }]);
    const o = (r && r.result) || {}; if (o.none) continue;
    auth = auth || o.auth; hk = [...new Set([...hk, ...(o.hk || [])])]; Object.assign(tpl, o.tpl || {});
    for (const e of o.log || []) { n++; const k = e.m + " " + e.p; const x = all[k] || (all[k] = { m: e.m, p: e.p, auth: !!e.auth, st: {}, req: e.req || [], res: e.res || [], n: 0 }); x.n++; x.st[e.st || 0] = (x.st[e.st || 0] || 0) + 1; if ((e.res || []).length > x.res.length) x.res = e.res; if ((e.req || []).length > x.req.length) x.req = e.req; }
  }
  const calls = Object.values(all).sort((a, b) => a.p.localeCompare(b.p));
  return { status: "done", note: `🗺 ΑΗΦΥ: ${tabs.length} καρτέλες · ${n} κλήσεις · ${calls.length} διαφορετικές · Authorization: ${auth ? "ναι" : "όχι"} · κεφαλίδες: ${hk.join(", ") || "—"}`, result: { calls, tpl, auth, hk, at: Date.now() } };
};
JOB_KIND.ehrapilog = "🗺 ΑΗΦΥ: χάρτης κλήσεων";
// 🔌 ΑΗΦΥ ΑΠΕΥΘΕΙΑΣ (δοκιμή, ΣΚΙΑ — δεν αποθηκεύει τίποτα στο Παραδόχαρτο): ασθενής με ΑΜΚΑ → ehrId → πλήθος παραπεμπτικών
// εργαστηριακών + χρόνιων διαγνώσεων. Ίδια σύνδεση/κεφαλίδες με την εφαρμογή (ahfy-hook). Η πρόσβαση στον ασθενή καταγράφεται όπως
// στην εφαρμογή: αν η εφαρμογή στέλνει λόγο πρόσβασης (payload.reasonPath από τον χάρτη κλήσεων), στέλνεται ΠΡΩΤΑ ο ίδιος λόγος.
// Επιστρέφει ΜΟΝΟ πλήθη/ονόματα πεδίων/χρόνους — καμία τιμή ασθενή.
JOB_RUNNERS.ehrdirect = async (job) => {
  const p = job.payload || {};
  const am = await pdxCall("pdxComorbAmka", [job.room, job.name]).catch(() => null);
  const amka = /^\d{11}$/.test(String(am && am.r || "")) ? String(am.r) : "";
  if (!amka) return { status: "failed", note: "ehrdirect: δεν υπάρχει ΑΜΚΑ στο Παραδόχαρτο για τον ασθενή" };
  if (!p.reasonPath && !p.noReasonOk && !p.probeOnly) return { status: "failed", note: "ehrdirect: δεν έχει οριστεί πώς καταγράφεται ο λόγος πρόσβασης — δεν γίνεται απευθείας πρόσβαση χωρίς αυτόν" };
  const host = await bgEhrHostTab(); if (!host || host.err) return { status: "failed", note: host?.err || "δεν άνοιξε παράθυρο" };
  const ehr = await bgEhrTab(host); if (!ehr) return { status: "failed", note: bgEhrErr || "δεν άνοιξε ο ΑΗΦΥ" };
  if (!(await ehrLoggedIn(ehr.id))) { const lg = await ahfyAutoLogin(ehr.id); if (!lg.ok) return { status: "failed", note: "ΑΗΦΥ σύνδεση: " + lg.err }; }
  const [r] = await chrome.scripting.executeScript({ target: { tabId: ehr.id }, world: "MAIN", args: [amka, p.reasonPath || "", p.reasonQuery || {}, p.reasonBody || null, !!p.probeOnly, p.consentReason == null ? "" : String(p.consentReason), String(p.consentMethod || "GET").toUpperCase()], func: async (...A0) => { try { return await (async (amka, rPath, rQuery, rBody, probeOnly, cReason, cMethod) => {
    const AH = (window.__efAh && window.__efAh.h) || {}; const H = { accept: "application/json" }; for (const [k, v] of Object.entries(AH)) H[k] = v;
    const T = {}; const t0 = performance.now(); const lap = (k) => { T[k] = Math.round(performance.now() - t0); };
    const get = async (path, q) => { const r = await fetch(path + "?" + new URLSearchParams(q), { credentials: "include", headers: H }); let j = null; try { j = await r.json(); } catch (e) {} return { st: r.status, j }; };
    const pt = await get("/doctor/api/patient/GetPatientByAmka", { amka }); lap("patient");
    if (pt.st !== 200 || !pt.j) return { err: "GetPatientByAmka HTTP " + pt.st, auth: !!AH.authorization };
    const keys = Object.keys(pt.j);
    // 🔎 μόνο αναζήτηση (ίδιο βήμα με την αναζήτηση της οθόνης): ΟΝΟΜΑΤΑ πεδίων της απάντησης (2 επίπεδα), καμία τιμή — δείχνει αν ζητείται λόγος/συναίνεση
    const find = (o, re, d = 0) => { if (!o || typeof o !== "object" || d > 3) return null; for (const [k, v] of Object.entries(o)) { if (re.test(k) && (typeof v === "string" || typeof v === "number")) return v; const x = find(v, re, d + 1); if (x != null) return x; } return null; };
    let ehrId = find(pt.j, /^ehr_?id$/i); const pid = find(pt.j, /^(patientId|id)$/i), amkaBack = String(find(pt.j, /^amka$/i) || "");
    if (amkaBack && amkaBack !== amka) return { err: "ο ΑΜΚΑ της απάντησης δεν ταιριάζει — σταμάτησε", keys };
    // 🔐 συναίνεση/πρόσβαση: η εφαρμογή παίρνει το ehrId από το consent/Status (hasConsent + ehrId)· χωρίς συναίνεση → RequestConsent (λόγος) — ΔΕΝ το στέλνουμε εδώ
    const pidC = find(pt.j, /^patientId$/i);
    let cs = null; if (pidC != null) { cs = await get("/doctor/api/consent/Status", { patientId: pidC }); lap("consent"); }
    const csKeys = cs && cs.j && typeof cs.j === "object" ? Object.keys(cs.j) : [];
    let hasConsent = !!(cs && cs.j && cs.j.hasConsent), ehrC = cs && cs.j ? (cs.j.ehrId ?? null) : null, req = null;
    // 🩺 χωρίς ενεργή πρόσβαση: ζητείται ΟΠΩΣ στην οθόνη, με τον λόγο «Θεράπων ιατρός» (οδηγία του χρήστη: σε όλους)
    if (!hasConsent && cReason && pidC != null) {
      const rq = await fetch("/doctor/api/consent/RequestConsent?" + new URLSearchParams({ patientId: pidC, reason: cReason }), { method: cMethod, credentials: "include", headers: H }); lap("request");
      let rj = null; try { rj = await rq.json(); } catch (e) {}
      req = { st: rq.st || rq.status, keys: rj && typeof rj === "object" ? Object.keys(rj) : [], has: !!(rj && rj.hasConsent), otp: !!(rj && rj.canHaveOtpConsent && !rj.hasConsent) };
      if (rj && rj.hasConsent && rj.ehrId) { hasConsent = true; ehrC = rj.ehrId; }
      else return { err: "αίτημα πρόσβασης («Θεράπων ιατρός») HTTP " + req.st + (req.otp ? " · ζητά OTP του ασθενή" : "") + " [" + req.keys.join(",") + "]", T };
    }
    if (probeOnly && hasConsent && ehrC) {
      const lh = await get("/doctor/api/lis/LisResultsHeaders", { ehrId: ehrC, pageNo: 1, pageSize: 50 }); lap("labs");
      // όπως η καρτέλα «Διαγνώσεις» της εφαρμογής: χρόνιες ΧΩΡΙΣ σελιδοποίηση (με pageNo/pageSize → 400) + όλες οι διαγνώσεις (σελίδα 1)
      const dx = await get("/doctor/api/diagnosis/GetDiagnosisChronicPaged", { ehrId: ehrC }); lap("dx");
      const da = await get("/doctor/api/diagnosis/GetDiagnosisByFilterPaged", { ehrId: ehrC, pageNo: 1, pageSize: 100 }); lap("dxall");
      const cnt = (o) => o && (o.totalItems ?? (Array.isArray(o.items) ? o.items.length : null));
      const ik = (o) => o && Array.isArray(o.items) && o.items[0] ? Object.keys(o.items[0]).slice(0, 30) : [];
      return { ok: true, probe: true, st: pt.st, req, consent: { st: cs.st, keys: csKeys, has: true }, labs: { st: lh.st, n: cnt(lh.j), keys: lh.j ? Object.keys(lh.j) : [], ik: ik(lh.j) }, dx: { st: dx.st, n: cnt(dx.j), keys: dx.j ? Object.keys(dx.j) : [], ik: ik(dx.j) }, dxall: { st: da.st, n: cnt(da.j), ik: ik(da.j) }, T, auth: !!AH.authorization, keys: Object.keys(pt.j) };
    }
    if (ehrC) ehrId = ehrC;
    if (probeOnly) return { ok: true, probe: true, st: pt.st, consent: { st: cs && cs.st, keys: csKeys, has: hasConsent }, T, auth: !!AH.authorization, keys: Object.keys(pt.j) };
    if (!ehrId) return { err: "δεν βρέθηκε ehrId στην απάντηση", keys };
    if (rPath) { const u = rPath + (Object.keys(rQuery).length ? "?" + new URLSearchParams(Object.fromEntries(Object.entries(rQuery).map(([k, v]) => [k, String(v).replace("{ehrId}", ehrId).replace("{patientId}", pid)])) ) : "");
      const rr = await fetch(u, { method: rBody ? "POST" : "GET", credentials: "include", headers: rBody ? { ...H, "content-type": "application/json" } : H, body: rBody ? JSON.stringify(rBody).replace("{ehrId}", ehrId).replace("{patientId}", pid) : undefined }); lap("reason");
      if (!rr.ok) return { err: "λόγος πρόσβασης HTTP " + rr.status, keys }; }
    const lh = await get("/doctor/api/lis/LisResultsHeaders", { ehrId, pageNo: 1, pageSize: 50 }); lap("labs");
    const dx = await get("/doctor/api/diagnosis/GetDiagnosisChronicPaged", { ehrId }); lap("dx");
    const cnt = (o) => o && (o.totalItems ?? (o.items || []).length ?? null);
    return { ok: true, keys, labs: { st: lh.st, n: cnt(lh.j), keys: lh.j ? Object.keys(lh.j) : [] }, dx: { st: dx.st, n: cnt(dx.j), keys: dx.j ? Object.keys(dx.j) : [] }, T, auth: !!AH.authorization };
  })(...A0); } catch (e) { return { err: "σφάλμα κώδικα: " + e.message }; } } }).catch((e) => [{ result: { err: e.message } }]);
  const o = (r && r.result) || { err: "δεν απάντησε" };
  if (o.err) return { status: "failed", note: "🔌 ΑΗΦΥ απευθείας: " + o.err, result: o };
  if (o.probe) return { status: "done", note: `🔌 ΑΗΦΥ απευθείας: ασθενής ${o.st} (${o.T.patient}ms) · συναίνεση ${o.consent ? o.consent.st + (o.consent.has ? (o.req ? " ✓ δόθηκε τώρα («Θεράπων ιατρός», " + o.T.request + "ms)" : " ✓ υπάρχει") : " ✗ δεν υπάρχει") + " [" + (o.consent.keys || []).join(",") + "]" : "—"}` + (o.labs ? ` · εργαστηριακά ${o.labs.st} (${o.labs.n ?? "?"} παραπεμπτικά) · χρόνιες διαγνώσεις ${o.dx.st} (${o.dx.n ?? "?"}) · όλες οι διαγνώσεις ${o.dxall ? o.dxall.st + " (" + (o.dxall.n ?? "?") + ")" : "—"} · σύνολο ${o.T.dxall || o.T.dx}ms` : ""), result: o };
  return { status: "done", note: `🔌 ΑΗΦΥ απευθείας: ασθενής ${o.T.patient}ms · εργαστηριακά ${o.labs.st} (${o.labs.n ?? "?"} παραπεμπτικά) · χρόνιες διαγνώσεις ${o.dx.st} (${o.dx.n ?? "?"}) · σύνολο ${o.T.dx}ms`, result: o };
};
JOB_KIND.ehrdirect = "🔌 ΑΗΦΥ: απευθείας (δοκιμή σκιάς)";
JOB_LIMIT_S.ehrdirect = 180;
// 7/11 (εντολή χρήστη): πριν από νέα συνταγή/παραπεμπτικό, η ανοιχτή επίσκεψη του ΙΔΙΟΥ ασθενή «Ολοκληρώνεται» και ανοίγει καινούρια
// (οι παλιές/μισές επισκέψεις έδιναν «Τα στοιχεία της συνταγής δεν είναι έγκυρα»). Εξαίρεση: αν άλλη συνταγή του ίδιου ΑΜΚΑ περιμένει έγκριση.
async function epPendingSame(amka, id) { const r = await jobsInApp(async (amka, id) => { try { if (typeof sb6 === "undefined") return { keep: true };
  const x = await sb6.from("oncall_jobs").select("id").in("kind", ["rx", "ref"]).in("status", ["review", "approve"]).neq("id", id).eq("payload->>amka", amka).limit(1);
  return { keep: !!(x.data || []).length || !!x.error }; } catch (e) { return { keep: true }; } }, [String(amka || ""), +id || 0]).catch(() => null); return !r || !!r.keep; }
JOB_RUNNERS.rx = (job) => self.EFEpres.run(job, { epPendingSame, pdxCall, bgEmrTab, comorbAmka, sleep: E.sleep, epExpiredSwitch, epresAutoLogin, epresLoggedIn, epresHasUser, epresLastWho, epresNameScore });
// 📋 Παραπεμπτικό: ίδια ροή με τη συνταγή, ΣΤΑΜΑΤΑ πριν την «Καταχώριση» (μόνο από το κινητό, JOB_APPROVE.ref)
JOB_RUNNERS.ref = (job) => self.EFEpres.refRun(job, { epPendingSame, pdxCall, bgEmrTab, comorbAmka, sleep: E.sleep, epExpiredSwitch, epresAutoLogin, epresLoggedIn, epresHasUser, epresLastWho, epresNameScore });
JOB_KIND.ref = "📋 Παραπεμπτικό";
// 🧪 6/11: ΤΕΣΤ ΑΝΤΟΧΗΣ e-prescription — πολλοί γύροι συνταγή/παραπεμπτικό σε ΑΜΚΑ δοκιμών, με «ενοχλήσεις» ανάμεσα:
// επαναφόρτωση, αποσύνδεση (σβήσιμο cookies e-prescription του παραθύρου του bot), ξανά επιλογή μονάδας, κλείσιμο καρτέλας.
// ΣΤΑΜΑΤΑ ΠΑΝΤΑ στον έλεγχο (mode review): ΠΟΤΕ «Καταχώριση». Μία ενεργή επίσκεψη για τον ΑΜΚΑ δοκιμών (ξαναχρησιμοποιείται).
async function epClearCookies() {
  const stores = await chrome.cookies.getAllCookieStores().catch(() => []); let n = 0;
  const inc = typeof botIncogOn === "function" ? await botIncogOn().catch(() => false) : false;
  if (!inc) return 0;   // ΠΟΤΕ τα cookies του κανονικού προφίλ (του γιατρού)
  const tabs = await chrome.tabs.query({}).catch(() => []), incIds = new Set(tabs.filter((t) => t.incognito).map((t) => t.id));
  const st = stores.find((x) => inc ? (x.tabIds || []).some((id) => incIds.has(id)) : x.id === "0"); if (!st) return 0;
  for (const c of await chrome.cookies.getAll({ storeId: st.id }).catch(() => [])) { if (!/e-prescription\.gr$/i.test(String(c.domain).replace(/^\./, ""))) continue; const url = "https://" + String(c.domain).replace(/^\./, "") + (c.path || "/"); if (await chrome.cookies.remove({ url, name: c.name, storeId: st.id }).catch(() => null)) n++; }
  return n;
}
JOB_RUNNERS.eptorture = async (job) => {
  const p = job.payload || {}, me = await botId();
  if (onlyBotOf(p) !== me) return { status: "failed", note: "🧪 μόνο με στόχο συγκεκριμένο υπολογιστή" };
  const amka = String(p.amka || ""); if (!/^\d{11}$/.test(amka)) return { status: "failed", note: "🧪 χρειάζεται ΑΜΚΑ δοκιμών (11 ψηφία)" };
  if (!(typeof botIncogOn === "function" && await botIncogOn().catch(() => false))) return { status: "failed", note: "🧪 το τεστ τρέχει ΜΟΝΟ όταν το bot δουλεύει στο δικό του (ανώνυμο) παράθυρο — αλλιώς θα πείραζε τις καρτέλες του γιατρού" };
  const rounds = Math.max(1, Math.min(12, +p.rounds || 6)), t0 = Date.now(), out = [];
  const PERT = ["καμία", "επαναφόρτωση", "αποσύνδεση", "κλείσιμο καρτέλας", "επαναφόρτωση στη μέση"];
  const H = { pdxCall, bgEmrTab, comorbAmka, sleep: E.sleep, epExpiredSwitch, epresAutoLogin, epresLoggedIn, epresHasUser, epresLastWho, epresNameScore };
  for (let r = 0; r < rounds; r++) {
    if (Date.now() - t0 > (JOB_LIMIT_S.eptorture - 60) * 1000) { out.push("⏹ σταμάτησε (όριο χρόνου)"); break; }
    const pert = PERT[r % PERT.length], kind = r % 2 ? "ref" : "rx";
    let { efbotEpTab: et } = await chrome.storage.session.get("efbotEpTab").catch(() => ({}));
    if (et) { const tt = await chrome.tabs.get(et).catch(() => null); if (!tt || !tt.incognito) et = null; }   // ποτέ καρτέλα εκτός του ανώνυμου παραθύρου
    await chrome.storage.local.remove(["efbotRxOpen", "efbotRefOpen"]).catch(() => {});   // κάθε γύρος από καθαρή αρχή
    try {
      if (pert === "επαναφόρτωση" && et) { await chrome.tabs.reload(et).catch(() => {}); await E.sleep(1500); }
      if (pert === "αποσύνδεση") { await epClearCookies(); if (et) { await chrome.tabs.reload(et).catch(() => {}); await E.sleep(1500); } }
      if (pert === "κλείσιμο καρτέλας" && et) { await chrome.tabs.remove(et).catch(() => {}); await chrome.storage.session.remove("efbotEpTab").catch(() => {}); }
    } catch (e) {}
    let midT = null; if (pert === "επαναφόρτωση στη μέση") midT = setTimeout(async () => { const { efbotEpTab: e2 } = await chrome.storage.session.get("efbotEpTab").catch(() => ({})); if (e2) chrome.tabs.reload(e2).catch(() => {}); }, 6000 + Math.random() * 6000);
    const sub = { id: job.id * 100 + r, kind, name: String(p.name || ""), room: null, payload: kind === "rx"
      ? { amka, icd: ["N39"], mode: "review", test: true, meds: [{ name: "Ciproxin", strength: "500mg", dose: "1", freq: 2, days: 7, part: "25%", boxes: 0, perBox: 0, line: "Ciproxin 500mg 1x2 για 7 ημέρες" }] }
      : { amka, icd: ["N39"], mode: "review", test: true, cat: "Βιολογικών Υλικών 1", exams: ["Γενική αίματος", "Κρεατινίνη"], just: "Έλεγχος νεφρικής λειτουργίας" } };
    const a = Date.now(); let res;
    try { res = await (kind === "rx" ? self.EFEpres.run(sub, H) : self.EFEpres.refRun(sub, H)); } catch (e) { res = { status: "failed", note: String(e && e.message || e) }; }
    clearTimeout(midT);
    const ok = res && /^(review|approve|done)$/.test(res.status);
    out.push((ok ? "✅" : "❌") + " " + (r + 1) + ". " + (kind === "rx" ? "συνταγή" : "παραπεμπτικό") + " · ενόχληση: " + pert + " · " + Math.round((Date.now() - a) / 1000) + "″" + (ok ? "" : " · " + String(res && res.note || "?").slice(0, 220)));
    await imgNote(job.id, "🧪 " + (r + 1) + "/" + rounds + " · " + out.filter((x) => x[0] === "✅").length + " ✅ · " + out.filter((x) => x[0] === "❌").length + " ❌").catch(() => {});
    await E.sleep(1500);
  }
  const bad = out.filter((x) => x.startsWith("❌")).length;
  return { status: "done", note: "🧪 e-prescription ×" + out.length + ": " + (out.length - bad) + " ✅ · " + bad + " ❌ (ποτέ «Καταχώριση»)\n" + out.join("\n"), push: ["🧪 Τεστ e-prescription", (out.length - bad) + "/" + out.length + " επιτυχίες"] };
};
JOB_KIND.eptorture = "🧪 Τεστ αντοχής e-prescription";
JOB_LIMIT_S.eptorture = 1500;
JOB_LIMIT_S.ref = 420;   // ≈ 90″ + 25″ × 12 εξετάσεις (ανώτατο 12 στο refRun)
JOB_RUNNERS.rxname = (job) => self.EFEpres.lookup(job, { pdxCall, bgEmrTab, comorbAmka, sleep: E.sleep, epresAutoLogin, epresLoggedIn });
// 🔑 Έλεγχος συνδέσεων: φάκελος, ΑΗΦΥ, e-prescription, Medilabi — με τους αποθηκευμένους κωδικούς, ΧΩΡΙΣ να ανοίξει ασθενή.
// Ό,τι βρει γράφεται στη σημείωση της εντολής (και ειδοποίηση στο κινητό). Για διάγνωση από μακριά.
// 🧪 ΤΕΣΤ ΑΝΤΟΧΗΣ ΣΥΝΔΕΣΕΩΝ (μόνο σύνδεση/ανάγνωση — κανένας ασθενής, κανένα κουμπί καταχώρισης).
// Κάθε γύρος: (από τον 2ο) πλήρης «αποσύνδεση» του bot = σβήσιμο ΟΛΩΝ των cookies του ΑΝΩΝΥΜΟΥ παραθύρου του bot (δεν αγγίζει
// τα κανονικά παράθυρα των γιατρών) → μετά σύνδεση σε κάθε σύστημα με χρονομέτρηση. Έτσι δοκιμάζεται το σενάριο «έκλεισε το
// παράθυρο / έληξε η σύνδεση». payload: {rounds: 1..5, only: "emr|ehr|ep|evo|med"}.
async function botIncogClearCookies() {
  const stores = await chrome.cookies.getAllCookieStores().catch(() => []);
  const inc = new Set((await chrome.tabs.query({}).catch(() => [])).filter((t) => t.incognito).map((t) => t.id));
  const st = stores.find((x) => (x.tabIds || []).some((id) => inc.has(id)));
  if (!st) return { n: 0, err: "δεν υπάρχει ανώνυμο παράθυρο του bot" };
  const cs = await chrome.cookies.getAll({ storeId: st.id }).catch(() => []);
  let n = 0;
  for (const c of cs) { const url = (c.secure ? "https://" : "http://") + String(c.domain).replace(/^\./, "") + (c.path || "/"); if (await chrome.cookies.remove({ url, name: c.name, storeId: st.id }).catch(() => null)) n++; }
  return { n };
}
JOB_RUNNERS.selftest = async (job) => {
  const p = job.payload || {}, rounds = Math.max(1, Math.min(5, +p.rounds || 3)), only = String(p.sys || (onlyBotOf(p) ? "" : p.only) || "emr|ehr|ep|evo|med");   // p.only = υπολογιστής (στόχευση) → τα συστήματα στο p.sys
  const lim = (pr, ms, what) => Promise.race([pr, new Promise((r) => setTimeout(() => r({ ok: false, err: what + ": δεν απάντησε σε " + Math.round(ms / 1000) + "″" }), ms))]);
  const res = { emr: [], ehr: [], ep: [], evo: [], med: [] };
  const NAME = { emr: "📁 ΝΠΣ", ehr: "🩺 ΑΗΦΥ", ep: "💊 e-prescription", evo: "🩻 Evorad", med: "🧪 Medilabi" };
  const run = async (k, fn) => { if (!only.includes(k)) return; const t = Date.now(); let r; try { r = await fn(); } catch (e) { r = { ok: false, err: e.message }; } res[k].push({ ok: !!r.ok, s: Math.round((Date.now() - t) / 100) / 10, err: r.ok ? "" : String(r.err || "").slice(0, 220) }); };
  const cleared = [];
  for (let i = 0; i < rounds; i++) {
    if (jobAbortId) break;
    imgNote(job.id, "🧪 γύρος " + (i + 1) + "/" + rounds + " · " + Math.round(i / rounds * 100) + "%");
    // πραγματική «αποσύνδεση»: κλείνουν ΟΛΑ τα ανώνυμα παράθυρα του bot (το Chrome σβήνει τότε όλη την ανώνυμη συνεδρία)
    // + cookies για σιγουριά → ο επόμενος γύρος ξεκινά από το μηδέν, όπως όταν κάποιος κλείσει το παράθυρο του bot
    if (i > 0) {
      const ck = await botIncogClearCookies();
      const ws = (await chrome.windows.getAll({ windowTypes: ["normal"] }).catch(() => [])).filter((w) => w.incognito);
      for (const w of ws) await chrome.windows.remove(w.id).catch(() => {});
      await chrome.storage.session.remove(["efbotEpTab", "efbotOrderPrep", "efbotFormOpen"]).catch(() => {});
      await E.sleep(2500);
      cleared.push({ cookies: ck.n, windows: ws.length });
    }
    let emr = null;
    await run("emr", async () => { emr = await bgEmrTab(); if (!emr || emr.err) return { ok: false, err: emr?.err || "δεν άνοιξε" }; return lim(bgEnsureLogin(emr.id), 100000, "ΝΠΣ"); });
    await run("ehr", async () => {
      if (!emr || emr.err) return { ok: false, err: "χωρίς ΝΠΣ" };
      for (let w = 0; w < 30 && comorbBusy; w++) await E.sleep(2000);
      const ehr = await bgEhrTab(emr).catch(() => null); if (!ehr) return { ok: false, err: bgEhrErr || "δεν άνοιξε" };
      if (await ehrLoggedIn(ehr.id)) return { ok: true };
      return lim(ahfyAutoLogin(ehr.id), 130000, "ΑΗΦΥ");
    });
    await run("ep", () => lim(self.EFEpres.loginCheck({ sleep: E.sleep, epresAutoLogin }), 130000, "e-prescription"));
    await run("evo", async () => { const r = await lim(JOB_RUNNERS.evoradprobe({ id: 0, payload: {} }), 90000, "Evorad"); const n = String(r.note || r.err || ""); return { ok: r.status === "done" && !/✗/.test(n), err: n.slice(0, 200) }; });
    await run("med", async () => { for (let w = 0; w < 60 && labsBusy; w++) await E.sleep(1000); await lim(labsTick(true), 120000, "Medilabi"); const st = (await chrome.storage.session.get("efbotLabs")).efbotLabs || {}; const m = String(st.lastMsg || ""); return { ok: !!m && !/Σφάλμα|σύνδεση|Ανοίξτε|κενή|απέτυχε|συμπληρώστε/i.test(m), err: m.slice(0, 200) }; });
  }
  const lines = Object.entries(res).filter(([, v]) => v.length).map(([k, v]) => {
    const ok = v.filter((x) => x.ok).length, ss = v.filter((x) => x.ok).map((x) => x.s), avg = ss.length ? Math.round(ss.reduce((a, b) => a + b, 0) / ss.length) : 0;
    const errs = [...new Set(v.filter((x) => !x.ok).map((x) => x.err))];
    return NAME[k] + ": " + ok + "/" + v.length + (avg ? " · ~" + avg + "″" : "") + (errs.length ? " · ✗ " + errs.join(" | ") : "");
  });
  const fails = Object.values(res).flat().filter((x) => !x.ok).length;
  return { status: "done", note: "🧪 Τεστ συνδέσεων (" + rounds + " γύροι" + (cleared.length ? ", πλήρης αποσύνδεση πριν από κάθε γύρο" : "") + ")\n" + lines.join("\n"), result: { res, cleared, rounds },
    push: ["🧪 Τεστ συνδέσεων: " + (fails ? fails + " αποτυχίες" : "όλα ✓"), lines.map((x) => x.slice(0, 90)).join("\n")] };
};
JOB_KIND.selftest = "🧪 Τεστ συνδέσεων";
// 🔎 8/11: έλεγχος ΚΑΘΕ αποθηκευμένου λογαριασμού e-prescription σε αυτόν τον υπολογιστή (μία είσοδος ο καθένας, καμία ενέργεια σε ασθενή):
// ✓ μπαίνει · ⏳ «ο κωδικός έχει λήξει» (το ίδιο το e-prescription ζητά αλλαγή) · ✗ απορρίφθηκε. Χωρίς ειδοποιήσεις στο κινητό.
// Λογαριασμός που απορρίφθηκε ΣΗΜΕΡΑ ως «λάθος» δεν ξαναδοκιμάζεται (κίνδυνος κλειδώματος) εκτός αν payload.force.
JOB_RUNNERS.epaccs = async (job) => {
  const p = job.payload || {};
  const tab = await self.EFEpres.epTab(); if (!tab || tab.err) return { status: "failed", note: "🔎 e-prescription: " + ((tab && tab.err) || "δεν άνοιξε") };
  const { efbotCredByHost: all = {} } = await V.get("efbotCredByHost");
  const given = [].concat(all["*epres"] || []).filter((a) => a && a.user && a.pass);
  const src = given.length ? given : Object.entries(all).filter(([k]) => /^\*ahfy$|prescription/i.test(k)).flatMap(([, v]) => [].concat(v || [])).filter((a) => a && a.user && a.pass);
  const users = [...new Set(src.map((a) => String(a.user)))].filter((u) => !p.users || [].concat(p.users).map((x) => String(x).toLowerCase()).includes(u.toLowerCase())).slice(0, 8);
  if (!users.length) return { status: "failed", note: "🔎 e-prescription: κανένας αποθηκευμένος λογαριασμός σε αυτόν τον υπολογιστή" };
  const out = [], res = [];
  credPushMute = true;
  try {
    for (const u of users) {
      const ul = u.toLowerCase();
      let { efbotEpresBad: bad = {} } = await chrome.storage.session.get("efbotEpresBad");
      const badK = Object.keys(bad).filter((k) => k.split("|")[1] && k.split("|")[1].toLowerCase() === ul);
      if (badK.length && !p.force && !(await epExpiredList()).includes(ul)) { out.push("• " + u + ": — απορρίφθηκε ήδη σήμερα, δεν ξαναδοκιμάστηκε (να μην κλειδώσει)"); res.push({ u, st: "skip" }); continue; }
      for (const k of badK) delete bad[k]; await chrome.storage.session.set({ efbotEpresBad: bad });
      await epCookieReset(tab.id);
      let ready = "";   // πραγματική νέα σελίδα εισόδου (ορατό πεδίο κωδικού), όχι η παλιά σελίδα πριν φορτώσει
      for (let i = 0; i < 40 && !ready; i++) { await new Promise((r) => setTimeout(r, 1000)); try { const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => { const pw = [...document.querySelectorAll("input[type=password]")].some((e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; }); return document.readyState !== "complete" ? "" : pw ? "form" : document.querySelector("a[href='/epres/patient']") ? "" : "out"; } }); ready = (r && r.result) || ""; if (ready === "out" && i < 4) ready = ""; } catch (e) {} }   // «out»: αποσυνδεδεμένη αρχική σελίδα (π.χ. κουμπί «Είσοδος») — τη χειρίζεται η αυτόματη σύνδεση
      if (!ready) { out.push("• " + u + ": — η σελίδα εισόδου δεν εμφανίστηκε μετά το καθάρισμα (δεν δοκιμάστηκε)"); res.push({ u, st: "noform" }); continue; }
      const t0 = Date.now();
      const lg = await Promise.race([epresAutoLogin(tab.id, "", { only: u }), new Promise((r) => setTimeout(() => r({ ok: false, err: "δεν απάντησε σε 130″" }), 130000))]).catch((e) => ({ ok: false, err: e.message }));
      let txt = ""; try { const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => String(document.body && document.body.innerText || "").replace(/\s+/g, " ").replace(/\d{5,}/g, "#").trim().slice(0, 160) }); txt = (r && r.result) || ""; } catch (e) {}
      const exp = /λήξει|expired/i.test(String(lg.err || "")) || /κωδικ\S*\s+πρόσβασ\S*.{0,40}έχει\s+λήξει/i.test(txt);
      const st = lg.ok && !exp ? "ok" : exp ? "expired" : "fail";
      if (st === "ok") { const l = (await epExpiredList()).filter((x) => x !== ul); await chrome.storage.session.set({ efbotEpExpired: { d: new Date().toDateString(), u: l } }).catch(() => {}); }
      out.push("• " + u + ": " + (st === "ok" ? "✓ μπαίνει" : st === "expired" ? "⏳ το e-prescription λέει «ο κωδικός πρόσβασής σας έχει λήξει» — θέλει ΑΛΛΑΓΗ από τον γιατρό (ο κωδικός δεν είναι λάθος)" : "✗ " + String(lg.err || "").slice(0, 200)) + " · " + Math.round((Date.now() - t0) / 1000) + "″");
      res.push({ u, st, err: String(lg.err || "").slice(0, 300), page: txt });
    }
  } finally { credPushMute = false; }
  // επαναφορά: κανονική σύνδεση με τον πρώτο λογαριασμό που δουλεύει
  await epCookieReset(tab.id); await new Promise((r) => setTimeout(r, 5000));
  const back = await epresAutoLogin(tab.id, "").catch((e) => ({ ok: false, err: e.message }));
  out.push("↩ επαναφορά: " + (back.ok ? "✓ " + (back.who || "") : "✗ " + String(back.err || "").slice(0, 120)));
  return { status: "done", note: "🔎 Λογαριασμοί e-prescription σε αυτόν τον υπολογιστή:\n" + out.join("\n"), result: { accs: res, at: Date.now() } };
};
JOB_KIND.epaccs = "🔎 e-prescription: έλεγχος κάθε λογαριασμού (μόνο σύνδεση)";
// 🗓 8/11: «Υποβολή» προγράμματος χειρουργείου από το Παραδόχαρτο → .xlsx στον φάκελο δικτύου (ΠΡΟΓΡΑΜΜΑ ΧΕΙΡΟΥΡΓΕΙΟΥ\<ΜΗΝΑΣ>)
// + εκτύπωση στον εκτυπωτή A4 (payload.printer, π.χ. «Lexmark MX530 Series XL»). Τα x/h είναι κρυπτογραφημένα με το κλειδί κλινικής (iv|ct base64).
JOB_RUNNERS.orsubmit = async (job) => {
  const p = job.payload || {};
  if (!p.x || !p.dir || !p.name) return { status: "failed", note: "🗓 λείπουν στοιχεία" };
  const plain = !!(p.dry && p.plainx);   // μόνο ΔΟΚΙΜΗ εγγραφής (γράφει & σβήνει προσωρινό): χωρίς κρυπτογράφηση
  let ck = null; if (!plain) { try { ck = await imgClinicKey(); } catch (e) { return { status: "failed", note: "🔐 " + e.message, env: true }; } }
  const dk = plain ? null : await crypto.subtle.importKey("raw", ck.raw, "AES-GCM", false, ["decrypt"]);
  const open = async (b) => { if (plain) return b64d(b); const u = b64d(b); return new Uint8Array(await crypto.subtle.decrypt({ name: "AES-GCM", iv: u.slice(0, 12) }, dk, u.slice(12))); };
  let xb, hb = null;
  try { xb = await open(p.x); if (p.h) hb = new TextDecoder().decode(await open(p.h)); } catch (e) { return { status: "failed", note: "🔐 δεν ανοίγει (άλλο κλειδί;)" }; }
  if (xb[0] !== 0x50 || xb[1] !== 0x4b) return { status: "failed", note: "🗓 το αρχείο δεν είναι .xlsx" };
  const out = [];
  const w = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "orsave", dir: String(p.dir), name: String(p.name), b64: b64e(xb), overwrite: !!p.overwrite, dry: !!p.dry }).catch((e) => ({ ok: false, err: e.message }));
  if (!w || !w.ok) return { status: "failed", note: "🗓 Excel: " + ((w && w.err) || "το βοηθητικό των Windows δεν απάντησε (θέλει ενημέρωση;)") };
  out.push("📄 " + (w.dry ? "δοκιμή εγγραφής ✓ " : "") + p.dir + "\\" + w.name);
  let printed = "";
  if (hb && p.print !== false && !p.dry) {
    const r = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "printhtml", html: hb, printer: String(p.printer || "") }).catch((e) => ({ ok: false, err: e.message }));
    printed = r && r.ok ? "🖨 " + (r.printer || "εκτυπωτής") : "⚠ εκτύπωση: " + ((r && r.err) || "χωρίς απάντηση");
    out.push(printed);
  }
  return { status: "done", note: "🗓 " + out.join(" · "), result: { name: w.name, path: w.path, printed, at: Date.now() } };
};
JOB_KIND.orsubmit = "🗓 Πρόγραμμα χειρουργείου: Excel στο δίκτυο + εκτύπωση";
// 🎤 8/11: υπαγόρευση (Whisper σε ΑΥΤΟΝ τον υπολογιστή): payload.a = WAV 16 kHz κρυπτογραφημένο με το κλειδί κλινικής (iv|ct base64)
// → κείμενο, ΚΡΥΠΤΟΓΡΑΦΗΜΕΝΟ πίσω (result.enc). Ο ήχος δεν μένει πουθενά (το βοηθητικό σβήνει το προσωρινό αρχείο).
JOB_RUNNERS.stt = async (job) => {
  const p = job.payload || {};
  if (!p.a) return { status: "failed", note: "🎤 χωρίς ήχο" };
  let ck; try { ck = await imgClinicKey(); } catch (e) { return { status: "failed", note: "🔐 " + e.message, env: true }; }
  let wav; try { const dk = await crypto.subtle.importKey("raw", ck.raw, "AES-GCM", false, ["decrypt"]); const u = b64d(p.a); wav = new Uint8Array(await crypto.subtle.decrypt({ name: "AES-GCM", iv: u.slice(0, 12) }, dk, u.slice(12))); }
  catch (e) { return { status: "failed", note: "🔐 ο ήχος δεν ανοίγει" }; }
  const r = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "stt", b64: b64e(wav), prompt: String(p.prompt || "").slice(0, 400) }).catch((e) => ({ ok: false, err: e.message }));
  if (!r || !r.ok) return { status: "failed", note: "🎤 " + ((r && r.err) || "χωρίς απάντηση"), env: /δεν έχει εγκατασταθεί/.test((r && r.err) || "") };
  let enc; try { enc = await fsSealJson({ text: r.text, secs: r.secs }); } catch (e) { return { status: "failed", note: "🔐 " + e.message }; }
  return { status: "done", note: "🎤 μεταγραφή " + String(r.text || "").length + " χαρακτήρες σε " + r.secs + "″", result: { enc, n: String(r.text || "").length, secs: r.secs, at: Date.now() } };
};
JOB_KIND.stt = "🎤 Υπαγόρευση (Whisper)";
JOB_RUNNERS.logins = async () => {
  const lim = (p, ms, what) => Promise.race([p, new Promise((r) => setTimeout(() => r({ ok: false, err: what + ": δεν απάντησε σε " + Math.round(ms / 1000) + "″" }), ms))]);
  const out = [];
  // 📁 Ιατρικός φάκελος
  const emr = await bgEmrTab().catch((e) => ({ err: e.message }));
  if (!emr || emr.err) out.push("📁 Φάκελος: ✗ " + (emr?.err || "δεν άνοιξε"));
  else {
    const r = await lim(bgEnsureLogin(emr.id), 90000, "φάκελος").catch((e) => ({ ok: false, err: e.message }));
    const shm = (await sharedGet())?.tabId === emr.id ? " (κοινό παράθυρο με φύλαξη)" : "";
    out.push("📁 Φάκελος: " + (r.ok ? "✓ συνδεδεμένος" + shm : "✗ " + r.err));
  }
  // 🩺 ΑΗΦΥ (στο ίδιο παράθυρο με τον φάκελο, όπως οι κανονικές εντολές)
  if (!emr || emr.err) out.push("🩺 ΑΗΦΥ: — δεν δοκιμάστηκε (ίδιος λόγος με τον φάκελο)");
  else {
    for (let i = 0; i < 60 && comorbBusy; i++) await E.sleep(2000);
    if (comorbBusy) out.push("🩺 ΑΗΦΥ: — απασχολημένο (τρέχει αυτόματη αναζήτηση)");
    else {
      const ehr = await bgEhrTab(emr).catch(() => null);
      if (!ehr) out.push("🩺 ΑΗΦΥ: ✗ " + (bgEhrErr || "δεν άνοιξε"));
      else if (await ehrLoggedIn(ehr.id)) out.push("🩺 ΑΗΦΥ: ✓ ήταν ήδη συνδεδεμένος");
      else {
        const r = await lim(ahfyAutoLogin(ehr.id), 130000, "ΑΗΦΥ").catch((e) => ({ ok: false, err: e.message }));
        out.push("🩺 ΑΗΦΥ: " + (r.ok ? "✓ μπήκε" + (r.who ? " (" + r.who + ")" : "") : "✗ " + r.err));
      }
    }
  }
  // 💊 e-prescription
  {
    const r = await lim(self.EFEpres.loginCheck({ sleep: E.sleep, epresAutoLogin }), 130000, "e-prescription").catch((e) => ({ ok: false, err: e.message }));
    out.push("💊 e-prescription: " + (r.ok ? "✓ " + r.how + (r.doctor && !String(r.how).includes(r.doctor) ? " · " + r.doctor : "") : "✗ " + r.err));
  }
  // 🧪 Medilabi (ένας πλήρης έλεγχος, όπως το «Φέρε τώρα»)
  {
    for (let i = 0; i < 60 && labsBusy; i++) await E.sleep(1000);
    await lim(labsTick(true), 120000, "Medilabi").catch(() => {});
    const st = (await chrome.storage.session.get("efbotLabs")).efbotLabs || {};
    const msg = String(st.lastMsg || "χωρίς απάντηση");
    const bad = /Σφάλμα|σύνδεση|Ανοίξτε|κενή|δεν στάλθηκαν|απέτυχε|συμπληρώστε/i.test(msg);
    out.push("🧪 Medilabi: " + (bad ? "✗ " : "✓ ") + msg.slice(0, 200));
  }
  const fails = out.filter((x) => / ✗ /.test(x)).length;
  return { status: "done", note: out.join("\n"), push: ["🔑 Έλεγχος συνδέσεων: " + (fails ? fails + " με πρόβλημα" : "όλα ✓"), out.map((x) => x.slice(0, 90)).join("\n")] };
};

// ===== 🔐 Κωδικοί από απόσταση, κρυπτογραφημένοι άκρη-σε-άκρη =====
// Ο υπολογιστής του νοσοκομείου φτιάχνει ζεύγος κλειδιών RSA-OAEP 3072. Το ιδιωτικό μένει ΜΟΝΟ εδώ, μέσα στο «χρηματοκιβώτιο»
// (AES-GCM, κλειδί κλειδωμένο από τα Windows/DPAPI). Το δημόσιο δημοσιεύεται στη βάση (oncall_labs «efbot|xfer»).
// Το Παραδόχαρτο (διαχειριστής) κρυπτογραφεί όνομα+κωδικό ΣΤΗ ΣΥΣΚΕΥΗ του με το δημόσιο κλειδί και στέλνει εντολή «cred».
// Η βάση βλέπει μόνο κρυπτογραφημένο κείμενο· μόλις αποθηκευτεί εδώ, σβήνεται και από τη βάση.
// Χωρίς DPAPI (π.χ. Mac/χωρίς βοηθητικό) η λειτουργία ΔΕΝ ενεργοποιείται: το ιδιωτικό κλειδί δεν μένει ποτέ ακρυπτογράφητο.
const b64e = (u8) => { let s = ""; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); };
const b64d = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
async function xferFingerprint(jwk) {
  const h = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(jwk.n + "." + jwk.e)));
  return [...h.slice(0, 8)].map((b) => b.toString(16).padStart(2, "0")).join("").toUpperCase().replace(/(.{4})(?=.)/g, "$1-");
}
let xferAt = 0;
let xferLease = false;
async function xferPublish() {
  if (Date.now() - xferAt < 30 * 60000) return;
  xferAt = Date.now();
  try {
    const st = await V.status().catch(() => ({ mode: "?" }));
    let pub = null, fp = "", err = "";
    if (st.mode !== "dpapi") err = "χρειάζεται το βοηθητικό των Windows (κρυπτογράφηση κωδικών) στον υπολογιστή του bot";
    else {
      let { efbotXferKey: k } = await V.get("efbotXferKey");
      if (!k || !k.priv || !k.pub) {
        const kp = await crypto.subtle.generateKey({ name: "RSA-OAEP", modulusLength: 3072, publicExponent: new Uint8Array([1, 0, 1]), hash: "SHA-256" }, true, ["encrypt", "decrypt"]);
        k = { priv: await crypto.subtle.exportKey("jwk", kp.privateKey), pub: await crypto.subtle.exportKey("jwk", kp.publicKey), at: Date.now() };
        await V.set({ efbotXferKey: k });
      }
      pub = { kty: k.pub.kty, n: k.pub.n, e: k.pub.e, alg: "RSA-OAEP-256", ext: true };
      fp = await xferFingerprint(pub);
    }
    await jobsInApp(async (data) => {
      try { if (typeof sb6 === "undefined" || !(await sb6.auth.getSession()).data.session) return { skip: true };
        await sb6.from("oncall_labs").upsert({ name_key: "efbot|xfer", name: "ef-bot", pid: null, data, updated_at: new Date().toISOString() }, { onConflict: "name_key" }); return { ok: true };
      } catch (e) { return { err: String(e) }; }
    }, [{ pub, fp, err, at: Date.now() }]);
  } catch (e) { xferAt = 0; }
}
const CRED_SYS = { pdx: "Παραδόχαρτο", emr: "ΝΠΣ / ιατρικός φάκελος", ahfy: "ΑΗΦΥ", epres: "e-prescription", medilabi: "Medilabi", evorad: "Evorad PACS", kerio: "Kerio (email κλινικής)" };
JOB_RUNNERS.cred = async (job) => {
  const p = job.payload || {};
  const fail = (note) => ({ status: "failed", note, wipe: true });
  if (!p.enc || !p.enc.wk || !p.enc.iv || !p.enc.ct) return fail("κενή εντολή");
  const { efbotXferKey: k } = await V.get("efbotXferKey");
  if (!k || !k.priv) return fail("ο υπολογιστής δεν έχει κλειδί — ξαναστείλτε σε λίγο");
  let o;
  try {
    const priv = await crypto.subtle.importKey("jwk", k.priv, { name: "RSA-OAEP", hash: "SHA-256" }, false, ["decrypt"]);
    const raw = new Uint8Array(await crypto.subtle.decrypt({ name: "RSA-OAEP" }, priv, b64d(p.enc.wk)));
    const ak = await crypto.subtle.importKey("raw", raw, "AES-GCM", false, ["decrypt"]);
    o = JSON.parse(new TextDecoder().decode(await crypto.subtle.decrypt({ name: "AES-GCM", iv: b64d(p.enc.iv) }, ak, b64d(p.enc.ct))));
  } catch (e) { return fail("δεν ανοίγει (στάλθηκε με παλιό κλειδί;) — ξαναστείλτε"); }
  const sys = String(o.sys || ""), user = String(o.user || "").trim(), pass = String(o.pass || "");
  if (!CRED_SYS[sys] || !user || !pass) return fail("ελλιπή στοιχεία");
  if (!(o.ts > Date.now() - 2 * 864e5 && o.ts < Date.now() + 10 * 60000)) return fail("παλιά εντολή — ξαναστείλτε");
  const hostsToPut = [];
  const put = (h) => hostsToPut.push(h);
  const patch = {};
  if (sys === "emr") {
    put("login.e-ygeia.gov.gr");
    patch.efbotEmrCred = { pass, ts: Date.now() };
    const { efbot } = await chrome.storage.local.get("efbot");
    if (efbot) { efbot.settings = efbot.settings || {}; efbot.settings.emrUser = user; await chrome.storage.local.set({ efbot }); }
    await chrome.storage.session.remove("efbotEmrLoginBad");
  } else if (sys === "ahfy") { put("*ahfy"); await chrome.storage.session.remove("efbotAhfyBad"); }
  else if (sys === "epres") { put("*epres"); await chrome.storage.session.remove("efbotEpresBad"); }
  else if (sys === "pdx") { const r = await pdxCredSave(user, pass, "remote"); if (!r.ok) return fail("δεν αποθηκεύτηκε: " + (r.err || "χρειάζεται το βοηθητικό των Windows")); }
  else if (sys === "medilabi") { patch.efbotLabsCred = { user, pass, ts: Date.now() }; await chrome.storage.session.remove("efbotLabsLoginTry"); }
  else if (sys === "evorad") { put("*evorad"); }
  else if (sys === "kerio") { const { efbot } = await chrome.storage.local.get("efbot"); put(String(efbot?.settings?.kerioHost || "mail").toLowerCase()); }
  let sv = { ok: true };
  if (hostsToPut.length) sv = await V.update("efbotCredByHost", (all0) => {
    const all = all0 && typeof all0 === "object" ? all0 : {};
    for (const h of hostsToPut) { const v = all[h], l = (Array.isArray(v) ? v : v ? [v] : []).filter((a) => String(a.user || "").toLowerCase() !== user.toLowerCase()); l.unshift({ user, pass, ts: Date.now(), remote: true }); all[h] = l.slice(0, 8); }
    return all;
  }).catch((e) => ({ ok: false, err: e.message }));
  if (sv.ok && Object.keys(patch).length) sv = await V.set(patch).catch((e) => ({ ok: false, err: e.message }));
  if (!sv.ok) return fail("δεν αποθηκεύτηκε: " + (sv.err || "σφάλμα") + " — ξαναστείλτε σε 1′");
  chrome.storage.local.set({ efbotCredNew: Date.now() }).catch(() => {});   // 🔀 να περάσει ΑΜΕΣΩΣ και στους άλλους υπολογιστές
  if (o.auto) {   // «δικός μου» λογαριασμός: ανανεώνεται μόνος του όταν συνδέομαι κανονικά σε αυτόν τον υπολογιστή
    const { efbot } = await chrome.storage.local.get("efbot");
    if (efbot) { efbot.settings = efbot.settings || {}; const l = new Set((efbot.settings.credAuto || []).map(String)); l.add(user); efbot.settings.credAuto = [...l].slice(0, 12); await chrome.storage.local.set({ efbot }); }
  }
  notify("🔐 Νέος κωδικός από απόσταση", CRED_SYS[sys] + " · χρήστης " + user + " (κρυπτογραφημένα)", false);
  // 📧 Kerio: δοκιμή σύνδεσης ΑΜΕΣΩΣ (χωρίς αποστολή) — ο γιατρός βλέπει στο κινητό αν δούλεψε και αν βρέθηκε η ομάδα
  let kchk = "";
  if (sys === "kerio") { try { const r = await JOB_RUNNERS.kmail({ id: 0, kind: "kmail", payload: { dry: true, test: true } }); kchk = " · " + String(r.note || "").replace(/^📧\s*/, "") + (r.status === "done" && r.result && !r.result.group && (r.result.groups || []).length ? " (ομάδες: " + r.result.groups.slice(0, 8).join(", ") + ")" : ""); } catch (e) { kchk = " · έλεγχος Kerio: " + e.message; } }
  return { status: "done", note: "🔐 αποθηκεύτηκε: " + CRED_SYS[sys] + " · χρήστης " + user + (o.auto ? " · ανανεώνεται μόνος του" : "") + kchk, wipe: true,
    push: ["🔐 Κωδικός αποθηκεύτηκε", CRED_SYS[sys] + " · " + user + " — στον υπολογιστή του νοσοκομείου"] };
};

// ⚡ Έξυπνη αναμονή (αντί για σταθερό E.sleep): επιστρέφει μόλις ΟΛΑ τα πλαίσια της καρτέλας είναι έτοιμα —
// readyState complete, κανένα αίτημα PrimeFaces/jQuery σε εξέλιξη και καμία αλλαγή στη σελίδα για QUIET ms.
// Ανώτατο όριο = η παλιά σταθερή αναμονή → ποτέ πιο αργό από πριν. Ο χρόνος που κερδίζεται μετριέται (bgTime).
const BG_QUIET = 150;
async function bgSettle(tabId, maxMs) {
  const t0 = Date.now();
  if (!tabId) { await E.sleep(maxMs); return; }
  await E.sleep(60);
  while (Date.now() - t0 < maxMs) {
    const r = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, args: [BG_QUIET], func: (quiet) => {
      try {
        if (!window.__efMut) { window.__efMut = Date.now(); new MutationObserver(() => { window.__efMut = Date.now(); }).observe(document.documentElement || document, { subtree: true, childList: true, attributes: true, characterData: true }); }
        let busy = document.readyState !== "complete";
        try { if (window.PrimeFaces && PrimeFaces.ajax && PrimeFaces.ajax.Queue && !PrimeFaces.ajax.Queue.isEmpty()) busy = true; } catch (e) {}
        try { if (window.jQuery && jQuery.active > 0) busy = true; } catch (e) {}
        return busy || Date.now() - window.__efMut < quiet ? 0 : 1;
      } catch (e) { return 1; }
    } }).catch(() => null);
    if (r && r.length && r.every((x) => !x || x.result !== 0)) break;
    await E.sleep(70);
  }
  bgTime.saved += Math.max(0, maxMs - (Date.now() - t0));
}
// ⏱ μετρητής χρόνου εργασίας: βήματα με διάρκεια, σταθερές αναμονές, κέρδος από τις έξυπνες αναμονές
const bgTime = { t0: 0, saved: 0, marks: [] };
function bgMark(label) { if (!bgTime.t0) return; const now = Date.now(); const last = bgTime.marks.length ? bgTime.marks[bgTime.marks.length - 1].at : bgTime.t0; bgTime.marks.push({ l: String(label).slice(0, 70), ms: now - last, at: now }); }
// 🧹 Πριν ανοίξει ασθενή: ό,τι άφησε ανοιχτό η προηγούμενη εργασία (παράθυρα PrimeFaces, πλαίσιο Medilabi, φόρμα)
// κρύβει τη λίστα ασθενών → η επόμενη εργασία κολλούσε ως 120″. Κλείνουμε τα παράθυρα· αν μένει κάτι, πίσω στην αρχική του φακέλου.
// 🔬 ΚΑΤΑΓΡΑΦΗ ΑΙΤΗΜΑΤΩΝ ΝΠΣ (μόνο ανάγνωση) — για να φτιαχτούν «απευθείας» βήματα χωρίς κλικ.
// Βάζει «αυτί» στα XMLHttpRequest/fetch της σελίδας (κύρια + πλαίσια) και κρατά: διεύθυνση, μέθοδο, ΟΝΟΜΑΤΑ παραμέτρων και
// τιμές μόνο αν είναι τεχνικές (id στοιχείων PrimeFaces, event, execute/render)· αριθμοί ≥5 ψηφίων και ονόματα κρύβονται.
async function netHook(tabId) {
  await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, world: "MAIN", func: () => {
    if (window.__efNetOn) return; window.__efNetOn = true; window.__efNet = window.__efNet || [];
    const mask = (v) => { v = String(v == null ? "" : v); if (/\d{5,}/.test(v)) return "•"; if (v.length > 80) return v.slice(0, 40) + "…(" + v.length + ")"; if (/^[A-ZΑ-Ω][A-ZΑ-Ω .'-]{3,}$/.test(v)) return "‹όνομα›"; return v; };
    const parse = (b) => { const o = {}; try { if (typeof b === "string") for (const [k, v] of new URLSearchParams(b)) o[k] = /ViewState/i.test(k) ? "‹vs " + String(v).length + "›" : mask(v); } catch (e) {} return o; };
    const X = XMLHttpRequest.prototype, open0 = X.open, send0 = X.send;
    X.open = function (m, u) { this.__ef = { m, u: String(u).replace(/\d{6,}/g, "•"), t: performance.now() }; return open0.apply(this, arguments); };
    X.send = function (b) { const r = this.__ef; if (r) { r.p = parse(b); r.at = Date.now(); r.where = location.pathname; this.addEventListener("loadend", () => { r.ms = Math.round(performance.now() - r.t); r.st = this.status; r.len = (this.responseText || "").length; r.upd = ((this.responseText || "").match(/<update id="([^"]+)"/g) || []).slice(0, 12).map((x) => x.slice(12, -1)); window.__efNet.push(r); }); } return send0.apply(this, arguments); };
  } }).catch(() => {});
}
async function netDump(tabId) {
  const r = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, world: "MAIN", func: () => { const a = window.__efNet || []; window.__efNet = []; return { where: location.pathname, a }; } }).catch(() => []);
  return (r || []).map((x) => x && x.result).filter((x) => x && x.a && x.a.length);
}
async function bgEmrClean(tabId, force) {
  // Η λίστα ασθενών φαίνεται ήδη και δεν υπάρχει ανοιχτός διάλογος: το ξαναφόρτωμα (μέσος 5,8″, έως 121″) δεν χρειάζεται
  if (force === true && (await bgEmrListVis(tabId)) === 1) {
    const dlg = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: () => [...document.querySelectorAll(".ui-dialog")].some((e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; }) || /medilabi/i.test(location.href) }).catch(() => []);
    if (!(dlg || []).some((x) => x && x.result)) return false;
  }
  const look = async () => ((await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: () => {
    const v = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    if (/medilabi/i.test(location.href)) return "medilabi";
    if (location.pathname !== "/" && !/\/emr-ui\//.test(location.pathname) && window.top === window) return "other";
    return [...document.querySelectorAll(".ui-dialog")].some(v) ? "dialog" : "";
  } }).catch(() => [])) || []).map((x) => x && x.result).filter(Boolean);
  let left = force ? ["force"] : await look();
  // 🔎 8/11: ΠΟΙΟ παράθυρο μένει ανοιχτό (τίτλος) — για να κλείνει χωρίς ξαναφόρτωμα
  let dTit = ""; if (left.includes("dialog")) dTit = ((await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: () => [...document.querySelectorAll(".ui-dialog")].filter((e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; }).map((e) => ((e.querySelector(".ui-dialog-title") || {}).textContent || "").trim().slice(0, 30) + (e.querySelector("iframe") ? "+if" : "") + (e.querySelector(".ui-dialog-titlebar-close") ? "" : "-x")).join("/") }).catch(() => [])) || []).map((x) => x && x.result).filter(Boolean).join("/").slice(0, 60);
  const t0c = Date.now();
  // 8/11: το παράθυρο «Παραγγελία Εξετάσεων» (Medilabi σε iframe) ΔΕΝ κλείνει με το Χ (μετρήθηκε ~2″ χαμένα) → κατευθείαν ξαναφόρτωμα
  const ifOnly = !!dTit && dTit.split("/").every((x) => /\+if/.test(x));
  for (let i = 0; i < 3 && !ifOnly && left.length && left.every((x) => x === "dialog"); i++) {
    await chrome.scripting.executeScript({ target: { tabId }, func: () => { [...document.querySelectorAll(".ui-dialog-titlebar-close")].filter((e) => e.getBoundingClientRect().width > 0).forEach((x) => x.click()); } }).catch(() => {});
    for (let k = 0; k < 12; k++) { await E.sleep(100); left = await look(); if (!left.length) break; }   // 6/11: έξοδος μόλις κλείσει
    if (left.length) { await bgSettle(tabId, 800); left = await look(); }
  }
  if (!left.length) { if (dTit) bgMark("κλείσιμο παραθύρου «" + dTit + "»"); return false; }
  await chrome.tabs.update(tabId, { url: EMR_HOME }).catch(() => {});
  for (let i = 0; i < 60; i++) { await E.sleep(150); const t = await chrome.tabs.get(tabId).catch(() => null); if (!t || t.status === "complete") break; }
  await bgSettle(tabId, 3000);
  bgMark("καθάρισμα οθόνης (" + left[0] + (dTit ? " «" + dTit + "» " + Math.round((Date.now() - t0c) / 100) / 10 : "") + ")");
  return true;
}
// ⚡ Γρήγορη επιστροφή στη λίστα ασθενών χωρίς ξαναφόρτωμα (το «force» κόστιζε 11–33″ ανά ασθενή):
// αν η λίστα δεν φαίνεται επειδή είναι ανοιχτός ασθενής → κλικ στην πρώτη καρτέλα/σύνδεσμο που οδηγεί στη λίστα.
async function bgEmrListVis(tabId) {
  const r = await chrome.scripting.executeScript({ target: { tabId }, func: () => { const t = document.getElementById("appForm:tabview:patientsTable"); if (!t) return 0; const b = t.getBoundingClientRect(); return b.width > 0 && b.height > 0 ? 1 : 2; } }).catch(() => null);
  return r && r[0] ? r[0].result : 0;
}
async function bgEmrToList(tabId) {
  const v0 = await bgEmrListVis(tabId);
  if (v0 === 1) return "ok";
  const how = await chrome.scripting.executeScript({ target: { tabId }, func: () => {
    const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    const nz = (s) => String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/\s+/g, " ").trim();
    const fire = (el) => { for (const t of ["pointerdown", "mousedown", "pointerup", "mouseup"]) el.dispatchEvent(new (t.startsWith("pointer") ? PointerEvent : MouseEvent)(t, { bubbles: true, cancelable: true, view: window })); el.click(); };
    // 1) καρτέλα του tabview που περιέχει τον πίνακα ασθενών
    const tbl = document.getElementById("appForm:tabview:patientsTable");
    if (tbl) { const panel = tbl.closest(".ui-tabs-panel"); if (panel && panel.id) { const a = document.querySelector('a[href="#' + CSS.escape(panel.id) + '"]'); if (a && vis(a)) { fire(a); return "tab"; } } }
    // 2) σύνδεσμοι «Ασθενείς / Λίστα ασθενών / Αρχική / Κλείσιμο ασθενή»
    const re = /^(ασθενεις|λιστα ασθενων|οι ασθενεις μου|αρχικη|αρχικη σελιδα|κλεισιμο ασθενη|επιστροφη)$/;
    const el = [...document.querySelectorAll("#appForm\\:content > nav a, nav a, .ui-tabs-nav a, .ui-menuitem-link, a, button")].find((e) => vis(e) && re.test(nz(e.innerText || e.textContent || e.title)));
    if (el) { fire(el); return "link:" + nz(el.innerText || el.textContent || el.title).slice(0, 20); }
    return "";
  } }).catch(() => null);
  const h = how && how[0] && how[0].result;
  if (!h) return "";
  for (let i = 0; i < 40; i++) { await new Promise((r) => setTimeout(r, 100)); if (await bgEmrListVis(tabId) === 1) { await bgSettle(tabId, 1500); bgMark("πίσω στη λίστα (" + h + ")"); return h; } }
  return "";
}
// ⚡ ΑΠΕΥΘΕΙΑΣ ΑΙΤΗΜΑΤΑ ΣΤΟ ΝΠΣ (PrimeFaces, όπως τα καταγράψαμε στο emrnetprobe #279): αναζήτηση επωνύμου με PrimeFaces.ab
// (SkipValidationSearchPatientsBtn) → μοναδική γραμμή με το ονοματεπώνυμο → widget.selectRow (rowSelect) → έλεγχος
// της μπάρας «Όνομα : …». Χωρίς κλικ, χωρίς σελίδες. Οτιδήποτε απρόσμενο → null και συνεχίζει ο κανονικός τρόπος.
// 🧠 Μνήμη ταυτότητας: data-rk της γραμμής ανά ασθενή (efbotIdCache) → ξεχωρίζει συνεπώνυμους χωρίς ερώτηση.
async function bgOpenPatientFast(tabId, name) {
  const nz = (x) => String(x || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().replace(/Σ\b/g, "Σ").replace(/\s+/g, " ").trim();
  const parts = String(name || "").trim().split(/\s+/); if (!parts[0] || parts[0].length < 3) return null;
  const { efbotIdCache: idc = {} } = await chrome.storage.local.get("efbotIdCache");
  const key = nz(name), rk0 = (idc[key] || {}).rk || "";
  const t0 = Date.now();
  const r = await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, world: "MAIN", args: [parts[0], key, rk0], func: async (sur, full, rk0) => {
    try {
      const nz = (x) => String(x || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().replace(/\s+/g, " ").trim();
      if (!window.PrimeFaces || !PrimeFaces.ab || !document.getElementById("appForm:tabview:SkipValidationSearchPatientsBtn")) return { why: "χωρίς οθόνη λίστας" };
      const inp = document.getElementById("appForm:tabview:surname") || document.getElementById("appForm:tabview:name"); if (!inp) return { why: "χωρίς πεδίο επωνύμου" };
      // 8/11 (εντολή χρήστη: ΟΧΙ χρονικά όρια): «έτοιμο» = καμία εκκρεμής κλήση ΚΑΙ ο πίνακας σταμάτησε να αλλάζει (300ms ησυχία)
      const idle = () => new Promise((res) => { let last = Date.now(); const tb = document.getElementById("appForm:tabview") || document.body; const mo = new MutationObserver(() => { last = Date.now(); }); mo.observe(tb, { childList: true, subtree: true, characterData: true });
        const f = () => { let busy = false; try { busy = !PrimeFaces.ajax.Queue.isEmpty(); } catch (e) {} if (busy) last = Date.now(); if (!busy && Date.now() - last >= 300) { mo.disconnect(); return res(); } setTimeout(f, 50); }; setTimeout(f, 30); });
      inp.value = nz(sur);   // το ΝΠΣ ψάχνει χωρίς τόνους (ΓΑΒΑΛΆΣ → ΓΑΒΑΛΑΣ· πριν: «δεν βρέθηκε» → αργό άνοιγμα με κλικ)
      await new Promise((res) => { PrimeFaces.ab({ s: "appForm:tabview:SkipValidationSearchPatientsBtn", f: "appForm", u: "appForm:tabview appForm:menuRight appForm:content appForm:tabview:patientGrid", oncomplete: () => res(), onerror: () => res() }); });
      await idle();
      const rows = [...document.querySelectorAll("#appForm\\:tabview\\:patientsTable_data > tr[data-rk]")];
      const want = nz(full), toks = want.split(" ");
      let hit = rows.filter((tr) => nz(tr.textContent).includes(want));
      if (!hit.length) hit = rows.filter((tr) => toks.every((t) => nz(tr.textContent).includes(t)));
      const W = Object.values(PrimeFaces.widgets || {}).find((w) => w && w.id === "appForm:tabview:patientsTable");
      // 6/11: όχι στην 1η σελίδα → οι επόμενες σελίδες του ίδιου αποτελέσματος (μόνο πλοήγηση, όπως τα βελάκια του πίνακα), έως 6
      let pg = 0;
      const findHit = () => { const rr = [...document.querySelectorAll("#appForm\\:tabview\\:patientsTable_data > tr[data-rk]")]; let h = rr.filter((tr) => nz(tr.textContent).includes(want)); if (!h.length) h = rr.filter((tr) => toks.every((t) => nz(tr.textContent).includes(t))); return h; };
      try { const P = W && (W.getPaginator ? W.getPaginator() : W.paginator); const pc = P && (P.getPageCount ? P.getPageCount() : (P.cfg && P.cfg.pageCount)) || 1;
        // όλες οι σελίδες του αποτελέσματος· κάθε αλλαγή σελίδας: περιμένουμε να ΑΛΛΑΞΕΙ ο πίνακας (όχι χρονόμετρο)
        while (!hit.length && P && P.setPage && pg < pc - 1) { pg++; P.setPage(pg); await idle(); hit = findHit(); } } catch (e) {}
      if (hit.length > 1 && rk0) { const h = hit.filter((tr) => tr.getAttribute("data-rk") === rk0); if (h.length === 1) hit = h; }
      if (hit.length !== 1) return { why: hit.length ? hit.length + " ίδια ονόματα" : "δεν βρέθηκε (σελίδες " + (pg + 1) + ", γραμμές " + document.querySelectorAll("#appForm\\:tabview\\:patientsTable_data > tr[data-rk]").length + ", πεδίο «" + inp.value + "»)", n: rows.length };
      if (!W || typeof W.selectRow !== "function") return { why: "χωρίς widget πίνακα" };
      try { W.unselectAllRows && W.unselectAllRows(true); } catch (e) {}
      const $ = window.jQuery || window.$; W.selectRow($ ? $(hit[0]) : hit[0], false);   // το PrimeFaces θέλει αντικείμενο jQuery (πριν: «a.hasClass is not a function»)
      await idle();
      // έλεγχος: η μπάρα στοιχείων δείχνει τον σωστό ασθενή
      for (let i = 0; i < 60; i++) { const bar = document.querySelector("#appForm\\:content > nav > ol"); if (bar && toks.every((t) => nz(bar.textContent).includes(t))) return { ok: true, rk: hit[0].getAttribute("data-rk") || "", pg }; await new Promise((r) => setTimeout(r, 100)); }
      return { why: "δεν επιβεβαιώθηκε στη μπάρα" };
    } catch (e) { return { why: String(e && e.message || e).slice(0, 80) }; }
  } }).catch((e) => [{ result: { why: e.message } }]);
  const res = r && r[0] && r[0].result;
  if (res && res.ok) {
    if (res.rk) { idc[key] = { ...(idc[key] || {}), rk: res.rk, at: Date.now() }; const ks = Object.keys(idc); if (ks.length > 300) delete idc[ks[0]]; await chrome.storage.local.set({ efbotIdCache: idc }); }
    bgMark("⚡ άνοιγμα ασθενή (απευθείας" + (res.pg ? ", σελίδα " + (res.pg + 1) : "") + ")"); return { ms: Date.now() - t0 };
  }
  bgMark("⚡ απευθείας: όχι (" + String((res && res.why) || "?").slice(0, 24) + ")");
  return null;
}
let traceTab = 0;
const TRACE_KINDS = /^(discharge|consult|order|orderprep|comorb)$/;
async function bgOpenPatient(tab, name, st) {
  // 🔬 καταγραφή αιτημάτων ΝΠΣ (μόνο ονόματα παραμέτρων/τεχνικές τιμές) σε εξιτήριο/κλήση/παραγγελία → για «απευθείας» βήματα
  if (TRACE_KINDS.test(jobRunningKind)) { try { await netHook(tab.id); traceTab = tab.id; } catch (e) {} }
  let r0;
  try { r0 = await bgOpenPatient0(tab, name, st); }
  catch (e) {
    // 🧪 7/11: ΜΟΝΟ δοκιμαστικές εργασίες — ο ασθενής δοκιμών (ΜΠΕΓΟΣ) δεν φαίνεται στους νοσηλευόμενους → φίλτρο «εκτός νοσοκομείου» από 2000
    if (!jobRunningTest || !/δεν βρέθηκε|σε καμία από/i.test(e.message || "")) throw e;
    const f = await emrListFilter(tab.id, { surname: String(name).trim().split(/\s+/)[0], inner: false, from: "01/01/2000" }).catch((x) => ({ err: x.message }));
    if (!f || f.err) throw e;
    emrFiltDirty = tab.id;
    r0 = await bgOpenPatient0(tab, name, st);
  }
  if (TRACE_KINDS.test(jobRunningKind)) { try { await netHook(tab.id); traceTab = tab.id; } catch (e) {} }
  chrome.storage.session.set({ efbotLastPt: { name: String(name || ""), at: Date.now() } }).catch(() => {});
  return r0;
}
// 🏥 Λάθος κλινική: κάθε λογαριασμός ΝΠΣ βλέπει τη λίστα της ΔΙΚΗΣ του κλινικής (π.χ. KDOUROUMIS → «Ουρολογικό Ημέρας»).
// Αν στη λίστα δεν υπάρχει ΚΑΝΕΝΑΣ από τους ασθενείς του Παραδόχαρτου → άλλη κλινική → αποσύνδεση και άλλος λογαριασμός.
const emrNz = (x) => String(x || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().replace(/\s+/g, " ").trim();
async function emrClinicCheck(tabId) {
  const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: () => ({
    who: ((document.getElementById("appForm:dynaButton") || {}).innerText || "").trim(),
    rows: [...document.querySelectorAll("#appForm\\:tabview\\:patientsTable_data > tr[data-rk]")].map((tr) => (tr.innerText || "").replace(/\s+/g, " ").slice(0, 120)) }) }).catch(() => [null]);
  const o = (r && r.result) || { rows: [] };
  let names = []; try { names = (await paradoxNames()).names || []; } catch (e) {}
  const sur = [...new Set(names.map((n) => emrNz(n).split(" ")[0]).filter((x) => x.length >= 3))];
  if (o.rows.length < 3 || sur.length < 3) return { ok: true, who: o.who, unsure: true };
  const hit = o.rows.filter((row) => sur.some((x) => emrNz(row).includes(x))).length;
  return { ok: hit > 0, who: o.who, rows: o.rows.length, hit };
}
// 🏥 ΝΠΣ: η λίστα ασθενών δείχνει την κλινική του πεδίου «Κλινική» (appForm:tabview:dptInput). Αν δεν είναι η
// «ΟΥΡΟΛΟΓΙΚΗ ΚΛΙΝΙΚΗ» (π.χ. «ΟΥΡΟΛΟΓΙΚΟ ΗΜΕΡΑΣ»), επιλέγεται αυτή και πατιέται «Αναζήτηση» — χωρίς αποσύνδεση.
// Μόνο φίλτρο προβολής: τίποτα δεν αποθηκεύεται.
const EMR_CLINIC_RE = /ΟΥΡΟΛΟΓΙΚΗ\s+ΚΛΙΝΙΚΗ/;
let emrClinicOkAt = {};
async function emrClinicEnsure(tabId, force, reOv) {
  // 6/11: χωρίς cache — το τμήμα του ΝΠΣ επανέρχεται σε κάθε φόρτωση/νέα καρτέλα (ένας έλεγχος ~50ms όταν είναι ήδη σωστό)
  if (reOv) emrClinicOkAt[tabId] = 0;   // άλλο τμήμα (π.χ. 3434 Ουρολογικό Ημέρας): η επόμενη εργασία ξαναγυρνά στην κλινική
  const [r] = await chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", args: [(reOv || EMR_CLINIC_RE).source], func: async (src) => {
    const re = new RegExp(src);
    const sel = document.getElementById("appForm:tabview:dptInput_input");
    if (!sel) return { none: true };
    const cur = (sel.selectedOptions[0] || {}).text || "";
    if (re.test(cur)) return { ok: true, already: true, cur };
    const opt = [...sel.options].find((o) => re.test(o.text));
    if (!opt) return { err: "δεν υπάρχει «Ουρολογική Κλινική» στις επιλογές (" + [...sel.options].map((o) => o.text).slice(0, 5).join(" | ") + ")", cur };
    const rows0 = document.querySelectorAll("#appForm\\:tabview\\:patientsTable_data > tr[data-rk]").length;
    let how = "";
    try {
      const W = window.PrimeFaces && PrimeFaces.widgets;
      const w = W && Object.values(W).find((x) => x && x.id === "appForm:tabview:dptInput");
      if (w && typeof w.selectValue === "function") { w.selectValue(opt.value); how = "widget"; }
    } catch (e) {}
    if (!how) { sel.value = opt.value; sel.dispatchEvent(new Event("change", { bubbles: true })); const lb = sel.closest(".ui-selectonemenu")?.querySelector(".ui-selectonemenu-label"); if (lb) lb.textContent = opt.text; how = "select"; }
    { const t0 = Date.now(); while (Date.now() - t0 < 1500) { try { if (window.PrimeFaces && PrimeFaces.ajax && PrimeFaces.ajax.Queue && PrimeFaces.ajax.Queue.isEmpty()) break; } catch (e) { break; } await new Promise((r) => setTimeout(r, 50)); } }
    // «Αναζήτηση» του ίδιου φίλτρου (κοντινότερο κουμπί με αυτό το κείμενο)
    const T = (e) => (e.innerText || e.textContent || "").replace(/\s+/g, " ").trim();
    let box = sel.closest(".ui-selectonemenu"), btn = null;
    for (let k = 0; box && k < 12 && !btn; k++, box = box.parentElement) btn = [...box.querySelectorAll("button, a, input[type=submit], [role=button]")].find((b) => /^αναζ[ηή]τηση$/i.test(T(b) || b.value || ""));
    if (btn) { btn.click(); how += "+αναζήτηση"; }
    for (let i = 0; i < 80; i++) { await new Promise((res) => setTimeout(res, 150)); const n = document.querySelectorAll("#appForm\\:tabview\\:patientsTable_data > tr[data-rk]").length; if (n !== rows0 && n > 1) break; }
    const now = (document.getElementById("appForm:tabview:dptInput_input")?.selectedOptions[0] || {}).text || "";
    return { ok: re.test(now), changed: true, from: cur, to: now, how, rows: document.querySelectorAll("#appForm\\:tabview\\:patientsTable_data > tr[data-rk]").length };
  } }).catch((e) => [{ result: { err: e.message } }]);
  const o = (r && r.result) || { err: "δεν απάντησε" };
  if (!reOv && (o.ok || o.none)) emrClinicOkAt[tabId] = Date.now();
  if (o.changed && !reOv) { try { const u = String(await pfExec(tabId, () => { const b = document.getElementById("appForm:dynaButton"); return b ? (b.innerText || b.textContent || "").trim() : ""; }) || "").toLowerCase(); if (u) { const { efbotEmrDeptSwitch: ds = {} } = await chrome.storage.local.get("efbotEmrDeptSwitch"); if (!ds[u]) { ds[u] = Date.now(); await chrome.storage.local.set({ efbotEmrDeptSwitch: ds }); } { const hu = await emrHumanUsers().catch(() => new Set()); const { efbotEmrRelogAt: ra = 0 } = await chrome.storage.local.get("efbotEmrRelogAt");
          if (Date.now() - ra > 30 * 60000 && (await emrAccounts()).some((a) => !ds[a.user.toLowerCase()] && !/^kdouroumis$/i.test(a.user) && !hu.has(a.user.toLowerCase()))) { await chrome.storage.local.set({ efbotEmrRelogAt: Date.now() }); await chrome.storage.session.set({ efbotEmrRelog: Date.now() }); } } } } catch (e) {} }
  if (o.changed) { bgMark("🏥 κλινική → " + String(o.to || "").slice(0, 30)); await bgSettle(tabId, 400).catch(() => {}); }
  return o;
}
// 🗺 ΝΠΣ: πού αλλάζει η κλινική; ΜΟΝΟ ανάγνωση — λίστες επιλογής/κουμπιά/ετικέτες με «κλινικ/τμήμα» στη σελίδα της λίστας
JOB_RUNNERS.emrclinicmap = async (job) => {
  const tab = await bgEmrTab();
  if (!tab || tab.err) return { status: "failed", note: tab?.err || "δεν άνοιξε ο φάκελος" };
  const lg = await bgEnsureLogin(tab.id); if (!lg.ok) return { status: "failed", note: lg.err };
  if (await bgEmrListVis(tab.id) !== 1) await bgEmrToList(tab.id);
  const set = (job.payload || {}).set ? await emrClinicEnsure(tab.id, true).catch((e) => ({ err: e.message })) : null;
  const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => {
    const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    const T = (e) => (e.innerText || e.textContent || "").replace(/\s+/g, " ").trim();
    const RE = /κλινικ|τμημ|τμήμ|μοναδ|clinic|dept|ward|unit/i;
    const out = { selects: [], menus: [], labels: [], buttons: [], who: T(document.getElementById("appForm:dynaButton") || {}) };
    for (const sel of document.querySelectorAll("select")) {
      const opts = [...sel.options].map((o) => o.text.trim()).filter(Boolean);
      const wrap = sel.closest(".ui-selectonemenu, .ui-selectmanymenu") || sel.parentElement;
      const lab = (sel.id && document.querySelector("label[for='" + sel.id.replace(/_input$/, "") + "'], label[for='" + sel.id + "']")) || null;
      if (opts.some((o) => RE.test(o)) || RE.test(sel.id || "") || (lab && RE.test(T(lab)))) out.selects.push({ id: sel.id, name: sel.name, vis: vis(wrap || sel), label: lab ? T(lab).slice(0, 60) : "", cur: (sel.selectedOptions[0] || {}).text || "", wrapCls: wrap ? String(wrap.className).slice(0, 80) : "", shown: wrap && wrap.querySelector ? T(wrap.querySelector(".ui-selectonemenu-label") || {}).slice(0, 60) : "", opts: opts.slice(0, 40) });
    }
    for (const m of document.querySelectorAll(".ui-selectonemenu, .ui-autocomplete, [role=combobox], [role=listbox]")) {
      if (!vis(m)) continue;
      out.menus.push({ id: m.id, cls: String(m.className).slice(0, 60), text: T(m).slice(0, 80) });
    }
    for (const e of document.querySelectorAll("label, span, td, th, b, strong, .ui-outputlabel, legend, h1, h2, h3")) {
      if (!vis(e) || e.children.length > 2) continue; const t = T(e);
      if (t && t.length < 80 && RE.test(t) && !out.labels.includes(t)) out.labels.push(t);
      if (out.labels.length > 40) break;
    }
    for (const b of document.querySelectorAll("a, button, [role=button], [role=menuitem], .ui-menuitem-link")) {
      const t = T(b); if (t && t.length < 60 && RE.test(t) && !out.buttons.includes(t)) out.buttons.push(t + (vis(b) ? "" : " (κρυφό)"));
      if (out.buttons.length > 40) break;
    }
    out.listRows = document.querySelectorAll("#appForm\\:tabview\\:patientsTable_data > tr[data-rk]").length;
    out.tabs = [...document.querySelectorAll("#appForm\\:tabview .ui-tabs-nav li")].map(T).slice(0, 10);
    return out;
  } }).catch((e) => [{ result: { err: e.message } }]);
  const o = (r && r.result) || {}; if (set) o.set = set;
  return { status: "done", note: (set ? "🏥 αλλαγή κλινικής: " + (set.ok ? "✓ " : "✗ ") + (set.from ? set.from + " → " : "") + (set.to || set.cur || set.err || "") + " (" + (set.how || "") + ", γραμμές " + (set.rows ?? "?") + ") · " : "") + "🗺 ΝΠΣ κλινική: " + (o.selects || []).length + " λίστες επιλογής · " + (o.menus || []).length + " μενού · χρήστης " + (o.who || "?") + " · γραμμές λίστας " + (o.listRows || 0), result: o };
};
// 🗺 ΝΠΣ: χάρτης για «Αναζήτηση ασθενών» (φίλτρα, σελίδες) και ιστορικό νοσηλειών/εξιτηρίων — ΜΟΝΟ ανάγνωση, ΜΟΝΟ ασθενής δοκιμών
JOB_RUNNERS.npsmap = async (job) => {
  const p = job.payload || {};
  // ΜΟΝΟ ο ασθενής δοκιμών, ακριβές όνομα (όχι υποσυμβολοσειρά)· κανένα ελεύθερο regex από το payload
  const NZ = (x) => String(x || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().replace(/\s+/g, " ").trim();
  const nm = "ΜΠΕΓΟΣ ΣΠΥΡΙΔΩΝ";
  if (p.name && NZ(p.name) !== NZ(nm)) return { status: "failed", note: "μόνο στον ασθενή δοκιμών (ΜΠΕΓΟΣ ΣΠΥΡΙΔΩΝ)" };
  const tab = await bgEmrTab(); if (!tab || tab.err) return { status: "failed", note: tab?.err || "δεν άνοιξε ο φάκελος" };
  const lg = await bgEnsureLogin(tab.id); if (!lg.ok) return { status: "failed", note: lg.err };
  if (await bgEmrListVis(tab.id) !== 1) await bgEmrToList(tab.id);
  const out = {};
  // 1) φόρμα αναζήτησης ασθενών + σελίδες πίνακα
  out.search = await pfExec(tab.id, () => {
    const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    const T = (e) => (e && (e.innerText || e.textContent) || "").replace(/\s+/g, " ").trim();
    const lab = (e) => { const id = e.id || ""; const l = id && (document.querySelector("label[for='" + CSS.escape(id) + "']") || document.querySelector("label[for='" + CSS.escape(id.replace(/_input$/, "")) + "']")); return T(l).slice(0, 60) || T(e.closest("td,div") && e.closest("td,div").previousElementSibling).slice(0, 60); };
    const inputs = [...document.querySelectorAll("[id^='appForm:tabview'] input:not([type=hidden]), [id^='appForm:tabview'] select")].filter(vis).slice(0, 40)
      .map((e) => ({ id: e.id, type: e.tagName === "SELECT" ? "select" : (e.type || "text"), label: lab(e), opts: e.tagName === "SELECT" ? [...e.options].map((o) => o.text.trim()).slice(0, 15) : undefined }));
    const btns = [...document.querySelectorAll("[id^='appForm:tabview'] button, [id^='appForm:tabview'] a.ui-commandlink")].filter(vis).map((b) => ({ id: b.id, t: T(b).slice(0, 40) })).slice(0, 25);
    const pag = document.querySelector("[id='appForm:tabview:patientsTable_paginator_bottom'], [id='appForm:tabview:patientsTable_paginator_top'], #appForm\\:tabview\\:patientsTable .ui-paginator");
    const heads = [...document.querySelectorAll("#appForm\\:tabview\\:patientsTable thead th")].map(T).filter(Boolean);
    return { inputs, btns, heads, rows: document.querySelectorAll("#appForm\\:tabview\\:patientsTable_data > tr[data-rk]").length, pager: pag ? { id: pag.id, text: T(pag).slice(0, 160), rpp: [...pag.querySelectorAll("select option")].map((o) => o.text) } : null };
  });
  // 2) ασθενής δοκιμών → μενού ασθενή (τι υπάρχει για νοσηλείες/εξιτήρια/ιστορικό)
  const { efbot: st } = await chrome.storage.local.get("efbot");
  try { await bgOpenPatient(tab, nm, st); } catch (e) { out.openErr = e.message; return { status: "done", note: "🗺 ΝΠΣ: φόρμα αναζήτησης: " + ((out.search && out.search.inputs) || []).length + " πεδία · άνοιγμα ασθενή: ✗ " + e.message, result: out }; }
  out.menu = await pfExec(tab.id, () => {
    const T = (e) => (e && (e.innerText || e.textContent) || "").replace(/\s+/g, " ").trim();
    const bar0 = T(document.querySelector("#appForm\\:content > nav > ol")) + " " + T(document.querySelector("[id*='patientHeader'], .patient-header, [id*='patientInfo']")) + " " + T(document.getElementById("appForm:content")).slice(0, 800);
    const m = document.getElementById("appForm:patientRightMenu");
    const items = m ? [...m.querySelectorAll("a, .ui-menuitem-link, span.ui-menuitem-text")].map(T).filter((t) => t && t.length < 60) : [];
    const all = [...document.querySelectorAll("a, button, .ui-menuitem-text, [role=tab], .ui-tabs-nav li")].map(T).filter((t) => t && t.length < 60 && /νοσηλ|εισαγ|εξιτ|ιστορ|επισκ|γνωμ|αρχει|παλαι/i.test(t));
    return { items: [...new Set(items)].slice(0, 60), hits: [...new Set(all)].slice(0, 40), bar: T(document.querySelector("#appForm\\:content > nav > ol")).slice(0, 200), who: bar0.slice(0, 1200) };
  });
  // ο ασθενής που άνοιξε πρέπει να είναι ο ΜΠΕΓΟΣ — αλλιώς σταματάμε πριν από οποιοδήποτε κλικ
  const whoN = NZ(out.menu && out.menu.who);
  if (!/ΜΠΕΓΟΣ/.test(whoN) || !/ΣΠΥΡΙΔΩΝ/.test(whoN)) return { status: "done", note: "🗺 ΝΠΣ: δεν επιβεβαιώθηκε ότι άνοιξε ο ΜΠΕΓΟΣ ΣΠΥΡΙΔΩΝ — σταμάτησα πριν από κλικ στο μενού", result: out };
  // 3) αν υπάρχει επιλογή «νοσηλείες/ιστορικό»: άνοιγμα (μόνο προβολή) + στήλες και 5 πρώτες γραμμές
  // 3) ΜΟΝΟ προβολή: συγκεκριμένες (ακριβές κείμενο) επιλογές του μενού ασθενή — καμία άλλη, κανένα κουμπί
  const SAFE = ["Ιστορικό ανά νοσηλεία", "Επεισόδια", "Συγκεντρωτικό Ιστορικό ασθενή", "Ιατρικό Εξιτήριο"];
  const have = new Set(((out.menu && out.menu.items) || []).concat((out.menu && out.menu.hits) || []));
  out.pages = [];
  for (const hit of SAFE.filter((x) => have.has(x))) {
    const ok = await emrClickText(tab.id, new RegExp("^" + hit.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "$", "i"), true).catch(() => false);
    await E.sleep(3000);
    const pg = await pfExec(tab.id, () => {
      const T = (e) => (e && (e.innerText || e.textContent) || "").replace(/\s+/g, " ").trim();
      const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      const root = document.getElementById("appForm:content") || document.body;
      const tbls = [...root.querySelectorAll("table")].filter(vis).map((t) => ({ id: t.id || (t.closest("[id]") || {}).id || "", heads: [...t.querySelectorAll("thead th")].map(T).filter(Boolean).slice(0, 20), rows: [...t.querySelectorAll("tbody tr")].slice(0, 8).map((r) => [...r.children].map((c) => T(c).slice(0, 80)).join(" ‖ ").slice(0, 400)) })).filter((x) => x.heads.length || x.rows.length).slice(0, 8);
      const sels = [...root.querySelectorAll("select, .ui-selectonemenu")].filter(vis).map((e) => ({ id: e.id, label: T(e.closest("td,div") && e.closest("td,div").previousElementSibling).slice(0, 50), opts: e.tagName === "SELECT" ? [...e.options].map((o) => o.text.trim()).slice(0, 20) : [...document.querySelectorAll("[id='" + e.id + "_items'] li")].map(T).slice(0, 20) })).slice(0, 10);
      const labels = [...root.querySelectorAll("label, .ui-outputlabel, legend, h1, h2, h3, .ui-panel-title, .ui-fieldset-legend, .ui-tabs-nav li")].filter(vis).map(T).filter((t) => t && t.length < 60);
      const btns = [...root.querySelectorAll("button, a.ui-commandlink, a.ui-button")].filter(vis).map(T).filter((t) => t && t.length < 40);
      const txt = T(root).slice(0, 1500);
      return { url: location.pathname, tbls, sels, labels: [...new Set(labels)].slice(0, 60), btns: [...new Set(btns)].slice(0, 30), txt };
    }).catch((e) => ({ err: e.message }));
    out.pages.push({ clicked: hit, ok: !!ok, page: pg });
  }
  // 4) πού είναι η αναζήτηση ΟΛΩΝ των ασθενών (όχι μόνο της κλινικής): σύνδεσμοι του γενικού μενού (ανάγνωση, χωρίς κλικ)
  out.globalMenu = await pfExec(tab.id, () => {
    const T = (e) => (e && (e.innerText || e.textContent) || "").replace(/\s+/g, " ").trim();
    return [...new Set([...document.querySelectorAll("a, .ui-menuitem-text, button")].map(T).filter((t) => t && t.length < 60 && /αναζ[ηή]τ|ασθεν|εύρεση|search|μητρ[ωώ]ο/i.test(t)))].slice(0, 40);
  }).catch(() => []);
  const s0 = out.search || {};
  return { status: "done", note: "🗺 ΝΠΣ: αναζήτηση " + (s0.inputs || []).length + " πεδία (" + (s0.inputs || []).map((x) => x.label || x.id.replace(/^.*:/, "")).filter(Boolean).slice(0, 10).join(", ") + ")" + (s0.pager ? " · σελίδες: «" + s0.pager.text.slice(0, 60) + "»" : " · χωρίς σελιδοποίηση") + " · μενού ασθενή: " + ((out.menu && out.menu.hits) || []).slice(0, 8).join(" | ") + (out.pages || []).map((x) => " · «" + x.clicked + "»: " + (((x.page && x.page.tbls) || []).map((t) => t.heads.join("/")).join(" ‖ ").slice(0, 160) || "χωρίς πίνακα")).join("") + (out.globalMenu && out.globalMenu.length ? " · αναζήτηση: " + out.globalMenu.slice(0, 8).join(" | ") : ""), result: out };
};
// 🗺 8/11: ΝΠΣ «Πορεία νόσου» — ΜΟΝΟ ανάγνωση, ΜΟΝΟ ο ασθενής δοκιμών ΤΟΥΣΗΣ ΧΡΗΣΤΟΣ: κλικ ΜΟΝΟ στην επιλογή μενού «Πορεία νόσου»
// (και, αν δεν φαίνεται, πρώτα «Ιστορικό ανά νοσηλεία») → πεδία/κουμπιά/πίνακες/editors. Κανένα κουμπί αποθήκευσης.
JOB_RUNNERS.npsprogmap = async (job) => {
  const NZ = (x) => String(x || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().replace(/\s+/g, " ").trim();
  // ασθενείς δοκιμών που όρισε ο χρήστης (ακριβές όνομα)
  const TEST = ["ΤΟΥΣΗΣ ΧΡΗΣΤΟΣ", "ΚΟΥΤΣΑΡΗΣ ΓΕΩΡΓΙΟΣ"], nm = TEST.find((x) => NZ(x) === NZ(job.name) || NZ(x).split(" ")[0] === NZ(job.name)) || "";
  if (!nm) return { status: "failed", note: "μόνο σε ασθενή δοκιμών (" + TEST.join(", ") + ")" };
  const tab = await bgEmrTab(); if (!tab || tab.err) return { status: "failed", note: tab?.err || "δεν άνοιξε ο φάκελος" };
  const lg = await bgEnsureLogin(tab.id); if (!lg.ok) return { status: "failed", note: lg.err };
  if (await bgEmrListVis(tab.id) !== 1) await bgEmrToList(tab.id);
  const { efbot: st } = await chrome.storage.local.get("efbot");
  try { await bgOpenPatient(tab, nm, st); } catch (e) { return { status: "failed", note: "άνοιγμα ασθενή: " + e.message }; }
  const dump = () => pfExec(tab.id, () => {
    const T = (e) => (e && (e.innerText || e.textContent) || "").replace(/\s+/g, " ").trim();
    const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    const root = document.getElementById("appForm:content") || document.body;
    const m = document.getElementById("appForm:patientRightMenu");
    const menu = m ? [...new Set([...m.querySelectorAll("a, .ui-menuitem-text")].map(T).filter((t) => t && t.length < 60))].slice(0, 80) : [];
    const lab = (e) => { const id = e.id || ""; const l = id && document.querySelector("label[for='" + CSS.escape(id) + "']"); return T(l).slice(0, 60) || T(e.closest("td") && e.closest("td").previousElementSibling).slice(0, 60); };
    const inputs = [...root.querySelectorAll("input:not([type=hidden]), textarea, select, [contenteditable=true], iframe")].filter(vis).slice(0, 60).map((e) => ({ id: e.id, t: e.tagName.toLowerCase() + ":" + (e.type || e.getAttribute("contenteditable") || ""), label: lab(e), ph: e.placeholder || "", ro: !!(e.readOnly || e.disabled), len: (e.value || "").length, cls: String(e.className || "").slice(0, 60) }));
    const tbls = [...root.querySelectorAll("table")].filter(vis).map((t) => ({ id: t.id || (t.closest("[id]") || {}).id || "", heads: [...t.querySelectorAll("thead th")].map(T).filter(Boolean).slice(0, 20), n: t.querySelectorAll("tbody tr").length, rows: [...t.querySelectorAll("tbody tr")].slice(0, 4).map((r) => [...r.children].map((c) => T(c).replace(/\d{8,}/g, "#").slice(0, 50)).join(" | ")) })).slice(0, 12);
    const btns = [...root.querySelectorAll("button, a.ui-commandlink, a.ui-button, input[type=submit], input[type=button]")].filter(vis).map((b) => ({ id: b.id, t: (T(b) || b.value || b.title || "").slice(0, 40) })).filter((b) => b.t || b.id).slice(0, 50);
    const labels = [...new Set([...root.querySelectorAll("label, .ui-outputlabel, legend, h1, h2, h3, .ui-panel-title, .ui-fieldset-legend, .ui-tabs-nav li, th")].filter(vis).map(T).filter((t) => t && t.length < 60))].slice(0, 80);
    return { url: location.pathname, who: T(document.querySelector("#appForm\\:content > nav > ol")).slice(0, 200) + " " + T(root).slice(0, 300), menu, inputs, tbls, btns, labels, txt: T(root).replace(/\d{8,}/g, "#").slice(0, 1500) };
  }).catch((e) => ({ err: e.message }));
  const out = { before: await dump() };
  if (!nm.split(" ").every((w) => NZ(out.before && out.before.who).includes(w))) return { status: "done", note: "🗺 δεν επιβεβαιώθηκε ότι άνοιξε ο " + nm + " — σταμάτησα πριν από κλικ", result: { map: out } };
  out.pages = [];
  for (const hit of ["Πορεία νόσου", "Ιστορικό ανά νοσηλεία", "Πορεία νόσου"]) {
    if (out.pages.some((x) => x.clicked === "Πορεία νόσου" && x.ok && /πορεία/i.test(JSON.stringify(x.page.labels || [])))) break;
    const ok = await emrClickText(tab.id, new RegExp("^" + hit + "$", "i"), true).catch(() => false);
    await bgSettle(tab.id, 3000); await E.sleep(800);
    out.pages.push({ clicked: hit, ok: !!ok, page: await dump() });
  }
  // 8/11 (έγκριση χρήστη «ναι το κάνεις»): «Νέα καταχώρηση» → ΜΟΝΟ ανάγνωση της φόρμας (SOAP / ISBAR)· ΠΟΤΕ αποθήκευση/οριστικοποίηση·
  // στο τέλος «Ακύρωση/Επιστροφή» (αν υπάρχει) και έλεγχος ότι ΔΕΝ προστέθηκε γραμμή στον πίνακα καταχωρήσεων.
  if (job.payload && job.payload.newform && out.pages.some((x) => x.clicked === "Πορεία νόσου" && x.ok)) {
    const dlg = () => pfExec(tab.id, () => {
      const T = (e) => (e && (e.innerText || e.textContent) || "").replace(/\s+/g, " ").trim();
      const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      const roots = [...document.querySelectorAll(".ui-dialog, .ui-overlaypanel, #appForm\\:content")].filter(vis);
      return roots.map((root) => ({ id: root.id, title: T(root.querySelector(".ui-dialog-title, h1, h2, legend")).slice(0, 80),
        fields: [...root.querySelectorAll("input:not([type=hidden]), textarea, select, [contenteditable=true], .ui-selectonemenu, .ui-selectcheckboxmenu, .ui-chkbox, .ui-radiobutton, iframe")].filter((e) => vis(e) || e.tagName === "SELECT").slice(0, 80).map((e) => {
          const id = e.id || (e.closest("[id]") || {}).id || ""; const l = id && document.querySelector("label[for='" + CSS.escape(id) + "']");
          const lab = T(l) || T(e.closest("td") && e.closest("td").previousElementSibling) || T(e.closest(".ui-g, .ui-grid-row, tr, .p-field, div") && e.closest(".ui-g, .ui-grid-row, tr, .p-field, div").querySelector("label, .ui-outputlabel"));
          return { id, tag: e.tagName.toLowerCase(), type: e.type || e.className.split(" ")[0] || "", label: lab.slice(0, 70), ph: e.placeholder || "", ro: !!(e.readOnly || e.disabled), max: e.maxLength > 0 && e.maxLength < 100000 ? e.maxLength : 0, opts: e.tagName === "SELECT" ? [...e.options].map((o) => o.text.trim()).slice(0, 30) : undefined }; }),
        labels: [...new Set([...root.querySelectorAll("label, .ui-outputlabel, legend, .ui-fieldset-legend, .ui-panel-title, th, h3, h4, .ui-tabs-nav li")].filter(vis).map(T).filter((t) => t && t.length < 80))].slice(0, 80),
        btns: [...root.querySelectorAll("button, a.ui-commandlink, a.ui-button, input[type=submit], input[type=button]")].filter(vis).map((b) => ({ id: b.id, t: (T(b) || b.value || b.title || "").slice(0, 40) })).slice(0, 40),
        rows: [...root.querySelectorAll("table tbody tr")].filter(vis).length,
        txt: T(root).replace(/\d{8,}/g, "#").slice(0, 1800) }));
    }).catch((e) => ({ err: e.message }));
    const NO = /αποθ[ηή]κ|οριστικ|υποβολ|καταχ[ωώ]ρ(ηση|ιση)$|save|submit|υπογραφ/i;
    const pg0 = ((out.pages.filter((x) => x.clicked === "Πορεία νόσου").pop()) || {}).page || {};
    const rows0 = (pg0.tbls || []).map((t) => t.rows.join("|")).join("#");
    out.newform = { types: (pg0.inputs || []).filter((x) => /select/.test(x.t)).length };
    const clk = await pfExec(tab.id, () => { const b = document.getElementById("appForm:SkipValidationAddNewCourseRecord"); if (!b) return { err: "δεν βρέθηκε το κουμπί" }; b.click(); return { ok: true, t: (b.innerText || b.value || "").trim() }; }).catch((e) => ({ err: e.message }));
    out.newform.click = clk; await bgSettle(tab.id, 3000); await E.sleep(800);
    out.newform.after = await dlg();
    // τύποι καταχώρησης (SOAP / ISBAR): επιλογή ΜΟΝΟ για να φανούν τα πεδία
    for (const ty of ["SOAP", "ISBAR"]) {
      const r = await pfExec(tab.id, (ty) => {
        const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
        const w = [...document.querySelectorAll(".ui-selectonemenu")].filter(vis).find((x) => [...(x.querySelector("select") || { options: [] }).options].some((o) => o.text.trim() === ty));
        if (!w) return { err: "χωρίς επιλογή " + ty };
        const trig = w.querySelector(".ui-selectonemenu-trigger") || w; ["mousedown", "mouseup", "click"].forEach((t) => trig.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window })));
        const pn = document.getElementById(w.id + "_panel") || document.getElementById(w.id + "_items")?.closest(".ui-selectonemenu-panel");
        const li = pn && [...pn.querySelectorAll("li")].find((x) => (x.getAttribute("data-label") || x.innerText).trim() === ty);
        if (li) ["mousedown", "mouseup", "click"].forEach((t) => li.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window })));
        else { const sel = w.querySelector("select"); const o = [...sel.options].find((o) => o.text.trim() === ty); sel.value = o.value; sel.dispatchEvent(new Event("change", { bubbles: true })); }
        return { ok: true, id: w.id };
      }, [ty]).catch((e) => ({ err: e.message }));
      await bgSettle(tab.id, 2500); await E.sleep(600);
      out.newform[ty] = { pick: r, page: await dlg() };
    }
    // έξοδος χωρίς αποθήκευση: μόνο κουμπιά ακύρωσης/επιστροφής (ποτέ αποθήκευση)
    const esc = await pfExec(tab.id, (noSrc) => { const NO = new RegExp(noSrc, "i"); const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      const b = [...document.querySelectorAll("button, a.ui-commandlink, a.ui-button, .ui-dialog-titlebar-close")].filter(vis).find((x) => /^(ακύρωση|επιστροφή|κλείσιμο|πίσω)$/i.test((x.innerText || x.title || "").trim()) || x.classList.contains("ui-dialog-titlebar-close"));
      if (!b) return { none: true }; const t = (b.innerText || b.title || "×").trim(); if (NO.test(t)) return { refused: t }; b.click(); return { ok: true, t }; }, [NO.source]).catch((e) => ({ err: e.message }));
    out.newform.exit = esc; await bgSettle(tab.id, 2500);
    if (!esc || !esc.ok) { await emrClickText(tab.id, /^Πορεία νόσου$/i, true).catch(() => false); await bgSettle(tab.id, 3000); }
    const fin = await dump(); out.newform.final = { tbls: fin.tbls, btns: fin.btns };
    out.newform.unchanged = ((fin.tbls || []).map((t) => t.rows.join("|")).join("#")) === rows0;
  }
  const last = out.pages[out.pages.length - 1] || {}; const pg = last.page || {};
  return { status: "done", note: (out.newform ? "📝 νέα καταχώρηση: " + (out.newform.click && out.newform.click.ok ? "άνοιξε" : "✗ " + JSON.stringify(out.newform.click)) + " · SOAP " + ((out.newform.SOAP && out.newform.SOAP.pick && out.newform.SOAP.pick.ok) ? "✓" : "✗") + " · ISBAR " + ((out.newform.ISBAR && out.newform.ISBAR.pick && out.newform.ISBAR.pick.ok) ? "✓" : "✗") + " · έξοδος " + JSON.stringify(out.newform.exit) + " · πίνακας " + (out.newform.unchanged ? "ίδιος ✓" : "ΑΛΛΑΞΕ ⚠") + " · " : "") + "🗺 ΝΠΣ «Πορεία νόσου»: " + out.pages.map((x) => x.clicked + (x.ok ? "✓" : "✗")).join(" → ") + " · πεδία " + (pg.inputs || []).length + " · κουμπιά: " + (pg.btns || []).map((b) => b.t).filter(Boolean).slice(0, 12).join(" | ") + " · πίνακες " + (pg.tbls || []).length, result: { map: out, at: Date.now() } };
};
JOB_KIND.npsprogmap = "🗺 ΝΠΣ: χάρτης «Πορεία νόσου» (μόνο ανάγνωση, ασθενείς δοκιμών)";
// 🗺 8/11: χάρτης «φακέλου νοσηλείας» στο ΝΠΣ (για το αυτόματο νυχτερινό «όλα για κάθε ασθενή»): για κάθε ενότητα του μενού
// (εξιτήριο, κλήσεις για εκτίμηση, διαγνώσεις, χειρουργεία, πρακτικά, πορεία νόσου…) → πίνακας + ΠΡΟΒΟΛΗ της 1ης γραμμής (πεδία & τιμές).
// ΜΟΝΟ ανάγνωση, ΜΟΝΟ ασθενείς δοκιμών. Πατά ΜΟΝΟ: επιλογή μενού, γραμμή πίνακα, κουμπί «προβολή» (μάτι/Προβολή). ΠΟΤΕ νέο/επεξεργασία/διαγραφή/αποθήκευση.
JOB_RUNNERS.npsepmap = async (job) => {
  const NZ = (x) => String(x || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().replace(/\s+/g, " ").trim();
  const TEST = ["ΤΟΥΣΗΣ ΧΡΗΣΤΟΣ", "ΚΟΥΤΣΑΡΗΣ ΓΕΩΡΓΙΟΣ"], nm = TEST.find((x) => NZ(x) === NZ(job.name) || NZ(x).split(" ")[0] === NZ(job.name)) || "";
  if (!nm) return { status: "failed", note: "μόνο σε ασθενή δοκιμών (" + TEST.join(", ") + ")" };
  const tab = await bgEmrTab(); if (!tab || tab.err) return { status: "failed", note: tab?.err || "δεν άνοιξε ο φάκελος" };
  const lg = await bgEnsureLogin(tab.id); if (!lg.ok) return { status: "failed", note: lg.err };
  if (await bgEmrListVis(tab.id) !== 1) await bgEmrToList(tab.id);
  const { efbot: st } = await chrome.storage.local.get("efbot");
  try { await bgOpenPatient(tab, nm, st); } catch (e) { return { status: "failed", note: "άνοιγμα ασθενή: " + e.message }; }
  const who = await pfExec(tab.id, () => (document.getElementById("appForm:content") || document.body).innerText.replace(/\s+/g, " ").slice(0, 400)).catch(() => "");
  if (!nm.split(" ").every((w) => NZ(who).includes(w))) return { status: "done", note: "🗺 δεν επιβεβαιώθηκε ο ασθενής — σταμάτησα" };
  const dump = () => pfExec(tab.id, () => {
    const T = (e) => (e && (e.innerText || e.textContent) || "").replace(/\s+/g, " ").trim(), vis = (e) => { const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0; };
    const roots = [...document.querySelectorAll(".ui-dialog")].filter(vis); const root = roots[roots.length - 1] || document.getElementById("appForm:content") || document.body;
    const lab = (e) => { const id = e.id || ""; const l = id && document.querySelector("label[for='" + CSS.escape(id) + "']"); return T(l).slice(0, 60) || T(e.closest("td") && e.closest("td").previousElementSibling).slice(0, 60) || T((e.closest(".ui-g, .ui-grid-row, tr, div") || {}).querySelector && e.closest(".ui-g, .ui-grid-row, tr, div").querySelector("label")).slice(0, 60); };
    const fields = [...root.querySelectorAll("input:not([type=hidden]), textarea, select, .ui-selectonemenu-label, [contenteditable=true]")].filter(vis).slice(0, 60).map((e) => ({ id: (e.id || "").replace(/j_idt\d+/g, "j"), t: e.tagName.toLowerCase() + (e.type ? ":" + e.type : ""), label: lab(e), ro: !!(e.readOnly || e.disabled), v: String(e.value != null && e.tagName !== "LABEL" ? e.value : T(e)).replace(/\d{8,}/g, "#").slice(0, 300) }));
    const tbls = [...root.querySelectorAll("table")].filter(vis).map((t) => ({ id: (t.id || (t.closest("[id]") || {}).id || "").replace(/j_idt\d+/g, "j"), heads: [...t.querySelectorAll("thead th")].map(T).filter(Boolean).slice(0, 20), n: t.querySelectorAll("tbody tr").length, rows: [...t.querySelectorAll("tbody tr")].slice(0, 3).map((r) => [...r.children].map((c) => T(c).replace(/\d{8,}/g, "#").slice(0, 80)).join(" | ")), acts: [...new Set([...t.querySelectorAll("tbody tr:first-child a, tbody tr:first-child button")].map((b) => (b.title || T(b) || b.className).slice(0, 30)))] })).filter((x) => x.heads.length || x.n).slice(0, 6);
    const btns = [...root.querySelectorAll("button, a.ui-commandlink, a.ui-button")].filter(vis).map((b) => (T(b) || b.title || "").slice(0, 30)).filter(Boolean).slice(0, 30);
    return { dlg: roots.length, title: T(root.querySelector(".ui-dialog-title, h1, h2, legend")).slice(0, 80), fields, tbls, btns, txt: T(root).replace(/\d{8,}/g, "#").slice(0, 2500) };
  }).catch((e) => ({ err: e.message }));
  const SECTIONS = [].concat(job.payload && job.payload.sections || ["Ιατρικό Εξιτήριο", "Κλήση για εκτίμηση", "Διάγνωση", "Εντολή για επέμβαση", "Πρακτικό Επέμβασης", "Ιατρικές Πράξεις", "Πορεία νόσου", "Ενημερωτικό Σημείωμα", "Διακίνηση"]);
  const out = { who: who.replace(/\d{8,}/g, "#").slice(0, 200), sec: [] };
  for (const sec of SECTIONS) {
    const ok = await emrClickText(tab.id, new RegExp("^" + sec + "$", "i"), true).catch(() => false);
    await bgSettle(tab.id, 6000);
    const list = await dump(); const one = { sec, ok: !!ok, list };
    // ΠΡΟΒΟΛΗ 1ης γραμμής: κουμπί «μάτι/Προβολή/Εμφάνιση» (ποτέ επεξεργασία/διαγραφή/νέο)· αλλιώς κλικ στη γραμμή (επιλογή)
    const v = await pfExec(tab.id, () => {
      const root = document.getElementById("appForm:content") || document.body, vis = (e) => { const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0; };
      const NO = /επεξεργ|διαγρ|ακύρ|νέ[αο]|αποθ|οριστικ|υποβολ|edit|delete|remove|trash|pencil|plus|save|close|print|εκτύπ/i;
      const tr = [...root.querySelectorAll("table tbody tr")].filter(vis).find((r) => r.children.length > 1 && !/Δεν βρέθηκαν/.test(r.innerText)); if (!tr) return { none: true };
      const b = [...tr.querySelectorAll("a, button")].find((x) => /προβολ|εμφάνι|view|search|eye|zoomin|magnif|info/i.test((x.title || "") + " " + (x.innerText || "") + " " + x.className + " " + ((x.querySelector("span,i") || {}).className || "")) && !NO.test((x.title || "") + " " + (x.innerText || "") + " " + x.className));
      if (b) { b.click(); return { how: "κουμπί " + (b.title || b.innerText || b.className).slice(0, 30) }; }
      const cell = tr.children[1] || tr.children[0]; cell.click(); return { how: "γραμμή" };
    }).catch((e) => ({ err: e.message }));
    if (v && !v.none && !v.err) { await bgSettle(tab.id, 6000); one.view = { how: v.how, page: await dump() };
      // κλείσιμο διαλόγου ΜΟΝΟ με το × ή «Κλείσιμο/Επιστροφή»
      await pfExec(tab.id, () => { const vis = (e) => { const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0; }; const x = [...document.querySelectorAll(".ui-dialog-titlebar-close, button, a")].filter(vis).find((b) => b.classList.contains("ui-dialog-titlebar-close") || /^(κλείσιμο|επιστροφή|πίσω)$/i.test((b.innerText || "").trim())); if (x) x.click(); }).catch(() => {});
      await bgSettle(tab.id, 3000); } else one.view = v;
    out.sec.push(one);
  }
  await bgEmrClean(tab.id).catch(() => {});
  return { status: "done", note: "🗺 φάκελος νοσηλείας: " + out.sec.map((x) => x.sec + (x.ok ? "✓" : "✗") + "(" + ((x.list && x.list.tbls) || []).map((t) => t.n).join("/") + (x.view && x.view.page ? "+προβολή" : "") + ")").join(" · "), result: { map: out, at: Date.now() } };
};
JOB_KIND.npsepmap = "🗺 ΝΠΣ: χάρτης φακέλου νοσηλείας (μόνο ανάγνωση, ασθενείς δοκιμών)";
JOB_LIMIT_S.npsepmap = 900;
// 🗺 8/11: ΝΠΣ ενότητα «Διάγνωση» (για συννοσηρότητες ΑΗΦΥ → «Πάθηση») — ΜΟΝΟ ανάγνωση, ΜΟΝΟ ο ασθενής δοκιμών ΤΟΥΣΗΣ ΧΡΗΣΤΟΣ.
// Κλικ ΜΟΝΟ σε επιλογή μενού ασθενή που λέγεται «Διάγνωση/Διαγνώσεις» (προβολή)· κανένα κουμπί, καμία αποθήκευση.
JOB_RUNNERS.npsdxmap = async (job) => {
  const NZ = (x) => String(x || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().replace(/\s+/g, " ").trim();
  const nm = "ΤΟΥΣΗΣ ΧΡΗΣΤΟΣ";
  if (NZ(job.name) !== NZ(nm) && NZ(job.name) !== "ΤΟΥΣΗΣ") return { status: "failed", note: "μόνο στον ασθενή δοκιμών (ΤΟΥΣΗΣ ΧΡΗΣΤΟΣ)" };
  const tab = await bgEmrTab(); if (!tab || tab.err) return { status: "failed", note: tab?.err || "δεν άνοιξε ο φάκελος" };
  const lg = await bgEnsureLogin(tab.id); if (!lg.ok) return { status: "failed", note: lg.err };
  if (await bgEmrListVis(tab.id) !== 1) await bgEmrToList(tab.id);
  const out = {};
  const { efbot: st } = await chrome.storage.local.get("efbot");
  try { await bgOpenPatient(tab, nm, st); } catch (e) { return { status: "failed", note: "άνοιγμα ασθενή: " + e.message }; }
  const dump = () => pfExec(tab.id, () => {
    const T = (e) => (e && (e.innerText || e.textContent) || "").replace(/\s+/g, " ").trim();
    const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    const root = document.getElementById("appForm:content") || document.body;
    const m = document.getElementById("appForm:patientRightMenu");
    const menu = m ? [...new Set([...m.querySelectorAll("a, .ui-menuitem-text")].map(T).filter((t) => t && t.length < 60))].slice(0, 80) : [];
    const hits = [...new Set([...document.querySelectorAll("a, button, .ui-menuitem-text, [role=tab], .ui-tabs-nav li")].map(T).filter((t) => t && t.length < 60 && /διαγν|παθησ|νοσημ|ιστορ/i.test(t)))].slice(0, 40);
    const lab = (e) => { const id = e.id || ""; const l = id && document.querySelector("label[for='" + CSS.escape(id) + "']"); return T(l).slice(0, 60) || T(e.closest("td") && e.closest("td").previousElementSibling).slice(0, 60); };
    const inputs = [...root.querySelectorAll("input:not([type=hidden]), textarea, select")].filter(vis).slice(0, 60).map((e) => ({ id: e.id, t: e.tagName.toLowerCase() + ":" + (e.type || ""), label: lab(e), opts: e.tagName === "SELECT" ? [...e.options].map((o) => o.text.trim()).slice(0, 25) : undefined }));
    const pfSel = [...root.querySelectorAll(".ui-selectonemenu")].filter(vis).map((e) => ({ id: e.id, label: lab(e) || T(e.previousElementSibling).slice(0, 50), cur: T(e.querySelector("label")).slice(0, 40), opts: [...document.querySelectorAll("[id='" + e.id + "_items'] li, [id='" + e.id + "_panel'] li")].map(T).slice(0, 25) }));
    const tbls = [...root.querySelectorAll("table")].filter(vis).map((t) => ({ id: t.id || (t.closest("[id]") || {}).id || "", heads: [...t.querySelectorAll("thead th")].map(T).filter(Boolean).slice(0, 20), rows: [...t.querySelectorAll("tbody tr")].slice(0, 6).map((r) => [...r.children].map((c) => T(c).slice(0, 40)).join(" | ")) })).filter((x) => x.heads.length).slice(0, 8);
    const btns = [...root.querySelectorAll("button, a.ui-commandlink, a.ui-button")].filter(vis).map((b) => ({ id: b.id, t: T(b).slice(0, 40) })).filter((b) => b.t).slice(0, 40);
    const labels = [...new Set([...root.querySelectorAll("label, .ui-outputlabel, legend, h1, h2, h3, .ui-panel-title, .ui-fieldset-legend, .ui-tabs-nav li")].filter(vis).map(T).filter((t) => t && t.length < 60))].slice(0, 80);
    return { url: location.pathname, who: T(document.querySelector("#appForm\\:content > nav > ol")).slice(0, 200) + " " + T(root).slice(0, 300), menu, hits, inputs, pfSel, tbls, btns, labels };
  }).catch((e) => ({ err: e.message }));
  out.before = await dump();
  const whoN = NZ(out.before && out.before.who);
  if (!/ΤΟΥΣΗΣ/.test(whoN)) return { status: "done", note: "🗺 δεν επιβεβαιώθηκε ότι άνοιξε ο ΤΟΥΣΗΣ — σταμάτησα πριν από κλικ", result: { map: out } };
  const cand = [...new Set([].concat(out.before.menu || [], out.before.hits || []))].filter((t) => /^(Διάγνωση|Διαγνώσεις|Διαγνώσεις ασθενούς|Διάγνωση εισαγωγής|Διαγνώσεις νοσηλείας)$/i.test(t));
  out.pages = [];
  for (const hit of cand.slice(0, 2)) {
    const ok = await emrClickText(tab.id, new RegExp("^" + hit.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "$", "i"), true).catch(() => false);
    await bgSettle(tab.id, 3000); await E.sleep(600);
    out.pages.push({ clicked: hit, ok: !!ok, page: await dump() });
  }
  // 2ο βήμα (payload.openAdd): «Προσθήκη Διάγνωσης» → ΜΟΝΟ ανάγνωση του παραθύρου → κλείσιμο με «Ακύρωση»/✕ (ΠΟΤΕ αποθήκευση)
  if ((job.payload || {}).openAdd && out.pages.length) {
    out.add = await Promise.race([new Promise((r) => setTimeout(() => r({ err: "χρονικό όριο 40″" }), 40000)), pfExec(tab.id, async () => {
      const T = (e) => (e && (e.innerText || e.textContent) || "").replace(/\s+/g, " ").trim();
      const vis = (e) => { if (!e) return false; const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
      const idle = async () => { const t0 = Date.now(); await sleep(100); while (Date.now() - t0 < 10000) { let b = false; try { b = !PrimeFaces.ajax.Queue.isEmpty(); } catch (e) {} if (!b) return; await sleep(100); } };
      const b = document.getElementById("appForm:SkipValidationAddDiagnosisDRG"); if (!b || !vis(b)) return { err: "χωρίς κουμπί «Προσθήκη Διάγνωσης»" };
      const d0 = [...document.querySelectorAll(".ui-dialog")].filter(vis).length;
      b.click(); await idle(); await sleep(800); await idle();
      const dl = [...document.querySelectorAll(".ui-dialog")].filter(vis);
      const root = dl[dl.length - 1] || document.getElementById("appForm:content");
      const lab = (e) => { const id = e.id || ""; const l = id && (document.querySelector("label[for='" + CSS.escape(id) + "']") || document.querySelector("label[for='" + CSS.escape(id.replace(/_(input|focus)$/, "")) + "']")); return T(l).slice(0, 60) || T(e.closest("td") && e.closest("td").previousElementSibling).slice(0, 60); };
      const inputs = [...root.querySelectorAll("input:not([type=hidden]), textarea, select")].filter(vis).map((e) => ({ id: e.id, t: e.tagName.toLowerCase() + ":" + (e.type || ""), label: lab(e), v: e.type === "checkbox" || e.type === "radio" ? !!e.checked : String(e.value || "").slice(0, 30) }));
      const sels = [...root.querySelectorAll(".ui-selectonemenu, .ui-autocomplete, .ui-selectoneradio, select")].filter(vis).map((e) => ({ id: e.id, cls: String(e.className).split(" ")[0], label: lab(e) || T(e.closest("td") && e.closest("td").previousElementSibling).slice(0, 50), cur: T(e.querySelector("label")).slice(0, 40), opts: (e.tagName === "SELECT" ? [...e.options].map((o) => o.text.trim()) : [...document.querySelectorAll("[id='" + e.id + "_items'] li, [id='" + e.id + "_panel'] li, [id='" + e.id + "'] td label")].map(T)).slice(0, 30) }));
      const btns = [...root.querySelectorAll("button, a.ui-commandlink, a.ui-button, .ui-dialog-titlebar-close")].filter(vis).map((x) => ({ id: x.id, t: T(x).slice(0, 40) || x.className.split(" ")[0] }));
      const labels = [...new Set([...root.querySelectorAll("label, .ui-outputlabel, legend, .ui-dialog-title, .ui-fieldset-legend")].filter(vis).map(T).filter((t) => t && t.length < 70))].slice(0, 60);
      const info = { dialogs: dl.length, was: d0, title: T(root.querySelector(".ui-dialog-title")), inputs, sels, btns, labels, text: T(root).slice(0, 900) };
      // κλείσιμο ΧΩΡΙΣ αποθήκευση
      const cancel = [...root.querySelectorAll("button, a")].filter(vis).find((x) => /^(Ακύρωση|Κλείσιμο|Άκυρο|Επιστροφή)$/.test(T(x))) || root.querySelector(".ui-dialog-titlebar-close");
      if (cancel && dl.length > d0) { cancel.click(); await idle(); await sleep(500); info.closed = [...document.querySelectorAll(".ui-dialog")].filter(vis).length; info.closedBy = T(cancel) || "✕"; }
      else info.closed = "όχι παράθυρο (σελίδα) — δεν πατήθηκε τίποτα άλλο";
      return info;
    }).catch((e) => ({ err: e.message }))]);
    // 3ο βήμα (payload.probeIcd): γράφει τον κωδικό στο «Διάγνωση ICD DRG» + 🔍 → ανάγνωση αποτελεσμάτων → κλείσιμο ΧΩΡΙΣ επιλογή/αποθήκευση
    const pc = String((job.payload || {}).probeIcd || "").replace(/[^A-Za-z0-9.\u0370-\u03ff\u1f00-\u1fff ]/g, "").trim().slice(0, 30);
    if (pc) {
      // (α) γράφει + 🔍 και επιστρέφει ΑΜΕΣΩΣ (η σελίδα μπορεί να ξαναφορτωθεί — πριν «κρεμούσε» η ανάγνωση)
      if ((job.payload || {}).probeType) await pfExec(tab.id, (t) => { window.__efTy = t; return 1; }, [String(job.payload.probeType).replace(/\D/g, "").slice(0, 3)]).catch(() => {});
      out.icd = { go: await Promise.race([new Promise((r) => setTimeout(() => r({ err: "όριο 15″" }), 15000)), pfExec(tab.id, (code) => {
        const inp = document.getElementById("appForm:icd10DiagnosisInput"), sb = document.getElementById("appForm:searchButtonIcd10Diagnosis");
        if (!inp || !sb) return { err: "χωρίς πεδίο/κουμπί ICD" };
        const evs = (() => { try { const ev = window.jQuery && jQuery._data && jQuery._data(inp, "events"); return ev ? Object.keys(ev).join(",") : ""; } catch (e) { return "?"; } })() + " · on: " + [...inp.attributes].filter((a) => /^on/.test(a.name)).map((a) => a.name + "=" + a.value.slice(0, 120)).join(" | ");
        let tySet = "";
        if (window.__efTy) { try { const w = window.PF && PF("widget_appForm_diagnosisTypeInputDRG"); if (w && w.selectValue) { w.selectValue(String(window.__efTy)); tySet = "PF:" + window.__efTy; } } catch (e) { tySet = "err:" + e.message; } }
        inp.focus(); inp.value = code; inp.dispatchEvent(new Event("input", { bubbles: true }));
        setTimeout(() => { try { inp.blur(); } catch (e) {} }, 50); setTimeout(() => sb.click(), 2500);
        return { evs, tySet, onclk: String(sb.getAttribute("onclick") || "").slice(0, 200) };
      }, [pc]).catch((e) => ({ err: e.message }))]) };
      // τα αποτελέσματα αργούν (μετρήθηκε >8″): αναμονή ώσπου το πάνελ να δείξει τον όρο αναζήτησης (έως 30″)
      for (let i = 0; i < 30; i++) { await E.sleep(1000); const t = await pfExec(tab.id, () => String((document.getElementById("appForm:icd10DiagnosisDrgSearchResultModal") || {}).textContent || "").replace(/\s+/g, " ")).catch(() => ""); if (t && (t.toUpperCase().includes(pc.toUpperCase()) || (i > 3 && !/Δεν βρέθηκαν/.test(t)))) { out.icd.waitS = i + 1; break; } }
      await bgSettle(tab.id, 3000);
      // (β) ανάγνωση αποτελεσμάτων — ΧΩΡΙΣ επιλογή
      out.icd.read = await Promise.race([new Promise((r) => setTimeout(() => r({ err: "όριο 15″" }), 15000)), pfExec(tab.id, (code) => {
        const T = (e) => (e && (e.innerText || e.textContent) || "").replace(/\s+/g, " ").trim();
        const vis = (e) => { if (!e) return false; const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
        const rp = document.getElementById("appForm:resultsPanelIcd10Diagnosis"), md = document.getElementById("appForm:icd10DiagnosisDrgSearchResultModal");
        const pan = (el) => el ? { vis: vis(el), cls: String(el.className).slice(0, 60), txt: String(el.textContent || "").replace(/\s+/g, " ").trim().slice(0, 500), rows: [...el.querySelectorAll("tbody tr")].slice(0, 8).map((r) => ({ rk: r.getAttribute("data-rk") || "", t: [...r.children].map((c) => String(c.textContent || "").replace(/\s+/g, " ").trim().slice(0, 50)).join(" | "), a: [...r.querySelectorAll("a,button,input")].map((x) => (x.id || "").slice(-40) + ":" + (x.type || x.tagName)).slice(0, 3) })), btns: [...el.querySelectorAll("button,a")].map((x) => (x.id || "").slice(-45) + "=" + String(x.textContent || "").trim().slice(0, 20)).slice(0, 12) } : null;
        const hitsC = [...document.querySelectorAll("td, li, span, a, label")].filter((e) => vis(e) && e.children.length === 0 && T(e).includes(code)).map((e) => T(e).slice(0, 80) + " <" + e.tagName + " " + ((e.closest("[id]") || {}).id || "").slice(-50) + ">").slice(0, 10);
        return { url: location.pathname, rp: pan(rp), md: pan(md), hitsC, inpV: (document.getElementById("appForm:icd10DiagnosisInput") || {}).value, dlg: [...document.querySelectorAll(".ui-dialog")].filter(vis).map((x) => (x.id || "").slice(-40) + ":" + T(x.querySelector(".ui-dialog-title"))).slice(0, 6) };
      }, [pc]).catch((e) => ({ err: e.message }))]);
      // (γ) κλείσιμο τυχόν παραθύρου αποτελεσμάτων ΧΩΡΙΣ επιλογή
      await pfExec(tab.id, () => { const vis = (e) => { if (!e) return false; const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; }; for (const d of [...document.querySelectorAll(".ui-dialog")].filter(vis)) { const c = d.querySelector(".ui-dialog-titlebar-close"); if (c) c.click(); } const i = document.getElementById("appForm:icd10DiagnosisInput"); if (i) i.value = ""; return 1; }).catch(() => {});
    }
  }
  const pg = out.pages[0] && out.pages[0].page;
  return { status: "done", note: "🗺 ΝΠΣ «Διάγνωση» (ΤΟΥΣΗΣ, μόνο ανάγνωση): μενού " + ((out.before.menu || []).length) + " · υποψήφια: " + (cand.join(", ") || "—") + (pg ? " · πεδία " + (pg.inputs || []).length + " · επιλογές " + (pg.pfSel || []).map((x) => x.label || x.id).slice(0, 6).join(", ") + " · κουμπιά " + (pg.btns || []).map((b) => b.t).slice(0, 10).join(" | ") : ""), result: { map: out } };
};
// 🩺 8/11: Συννοσηρότητες (ΑΗΦΥ) → ΝΠΣ ενότητα «Διάγνωση», τύπος «ΠΑΘΗΣΗ», ΑΥΤΟΜΑΤΗ αποθήκευση (απόφαση χρήστη 01:36).
// payload: { codes:[{code,desc}] }. Προς το παρόν ΜΟΝΟ ο ασθενής δοκιμών ΤΟΥΣΗΣ (δοκιμή)· πραγματικοί ασθενείς μόνο με ρύθμιση npsdx_on.
// Ασφάλεια: «Προσθήκη» πατιέται ΜΟΝΟ αν ο τύπος δείχνει ΠΑΘΗΣΗ ΚΑΙ το πεδίο ICD δείχνει τον ζητούμενο κωδικό· ήδη υπάρχων κωδικός → παράλειψη.
// Κωδικοί που στο ΝΠΣ υπάρχουν μόνο ως υποκωδικοί → ο υποκωδικός που όρισε ο χρήστης (8/11: «Για I10 θα βάζεις το .00»)
const NPSDX_MAP = { I10: "I10.00" };
// Αυτόματη ουρά: μετά από συννοσηρότητες (ΑΗΦΥ ή επιλογή γιατρού) → εργασία npsdx με ΟΣΟΥΣ κωδικούς δεν έχουν σταλεί ήδη για τον ασθενή
async function npsdxQueue(k, name, codes0) {
  try {
    const nz = (x) => String(x || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/ς/g, "σ").replace(/\s+/g, " ").trim();
    let codes = icdList(codes0 || []);
    if (!codes.length && k) { const r = await jobsInApp((k, name) => { try { const f = window.pdxRecFind && window.pdxRecFind(k, name); const c = f && f.d && f.d.comorb && f.d.comorb.codes; return { r: Array.isArray(c) ? c.map((x) => x && x.code).filter(Boolean) : [] }; } catch (e) { return { err: String(e) }; } }, [k, name], 15000).catch(() => null); codes = icdList((r && r.r) || []); }
    if (!codes.length || !String(name || "").trim()) return;
    try { const off = await jobsInApp(async () => { try { const r = await sb6.from("oncall_config").select("value").eq("key", "npsdx_off").maybeSingle(); return { r: !!(r.data && r.data.value && r.data.value !== "0" && r.data.value !== false) }; } catch (e) { return { r: false }; } }, [], 10000); if (off && off.r) return; } catch (e) {}
    const key = nz(name); const { efbotNpsdxSent: sent = {} } = await chrome.storage.local.get("efbotNpsdxSent");
    const have = new Set((sent[key] && sent[key].c) || []); const neu = codes.filter((c) => !have.has(c));
    if (!neu.length) return;
    const ins = await jobsInsert({ name_key: key, name, room: null, kind: "npsdx", payload: { codes: neu.map((code) => ({ code })), auto: true, quiet: true } });
    if (ins && ins.ok) { sent[key] = { c: [...have, ...neu].slice(-40), at: Date.now() }; for (const kk of Object.keys(sent)) if (Date.now() - (sent[kk].at || 0) > 30 * 864e5) delete sent[kk]; await chrome.storage.local.set({ efbotNpsdxSent: sent }); }
  } catch (e) {}
}
JOB_RUNNERS.npsdx = async (job) => {
  const NZ = (x) => String(x || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().replace(/\s+/g, " ").trim();
  const p = job.payload || {};
  const isTest = /^ΤΟΥΣΗΣ( ΧΡΗΣΤΟΣ)?$/.test(NZ(job.name));
  // 8/11: ενεργό για όλους τους ασθενείς (έγκριση χρήστη «Αυτόματα θα τα περνάς»)· διακόπτης ανάγκης: oncall_config «npsdx_off»
  const codes = [...new Set((Array.isArray(p.codes) ? p.codes : []).map((o) => String((o && o.code) || o || "").toUpperCase().replace(/[^A-Z0-9.]/g, "")).filter((c) => /^[A-Z]\d{2}(\.\d{1,2})?$/.test(c)).map((c) => NPSDX_MAP[c] || c))].slice(0, 15);
  if (!codes.length) return { status: "failed", note: "κανένας έγκυρος κωδικός ICD-10" };
  const tab = await bgEmrTab(); if (!tab || tab.err) return { status: "failed", note: tab?.err || "δεν άνοιξε ο φάκελος" };
  const lg = await bgEnsureLogin(tab.id); if (!lg.ok) return { status: "failed", note: lg.err };
  if (await bgEmrListVis(tab.id) !== 1) await bgEmrToList(tab.id);
  const { efbot: st } = await chrome.storage.local.get("efbot");
  try { await bgOpenPatient(tab, job.name, st); } catch (e) { return { status: "failed", note: "άνοιγμα ασθενή: " + e.message }; }
  bgMark("άνοιγμα ασθενή");
  const T0 = (fn, args, ms) => Promise.race([new Promise((r) => setTimeout(() => r({ err: "όριο " + Math.round((ms || 15000) / 1000) + "″" }), ms || 15000)), pfExec(tab.id, fn, args || []).catch((e) => ({ err: e.message }))]);
  const who = await T0(() => String((document.querySelector("#appForm\\:content > nav > ol") || {}).innerText || "") + " " + String((document.getElementById("appForm:content") || document.body).innerText || "").slice(0, 400));
  const whoN = NZ(typeof who === "string" ? who : "");
  if (!NZ(job.name).split(" ").every((w) => whoN.includes(w))) return { status: "failed", note: "δεν επιβεβαιώθηκε ο ασθενής στον φάκελο — δεν έγινε τίποτα" };
  if (!(await emrClickText(tab.id, /^Διάγνωση$/i, true).catch(() => false))) return { status: "failed", note: "δεν βρέθηκε η ενότητα «Διάγνωση»" };
  await bgSettle(tab.id, 4000); bgMark("ενότητα Διάγνωση");
  const table = () => T0(() => [...document.querySelectorAll("[id='appForm:j_idt519_data'] > tr, [id$='_data'] > tr[data-rk]")].map((r) => [...r.children].map((c) => String(c.textContent || "").replace(/\s+/g, " ").trim()).join(" | ")).filter((t) => /\([A-Z]\d/.test(t)));
  const done = [], skip = [], fail = [], tr = [];
  for (const code of codes) {
    const rows0 = await table(); const has = (rows) => Array.isArray(rows) && rows.some((t) => /ΠΑΘΗΣΗ/.test(t) && t.includes("(" + code + ")"));
    if (has(rows0)) { skip.push(code); continue; }
    // 1) φόρμα «Προσθήκη Διάγνωσης» + τύπος ΠΑΘΗΣΗ + κωδικός + 🔍 (επιστροφή αμέσως)
    const go = await T0((code) => {
      const vis = (e) => { if (!e) return false; const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      let inp = document.getElementById("appForm:icd10DiagnosisInput");
      if (!vis(inp)) { const b = document.getElementById("appForm:SkipValidationAddDiagnosisDRG"); if (!b) return { err: "χωρίς «Προσθήκη Διάγνωσης»" }; b.click(); return { opened: 1 }; }
      return { ready: 1 };
    }, [code]);
    if (go && go.err) { fail.push(code + ": " + go.err); continue; }
    if (go && go.opened) { for (let i = 0; i < 20; i++) { await E.sleep(400); const x = await T0(() => { const e = document.getElementById("appForm:icd10DiagnosisInput"); const b = e && e.getBoundingClientRect(); let busy = false; try { busy = !PrimeFaces.ajax.Queue.isEmpty(); } catch (er) {} return !!(b && b.width > 0) && !busy; }, [], 3000); if (x === true) break; } await E.sleep(300); }
    const g2 = await T0((code) => {
      const inp = document.getElementById("appForm:icd10DiagnosisInput"), sb = document.getElementById("appForm:searchButtonIcd10Diagnosis");
      if (!inp || !sb) return { err: "χωρίς πεδίο ICD" };
      try { PF("widget_appForm_diagnosisTypeInputDRG").selectValue("14"); } catch (e) { return { err: "τύπος: " + e.message }; }
      const md = document.getElementById("appForm:icd10DiagnosisDrgSearchResultModal"); window.__efDx0 = String((md || {}).textContent || "");
      // η τιμή του πεδίου φτάνει στον διακομιστή με το «blur» (ajax) — όπως όταν ο χρήστης φεύγει από το πεδίο· ΜΕΤΑ το 🔍
      inp.focus(); inp.value = code; inp.dispatchEvent(new Event("input", { bubbles: true })); setTimeout(() => { try { inp.blur(); } catch (e) {} }, 50); return { ok: 1 };
    }, [code]);
    if (g2 && g2.err) { fail.push(code + ": " + g2.err); continue; }
    for (let i = 0; i < 25; i++) { await E.sleep(300); const x = await T0(() => { try { return PrimeFaces.ajax.Queue.isEmpty(); } catch (e) { return true; } }, [], 3000); if (x === true && i > 1) break; }
    await T0(() => { const sb = document.getElementById("appForm:searchButtonIcd10Diagnosis"); if (sb) setTimeout(() => sb.click(), 50); return 1; });
    // 2) αποτελέσματα (αργούν): γραμμή που αρχίζει ΑΚΡΙΒΩΣ με «CODE:»
    let pick = null;
    for (let i = 0; i < 35 && !pick; i++) { await E.sleep(1000);
      const r = await T0((code) => { const md = document.getElementById("appForm:icd10DiagnosisDrgSearchResultModal"); if (!md) return null; const rows = [...md.querySelectorAll("tbody tr[data-rk]")].map((x) => ({ rk: x.getAttribute("data-rk"), t: String(x.textContent || "").replace(/\s+/g, " ").trim() })); const ex = rows.filter((x) => x.t.startsWith(code + ":")); return { n: rows.length, ex: ex.map((x) => x.rk), t: rows.slice(0, 3).map((x) => x.t.slice(0, 60)) }; }, [code], 5000);
      if (r && r.ex && r.ex.length === 1) pick = r.ex[0]; else if (r && r.ex && r.ex.length > 1) { fail.push(code + ": πολλές γραμμές"); break; }
      if (i === 34) tr.push(code + " χωρίς αποτέλεσμα (" + JSON.stringify(r || {}).slice(0, 160) + ")"); }
    if (!pick) { if (!fail.some((f) => f.startsWith(code))) fail.push(code + ": δεν βρέθηκε στη λίστα ICD του ΝΠΣ"); continue; }
    // 3) επιλογή της γραμμής (κλικ στη γραμμή — όπως ο χρήστης)
    await T0((rk) => { const md = document.getElementById("appForm:icd10DiagnosisDrgSearchResultModal"); const r = md && md.querySelector("tbody tr[data-rk='" + CSS.escape(rk) + "']"); if (!r) return { err: "χάθηκε η γραμμή" }; (r.querySelector("td") || r).click(); return { ok: 1 }; }, [pick]);
    for (let i = 0; i < 30; i++) { await E.sleep(300); const x = await T0(() => { try { return PrimeFaces.ajax.Queue.isEmpty(); } catch (e) { return true; } }, [], 3000); if (x === true && i > 2) break; }
    // 4) έλεγχος πριν την αποθήκευση: τύπος = ΠΑΘΗΣΗ και το ICD της φόρμας = ο κωδικός
    const chk = await T0((code) => { const ty = document.getElementById("appForm:diagnosisTypeInputDRG"); const tyL = String(((ty && ty.querySelector("label")) || {}).textContent || "").trim(); const inp = document.getElementById("appForm:icd10DiagnosisInput"); const v = String((inp || {}).value || ""); const near = String(((inp && inp.closest("tr,div")) || {}).textContent || "").replace(/\s+/g, " ").slice(0, 200); return { tyL, v, near, okTy: /ΠΑΘΗΣΗ/.test(tyL), okCode: v.toUpperCase().includes(code) || near.toUpperCase().includes(code) }; }, [code]);
    tr.push(code + " πριν: " + JSON.stringify(chk || {}).slice(0, 220));
    if (!(chk && chk.okTy && chk.okCode) || p.dry) { fail.push(code + ": " + (p.dry ? "δοκιμή χωρίς αποθήκευση" : "η φόρμα δεν δείχνει ΠΑΘΗΣΗ + " + code + " — ΔΕΝ αποθηκεύτηκε")); continue; }
    // 5) αποθήκευση («Προσθήκη Διάγνωσης» της φόρμας) + επιβεβαίωση στον πίνακα
    await T0(() => { const b = document.getElementById("appForm:createDiagnosisBtnDRG"); if (!b) return { err: "χωρίς κουμπί" }; b.click(); return { ok: 1 }; });
    for (let i = 0; i < 40; i++) { await E.sleep(300); const x = await T0(() => { try { return PrimeFaces.ajax.Queue.isEmpty(); } catch (e) { return true; } }, [], 3000); if (x === true && i > 2) break; }
    let ok = false; for (let i = 0; i < 10 && !ok; i++) { ok = has(await table()); if (!ok) await E.sleep(1000); }
    const msg = await T0(() => [...document.querySelectorAll(".ui-messages, .ui-growl-message, .ui-message")].map((e) => String(e.textContent || "").replace(/\s+/g, " ").trim()).filter(Boolean).join(" · ").slice(0, 200));
    if (ok) done.push(code); else fail.push(code + ": δεν φάνηκε στον πίνακα" + (typeof msg === "string" && msg ? " (" + msg + ")" : ""));
    bgMark("ICD " + code + (ok ? " ✓" : " ✗"));
  }
  const rowsEnd = await table();
  return { status: fail.length && !done.length && !skip.length ? "failed" : "done",
    note: "🩺 «Διάγνωση» (ΠΑΘΗΣΗ): " + (done.length ? "✓ " + done.join(", ") : "—") + (skip.length ? " · υπήρχαν ήδη: " + skip.join(", ") : "") + (fail.length ? " · ⚠ " + fail.join(" · ") : ""),
    result: { done, skip, fail, tr, rows: Array.isArray(rowsEnd) ? rowsEnd.slice(0, 12) : rowsEnd } };
};
// 🌤 ΝΠΣ «3434 – ΟΥΡΟΛΟΓΙΚΟ ΗΜΕΡΑΣ»: λίστα ασθενών + χαρτογράφηση «Συγκεντρωτικό Εξιτήριο» — ΜΟΝΟ ανάγνωση (κανένα κουμπί).
// Το τμήμα ανοίγει μόνο με λογαριασμό ειδικού (payload.emrUser, προεπιλογή KDOUROUMIS): αλλαγή λογαριασμού στο ΔΙΚΟ του παράθυρο.
// 🏥 6/11: «Ασθενείς ΝΠΣ» — ΜΟΝΟ ανάγνωση της λίστας νοσηλευομένων (όλες οι σελίδες) για σύγκριση με το Παραδόχαρτο.
// 3434 (Ουρολογικό Ημέρας) → ίδια ροή με το dayunit (λογαριασμός ειδικού), χωρίς χαρτογράφηση.
// 🏥 7/11: η ΠΡΑΓΜΑΤΙΚΗ λίστα της κλινικής = καρτέλα «Διαχείριση Κλινικής» → «Ασθενείς» («Σύνολο ασθενών: N») — όχι αποτέλεσμα αναζήτησης.
// ΜΟΝΟ ανάγνωση: κλικ σε καρτέλα/πάνελ/σελίδες. Στο τέλος επιστρέφει στην καρτέλα «Διαχείριση Ασθενών».
async function emrClinicPanelRead(tabId) {
  const [r] = await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, world: "MAIN", func: async () => {
    try {
      const T = (e) => (e && (e.innerText || e.textContent) || "").replace(/\s+/g, " ").trim();
      const nz = (x) => String(x || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
      const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
      const idle = async () => { const t0 = Date.now(); await sleep(80); while (Date.now() - t0 < 15000) { let busy = false; try { busy = !PrimeFaces.ajax.Queue.isEmpty(); } catch (e) {} if (!busy) return; await sleep(80); } };
      const vis = (e) => { if (!e) return false; const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0; };
      const tabs = [...document.querySelectorAll(".ui-tabs-nav li")];
      const tClin = tabs.find((li) => /διαχειριση\s+κλινικης/.test(nz(T(li)))), tPat = tabs.find((li) => /διαχειριση\s+ασθενων/.test(nz(T(li))));
      if (!tClin) return { err: "δεν βρέθηκε η καρτέλα «Διαχείριση Κλινικής»" };
      if (!/ui-state-active|ui-tabs-selected/.test(tClin.className)) { (tClin.querySelector("a") || tClin).click(); await idle(); await sleep(400); }
      // πάνελ «Ασθενείς» (μπορεί να φορτώνει με καθυστέρηση ή να είναι κλειστό)
      const findTbl = () => [...document.querySelectorAll("table")].filter(vis).filter((t) => { const h = nz(T(t.querySelector("thead"))); return /θαλαμ/.test(h) && /κλιν/.test(h) && !t.closest("[id='appForm:tabview:patientsTable']"); })[0];
      const headsNow = () => [...document.querySelectorAll(".ui-accordion-header, .ui-panel-titlebar, .ui-fieldset-legend, h3")].filter(vis);
      let tbl = null; for (let i = 0; i < 40 && !(tbl = findTbl()); i++) {
        if (i === 5 || i === 20) { const hA = headsNow().find((h) => /^ασθενεις\b/.test(nz(T(h)).trim())); if (hA) { (hA.querySelector("a,.ui-panel-titlebar-icon,.ui-accordion-toggle-icon") || hA).click(); await idle(); } }
        await sleep(200); }
      if (!tbl) return { err: "δεν βρέθηκε ο πίνακας «Ασθενείς»", heads: headsNow().map(T).slice(0, 15), tables: [...document.querySelectorAll("table")].filter(vis).map((t) => T(t.querySelector("thead")).slice(0, 60)).slice(0, 10), tab: T(document.querySelector(".ui-tabs-nav li.ui-state-active")) };
      const box = tbl.closest(".ui-datatable") || tbl.parentElement;
      const scope = box.parentElement || document;
      const tot = +((T(scope).match(/Σύνολο\s+ασθενών\s*:\s*(\d+)/) || T(document.body).match(/Σύνολο\s+ασθενών\s*:\s*(\d+)/) || [])[1] || 0);
      const hs = [...tbl.querySelectorAll("thead th")].map(T);
      const read = () => [...box.querySelectorAll("tbody tr")].map((tr) => [...tr.children].map(T)).filter((c) => c.length >= 2 && c.join("").trim());
      const sig = () => read().map((c) => c.join("|")).join("#");
      const seen = new Map(); const t0 = Date.now(); let pages = 1;
      // όσο πιο πολλές γραμμές ανά σελίδα γίνεται (επιλογή του πίνακα), αλλιώς σελίδα-σελίδα
      const rpp = box.querySelector(".ui-paginator-rpp-options"); if (rpp) { const best = [...rpp.options].map((o) => +o.value).filter((n) => n > 0).sort((a, b) => b - a)[0]; if (best && +rpp.value !== best) { const s0 = sig(); rpp.value = String(best); rpp.dispatchEvent(new Event("change", { bubbles: true })); await idle(); const tw = Date.now(); while (sig() === s0 && Date.now() - tw < 5000) await sleep(80); } }
      for (const c of read()) seen.set(c.join("|"), c);
      for (let i = 0; i < 20 && Date.now() - t0 < 60000; i++) {
        const nx = box.querySelector(".ui-paginator-next"); if (!nx || /ui-state-disabled/.test(nx.className)) break;
        const s0 = sig(); nx.click(); await idle(); const tw = Date.now(); while (sig() === s0 && Date.now() - tw < 6000) await sleep(80); if (sig() === s0) break;
        pages++; for (const c of read()) seen.set(c.join("|"), c);
      }
      const first = box.querySelector(".ui-paginator-first"); if (first && !/ui-state-disabled/.test(first.className)) { first.click(); await idle(); }
      if (tPat) { (tPat.querySelector("a") || tPat).click(); await idle(); }
      return { hs, rows: [...seen.values()], pages, tot };
    } catch (e) { return { err: String(e && e.message || e) }; }
  } }).catch((e) => [{ result: { err: e.message } }]);
  return (r && r.result) || { err: "δεν απάντησε" };
}
JOB_RUNNERS.npslist = async (job) => {
  const p = job.payload || {};
  if (String(p.dpt || "") === "3434") { const r = await JOB_RUNNERS.dayunit({ ...job, payload: { ...p, map: false } }); if (r && r.result) r.result.dpt = "3434"; if (r && r.status === "done") r.note = "🏥 ΝΠΣ 3434: " + ((r.result && r.result.rows) || []).length + " ασθενείς"; return r; }
  const tab = await bgEmrTab(); if (!tab || tab.err) return { status: "failed", note: tab?.err || "δεν άνοιξε ο φάκελος" };
  const lg = await bgEnsureLogin(tab.id); if (!lg.ok) return { status: "failed", note: lg.err };
  if (await bgEmrListVis(tab.id) !== 1) await bgEmrToList(tab.id);
  const cl = await emrClinicEnsure(tab.id, true).catch((e) => ({ err: e.message }));
  await E.sleep(600);
  // ποτέ κόλλημα: όριο 50″ (7/11 έμεινε >5′ «σε εξέλιξη»)
  let cp = !p.panel ? { err: "παράλειψη", skip: true } : await Promise.race([emrClinicPanelRead(tab.id).catch((e) => ({ err: e.message })), new Promise((r) => setTimeout(() => r({ err: "χρονικό όριο 50″", timeout: true }), 50000))]);
  if (cp && cp.timeout) { try { await bgEmrClean(tab.id, true); await bgEnsureLogin(tab.id); if (await bgEmrListVis(tab.id) !== 1) await bgEmrToList(tab.id); await emrClinicEnsure(tab.id, true).catch(() => {}); } catch (e) {} }
  let r = null;
  if (cp && !cp.err && (cp.rows || []).length && (!cp.tot || cp.tot === cp.rows.length)) r = { hs: cp.hs, rows: cp.rows.map((c, i) => ({ rk: "k" + i, c })), pages: cp.pages, flt: { src: "Διαχείριση Κλινικής" }, tot: cp.tot };
  if (!r && !(cp && cp.timeout) && !(cp && cp.skip && Date.now() - (self.__npsCleanAt || 0) < 0)) { self.__npsCleanAt = Date.now(); try { await bgEmrClean(tab.id, true); await bgEnsureLogin(tab.id); if (await bgEmrListVis(tab.id) !== 1) await bgEmrToList(tab.id); await emrClinicEnsure(tab.id, true).catch(() => {}); await E.sleep(600); } catch (e) {} }   // καθαρή σελίδα → καθαρή αναζήτηση
  if (!r) r = (await chrome.scripting.executeScript({ target: { tabId: tab.id, frameIds: [0] }, world: "MAIN", func: async () => {
    try {
      const T = (e) => (e && (e.innerText || e.textContent) || "").replace(/\s+/g, " ").trim();
      const idle = () => new Promise((res) => { const t0 = Date.now(); const f = () => { let busy = false; try { busy = !PrimeFaces.ajax.Queue.isEmpty(); } catch (e) {} if (!busy || Date.now() - t0 > 15000) return res(); setTimeout(f, 60); }; setTimeout(f, 60); });
      const inp = document.getElementById("appForm:tabview:surname");
      if (window.PrimeFaces) { if (inp) inp.value = ""; for (const k of ["name", "father_name", "pat_sn", "hosp_pat_sn", "lastname", "firstname"]) { const e = document.getElementById("appForm:tabview:" + k); if (e) e.value = ""; }   // 7/11: ΠΑΝΤΑ καθαρή αναζήτηση (το φίλτρο μπορεί να έχει μείνει στον server από προηγούμενο άνοιγμα ασθενή → «1 ασθενής»)
        { const r0 = document.getElementById("appForm:tabview:isInnerPatient:0"), r1 = document.getElementById("appForm:tabview:isInnerPatient:1"); if (r0 && r1) { r0.checked = true; r1.checked = false; } const df = document.getElementById("appForm:tabview:dateInputFrom_input"); if (df) df.value = ""; } await new Promise((res) => { PrimeFaces.ab({ s: "appForm:tabview:SkipValidationSearchPatientsBtn", f: "appForm", u: "appForm:tabview appForm:menuRight appForm:content appForm:tabview:patientGrid", oncomplete: () => res() }); setTimeout(res, 8000); }); await idle(); }
      const hs = [...document.querySelectorAll("#appForm\\:tabview\\:patientsTable thead th")].map(T);
      const W = Object.values((window.PrimeFaces && PrimeFaces.widgets) || {}).find((w) => w && w.id === "appForm:tabview:patientsTable");
      const P = W && (W.getPaginator ? W.getPaginator() : W.paginator);
      const pc = (P && (P.getPageCount ? P.getPageCount() : (P.cfg && P.cfg.pageCount))) || 1;
      const read = () => [...document.querySelectorAll("#appForm\\:tabview\\:patientsTable_data > tr[data-rk]")].map((tr) => ({ rk: tr.getAttribute("data-rk") || "", c: [...tr.children].map(T) }));
      const seen = new Map(); const t0 = Date.now();
      for (let pg = 0; pg < Math.min(pc, 15) && Date.now() - t0 < 45000; pg++) {
        if (pg > 0 && P && P.setPage) { const s0 = read().map((x) => x.rk + x.c.join()).join("|"); P.setPage(pg); await idle(); const tw = Date.now(); while (read().map((x) => x.rk + x.c.join()).join("|") === s0 && Date.now() - tw < 6000) await new Promise((r) => setTimeout(r, 80)); await idle(); await new Promise((r) => setTimeout(r, 120)); }
        for (const x of read()) if (!seen.has(x.rk + "|" + x.c.join("|"))) seen.set(x.rk + "|" + x.c.join("|"), x);
      }
      if (P && P.setPage && pc > 1) { P.setPage(0); await idle(); }
      const tot = +((document.body.innerText.match(/Σύνολο\s+ασθενών\s*:\s*(\d+)/) || [])[1] || 0);
      const flt = { inner: !!(document.querySelector("[id='appForm:tabview:isInnerPatient:0']") || {}).checked, dept: T(document.querySelector("[id$='dptInput_label']")) };
      return { hs, rows: [...seen.values()], pages: pc, flt, tot };
    } catch (e) { return { err: String(e && e.message || e) }; }
  } }).catch((e) => [{ result: { err: e.message } }]))[0]?.result || { err: "δεν απάντησε" };
  if (r.err) return { status: "failed", note: "🏥 ΝΠΣ: " + r.err + (cp && cp.err ? " · Διαχείριση Κλινικής: " + cp.err : "") };
  if (cp && cp.err && !cp.skip) r.cpErr = cp.err + (cp.heads ? " · τίτλοι: " + cp.heads.join(" / ").slice(0, 200) : "") + (cp.tables ? " · πίνακες: " + cp.tables.join(" / ").slice(0, 200) : "") + (cp.tab ? " · καρτέλα: " + cp.tab : ""); else if (cp && cp.tot && cp.tot !== (cp.rows || []).length) r.cpErr = "Διαχείριση Κλινικής: διάβασα " + (cp.rows || []).length + " από " + cp.tot;
  const nz = (x) => String(x || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  const ix = (re) => (r.hs || []).findIndex((h) => re.test(nz(h)));
  const iRoom = ix(/θαλαμ/), iBed = ix(/κλιν/), iName = ix(/ον\/?νυμο|ονοματεπ|ασθεν/), iAdm = ix(/εισαγ|ημ\/?νια/), iAm = ix(/κωδ|α\.?\s?μ\.?$|μητρ/), iDoc = ix(/θεραπ|ιατρ/), iAmka = ix(/αμκα/);
  const rows = (r.rows || []).map((x) => ({ room: iRoom >= 0 ? x.c[iRoom] : "", bed: iBed >= 0 ? x.c[iBed] : "", name: iName >= 0 ? x.c[iName] : "", admit: iAdm >= 0 ? x.c[iAdm] : "", am: iAm >= 0 ? (String(x.c[iAm]).match(/\d{6,9}/) || [""])[0] : "", amka: iAmka >= 0 ? (String(x.c[iAmka]).match(/\d{11}/) || [""])[0] : "", doc: iDoc >= 0 ? x.c[iDoc] : "", cells: x.c.slice(0, 12) })).filter((x) => x.name);
  return { status: "done", note: "🏥 ΝΠΣ " + (r.flt && (r.flt.dept || r.flt.src) || "") + ": " + rows.length + " ασθενείς (" + r.pages + " σελ.)" + (r.cpErr ? " · ⚠ " + r.cpErr : "") + (r.tot ? (r.tot === rows.length ? " ✓ ίδιο με το «Σύνολο»" : " ⚠ το ΝΠΣ γράφει Σύνολο " + r.tot) : ""), result: { dpt: "3449", heads: r.hs, rows, flt: r.flt, clinic: cl, at: Date.now() } };
};
JOB_KIND.npslist = "🏥 ΝΠΣ: ασθενείς κλινικής";
JOB_LIMIT_S.npslist = 180;
JOB_RUNNERS.dayunit = async (job) => {
  const p = job.payload || {};
  const want = String(p.emrUser || "KDOUROUMIS").trim();
  const acc = (await emrAccounts()).find((a) => a.user.toLowerCase() === want.toLowerCase());
  if (!acc) return { status: "failed", note: "🌤 ο λογαριασμός ΝΠΣ «" + want + "» δεν είναι αποθηκευμένος σε αυτόν τον υπολογιστή (🔐 Κωδικοί του bot)" };
  let tab = await bgEmrTab(); if (!tab || tab.err) return { status: "failed", note: tab?.err || "δεν άνοιξε ο φάκελος" };
  const who = async () => String(await pfExec(tab.id, () => { const b = document.getElementById("appForm:dynaButton"); return b ? (b.innerText || b.textContent || "").trim() : ""; }).catch(() => "") || "");
  let lg = await bgEnsureLogin(tab.id); if (!lg.ok) return { status: "failed", note: lg.err };
  if ((await who()).toLowerCase().indexOf(acc.user.toLowerCase()) < 0) {
    // ΜΟΝΟ καρτέλες ΝΠΣ του ανώνυμου παραθύρου του bot — ποτέ του χρήστη
    await chrome.storage.session.set({ efbotEmrOnce: { user: acc.user, at: Date.now() } });
    await botIncogReset();
    tab = await bgEmrTab(); if (!tab || tab.err) return { status: "failed", note: tab?.err || "δεν άνοιξε ο φάκελος" };
    lg = await bgEnsureLogin(tab.id); if (!lg.ok) return { status: "failed", note: lg.err };
    await chrome.storage.session.remove("efbotEmrOnce").catch(() => {});
    const w2 = await who();
    if (w2 && w2.toLowerCase().indexOf(acc.user.toLowerCase()) < 0) return { status: "failed", note: "🌤 δεν μπήκε με " + acc.user + " (συνδεδεμένος: " + w2 + ")" };
  }
  if (await bgEmrListVis(tab.id) !== 1) await bgEmrToList(tab.id);
  const cl = await emrClinicEnsure(tab.id, true, /(^|\D)3434(\D|$)|ΟΥΡΟΛΟΓΙΚΟ\s+ΗΜΕΡΑΣ/).catch((e) => ({ err: e.message }));
  if (!cl || !cl.ok) return { status: "failed", note: "🌤 δεν άνοιξε το «3434 – ΟΥΡΟΛΟΓΙΚΟ ΗΜΕΡΑΣ»: " + String((cl && (cl.err || cl.to || cl.cur)) || "").slice(0, 160), result: { clinic: cl } };
  await E.sleep(1200);
  const list = await pfExec(tab.id, () => {
    const T = (e) => (e && (e.innerText || e.textContent) || "").replace(/\s+/g, " ").trim();
    const hs = [...document.querySelectorAll("#appForm\\:tabview\\:patientsTable thead th")].map(T);
    const rows = [...document.querySelectorAll("#appForm\\:tabview\\:patientsTable_data > tr[data-rk]")].map((tr) => [...tr.children].map(T)).slice(0, 80);
    const pag = document.querySelector("#appForm\\:tabview\\:patientsTable .ui-paginator");
    return { hs, rows, pager: pag ? T(pag).slice(0, 120) : "" };
  }).catch((e) => ({ err: e.message }));
  const out = { clinic: cl, heads: (list && list.hs) || [], rows: [], pager: (list && list.pager) || "" };
  const ix = (re) => out.heads.findIndex((h) => re.test(String(h).normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase()));
  const iName = ix(/ον\/?νυμο|ονοματεπ|ασθεν/), iAmka = ix(/αμκα/), iAdm = ix(/εισαγ/), iAm = ix(/κωδ|α\.?\s?μ\.?$|μητρ/);
  out.rows = ((list && list.rows) || []).map((r) => ({ name: iName >= 0 ? r[iName] : "", amka: iAmka >= 0 ? (String(r[iAmka]).match(/\d{11}/) || [""])[0] : "", admit: iAdm >= 0 ? r[iAdm] : "", am: iAm >= 0 ? r[iAm] : "", cells: r.slice(0, 14) })).filter((x) => x.name || x.cells.some(Boolean));
  // χαρτογράφηση (ΜΟΝΟ ανάγνωση): «Μαζικές Διαδικασίες → Συγκεντρωτικό Εξιτήριο»
  if (p.map !== false) {
    await pfExec(tab.id, () => { const m = [...document.querySelectorAll("a, [role=menuitem], .ui-menuitem-link")].find((e) => /^μαζικ[εέ]ς\s+διαδικασ[ιί]ες$/i.test((e.innerText || e.textContent || "").trim())); if (!m) return false;
      for (const t of ["pointerover", "mouseover", "mouseenter", "pointerenter"]) m.dispatchEvent(new (t.startsWith("pointer") ? PointerEvent : MouseEvent)(t, { bubbles: true, cancelable: true, view: window })); return true; }).catch(() => false);
    await E.sleep(700);
    const okM = await emrClickText(tab.id, /^συγκεντρωτικ[οό]\s+εξιτ[ηή]ριο$/, true).catch(() => false);
    await E.sleep(3000);
    out.map = { clicked: String(okM), page: await pfExec(tab.id, () => {
      const T = (e) => (e && (e.innerText || e.textContent) || "").replace(/\s+/g, " ").trim();
      const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      const root = document.getElementById("appForm:content") || document.body;
      const lab = (e) => { const id = e.id || ""; const l = id && (document.querySelector("label[for='" + CSS.escape(id) + "']") || document.querySelector("label[for='" + CSS.escape(id.replace(/_input$/, "")) + "']")); return T(l).slice(0, 60) || T(e.closest("td,div") && e.closest("td,div").previousElementSibling).slice(0, 60); };
      const inputs = [...root.querySelectorAll("input:not([type=hidden]), select, textarea")].filter((e) => vis(e) || e.tagName === "SELECT").slice(0, 60)
        .map((e) => ({ id: e.id, tag: e.tagName.toLowerCase(), type: e.type || "", label: lab(e), opts: e.tagName === "SELECT" ? [...e.options].map((o) => o.text.trim()).slice(0, 40) : undefined }));
      const tbls = [...root.querySelectorAll("table")].filter(vis).map((t) => ({ id: t.id || (t.closest("[id]") || {}).id || "", heads: [...t.querySelectorAll("thead th")].map(T).filter(Boolean).slice(0, 20), n: t.querySelectorAll("tbody tr").length })).slice(0, 10);
      const labels = [...root.querySelectorAll("label, .ui-outputlabel, legend, h1, h2, h3, .ui-panel-title, .ui-fieldset-legend, .ui-tabs-nav li")].filter(vis).map(T).filter((t) => t && t.length < 70);
      const btns = [...root.querySelectorAll("button, a.ui-commandlink, a.ui-button, input[type=submit]")].filter(vis).map((b) => T(b) || b.value || "").filter((t) => t && t.length < 50);
      return { url: location.pathname, inputs, tbls, labels: [...new Set(labels)].slice(0, 80), btns: [...new Set(btns)].slice(0, 40) };
    }).catch((e) => ({ err: e.message })) };
  }
  await bgEmrToList(tab.id).catch(() => {});
  emrClinicOkAt[tab.id] = 0;   // η επόμενη εργασία ξαναγυρνά στην 3449
  return { status: "done", note: "🌤 Ουρολογικό Ημέρας: " + out.rows.length + " ασθενείς" + (out.map ? " · χαρτογράφηση Συγκεντρωτικού Εξιτηρίου: " + (out.map.clicked === "false" ? "δεν βρέθηκε" : ((out.map.page && out.map.page.inputs) || []).length + " πεδία") : ""), result: out };
};
JOB_KIND.dayunit = "🌤 Ουρολογικό Ημέρας: ασθενείς (μόνο ανάγνωση)";
JOB_LIMIT_S.dayunit = 180;
// 🏥 ΝΠΣ: νοσηλείες (Επεισόδια) + εξιτήρια ενός ασθενή — ΜΟΝΟ ανάγνωση (ακριβές κείμενο μενού, κανένα κουμπί)
// 🔎 6/11: διάγνωση λίστας ασθενών ΝΠΣ (ΜΟΝΟ ανάγνωση): κλινική, σελίδες, πλήθος, ενεργά φίλτρα, πόσες γραμμές ταιριάζουν με ένα κομμάτι
// ονόματος (π.χ. «ΜΠΕΓ») — χωρίς να καταγράφονται ονόματα άλλων ασθενών.
JOB_RUNNERS.npslistdiag = async (job) => {
  const p = job.payload || {}, tok = String(p.tok || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().trim();
  if (tok.length < 3) return { status: "failed", note: "χωρίς κομμάτι ονόματος (≥3)" };
  const tab = await bgEmrTab(); if (!tab || tab.err) return { status: "failed", note: tab?.err || "δεν άνοιξε ο φάκελος" };
  const lg = await bgEnsureLogin(tab.id); if (!lg.ok) return { status: "failed", note: lg.err };
  if (await bgEmrListVis(tab.id) !== 1) await bgEmrToList(tab.id);
  const cl = await emrClinicEnsure(tab.id).catch((e) => ({ err: e.message }));
  const snap = async () => (await chrome.scripting.executeScript({ target: { tabId: tab.id, frameIds: [0] }, world: "MAIN", args: [tok], func: (tok) => {
    const nz = (x) => String(x || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().replace(/\s+/g, " ").trim();
    const rows = [...document.querySelectorAll("#appForm\\:tabview\\:patientsTable_data > tr[data-rk]")];
    const pag = (document.querySelector("#appForm\\:tabview\\:patientsTable_paginator_bottom, #appForm\\:tabview\\:patientsTable_paginator_top, .ui-paginator") || {}).innerText || "";
    const filt = [...document.querySelectorAll("#appForm\\:tabview input:not([type=hidden]), #appForm\\:tabview select, #appForm\\:tabview .ui-selectonemenu-label, #appForm\\:tabview .ui-chkbox-box")].map((e) => (e.id || e.className || "").replace(/^appForm:tabview:/, "").slice(0, 40) + "=" + (e.type === "checkbox" ? e.checked : /ui-chkbox-box/.test(e.className) ? /ui-state-active/.test(e.className) : String(e.value || e.innerText || "").slice(0, 30))).filter((x) => !/surname=|name=.{4,}/i.test(x)).slice(0, 25);
    const tabs = [...document.querySelectorAll("#appForm\\:tabview .ui-tabs-nav li")].map((li) => (li.innerText || "").trim() + (/ui-state-active|ui-tabs-selected/.test(li.className) ? "*" : "")).slice(0, 8);
    const dept = (document.querySelector("[id$='dptInput_label'], [id*='dpt'] .ui-selectonemenu-label") || {}).innerText || "";
    return { n: rows.length, hits: rows.filter((r) => nz(r.textContent).includes(tok)).length, pag: pag.replace(/\s+/g, " ").slice(0, 80), filt, tabs, dept: dept.slice(0, 50) };
  } }).catch((e) => [{ result: { err: e.message } }]))[0]?.result || {};
  const a = await snap();
  // και με αναζήτηση επωνύμου (όπως το γρήγορο άνοιγμα)
  await chrome.scripting.executeScript({ target: { tabId: tab.id, frameIds: [0] }, world: "MAIN", args: [tok], func: async (tok) => { const inp = document.getElementById("appForm:tabview:surname"); if (!inp || !window.PrimeFaces) return; inp.value = tok;
    await new Promise((res) => { PrimeFaces.ab({ s: "appForm:tabview:SkipValidationSearchPatientsBtn", f: "appForm", u: "appForm:tabview appForm:menuRight appForm:content appForm:tabview:patientGrid", oncomplete: () => res() }); setTimeout(res, 8000); }); } }).catch(() => {});
  await E.sleep(1200);
  const b = await snap();
  // επαναφορά: άδειο επώνυμο
  await chrome.scripting.executeScript({ target: { tabId: tab.id, frameIds: [0] }, world: "MAIN", func: async () => { const inp = document.getElementById("appForm:tabview:surname"); if (!inp || !window.PrimeFaces) return; inp.value = "";
    await new Promise((res) => { PrimeFaces.ab({ s: "appForm:tabview:SkipValidationSearchPatientsBtn", f: "appForm", u: "appForm:tabview appForm:menuRight appForm:content appForm:tabview:patientGrid", oncomplete: () => res() }); setTimeout(res, 8000); }); } }).catch(() => {});
  return { status: "done", note: "🔎 ΝΠΣ λίστα: κλινική «" + (a.dept || (cl && cl.cur) || "?") + "» · χωρίς φίλτρο: " + a.n + " γραμμές, «" + tok + "» " + a.hits + " · " + a.pag + " · με αναζήτηση επωνύμου: " + b.n + " γραμμές, ταιριάζουν " + b.hits + " · " + b.pag + " · καρτέλες: " + (a.tabs || []).join("/") + " · φίλτρα: " + (a.filt || []).join(", "), result: { a, b, cl } };
};
JOB_KIND.npslistdiag = "🔎 ΝΠΣ: διάγνωση λίστας";
JOB_LIMIT_S.npslistdiag = 120;
// φίλτρα της λίστας ασθενών του ΝΠΣ: επώνυμο, νοσηλευόμενοι (inner) ή όχι, ημερομηνία από. Επιστρέφει πόσες γραμμές βγήκαν.
async function emrListFilter(tabId, o) {
  const [r] = await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, world: "MAIN", args: [o], func: async (o) => {
    if (!window.PrimeFaces) return { err: "χωρίς PrimeFaces" };
    const sn = document.getElementById("appForm:tabview:surname"); for (const k of ["name", "father_name", "pat_sn", "hosp_pat_sn"]) { const e = document.getElementById("appForm:tabview:" + k); if (e) e.value = ""; }
    if (sn) sn.value = o.surname || ""; else { const nm = document.getElementById("appForm:tabview:name"); if (nm) nm.value = o.surname || ""; }
    const r0 = document.getElementById("appForm:tabview:isInnerPatient:0"), r1 = document.getElementById("appForm:tabview:isInnerPatient:1");
    if (r0 && r1) { r0.checked = !!o.inner; r1.checked = !o.inner; [r0, r1].forEach((x) => { const box = x.closest(".ui-radiobutton") && x.closest(".ui-radiobutton").querySelector(".ui-radiobutton-box"); if (box) box.classList.toggle("ui-state-active", x.checked); }); }
    else if (!o.inner) return { err: "δεν βρέθηκε η επιλογή «νοσηλευόμενοι»" };
    const df = document.getElementById("appForm:tabview:dateInputFrom_input"); if (df) df.value = o.from || "";
    await new Promise((res) => { PrimeFaces.ab({ s: "appForm:tabview:SkipValidationSearchPatientsBtn", f: "appForm", u: "appForm:tabview appForm:menuRight appForm:content appForm:tabview:patientGrid", oncomplete: () => res() }); setTimeout(res, 12000); });
    await new Promise((r) => setTimeout(r, 600));
    return { n: document.querySelectorAll("#appForm\\:tabview\\:patientsTable_data > tr[data-rk]").length };
  } }).catch((e) => [{ result: { err: e.message } }]);
  return (r && r.result) || { err: "χωρίς απάντηση" };
}
// 🏥 7/11: ασθενείς ΝΠΣ που ΔΕΝ είναι στο Παραδόχαρτο → ΑΜ/ΑΜΚΑ από τον ΝΠΣ + διαγνώσεις ΑΗΦΥ (μόνο ανάγνωση).
// Τα αποτελέσματα μένουν στην εργασία· η εφαρμογή τα δείχνει στη λίστα και τα περνά στον ασθενή όταν μπει σε κρεβάτι.
JOB_RUNNERS.npsenrich = async (job) => {
  const p = job.payload || {}, names = (Array.isArray(p.names) ? p.names : []).map((x) => String(x || "").trim()).filter(Boolean).slice(0, 10);
  if (!names.length) return { status: "done", note: "🏥 τίποτα για συμπλήρωση", result: { pts: {} } };
  const pts = {}, t0 = Date.now(); let nA = 0, nD = 0;
  for (const name of names) {
    if (Date.now() - t0 > 200000) break;
    const r = await JOB_RUNNERS.npspat({ ...job, name, payload: { name, quiet: true } }).catch((e) => ({ status: "failed", note: e.message }));
    const o = (r && r.result) || {}; pts[name] = { amka: o.amka || "", am: o.am || "", father: o.father || "", full: o.full || "", adm: (o.adm || [])[0] || null, err: r && r.status !== "done" ? String(r.note || "").slice(0, 120) : "" };
    if (o.amka) nA++;
  }
  // ΑΗΦΥ: διαγνώσεις για όσους βρέθηκε ΑΜΚΑ (ίδιος δρόμος με τις αυτόματες συννοσηρότητες — απευθείας αιτήματα)
  if (Object.values(pts).some((x) => /^\d{11}$/.test(x.amka))) { if (comorbBusy) comorbYield = true; for (let i = 0; i < 45 && comorbBusy; i++) await E.sleep(2000); }
  if (Object.values(pts).some((x) => /^\d{11}$/.test(x.amka)) && !comorbBusy) {
    comorbBusy = true;
    try {
      const host = await bgEhrHostTab(); const ehr = host && !host.err ? await bgEhrTab(host) : null;
      // 7/11: όπως οι άλλες εργασίες ΑΗΦΥ — αυτόματη σύνδεση αν χρειάζεται (πριν: «χωρίς σύνδεση» για όλους)
      let lgErr = ""; if (ehr && !(await ehrLoggedIn(ehr.id))) { const lg = await ahfyAutoLogin(ehr.id).catch((e) => ({ ok: false, err: e.message })); if (!lg || !lg.ok) lgErr = String((lg && lg.err) || "").slice(0, 80); }
      if (ehr && !lgErr && (await ehrLoggedIn(ehr.id))) {
        await ehrDialogClear(ehr.id).catch(() => {});
        for (const [name, x] of Object.entries(pts)) {
          if (!/^\d{11}$/.test(x.amka) || Date.now() - t0 > 260000) continue;
          const d = await ehrDirect(ehr.id, x.amka, name, { dx: true, labs: false }).catch((e) => ({ err: e.message }));
          if (d && d.ok && d.nameOk !== false) { x.dx = (d.lines || []).slice(0, 200); nD++; } else x.dxErr = String((d && d.err) || "όχι").slice(0, 100);
        }
      } else Object.values(pts).forEach((x) => { if (x.amka) x.dxErr = "ΑΗΦΥ: χωρίς σύνδεση" + (lgErr ? " · " + lgErr : ""); });
    } finally { comorbBusy = false; }
  }
  // 🧪 Medilabi: εργαστηριακά τους (με ΑΜΚΑ → ένας ασθενής) → στον ίδιο πίνακα με τους ασθενείς του Παραδόχαρτου (oncall_labs)
  let nL = 0; const up = [];
  for (const [name, x] of Object.entries(pts)) {
    if (!/^\d{11}$/.test(x.amka) || Date.now() - t0 > 280000) continue;
    try {
      const f = await JOB_RUNNERS.medfind({ id: 0, name: "", payload: { q: "", f: { amka: x.amka }, scope: "all", quiet: 1 } });
      const L = ((f && f.result && f.result.pts) || []).filter((c) => c.pid && String(c.row || "").includes(x.amka));
      const pids = [...new Set(L.map((c) => c.pid))]; if (pids.length !== 1) { x.medErr = pids.length ? pids.length + " ασθενείς" : "δεν βρέθηκε"; continue; }
      x.pid = pids[0];
      const m = await JOB_RUNNERS.medpt({ id: 0, name: "", payload: { pid: x.pid } });
      const all = m && m.result && m.result.all; if (all && (all.dates || []).length) { up.push({ name_key: Medilabi_norm(name), name, pid: x.pid, data: all }); nL++; }
    } catch (e) { x.medErr = String(e.message || e).slice(0, 80); }
  }
  if (up.length) { const r = await labsUploadAll(up).catch((e) => ({ err: e.message })); if (!r || !r.ok) Object.values(pts).forEach((x) => { if (x.pid) x.medErr = "αποστολή: " + ((r && r.err) || "?"); }); }
  return { status: "done", note: "🏥 ΝΠΣ εκτός Παραδόχαρτου: " + names.length + " · ΑΜΚΑ " + nA + " · ΑΗΦΥ " + nD + " · εργαστηριακά " + nL, result: { pts, at: Date.now() } };
};
JOB_KIND.npsenrich = "🏥 ΝΠΣ: στοιχεία ασθενών εκτός λίστας";
JOB_LIMIT_S.npsenrich = 420;
JOB_RUNNERS.npspat = async (job) => {
  const p = job.payload || {};
  const nm = String(p.name || job.name || "").trim(), amka = String(p.amka || "").replace(/\D/g, "");
  if (!nm) return { status: "failed", note: "χωρίς όνομα ασθενή" };
  const tab = await bgEmrTab(); if (!tab || tab.err) return { status: "failed", note: tab?.err || "δεν άνοιξε ο φάκελος" };
  const lg = await bgEnsureLogin(tab.id); if (!lg.ok) return { status: "failed", note: lg.err };
  if (await bgEmrListVis(tab.id) !== 1) await bgEmrToList(tab.id);
  const { efbot: st } = await chrome.storage.local.get("efbot");
  let outside = false;
  try { await bgOpenPatient(tab, nm, st); }
  catch (e) {
    // 7/11 (εντολή χρήστη): παλαιότεροι ασθενείς που ΔΕΝ νοσηλεύονται → φίλτρο «εκτός νοσοκομείου» + πολύ παλιά ημερομηνία + επώνυμο
    const f1 = await emrListFilter(tab.id, { surname: nm.split(/\s+/)[0], inner: false, from: "01/01/2000" }).catch((x) => ({ err: x.message }));
    let ok2 = false;
    if (f1 && !f1.err) { try { await bgOpenPatient(tab, nm, st); ok2 = true; outside = true; } catch (e2) {} }
    if (!ok2) { await emrListFilter(tab.id, { surname: "", inner: true, from: "" }).catch(() => {}); return { status: "failed", note: "🏥 ΝΠΣ: δεν βρέθηκε ούτε στους νοσηλευόμενους ούτε εκτός νοσοκομείου (από 2000) — " + e.message + (f1 && f1.err ? " · φίλτρο: " + f1.err : f1 && f1.n != null ? " · εκτός νοσοκομείου: " + f1.n + " γραμμές" : "") }; }
  }
  const T = (e) => (e && (e.innerText || e.textContent) || "").replace(/\s+/g, " ").trim();
  const head = await pfExec(tab.id, () => (document.getElementById("appForm:content") || document.body).innerText.replace(/\s+/g, " ").slice(0, 2500)).catch(() => "");
  const hAmka = (String(head).match(/ΑΜΚΑ\s*:\s*(\d{11})/) || [])[1] || "";
  // ⛔ ασφάλεια: αν ξέρουμε ΑΜΚΑ, πρέπει να ταιριάζει με αυτόν που άνοιξε (συνωνυμίες)
  if (amka && !hAmka) return { status: "failed", note: "🏥 ΝΠΣ: δεν διαβάστηκε ο ΑΜΚΑ του ασθενή που άνοιξε — σταμάτησα (συνωνυμίες)" };
  if (amka && hAmka && amka !== hAmka) return { status: "failed", note: "🏥 ΝΠΣ: άνοιξε άλλος ασθενής με ίδιο όνομα (ΑΜΚΑ δεν ταιριάζει) — σταμάτησα" };
  // 🪪 8/11: πατρώνυμο + ολόκληρο όνομα, αν τα γράφει η σελίδα του ασθενή (για την καρτέλα στο Παραδόχαρτο)
  // «Όνομα Πατέρα» είναι ΠΕΔΙΟ φόρμας (Γενικά Στοιχεία) → η τιμή του input (όχι το κείμενο της σελίδας)
  const fInfo = await pfExec(tab.id, () => {
    const vis = (e) => !!e && e.getBoundingClientRect().width > 0;
    const byId = [...document.querySelectorAll("input")].find((i) => /father|patr|pater/i.test(i.id || i.name || "") && String(i.value || "").trim());
    if (byId) return { v: byId.value, how: "id " + byId.id };
    for (const l of document.querySelectorAll("label, td, span, div")) {
      if (l.children.length > 2 || !/^\s*Όνομα Πατέρα\s*:?\s*$/.test(l.textContent || "")) continue;
      const f = l.getAttribute && l.getAttribute("for"); if (f && document.getElementById(f)) return { v: document.getElementById(f).value || "", how: "for" };
      let c = l; for (let k = 0; k < 4 && c; k++, c = c.parentElement) { const ins = [...c.querySelectorAll("input[type=text], input:not([type])")]; const after = ins.find((i) => l.compareDocumentPosition(i) & Node.DOCUMENT_POSITION_FOLLOWING); if (after) return { v: after.value || "", how: "δίπλα" }; }
    }
    return { v: "", ids: [...document.querySelectorAll("input")].filter(vis).map((i) => i.id).filter(Boolean).slice(0, 40) };
  }).catch((e) => ({ v: "", err: e.message }));
  const father = /^[Α-ΩΆ-ΏA-Z][Α-ΩΆ-Ώα-ωά-ώA-Za-z]{1,}$/.test(String((fInfo && fInfo.v) || "").trim()) ? String(fInfo.v).trim() : "";
  const fullName = ((String(head).match(/Όνομα\s*:\s*([Α-ΩΆ-Ώ][Α-ΩΆ-Ώ ]+?)\s+(?:ΑΜΚΑ|Α\.?Μ\.?Κ\.?Α|Ιατρικός)/) || [])[1] || "").trim();
  const out = { father: father.toUpperCase(), full: fullName, fDiag: fInfo, headDiag: String(head).replace(/\d{6,}/g, "#").slice(0, 900), amka: hAmka || amka, am: (String(head).match(/Κωδικός Ασθενή\s*:\s*(\d+)/) || [])[1] || "", clinicNow: (String(head).match(/Τμήμα Ιατρικής Ευθύνης\s*:\s*([^:]+?)(?=\s+[Α-ΩA-Z][^ ]* ?[^ ]* ?:|$)/) || [])[1] || "", adm: [], dc: [] };
  const iso = (d) => { const m = /(\d{2})-(\d{2})-(\d{4})(?:\s+(\d{2}):(\d{2}))?/.exec(d || ""); return m ? m[3] + "-" + m[2] + "-" + m[1] + (m[4] ? "T" + m[4] + ":" + m[5] : "") : ""; };
  if (await emrClickText(tab.id, /^Επεισόδια$/, true).catch(() => false)) {
    await bgSettle(tab.id, 6000);
    // 8/11 (εντολή χρήστη): ΑΝΟΙΓΜΑ ΟΛΩΝ των επεισοδίων (κάθε νοσηλεία μπορεί να πέρασε από πολλές κλινικές) → ποιες ήταν ΣΤΗΝ ΚΛΙΝΙΚΗ ΜΑΣ
    // και ποιες σε άλλες. Μόνο ανάγνωση: πατά ΜΟΝΟ «ανάπτυξη» (τρίγωνα/τίτλους ενοτήτων), ποτέ κουμπιά. Αναμονή = μέχρι να ησυχάσει η σελίδα.
    for (let k = 0; k < 40; k++) {
      const r = await pfExec(tab.id, () => {
        const root = document.getElementById("appForm:content") || document.body, vis = (e) => { const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0; };
        const t = [...root.querySelectorAll(".ui-row-toggler.ui-icon-circle-triangle-e, .ui-accordion-header[aria-expanded=false], .ui-fieldset-toggleable.ui-fieldset-collapsed > legend, .ui-panel-titlebar-icon .ui-icon-plusthick, .ui-tree-toggler.ui-icon-triangle-1-e, .ui-treetable-toggler.ui-icon-triangle-1-e")].filter(vis)
          .filter((e) => !e.__efOpened)[0];
        if (!t) return { done: true };
        t.__efOpened = 1; (t.closest("a") || t).click(); return { clicked: (t.className || t.tagName).toString().slice(0, 40) };
      }).catch((e) => ({ err: e.message }));
      if (!r || r.done || r.err) { out.epOpen = k; break; }
      await bgSettle(tab.id, 5000);
    }
    const ep = await pfExec(tab.id, () => {
      const root = document.getElementById("appForm:content") || document.body, T = (e) => (e && (e.innerText || e.textContent) || "").replace(/\s+/g, " ").trim();
      // κάθε επεισόδιο: το μικρότερο στοιχείο που περιέχει ΕΝΑ «Επεισόδιο :» (μαζί με ό,τι άνοιξε από κάτω)
      const heads = [...root.querySelectorAll("*")].filter((e) => e.children.length < 40 && /^Επεισόδιο\s*:/.test(T(e)) && !/Επεισόδιο\s*:[\s\S]*Επεισόδιο\s*:/.test(T(e)));
      const blocks = []; const seen = new Set();
      for (const h of heads) { let b = h; while (b.parentElement && b.parentElement !== root && (T(b.parentElement).match(/Επεισόδιο\s*:/g) || []).length <= 1) b = b.parentElement; if (seen.has(b)) continue; seen.add(b); blocks.push(T(b).replace(/\d{8,}/g, "#").slice(0, 3000)); }
      return { blocks, all: T(root).replace(/\d{8,}/g, "#").slice(0, 6000) };
    }).catch(() => ({ blocks: [], all: "" }));
    out.epDump = { n: (ep.blocks || []).length, sample: (ep.blocks || []).slice(0, 3).map((x) => x.slice(0, 700)) };
    const OURS = /ΟΥΡΟΛΟΓ/i, DEPT = /([Α-ΩΆ-Ώ][Α-ΩΆ-Ώ\-\. ]{2,60}?(?:ΚΛΙΝΙΚΗ|ΤΜΗΜΑ|ΜΟΝΑΔΑ|ΜΕΘ|Μ\.Ε\.Θ\.|ΤΕΠ|ΗΜΕΡΑΣ))/g;
    const src = (ep.blocks && ep.blocks.length) ? ep.blocks : [String(ep.all || "")];
    for (const b of src) for (const m of String(b).matchAll(/Επεισόδιο\s*:\s*(.+?)\s+Ημ\.Εισαγωγής\s*:\s*([\d\- :]+?)\s+Ημ\.Εξόδου\s*:\s*(-|[\d\- :]+?)(?=\s|$)/g)) {
      const depts = [...new Set([...String(b).matchAll(DEPT)].map((x) => x[1].trim().replace(/\s+/g, " ")))].slice(0, 12);
      const clinic = m[1].trim();
      out.adm.push({ clinic, from: iso(m[2]), to: m[3].trim() === "-" ? "" : iso(m[3]), depts, ours: OURS.test(clinic) || depts.some((d) => OURS.test(d)), det: String(b).slice(0, 1500) });
    }
  }
  if (await emrClickText(tab.id, /^Ιατρικό Εξιτήριο$/, true).catch(() => false)) {
    await E.sleep(2500);
    out.dc = await pfExec(tab.id, () => { const T = (e) => (e && (e.innerText || e.textContent) || "").replace(/\s+/g, " ").trim();
      const t = [...document.querySelectorAll("table")].find((x) => /Τύπος Εξιτηρίου/.test(T(x.querySelector("thead")))); if (!t) return [];
      const hs = [...t.querySelectorAll("thead th")].map(T);
      return [...t.querySelectorAll("tbody tr")].map((r) => [...r.children].map(T)).filter((c) => c.length > 2).map((c) => Object.fromEntries(hs.map((h, i) => [h, c[i] || ""]))).slice(0, 30); }).catch(() => []);
    out.dc = (out.dc || []).map((r) => ({ type: r["Τύπος Εξιτηρίου"] || "", outcome: r["Έκβαση Νοσηλείας"] || "", at: iso(r["Ημ/νία - ώρα Εξόδου"] || ""), cancelled: /ακυρ/i.test(r["Ακυρωμένο ή ΟΧΙ"] || ""), drg: r["KEN -> DRG"] || "" }));
  }
  await bgEmrClean(tab.id).catch(() => {});
  if (outside) { out.outside = true; try { await bgEmrToList(tab.id); await emrListFilter(tab.id, { surname: "", inner: true, from: "" }); } catch (e) {} }   // επαναφορά φίλτρων της λίστας
  return { status: "done", note: "🏥 ΝΠΣ: " + out.adm.length + " επεισόδια · " + out.dc.length + " εξιτήρια" + (outside ? " (εκτός νοσοκομείου)" : ""), result: out };
};
JOB_KIND.npspat = "🏥 ΝΠΣ: νοσηλείες & εξιτήρια ασθενή (μόνο ανάγνωση)";
JOB_LIMIT_S.npspat = 300;
JOB_KIND.npsmap = "🗺 ΝΠΣ: αναζήτηση ασθενών & ιστορικό (μόνο ανάγνωση)";
JOB_LIMIT_S.npsmap = 240;
JOB_KIND.emrclinicmap = "🗺 ΝΠΣ: πού αλλάζει η κλινική (μόνο ανάγνωση)";
JOB_LIMIT_S.emrclinicmap = 120;
async function bgOpenPatient0(tab, name, st) {
  await bgEmrClean(tab.id);
  { const { efbotNoFast } = await chrome.storage.local.get("efbotNoFast"); if (!efbotNoFast && (await bgEmrListVis(tab.id)) === 1) { await emrClinicEnsure(tab.id).catch(() => {}); const f = await bgOpenPatientFast(tab.id, name).catch(() => null); if (f) return { fast: true }; } }
  // λίστα κρυμμένη (ανοιχτός ασθενής/άλλη καρτέλα) → γρήγορη επιστροφή· αν δεν γίνεται, ξαναφόρτωμα ΤΩΡΑ (όχι 60″ αναμονή)
  if (await bgEmrListVis(tab.id) !== 1 && !(await bgEmrToList(tab.id))) { await bgEmrClean(tab.id, true); await bgEnsureLogin(tab.id).catch(() => {}); }
  // μετά το ξαναφόρτωμα το ΝΠΣ θυμάται τον τελευταίο ασθενή και ανοίγει σε καρτέλα του («Γενικά Στοιχεία»…) → πίσω στην καρτέλα της λίστας
  if (await bgEmrListVis(tab.id) !== 1) await bgEmrToList(tab.id);
  await emrClinicEnsure(tab.id).catch(() => {});
  try { return await bgRunWorkflow(st?.settings?.openerId || "anoigma", { [E.BULKVAR]: name }, tab.id, { opener: false }); }
  catch (e) {
    if (!/λίστα ασθενών|δεν βρέθηκε|not found/i.test(e.message || "")) throw e;
    // η λίστα διαβάστηκε ολόκληρη και ο ασθενής δεν είναι εκεί → ξαναφόρτωμα δεν αλλάζει τίποτα (κόστιζε 11″)
    if (/σε καμία από τις \d+ σελίδες/.test(e.message || "") && await bgEmrListVis(tab.id) === 1) {
      const sw = await emrClinicEnsure(tab.id, true);
      if (!sw.changed) { const cc = await emrClinicCheck(tab.id); if (cc.ok || !sw.err) throw e; throw new Error(e.message + " — ⚠ η λίστα είναι άλλης κλινικής: " + sw.err); }
      if (!sw.ok) throw new Error(e.message + " — ⚠ δεν άλλαξε η κλινική σε «Ουρολογική Κλινική» (" + (sw.err || sw.to || "") + ")");
      return await bgRunWorkflow(st?.settings?.openerId || "anoigma", { [E.BULKVAR]: name }, tab.id, { opener: false });
    }
    await bgEmrClean(tab.id, true);   // μία ακόμα προσπάθεια από την αρχική οθόνη
    await bgEnsureLogin(tab.id).catch(() => {});
    if (await bgEmrListVis(tab.id) !== 1) await bgEmrToList(tab.id);
    return await bgRunWorkflow(st?.settings?.openerId || "anoigma", { [E.BULKVAR]: name }, tab.id, { opener: false });
  }
}
async function emrClickText(tabId, re, fast) {
  // Όπως το εξιτήριο: πρώτα το δεξί μενού του ασθενή (#appForm:patientRightMenu, πατιέται και κρυφό), με πλήρη ακολουθία
  // pointer/mouse + click (το PrimeFaces δεν αντιδρά πάντα σε σκέτο click). Μετά περιμένει να ΑΛΛΑΞΕΙ η σελίδα (έως 15″).
  const sig = async () => { const r = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: () => location.href + "#" + document.querySelectorAll("input,select,textarea,button").length + "#" + (document.querySelector(".ui-panel-title,.ui-dialog-title,h1,h2")?.innerText || "").slice(0, 40) }).catch(() => []); return r.map((x) => x.result).join("|"); };
  const before = await sig();
  const res = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, args: [re.source], func: (src) => {
    const re = new RegExp(src, "i"), vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    const STOP = /αποθήκευσ|αποστολ|υποβολ|οριστικ|διαγραφ|ακύρωσ|καταχώρ/i;
    const ok = (e) => re.test((e.innerText || e.textContent || "").trim()) && (e.innerText || e.textContent || "").trim().length < 60 && !STOP.test(e.innerText || e.textContent || "");
    let el = [...document.querySelectorAll("#appForm\\:patientRightMenu a.ui-menuitem-link")].find(ok);
    if (!el && /νοσηλευ/i.test(src)) el = [...document.querySelectorAll(".ui-menu a.ui-menuitem-link, .ui-menubar a.ui-menuitem-link, .ui-tieredmenu a.ui-menuitem-link")].find(ok)
      || [...document.querySelectorAll("a.ui-menuitem-link, [role=menuitem], li.ui-menuitem > a, a")].find(ok);   // 6/11: «Συνολική Εικόνα Νοσηλευομένων» κρυφό μέσα σε «Μαζικές Διαδικασίες»   // κρυφό υπομενού (Μαζικές Διαδικασίες)
    if (!el) el = [...document.querySelectorAll("a, button, [role=button], [role=menuitem], [role=tab], .ui-menuitem-link, .ui-commandlink")].find((e) => vis(e) && ok(e));
    if (!el) return false;
    const fire = (t) => el.dispatchEvent(new (t.startsWith("pointer") ? PointerEvent : MouseEvent)(t, { bubbles: true, cancelable: true, view: window }));
    try { el.scrollIntoView({ block: "center" }); } catch (e) {}
    fire("pointerdown"); fire("mousedown"); try { el.focus(); } catch (e) {} fire("pointerup"); fire("mouseup"); el.click();
    return true;
  } }).catch(() => []);
  if (!res.some((r) => r && r.result)) return false;
  for (let i = 0; i < 100; i++) { await E.sleep(150); const now = await sig(); if (now && now !== before) { if (!fast) await bgSettle(tabId, 1500); bgMark("κλικ " + re.source.replace(/[\\^$\[\]()?*+|]/g, "").slice(0, 24)); return true; } }
  return "nochange";
}
// 🔎 Πού είναι ο Evorad / PACS; ΜΟΝΟ ανάγνωση: ανοιχτές καρτέλες (διεύθυνση + τίτλος) και σύνδεσμοι/πλαίσια μέσα στις
// σελίδες του νοσοκομείου που είναι ήδη ανοιχτές. Κρατά μόνο προέλευση + πρώτο κομμάτι διαδρομής — ποτέ ερωτήματα ή στοιχεία ασθενών.
// Το ιστορικό/σελιδοδείκτες του Chrome ΔΕΝ διαβάζονται (το bot δεν έχει τέτοια άδεια).
JOB_RUNNERS.findpacs = async () => {
  const RX = /evorad|pacs|dicom|wado|radiolog|ακτινολ|απεικον|imaging|viewer/i;
  const short = (u) => { try { const x = new URL(u); if (!/^https?:$/.test(x.protocol)) return ""; const seg = x.pathname.split("/").filter(Boolean)[0] || ""; return x.origin + (seg ? "/" + seg : ""); } catch (e) { return ""; } };
  const found = new Map();
  const add = (u, why) => { const k = short(u); if (k && !found.has(k)) found.set(k, String(why || "").replace(/\d{6,}/g, "•••").slice(0, 80)); };
  const tabs = await chrome.tabs.query({}).catch(() => []);
  for (const t of tabs) if (RX.test(t.url || "") || RX.test(t.title || "")) add(t.url, "καρτέλα: " + (t.title || ""));
  const intra = tabs.filter((t) => /^https?:\/\/(10\.|172\.(1[6-9]|2\d|3[01])\.|192\.168\.|[^/]*\.gov\.gr|[^/.]+(:\d+)?\/)/i.test(t.url || ""));
  for (const t of intra.slice(0, 15)) {
    try {
      const res = await chrome.scripting.executeScript({ target: { tabId: t.id, allFrames: true }, func: (src) => {
        const RX = new RegExp(src, "i"), out = [];
        for (const a of document.querySelectorAll("a[href], iframe[src], frame[src], form[action]")) {
          const u = a.href || a.src || a.action || "", lab = (a.innerText || a.title || a.name || "").replace(/\s+/g, " ").trim();
          if (RX.test(u) || RX.test(lab)) out.push([u, lab.slice(0, 60)]);
          if (out.length > 30) break;
        }
        return out;
      }, args: [RX.source] });
      for (const r of res || []) for (const [u, lab] of r.result || []) add(u, "σύνδεσμος στο " + (new URL(t.url).host) + (lab ? ": " + lab : ""));
    } catch (e) {}
  }
  const list = [...found].map(([url, why]) => ({ url, why })).slice(0, 20);
  const { efbotCredByHost: cb } = await V.get("efbotCredByHost").catch(() => ({}));
  const hasCred = !!(cb && cb["*evorad"] && (Array.isArray(cb["*evorad"]) ? cb["*evorad"].length : 1));
  return list.length
    ? { status: "done", note: "🔎 βρέθηκαν: " + list.map((x) => x.url).join(" · ").slice(0, 300) + (hasCred ? " · κωδικός Evorad: ✓" : " · κωδικός Evorad: δεν έχει σταλεί"), result: { list, hasCred, tabs: tabs.length } }
    : { status: "done", note: "🔎 δεν βρέθηκε Evorad/PACS στις " + tabs.length + " ανοιχτές καρτέλες ούτε σε συνδέσμους του ΝΠΣ — άνοιξέ τον μία φορά στον υπολογιστή και ξαναστείλε", result: { list: [], hasCred, tabs: tabs.length } };
};
// ===== 🩻 Evorad PACS — ΜΟΝΟ χαρτογράφηση (probe) =====
// Ανοίγει τον Evorad (διεύθυνση από το 🔎 findpacs ή payload.url), συνδέεται με τον αποθηκευμένο κωδικό (🔐 «Evorad»)
// και καταγράφει ΜΟΝΟ δομή: πεδία (id/name/placeholder), κουμπιά, μενού, επικεφαλίδες πινάκων, πλαίσια, διευθύνσεις.
// Ποτέ κελιά πινάκων (ονόματα ασθενών)· κείμενα με ≥5 ψηφία κρύβονται. Δεν ανοίγει μελέτη, δεν αλλάζει τίποτα.
JOB_RUNNERS.evoradprobe = async (job) => {
  const p = job.payload || {};
  let base = String(p.url || "");
  if (!base) { const { efbotEvoradUrl: u } = await chrome.storage.local.get("efbotEvoradUrl"); base = u || "http://172.16.1.26:2080/index.jsp"; }
  await chrome.storage.local.set({ efbotEvoradUrl: base });
  let tab = await botSiteTab(new URL(base).origin, base);
  if (!tab) return { status: "failed", note: "δεν άνοιξε ο Evorad" };
  tab = (await tabWake(tab.id)) || tab;
  const ready = async () => { for (let i = 0; i < 40; i++) { const t = await chrome.tabs.get(tab.id).catch(() => null); if (!t) return false; if (t.status === "complete") return true; await E.sleep(400); } return true; };
  await ready();
  const snap = async () => {
    const r = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: () => {
      const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      const clean = (t) => String(t || "").replace(/\s+/g, " ").trim().replace(/\d{5,}/g, "•••").slice(0, 50);
      const inputs = [...document.querySelectorAll("input:not([type=hidden]), select, textarea")].filter(vis).slice(0, 40).map((e) => ({ tag: e.tagName.toLowerCase(), type: e.type || "", id: e.id || "", name: e.name || "", ph: clean(e.placeholder || ""), lab: clean((e.labels && e.labels[0] && e.labels[0].innerText) || e.getAttribute("aria-label") || e.title || "") }));
      const buttons = [...document.querySelectorAll("button, input[type=submit], input[type=button], [role=button]")].filter(vis).slice(0, 40).map((e) => clean(e.innerText || e.value || e.title || e.getAttribute("aria-label")));
      const menu = [...document.querySelectorAll("nav a, [role=menuitem], [role=tab], .menu a, .nav a, li > a, a.btn")].filter(vis).slice(0, 50).map((e) => clean(e.innerText || e.title)).filter(Boolean);
      const heads = [...document.querySelectorAll("table")].filter(vis).slice(0, 6).map((t) => [...t.querySelectorAll("thead th, thead td, tr:first-child th")].map((h) => clean(h.innerText)).filter(Boolean)).filter((x) => x.length);
      const frames = [...document.querySelectorAll("iframe, frame")].map((f) => { try { const u = new URL(f.src, location.href); return u.origin + u.pathname; } catch (e) { return ""; } }).filter(Boolean);
      return { url: location.origin + location.pathname, title: clean(document.title), pw: !!document.querySelector("input[type=password]"), inputs, buttons: [...new Set(buttons)].filter(Boolean), menu: [...new Set(menu)], heads, frames, scripts: [...document.scripts].map((s) => s.src).filter((s) => /evorad|viewer|dicom|wado|cornerstone|ohif|weasis/i.test(s)).slice(0, 8) };
    } }).catch((e) => [{ result: { err: e.message } }]);
    return (r || []).map((x) => x && x.result).filter(Boolean);
  };
  let s1 = await snap();
  if (s1.some((x) => x.err)) {   // μία ακόμα προσπάθεια: ξαναφόρτωση της σελίδας
    await chrome.tabs.reload(tab.id).catch(() => {}); await E.sleep(1500); await ready(); await E.sleep(800);
    s1 = await snap();
  }
  if (s1.some((x) => x.err)) {
    const t2 = await chrome.tabs.get(tab.id).catch(() => null), why = await siteAccessWhy(base);
    let perm = "?"; try { const u = new URL(base); perm = String(await chrome.permissions.contains({ origins: [u.protocol + "//" + u.hostname + "/*"] })); } catch (e) { perm = "σφάλμα: " + e.message; }
    const fr = await chrome.webNavigation.getAllFrames({ tabId: tab.id }).catch(() => null);
    const diag = "καρτέλα " + (t2 ? (String(t2.url || "").replace(/\?.*$/, "").slice(0, 60) + " · " + t2.status + (t2.discarded ? " · παγωμένη" : "")) : "—") + " · άδεια " + perm + " · πλαίσια " + (fr ? fr.map((f) => String(f.url || "").replace(/\?.*$/, "").slice(0, 50)).join(", ") : "—");
    return { status: "failed", note: "Evorad: δεν διαβάζεται" + (why || " (" + String(s1[0].err).slice(0, 100) + ")") + " · " + diag };
  }
  let login = "δεν χρειάστηκε";
  if (s1.some((x) => x.pw)) {
    const { efbotCredByHost: all = {} } = await V.get("efbotCredByHost");
    const v = all["*evorad"] || all[new URL(base).host]; const acc = (Array.isArray(v) ? v : v ? [v] : []).find((a) => a && a.pass);
    if (!acc) return { status: "failed", note: "Evorad: ζητά σύνδεση και δεν υπάρχει κωδικός — στείλτε τον από το 🔐 «Evorad»", result: { before: s1 } };
    await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, args: [acc.user, acc.pass], func: (user, pass) => {
      const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      const pw = [...document.querySelectorAll("input[type=password]")].find(vis); if (!pw) return false;
      const form = pw.form || document;
      const fields = [...form.querySelectorAll("input:not([type=hidden]):not([type=password]):not([type=checkbox]):not([type=radio]):not([type=submit]):not([type=button])")].filter(vis);
      const userEl = fields.filter((f) => f.compareDocumentPosition(pw) & Node.DOCUMENT_POSITION_FOLLOWING).pop() || fields[0];
      const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
      const fill = (el, v) => { el.focus(); set.call(el, v); for (const ev of ["input", "change", "keyup", "blur"]) el.dispatchEvent(new Event(ev, { bubbles: true })); };
      if (userEl) fill(userEl, user); fill(pw, pass);
      // Evorad: το «Sign in» είναι σύνδεσμος (<a>), όχι κουμπί — ψάχνουμε σε όλη τη σελίδα
      const RXS = /sign\s*in|log\s*in|login|είσοδος|σύνδεση|enter/i;
      const btn = [...form.querySelectorAll("button, input[type=submit], input[type=button], [role=button]")].filter(vis).find((b) => /submit/i.test(b.type) || RXS.test(b.innerText || b.value || ""))
        || [...document.querySelectorAll("a, button, [onclick], [role=button], div, span")].filter(vis).find((b) => b.children.length < 3 && RXS.test((b.innerText || b.value || b.title || "").trim()) && (b.innerText || "").trim().length < 25);
      if (btn) { for (const t of ["pointerdown", "mousedown", "pointerup", "mouseup"]) btn.dispatchEvent(new (t.startsWith("pointer") ? PointerEvent : MouseEvent)(t, { bubbles: true, cancelable: true, view: window })); btn.click(); return "click:" + btn.tagName; }
      if (pw.form && pw.form.requestSubmit) { pw.form.requestSubmit(); return "submit"; }
      for (const t of ["keydown", "keypress", "keyup"]) pw.dispatchEvent(new KeyboardEvent(t, { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true }));
      return "enter";
    } }).catch(() => null);
    await E.sleep(3000); await ready(); await E.sleep(1500);
    const s2 = await snap();
    login = s2.some((x) => x.pw) ? "✗ ο κωδικός δεν μπήκε (η φόρμα εισόδου εμφανίζεται ακόμα)" : "✓ μπήκε (" + acc.user + ")";
    s1 = s2;
  }
  const main = s1[0] || {};
  return { status: "done", note: "🩻 Evorad: σύνδεση " + login + " · σελίδα «" + (main.title || "") + "» · πεδία " + s1.reduce((n, x) => n + (x.inputs || []).length, 0) + " · κουμπιά " + s1.reduce((n, x) => n + (x.buttons || []).length, 0) + (main.heads && main.heads.length ? " · στήλες: " + main.heads[0].slice(0, 10).join(" | ") : ""), result: { frames: s1, at: Date.now() } };
};
// 💊 ΝΠΣ — φαρμακευτική αγωγή νοσηλευόμενου: ΜΟΝΟ χαρτογράφηση (probe). Ανοίγει τον ασθενή, καταγράφει ΟΛΟ το μενού του
// (δεξί μενού + καρτέλες), μπαίνει στην ενότητα φαρμάκων (αγωγή / οδηγίες / χορηγήσεις / συνταγή) και, αν υπάρχει,
// ανοίγει τη «Νέα …» φόρμα για να δει τα πεδία. ΚΑΜΙΑ αποθήκευση: το emrClickText αρνείται Αποθήκευση/Υποβολή/Καταχώρηση,
// και στο τέλος κλείνει τους διαλόγους. Ονόματα ασθενών και αριθμοί ≥5 ψηφίων φιλτράρονται.
// ⚙️ Ρυθμίσεις του bot από το Παραδόχαρτο (μόνο λευκή λίστα): δικό του ανώνυμο παράθυρο, λεπτά αδράνειας πριν δουλέψει
// σε κοινό παράθυρο. Το «Να επιτρέπεται στην ανώνυμη περιήγηση» ΔΕΝ αλλάζει από επέκταση — μόνο από chrome://extensions.
JOB_RUNNERS.botcfg = async (job) => {
  const p = job.payload || {};
  const { efbot } = await chrome.storage.local.get("efbot");
  if (!efbot) return { status: "failed", note: "δεν βρέθηκαν ρυθμίσεις του bot σε αυτόν τον υπολογιστή" };
  efbot.settings = efbot.settings || {};
  const done = [];
  if (typeof p.botIncog === "boolean") {
    if (p.botIncog && !(await chrome.extension.isAllowedIncognitoAccess().catch(() => false))) return { status: "failed", note: "πρώτα: chrome://extensions → ef-bot → Λεπτομέρειες → «Να επιτρέπεται στην ανώνυμη περιήγηση»" };
    efbot.settings.botIncog = p.botIncog; done.push("δικό του παράθυρο: " + (p.botIncog ? "ναι" : "όχι"));
  }
  if (typeof p.comorbAuto === "boolean") { efbot.settings.comorbAuto = p.comorbAuto; await chrome.storage.local.set({ efbot }); done.push("αυτόματες συννοσηρότητες (1 φορά/ασθενή): " + (p.comorbAuto ? "ναι" : "όχι")); }
  // 🔐 ΜΙΑ φορά με συγκεκριμένο λογαριασμό ΝΠΣ (από τη λίστα του Παραδόχαρτου): ισχύει στην επόμενη σύνδεση του bot
  if (p.epOnce !== undefined) {
    const u = String(p.epOnce || "").trim();
    if (!u) { await chrome.storage.session.remove("efbotEpOnce"); return { status: "done", note: "🔐 e-prescription/ΑΗΦΥ: αυτόματη επιλογή λογαριασμού" }; }
    await chrome.storage.session.set({ efbotEpOnce: { user: u, at: Date.now() } });
    // το e-prescription τρέχει σε κανονικό παράθυρο (κοινή σύνδεση με όποιον δουλεύει στον υπολογιστή): ΔΕΝ αποσυνδέουμε κανέναν·
    // ο λογαριασμός ισχύει στην επόμενη είσοδο (όταν λήξει η τρέχουσα σύνδεση ή όταν δεν υπάρχει)
    return { status: "done", note: "🔐 e-prescription/ΑΗΦΥ: στην επόμενη είσοδο με " + u + " (μία φορά, ισχύει 2 ώρες)" };
  }
  if (p.emrOnce !== undefined) {
    const u = String(p.emrOnce || "").trim();
    if (!u) { await chrome.storage.session.remove("efbotEmrOnce"); done.push("λογαριασμός: αυτόματη επιλογή"); }
    else {
      const acc = (await emrAccounts()).find((a) => a.user.toLowerCase() === u.toLowerCase());
      if (!acc) return { status: "failed", note: "ο λογαριασμός «" + u + "» δεν είναι αποθηκευμένος στο bot" };
      await chrome.storage.session.set({ efbotEmrOnce: { user: acc.user, at: Date.now() } });
      // αποσύνδεση του παραθύρου του bot ώστε η επόμενη εργασία να μπει με τον νέο λογαριασμό
      // ΜΟΝΟ καρτέλες ΝΠΣ του δικού του (ανώνυμου) παραθύρου — ποτέ του χρήστη
      try { await botIncogReset(); } catch (e) {}
      done.push("επόμενη σύνδεση ΝΠΣ με: " + acc.user + " (μία φορά)");
    }
    return { status: "done", note: "🔐 " + done.join(" · ") };
  }
  if (p.emrIdleMin != null) { const m = Math.max(1, Math.min(30, parseFloat(p.emrIdleMin) || 5)); efbot.settings.emrIdleMin = m; done.push("αναμονή αδράνειας: " + m + "′"); }
  if (!done.length) return { status: "failed", note: "καμία αλλαγή" };
  await chrome.storage.local.set({ efbot });
  await chrome.storage.session.remove("efbotShared").catch(() => {});
  return { status: "done", note: "⚙️ " + done.join(" · ") };
};
// 🩻 Evorad: αναζήτηση εξετάσεων ΕΝΟΣ ασθενή (payload {name, pid, mod}) — μόνο ανάγνωση.
// Σελίδα /ris/exams/exams.jsp: #searchName, #searchPatientID, #searchModalityType, #fromDate/#toDate, κουμπί «Αναζήτηση».
// Επιστρέφει τις γραμμές (ημερομηνία, περιγραφή, τύπος, κωδικοί ασθενή) + τους συνδέσμους/ενέργειες της γραμμής
// (για να ανοίγει ο viewer). Με probe:true κρατά και τις επιλογές του «Τύπος Μηχανήματος».
JOB_RUNNERS.evoradfind = async (job) => {
  const p = job.payload || {};
  const { efbotEvoradUrl: u0 } = await chrome.storage.local.get("efbotEvoradUrl");
  const base = u0 || "http://172.16.1.26:2080/index.jsp", origin = new URL(base).origin;
  let tab = await botSiteTab(origin, origin + "/ris/exams/exams.jsp");
  if (!tab) return { status: "failed", note: "δεν άνοιξε ο Evorad" };
  tab = (await tabWake(tab.id)) || tab;
  const ready = async () => { for (let i = 0; i < 40; i++) { const t = await chrome.tabs.get(tab.id).catch(() => null); if (!t) return; if (t.status === "complete") return; await E.sleep(400); } };
  const run = (func, args, main) => chrome.scripting.executeScript({ target: { tabId: tab.id }, func, args: args || [], world: main ? "MAIN" : "ISOLATED" }).then((r) => r[0] && r[0].result).catch((e) => ({ err: e.message }));
  await ready();
  if ((await run(() => !!document.querySelector("input[type=password]"))) === true) {
    const { efbotCredByHost: all = {} } = await V.get("efbotCredByHost");
    const v = all["*evorad"] || all[new URL(base).host]; const acc = (Array.isArray(v) ? v : v ? [v] : []).find((a) => a && a.pass);
    if (!acc) return { status: "failed", note: "Evorad: δεν υπάρχει κωδικός (🔐 «Evorad»)" };
    await run((user, pass) => {
      const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
      const fill = (el, v) => { el.focus(); set.call(el, v); for (const ev of ["input", "change", "keyup", "blur"]) el.dispatchEvent(new Event(ev, { bubbles: true })); };
      const pw = document.querySelector("input[type=password]"), us = document.querySelector("#user") || [...document.querySelectorAll("input[type=text]")][0];
      if (us) fill(us, user); fill(pw, pass);
      const b = [...document.querySelectorAll("a, button, input[type=submit], [onclick]")].find((x) => /sign\s*in|login|είσοδ/i.test((x.innerText || x.value || "").trim()));
      if (b) b.click(); else if (pw.form) pw.form.requestSubmit();
    }, [acc.user, acc.pass]);
    await E.sleep(2500); await ready();
  }
  if (!/\/exams\//.test((await chrome.tabs.get(tab.id).catch(() => ({}))).url || "")) { await chrome.tabs.update(tab.id, { url: origin + "/ris/exams/exams.jsp" }).catch(() => {}); await E.sleep(1500); await ready(); }
  const pad = (n) => String(n).padStart(2, "0"), now = new Date(), today = pad(now.getDate()) + "/" + pad(now.getMonth() + 1) + "/" + now.getFullYear();
  const doSearch = (name) => run((q) => {
    const $ = (id) => document.getElementById(id);
    const set = (el, v) => { if (!el) return; const pr = el.tagName === "SELECT" ? HTMLSelectElement.prototype : HTMLInputElement.prototype; Object.getOwnPropertyDescriptor(pr, "value").set.call(el, v); el.dispatchEvent(new Event("input", { bubbles: true })); el.dispatchEvent(new Event("change", { bubbles: true })); };
    const mods = $("searchModalityType") ? [...$("searchModalityType").options].map((o) => o.value).filter(Boolean) : [];
    set($("searchName"), q.name || ""); set($("searchPatientID"), q.pid || ""); set($("searchExamID"), "");
    if ($("searchModalityType")) { const o = q.mod ? [...$("searchModalityType").options].find((o) => new RegExp("^(" + q.mod + ")$", "i").test(o.value)) : null; set($("searchModalityType"), o ? o.value : ""); }
    set($("fromDate"), q.from); set($("toDate"), q.to);
    document.querySelectorAll("td.dataTables_empty").forEach((td) => td.closest("tr") && td.closest("tr").remove());
    [...document.querySelectorAll("tbody tr")].filter((tr) => tr.children.length >= 8).forEach((tr) => tr.remove());
    const btn = [...document.querySelectorAll("button, input[type=button], input[type=submit], a")].find((b) => /^αναζήτηση$/i.test((b.innerText || b.value || "").trim()));
    if (!btn) return { err: "δεν βρέθηκε το κουμπί «Αναζήτηση»", mods };
    btn.click(); return { ok: true, mods };
  }, [{ name, pid: p.pid || "", mod: p.mod || "", from: p.from || "01/01/2005", to: p.to || today }]);
  // Οι γραμμές: σε πίνακα DataTables οι επικεφαλίδες και οι γραμμές είναι σε ΔΙΑΦΟΡΕΤΙΚΑ <table>. Παίρνουμε επικεφαλίδες
  // από όποιον έχει «Ονοματεπώνυμο» και γραμμές (≥8 κελιά) από όλους. Αν υπάρχει το API του DataTables, και τα δεδομένα του.
  const readRows = (q) => run((q) => {
    const nz = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().replace(/\s+/g, " ").trim();
    const ht = [...document.querySelectorAll("table")].find((x) => [...x.querySelectorAll("th")].some((h) => /ονοματεπ/i.test(h.textContent || "")));
    const hs = ht ? [...ht.querySelectorAll("th")].map((h) => (h.textContent || "").replace(/\s+/g, " ").trim()).filter((x, i, a) => x || i < a.length) : [];
    const ix = (re) => hs.findIndex((h) => re.test(h));
    const iN = ix(/ονοματεπ/i), iD = ix(/^ημερομην/i), iDesc = ix(/περιγραφ/i), iT = ix(/^τ[υύ]πος/i), iP = ix(/κωδ.*ασθεν/i), iId = ix(/^id$/i), iTime = ix(/^[ωώ]ρα/i), iG = ix(/γν[ωώ]μ/i);
    const trs = [...document.querySelectorAll("tbody tr")].filter((tr) => tr.children.length >= 8);
    const want = nz(q.name).split(" ").filter((w) => w.length >= 3);
    const out = [];
    for (const tr of trs.slice(0, 200)) {
      const td = [...tr.children].map((c) => (c.textContent || "").replace(/\s+/g, " ").trim());
      const nm = nz(td[iN]); const pidOk = q.pid && td.join(" ").includes(q.pid);
      if (want.length && !want.every((w) => nm.includes(w)) && !pidOk) continue;
      tr.setAttribute("data-efbot-row", String(out.length));
      const links = [...tr.querySelectorAll("a[href], [onclick], button, i[class], span[class*=icon]")].slice(0, 8).map((a) => ({ tag: a.tagName, x: (a.textContent || a.title || "").trim().slice(0, 30), c: String(a.className || "").slice(0, 60), h: String(a.getAttribute("href") || "").slice(0, 200), o: String(a.getAttribute("onclick") || "").slice(0, 200) }));
      out.push({ id: td[iId] || "", name: td[iN] || "", date: td[iD] || "", time: iTime >= 0 ? td[iTime] : "", desc: td[iDesc] || "", type: td[iT] || "", pcode: iP >= 0 ? td[iP] : "", report: iG >= 0 ? td[iG] : "", links, rowClick: String(tr.getAttribute("onclick") || "").slice(0, 200) });
    }
    let dt = null;
    try { const $j = window.jQuery; if ($j && $j.fn && $j.fn.dataTable) { const tb = $j.fn.dataTable.tables(); if (tb.length) { const api = $j(tb[0]).DataTable(); const d = api.rows().data().toArray(); dt = { n: d.length, keys: d[0] && typeof d[0] === "object" ? Object.keys(d[0]).slice(0, 40) : null }; } } } catch (e) { dt = { err: String(e.message || e).slice(0, 80) }; }
    return { rows: out, n: trs.length, hs, dt, empty: (document.querySelector("td.dataTables_empty") || {}).textContent || "" };
  }, [q], true);
  const G = { Α: "A", Β: "V", Γ: "G", Δ: "D", Ε: "E", Ζ: "Z", Η: "I", Θ: "TH", Ι: "I", Κ: "K", Λ: "L", Μ: "M", Ν: "N", Ξ: "X", Ο: "O", Π: "P", Ρ: "R", Σ: "S", Τ: "T", Υ: "Y", Φ: "F", Χ: "CH", Ψ: "PS", Ω: "O" };
  const toLat = (t) => String(t || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().replace(/ΟΥ/g, "OU").replace(/ΑΙ/g, "AI").replace(/ΕΙ/g, "EI").replace(/ΟΙ/g, "OI").replace(/ΜΠ/g, "MP").replace(/ΝΤ/g, "NT").replace(/ΓΓ/g, "NG").replace(/[Α-Ω]/g, (c) => G[c] || "");
  const tries = [];
  if (p.name && /[Α-ΩΆ-Ώ]/i.test(p.name)) tries.push(toLat(p.name));
  tries.push(p.name || "");
  let go = null, rr = null, latin = "";
  for (const nm of tries) {
    go = await doSearch(nm);
    if (!go || go.err) return { status: "failed", note: "Evorad: " + ((go && go.err) || "η σελίδα δεν απάντησε") };
    await E.sleep(700);
    for (let i = 0; i < 24; i++) { await E.sleep(500); rr = await readRows({ name: nm, pid: p.pid || "" }); if (rr && (rr.n > 0 || rr.empty)) break; }
    if (rr && rr.rows && rr.rows.length) { if (nm !== p.name) latin = nm; break; }
  }
  const R = (rr && rr.rows) || [];
  // διαγνωστικά: τι γράφουν τα πεδία και ποια αιτήματα getExams έγιναν (τελευταία 3)
  const diag = R.length ? null : await run(() => ({ fields: ["searchName", "searchPatientID", "searchExamID", "searchModalityType", "fromDate", "toDate"].map((id) => id + "=" + ((document.getElementById(id) || {}).value || "")).join(" "), req: performance.getEntriesByType("resource").map((e) => e.name).filter((u) => /getExams/i.test(u)).slice(-3).map((u) => u.replace(location.origin, "").slice(0, 200)), url: location.pathname }), [], true);
  // 🔎 probe: άνοιγμα της πρώτης εξέτασης — πώς φορτώνει ο viewer (μόνο διευθύνσεις/δομή, χωρίς εικόνες)
  let viewer = null;
  if (p.probe && R.length) {
    const created = []; const onC = (t) => created.push(t.id); chrome.tabs.onCreated.addListener(onC);
    const before = (await chrome.tabs.get(tab.id).catch(() => ({}))).url || "";
    const how = await run(() => {
      const tr = document.querySelector('tr[data-efbot-row="0"]'); if (!tr) return "no-row";
      const a = [...tr.querySelectorAll("a, button, i, span")].find((x) => /view|eye|image|εικ|προβολ|viewer|dicom|pacs/i.test((x.className || "") + " " + (x.title || "") + " " + (x.textContent || "") + " " + (x.getAttribute && x.getAttribute("href") || "")));
      const el = a || tr;
      for (const t of ["mousedown", "mouseup", "click"]) el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window }));
      if (!a) el.dispatchEvent(new MouseEvent("dblclick", { bubbles: true, cancelable: true, view: window }));
      return a ? "link:" + (a.className || a.tagName) : "row-dblclick";
    }, [], true);
    await E.sleep(5000);
    chrome.tabs.onCreated.removeListener(onC);
    const vt = created.length ? created[created.length - 1] : tab.id;
    await E.sleep(1500);
    const vtab = await chrome.tabs.get(vt).catch(() => null);
    const snap = vtab ? await chrome.scripting.executeScript({ target: { tabId: vt, allFrames: true }, func: () => {
      const strip = (u) => { try { const x = new URL(u, location.href); return x.origin + x.pathname + (x.search ? "?" + [...x.searchParams.keys()].join("&") : ""); } catch (e) { return ""; } };
      const res = performance.getEntriesByType("resource").map((e) => strip(e.name)).filter((u) => /wado|dicom|instance|image|jpe?g|png|frame|study|series|render|thumb/i.test(u));
      return { url: strip(location.href), title: document.title, imgs: [...document.images].slice(0, 10).map((i) => ({ src: strip(i.currentSrc || i.src), w: i.naturalWidth, h: i.naturalHeight })), canvas: [...document.querySelectorAll("canvas")].map((c) => c.width + "x" + c.height).slice(0, 6), iframes: [...document.querySelectorAll("iframe")].map((f) => strip(f.src)).slice(0, 5), res: [...new Set(res)].slice(0, 25), scripts: [...document.scripts].map((s) => strip(s.src)).filter(Boolean).slice(0, 15) };
    } }).then((r) => r.map((x) => x.result)).catch((e) => [{ err: e.message }]) : null;
    viewer = { how, newTab: created.length > 0, urlBefore: before.replace(/\?.*$/, ""), tabUrl: vtab ? String(vtab.url || "").replace(/\?.*$/, "") : "", snap };
    if (created.length) for (const id of created) chrome.tabs.remove(id).catch(() => {});
  }
  return { status: "done", note: "🩻 Evorad: " + R.length + " εξετάσεις" + (p.name ? " για «" + (latin && R.length ? latin : p.name) + "»" : "") + (R[0] ? " · πιο πρόσφατη: " + R[0].date + " " + R[0].type + " " + R[0].desc : "") + " · γραμμές πίνακα " + ((rr && rr.n) || 0) + (rr && rr.empty ? " («" + rr.empty.slice(0, 40) + "»)" : "") + (viewer ? " · viewer: " + viewer.how + (viewer.newTab ? " → νέα καρτέλα " + viewer.tabUrl : " → " + viewer.tabUrl) : "") + (diag ? " · πεδία: " + diag.fields + " · αιτήματα: " + (diag.req || []).join(" | ") + " · σελίδα " + diag.url : ""), result: { rows: R, diag, total: rr && rr.n, heads: rr && rr.hs, dt: rr && rr.dt, latin, viewer, at: Date.now() } };
};
// 🫁 Ακτινογραφία (θώρακος) από τον Evorad → κινητό, ΚΡΥΠΤΟΓΡΑΦΗΜΕΝΗ με το δημόσιο κλειδί του κινητού (payload.pub).
// 1) αναζήτηση (όπως evoradfind) → δεδομένα DataTables (amka, examid, examdate, exammodalitytype, όνομα)
// 2) ταυτοποίηση: ίδιος ΑΜΚΑ (ή ΑΜ στο patientid/secondarypatientid)· χωρίς αυτούς μόνο αν το επώνυμο αντιστοιχεί σε ΕΝΑΝ ασθενή
// 3) πιο πρόσφατη DX/CR/XR → getSeries → viewer (index.jsp) σε καρτέλα στο παρασκήνιο → η μεγαλύτερη εικόνα/καμβάς
// 4) AES-GCM + RSA-OAEP → result.enc. Το κινητό την ανοίγει και σβήνει το αντίγραφο· το bot σβήνει ό,τι μένει >2 ώρες.
// ΑΜ από την πάνω μπάρα του ασθενή στο ΝΠΣ (όταν λείπει από το Παραδόχαρτο): «Ετικέτα : 8 ψηφία», όχι ΑΜΚΑ/Π.Ι.Φ/ταυτότητα
async function bgReadAmFromEmr(name) {
  const tab = await bgEmrTab(); if (!tab || tab.err) return "";
  const lg = await bgEnsureLogin(tab.id); if (!lg.ok) return "";
  const { efbot: st } = await chrome.storage.local.get("efbot");
  try { await bgOpenPatient(tab, name, st); } catch (e) { return ""; }
  const r = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: () => {
    const txt = (document.querySelector("#appForm\\:content > nav, nav, header, .patient-bar, [id*=patientInfo], [id*=patientHeader]") || document.body).innerText || "";
    const out = [];
    for (const m of txt.matchAll(/([Α-ΩA-Zα-ωa-zΆ-ώ.\s]{1,30}?)\s*:\s*(\d{6,10})(?!\d)/g)) {
      const lab = m[1].trim(), v = m[2];
      if (/ΑΜΚΑ|Α\.?Μ\.?Κ\.?Α|Π\.?Ι\.?Φ|ταυτ|ADT|τηλ/i.test(lab)) continue;
      out.push({ lab, v, pri: /^(Α\.?Μ\.?|ΑΜ|Αρ\.?\s*Μητρ|Μητρ)/i.test(lab) ? 0 : 1 });
    }
    out.sort((a, b) => a.pri - b.pri);
    return out.length ? out[0].v : "";
  } }).catch(() => []);
  return ((r || []).map((x) => x && x.result).find(Boolean)) || "";
}

// 🔎 7/11: Evorad — από πού κατεβάζει ο viewer τις εικόνες μιας ΑΞΟΝΙΚΗΣ (μόνο ανάγνωση: λίστα εξετάσεων/σειρών + διευθύνσεις που ζητά ο viewer)
JOB_RUNNERS.evoradnet = async (job) => {
  const p = job.payload || {};
  const f = await JOB_RUNNERS.evoradfind({ ...job, payload: { name: "", pid: "", probe: false, from: new Date().toLocaleDateString("en-GB"), to: new Date().toLocaleDateString("en-GB") } });
  if (f.status !== "done" && !/εξετάσεις/.test(f.note || "")) return f;
  const { efbotEvoradUrl: u0 } = await chrome.storage.local.get("efbotEvoradUrl");
  const origin = new URL(u0 || "http://172.16.1.26:2080/index.jsp").origin;
  const tab = await botSiteFind(origin); if (!tab) return { status: "failed", note: "ο Evorad έκλεισε" };
  const G = { Α: "A", Β: "V", Γ: "G", Δ: "D", Ε: "E", Ζ: "Z", Η: "I", Θ: "TH", Ι: "I", Κ: "K", Λ: "L", Μ: "M", Ν: "N", Ξ: "X", Ο: "O", Π: "P", Ρ: "R", Σ: "S", Τ: "T", Υ: "Y", Φ: "F", Χ: "CH", Ψ: "PS", Ω: "O" };
  const sur = String(p.name || "").trim().split(/\s+/)[0].normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase();
  const L0 = sur.replace(/ΟΥ/g, "OU").replace(/ΜΠ/g, "MP").replace(/ΝΤ/g, "NT").replace(/[Α-Ω]/g, (c) => G[c] || c);
  const V = new Set([sur, L0, L0.replace(/Y/g, "I"), L0.replace(/Y/g, "U"), L0.replace(/OU/g, "U"), L0.replace(/Y/g, "I").replace(/OU/g, "U"), L0.replace(/I/g, "Y"), L0.slice(0, Math.max(5, L0.length - 3))]);
  const today = new Date().toISOString().slice(0, 10); let all = [], used = "";
  for (const nm of [...V].filter((x) => x && x.length >= 4)) {
    const r = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: "MAIN", args: [nm, today], func: async (nm, today) => { try { const res = await fetch(location.origin + "/api/getExams?name=" + encodeURIComponent(nm) + "&fromDate=2005-01-01&toDate=" + today + "&", { credentials: "include" }); const j = await res.json(); const d = Array.isArray(j) ? j : (j.data || j.aaData || []); return d.map((d) => ({ examid: d.examid, date: d.examdate, mod: d.exammodalitytype, desc: d.studydescription || "", last: d.lastname || "", first: d.firstname || "" })); } catch (e) { return { err: String(e.message || e) }; } } }).then((x) => x[0] && x[0].result).catch((e) => ({ err: e.message }));
    if (Array.isArray(r) && r.length) { all = all.concat(r); used += nm + " "; }
  }
  const cts = all.filter((x) => /CT/i.test(x.mod || "") || /ΑΞΟΝ|CT|TOMO/i.test(x.desc || ""));
  if (!cts.length) return { status: "failed", note: "Evorad: καμία αξονική για «" + sur + "» (δοκιμές: " + [...V].join(", ") + ") · όλες: " + all.length, result: { all: all.slice(0, 20) } };
  cts.sort((a, b) => String(b.date).localeCompare(String(a.date)));
  const ex = cts[0];
  const ser = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: "MAIN", args: [ex.examid], func: async (examid) => { try { const r = await (await fetch(location.origin + "/api/getSeries?examuid=" + encodeURIComponent(examid), { credentials: "include" })).json(); return { keys: Object.keys((r.data || [])[0] || {}), list: (r.data || []).map((d) => ({ ref: d.examinationref, jfx: d.jfxuid, n: (d.imageNames || []).length, img0: (d.imageNames || [])[0] || "", desc: d.description || "", prot: d.protocolname || "" })) }; } catch (e) { return { err: e.message }; } } }).then((r) => r[0] && r[0].result).catch((e) => ({ err: e.message }));
  if (!ser || !ser.list || !ser.list.length) return { status: "failed", note: "Evorad: χωρίς σειρές (" + (ser && ser.err || "") + ")" };
  const s0 = ser.list.slice().sort((a, b) => b.n - a.n)[0];
  const vurl = origin + "/viewers/static/index.jsp?&examid=" + encodeURIComponent(s0.ref) + "&id=" + encodeURIComponent(ex.examid) + "&seriesid=" + encodeURIComponent(s0.jfx) + "&keyImage=false&input=";
  const vt = await chrome.tabs.create({ windowId: tab.windowId, url: vurl, active: false }).catch(() => null);
  let net = null;
  if (vt) { await E.sleep(15000);
    const r = await chrome.scripting.executeScript({ target: { tabId: vt.id, allFrames: true }, func: async () => { const E = performance.getEntriesByType("resource").filter((e) => !/\.(css|woff2?|ttf|svg|gif|png|ico)(\?|$)/i.test(e.name) || /image|dicom|wado|getimage/i.test(e.name)).map((e) => ({ u: e.name.replace(location.origin, ""), t: e.initiatorType, sz: e.transferSize || e.encodedBodySize || 0, ms: Math.round(e.duration) })); const g = {}; E.forEach((e) => { const k = e.u.replace(/[0-9a-f]{8,}|\d{4,}/gi, "#").split("?")[0]; (g[k] = g[k] || { n: 0, sz: 0, ex: e.u.slice(0, 220), t: e.t }); g[k].n++; g[k].sz += e.sz; }); const oth = performance.getEntriesByType("resource").filter((e) => !/^(script|link|css)$/.test(e.initiatorType)).map((e) => e.initiatorType + " " + Math.round(e.transferSize || e.encodedBodySize || 0) + " " + e.name.replace(location.origin, "").slice(0, 200)); const src = {}; for (const f of ["/viewers/static/index.js", "/src/app/application.js", "/src/io/urlsLoader.js", "/src/io/filesLoader.js"]) { try { const t = await (await fetch(location.origin + f, { credentials: "include" })).text(); src[f] = t.split(/\n/).map((l, i) => [i + 1, l.trim()]).filter(([, l]) => /url|ajax|fetch\(|XMLHttp|getImage|wado|dicom|\.dcm|zip|imageNames|jfx|api\/|loadURLs|\.jsp|servlet/i.test(l)).slice(0, 60).map(([i, l]) => i + ": " + l.slice(0, 220)); } catch (e) { src[f] = ["σφάλμα " + e.message]; } } return { href: location.href.slice(0, 160), oth: oth.slice(-60), nOth: oth.length, src, groups: Object.entries(g).sort((a, b) => b[1].sz - a[1].sz).slice(0, 25).map(([k, v]) => ({ k, ...v })) }; } }).catch((e) => [{ result: { err: e.message } }]);
    net = r.map((x) => x.result).filter(Boolean);
    await chrome.tabs.remove(vt.id).catch(() => {}); }
  return { status: "done", note: "🔎 Evorad: " + cts.length + " αξονικές («" + used.trim() + "») · σειρά " + s0.n + " εικόνες · πρώτη εικόνα: " + String(s0.img0).slice(0, 80), result: { ex, seriesKeys: ser.keys, series: ser.list.slice(0, 15), vnet: net, img0: s0.img0 } };
};
// 🖥 8/11: τηλεχειρισμός από το κινητό — ανοίγει το Νίκος CT Viewer ΣΕ ΑΥΤΟΝ τον υπολογιστή στη συγκεκριμένη εξέταση του Evorad
JOB_RUNNERS.ctremote = async (job) => {
  const p = job.payload || {};
  // 🔑 8/11: η σύνδεση του Evorad που έχει ήδη το bot (Chrome) περνά στην εφαρμογή → ανοίγει χωρίς να ζητά σύνδεση
  let ck = [];
  try {
    const { efbotEvoradUrl: u0 } = await chrome.storage.local.get("efbotEvoradUrl"); const origin = new URL(u0 || "http://172.16.1.26:2080/index.jsp").origin;
    const get = async () => (await chrome.cookies.getAll({ url: origin }).catch(() => [])).map((c) => ({ n: c.name, v: c.value, p: c.path || "/" }));
    ck = await get();
    if (!ck.length) { const d = new Date().toLocaleDateString("en-GB"); await JOB_RUNNERS.evoradfind({ id: 0, name: "", payload: { name: "", pid: "", probe: false, from: d, to: d } }).catch(() => {}); ck = await get(); }
    ck = ck.map((c) => Object.assign(c, { o: origin }));
  } catch (e) {}
  const r = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "ctopen", examid: String(p.examid || ""), sur: String(p.sur || ""), fn: String(p.fn || ""), amka: String(p.amka || ""), cookies: ck }).catch((e) => ({ ok: false, err: e.message }));
  if (!r || !r.ok) return { status: "failed", note: "🖥 δεν άνοιξε: " + ((r && r.err) || "χωρίς απάντηση") };
  return { status: "done", note: "🖥 άνοιξε το Νίκος CT Viewer" + (p.desc ? " · " + p.desc : "") };
};
JOB_KIND.ctremote = "🖥 Άνοιγμα απεικόνισης στον υπολογιστή";
// 🗂 8/11: «Αρχείο Ασθενών» — tablet συμβουλίου / ρυθμίσεις από το κινητό → ΤΟΠΙΚΟΣ server της βάσης (μέσω βοηθητικού, μόνο /api/…)
// payload: { only: <υπολογιστής-server>, calls: [{method, path, body}] } → result.out[] = {status, json}. Μετά την απάντηση τα δεδομένα σβήνονται από τη βάση εντολών.
// ⚡ 8/11: αιτήματα στη βάση ΑΠΕΥΘΕΙΑΣ από το bot στο 127.0.0.1:8780 (το κλειδί ζητείται ΜΙΑ φορά από το βοηθητικό).
// Πριν: κάθε αίτημα = νέο powershell (≈12″ στο Παράθυρο). Αν αποτύχει → ο παλιός δρόμος (βοηθητικό «dbcall»).
const PDXDB_PATH = /^\/(api\/[\w\/\-?=&.%]+|health)$/;
let pdxDbSlowWhy = "";
async function pdxDbKey(force) {
  if (!force) { const { efbotDbKey: k } = await chrome.storage.session.get("efbotDbKey").catch(() => ({})); if (k && k.key) return k; }
  const r = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "dbkey" }).catch((e) => ({ ok: false, err: e.message }));
  if (!r || !r.ok || !r.key) { pdxDbSlowWhy = "dbkey: " + String((r && r.err) || "χωρίς απάντηση").slice(0, 100); return null; }
  const k = { key: r.key, port: +r.port || 8780 }; await chrome.storage.session.set({ efbotDbKey: k }).catch(() => {}); return k;
}
async function pdxDbReq(method, path, body, who) {
  path = String(path || ""); method = String(method || "GET").toUpperCase(); if (!/^(GET|POST|DELETE)$/.test(method)) method = "GET";
  if (!PDXDB_PATH.test(path)) return { ok: false, err: "μη επιτρεπτή διαδρομή" };
  const direct = async (k) => { const ac = new AbortController(), to = setTimeout(() => ac.abort(), 60000);
    try { const x = await fetch("http://127.0.0.1:" + k.port + path, { method, signal: ac.signal, headers: { "content-type": "application/json; charset=utf-8", "x-pdx-key": k.key, "x-pdx-user": "bot:" + String(who || "app").slice(0, 30) }, body: body == null || method === "GET" ? undefined : JSON.stringify(body) });
      return { ok: true, status: x.status, json: await x.text(), fast: true }; } finally { clearTimeout(to); } };
  try {
    let k = await pdxDbKey(false);
    if (!k) pdxDbSlowWhy = "χωρίς κλειδί από το βοηθητικό";
    if (k) { let r = await direct(k); if (r.status === 401) { k = await pdxDbKey(true); if (k) r = await direct(k); } if (r && r.status !== 401) { pdxDbSlowWhy = ""; return r; } pdxDbSlowWhy = "κλειδί απορρίφθηκε (401)"; }
  } catch (e) { pdxDbSlowWhy = String(e && e.message || e).slice(0, 120); }
  return chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "dbcall", method, path, body: body === undefined ? null : body, who: String(who || "app").slice(0, 30) }).catch((e) => ({ ok: false, err: e.message }));
}
JOB_RUNNERS.pdxdb = async (job) => {
  const p = job.payload || {}, calls = (Array.isArray(p.calls) ? p.calls : []).slice(0, 20);
  if (!calls.length) return { status: "failed", note: "χωρίς αιτήματα" };
  // καθάρισμα: παλιές εντολές της βάσης (>10′) χάνουν το περιεχόμενό τους (ονόματα/αποφάσεις μένουν μόνο στον server της κλινικής)
  jobsInApp(async () => { try { const old = new Date(Date.now() - 10 * 60000).toISOString(); await sb6.from("oncall_jobs").update({ status: "dismissed", payload: { wiped: true }, note: "🗂 (καθαρίστηκε)" }).eq("kind", "pdxdb").lt("updated_at", old).in("status", ["done", "failed"]); return 1; } catch (e) { return 0; } }, []).catch(() => {});
  const out = []; let fastN = 0;
  for (const c of calls) {
    const r = await pdxDbReq(c.method, c.path, c.body, c.who);
    if (r && r.fast) fastN++;
    if (!r || !r.ok) return { status: "failed", note: "🗂 " + ((r && r.err) || "το βοηθητικό δεν απάντησε"), result: { out } };
    let j = null; try { j = JSON.parse(r.json || "null"); } catch (e) {}
    out.push({ status: r.status, json: j });
  }
  return { status: "done", note: "🗂 " + calls.length + " αίτημα/τα στη βάση" + (fastN === calls.length ? " ⚡" : " · αργός δρόμος" + (pdxDbSlowWhy ? ": " + pdxDbSlowWhy : "")), result: { out } };
};
JOB_KIND.pdxdb = "🗂 Αρχείο Ασθενών";
// 📧 8/11: email από το Kerio της κλινικής («📷 Σάρωση προγράμματος» → ομάδα «Πρόγραμμα χειρουργείου»).
// payload {path: img-enc/<…>.bin (PDF κρυπτογραφημένο με το κλειδί κλινικής), group, subject, text, fname, dry}
// Κωδικός: ΜΟΝΟ από το χρηματοκιβώτιο του bot (efbotCredByHost, host του webmail — το μαθαίνει με «🔑 Μάθε τους κωδικούς»).
// dry: σύνδεση + εύρεση ομάδας, ΧΩΡΙΣ αποστολή (επιστρέφει μόνο ονόματα ομάδων και πλήθος μελών).
async function kerioCred() {
  const { efbotCredByHost: cb = {} } = await V.get("efbotCredByHost").catch(() => ({}));
  const { efbot } = await chrome.storage.local.get("efbot"); const pref = String(efbot?.settings?.kerioHost || "").toLowerCase();
  const hosts = Object.keys(cb).filter((h) => (pref ? h === pref : /^(mail|webmail|kerio)([.:]|$)|^(mail|webmail)\./i.test(h)));
  for (const h of hosts) { const a = [].concat(cb[h] || []).find((x) => x && x.user && x.pass); if (a) return { host: h, user: a.user, pass: a.pass }; }
  return null;
}
JOB_RUNNERS.kmail = async (job) => {
  const p = job.payload || {};
  const cr = await kerioCred();
  if (!cr) return { status: "failed", note: "📧 δεν υπάρχει κωδικός Kerio σε αυτό το bot — πατήστε «🔑 Μάθε τους κωδικούς» και συνδεθείτε μία φορά στο webmail (http://mail/webmail/)" };
  let pdf = null;
  // 📷 σάρωση από τη σελίδα του Claude: σελίδες JPEG (κρυπτογραφημένες) μέσα στη γραμμή scanq → PDF εδώ
  const scanWipe = () => (p.scanq ? jobsInApp(async (id) => { try { await sb6.from("oncall_jobs").update({ status: "done", payload: { wiped: true } }).eq("id", id); return 1; } catch (e) { return 0; } }, [+p.scanq]).catch(() => {}) : Promise.resolve());
  if (p.scanq && !p.dry) {
    // 8/11: σάρωση με ΚΛΕΙΔΙ ΜΙΑΣ ΧΡΗΣΗΣ (από το κινητό, μέσω της σελίδας Claude): p.wk = {αποτύπωμα υπολογιστή: RSA(κλειδί)}
    let ck = null;
    if (p.wk) { try { const me = await myXfer(); const w = me && p.wk[me.fp]; if (!w) return { status: "failed", env: true, note: "🔐 η σάρωση δεν προορίζεται γι' αυτόν τον υπολογιστή" };
        const priv = await crypto.subtle.importKey("jwk", me.k.priv, { name: "RSA-OAEP", hash: "SHA-256" }, false, ["decrypt"]);
        ck = { raw: new Uint8Array(await crypto.subtle.decrypt({ name: "RSA-OAEP" }, priv, b64d(w))) }; }
      catch (e) { return { status: "failed", note: "🔐 το κλειδί της σάρωσης δεν ανοίγει: " + e.message }; } }
    else { try { ck = await imgClinicKey(); } catch (e) { return { status: "failed", note: "🔐 " + e.message }; } }
    const r = await jobsInApp(async (id) => { try { if (typeof sb6 === "undefined") return { skip: true }; const q = await sb6.from("oncall_jobs").select("payload").eq("id", id).maybeSingle(); if (q.error) return { err: q.error.message }; return { pages: ((q.data || {}).payload || {}).pages || [] }; } catch (e) { return { err: String(e) }; } }, [+p.scanq], 60000);
    if (!r || !r.pages) return { status: "failed", note: "📧 λήψη σάρωσης: " + ((r && r.err) || "το Παραδόχαρτο δεν είναι ανοιχτό στον υπολογιστή του bot") };
    if (!r.pages.length) return { status: "failed", note: "📧 η σάρωση δεν έχει πια σελίδες (σβήστηκε;)" };
    try { const dk = await crypto.subtle.importKey("raw", ck.raw, "AES-GCM", false, ["decrypt"]); const jp = [];
      for (const b of r.pages) { const u = b64d(b); jp.push(new Uint8Array(await crypto.subtle.decrypt({ name: "AES-GCM", iv: u.slice(0, 12) }, dk, u.slice(12)))); }
      pdf = kMail.pdfFromJpegs(jp); }
    catch (e) { return { status: "failed", note: "🔐 η σάρωση δεν ανοίγει με το κλειδί κλινικής" }; }
  }
  if (p.path && !p.dry) {
    let ck; try { ck = await imgClinicKey(); } catch (e) { return { status: "failed", note: "🔐 " + e.message }; }
    const r = await jobsInApp(async (path) => { try { if (typeof sb6 === "undefined") return { skip: true }; const dl = await sb6.storage.from("img-enc").download(path); if (dl.error) return { err: dl.error.message }; const u = new Uint8Array(await dl.data.arrayBuffer()); let s = ""; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return { b64: btoa(s) }; } catch (e) { return { err: String(e) }; } }, [p.path], 60000);
    if (!r || !r.b64) return { status: "failed", note: "📧 λήψη σάρωσης: " + ((r && r.err) || "το Παραδόχαρτο δεν είναι ανοιχτό στον υπολογιστή του bot") };
    try { const u = b64d(r.b64), dk = await crypto.subtle.importKey("raw", ck.raw, "AES-GCM", false, ["decrypt"]); pdf = new Uint8Array(await crypto.subtle.decrypt({ name: "AES-GCM", iv: u.slice(0, 12) }, dk, u.slice(12))); }
    catch (e) { return { status: "failed", note: "🔐 η σάρωση δεν ανοίγει με το κλειδί κλινικής" }; }
  }
  let cli = null, base = "", lastErr = "";
  const F = (u, o) => fetch(u, o), cand = await kMail.resolve(cr.host, F);
  // Όνομα σύνδεσης: στο webmail αρκεί «ouro», στο API το Kerio θέλει συχνά «ouro@laiko.gr» (χρήστης@τομέας — ΟΧΙ η διεύθυνση email).
  // Δοκιμάζονται το πολύ 2 μορφές (για να μην κλειδώσει ο λογαριασμός) και η σωστή κρατιέται (settings.kerioUser).
  const { efbot: eb0 } = await chrome.storage.local.get("efbot"); const st0 = (eb0 && eb0.settings) || {};
  const dom = String(st0.kerioDomain || "laiko.gr").trim(), u0 = String(cr.user || "").trim();
  const users = [...new Set([st0.kerioUser && String(st0.kerioUser).split("@")[0].toLowerCase() === u0.split("@")[0].toLowerCase() ? st0.kerioUser : null, /@/.test(u0) ? u0 : u0 + "@" + dom, u0].filter(Boolean))].slice(0, 2);
  let badPw = "";
  for (const c0 of cand) {
    for (const un of users) {
      const c = kMail.client(c0.base, F);
      try { await c.login(un, cr.pass); cli = c; base = c0.base;
        if (st0.kerioUser !== un) { try { const { efbot } = await chrome.storage.local.get("efbot"); if (efbot) { efbot.settings = efbot.settings || {}; efbot.settings.kerioUser = un; await chrome.storage.local.set({ efbot }); } } catch (e2) {} }
        break; }
      catch (e) {
        // -32700/-32600 (Parse error/Invalid request) = πρόβλημα διεύθυνσης/ανακατεύθυνσης, όχι κωδικού → επόμενη διεύθυνση
        if (e && (e.code === -32700 || e.code === -32600 || e.code === undefined)) { lastErr = c0.base + " " + (c0.via || "") + ": " + String(e && e.message || e).slice(0, 80); break; }
        badPw = String(e.message).slice(0, 80);
      }
    }
    if (cli || badPw) break;
  }
  // 🖱 όπως ο άνθρωπος: ανοίγει τη σελίδα του Kerio, γράφει τα στοιχεία στα πλαίσια, πατά «Είσοδος» — και δουλεύει μέσα από εκείνη τη σύνδεση
  let uiTab = null;
  if (!cli && badPw) {
    const u = await kerioUiLogin(cand.map((x) => x.base), u0, cr.pass);
    if (u.ok) { uiTab = u.tabId; base = u.base; cli = kMail.client(base, kerioTabFetch(u.tabId)); cli.setToken(u.token); badPw = ""; }
    else return { status: "failed", note: "📧 Kerio: η είσοδος από τη σελίδα δεν έγινε" + (u.msg ? " — η σελίδα λέει: «" + u.msg + "»" : "") + (badPw ? " · API: " + badPw : "") + " — ελέγξτε τον κωδικό (🔐 Κωδικός Kerio)", result: { diag: kerioUiLogin.diag || null, user: u0.replace(/./g, (c, i) => (i < 2 ? c : "•")) } };
  }
  if (!cli && badPw) return { status: "failed", note: "📧 Kerio: η σύνδεση απορρίφθηκε για «" + users.join("» και «") + "» (" + badPw + ") — ελέγξτε τον κωδικό" };
  if (!cli) return { status: "failed", env: !/Parse error|Invalid request/i.test(lastErr), note: "📧 το Kerio (" + cr.host + ") δεν συνδέεται από αυτόν τον υπολογιστή" + (lastErr ? " · " + lastErr : "") + " · δοκιμάστηκαν: " + cand.map((x) => x.base + " (" + x.via + ")").join(", ") };
  try {
    const want = String(p.group || "Πρόγραμμα χειρουργείου");
    const g = await kMail.findGroup(cli, want);
    if (p.dry) return { status: "done", note: "📧 Kerio ✓ σύνδεση · ομάδα «" + (g.group || "δεν βρέθηκε") + "»" + (g.group ? " · " + g.members.length + " παραλήπτες" : ""), result: { group: g.group, n: g.members.length, groups: g.groups.slice(0, 40), folders: g.folders.slice(0, 20), base } };
    if (!g.group || !g.members.length) { scanWipe(); return { status: "failed", note: "📧 δεν βρέθηκε η ομάδα «" + want + "» στις επαφές του Kerio" + (g.groups.length ? " (υπάρχουν: " + g.groups.slice(0, 6).join(", ") + ")" : "") }; }
    if (!pdf) return { status: "failed", note: "📧 χωρίς συνημμένο" };
    const s = await kMail.send(cli, { to: g.members, subject: p.subject || "Πρόγραμμα χειρουργείου", text: p.text || "", att: { bytes: pdf, name: p.fname || "programma.pdf", type: "application/pdf" } });
    if (p.path) jobsInApp(async (path) => { try { await sb6.storage.from("img-enc").remove([path]); return 1; } catch (e) { return 0; } }, [p.path]).catch(() => {});
    scanWipe();
    if (!p.test) labsPushPhone("📧 Στάλθηκε: " + (p.subject || "Πρόγραμμα χειρουργείου"), "σε «" + g.group + "» (" + s.n + " παραλήπτες)").catch(() => {});
    return { status: "done", note: "📧 στάλθηκε σε «" + g.group + "» · " + s.n + " παραλήπτες", result: { group: g.group, n: s.n } };
  } catch (e) { return { status: "failed", note: "📧 " + String(e && e.message || e).slice(0, 160) }; }
  finally { if (uiTab) { chrome.tabs.remove(uiTab).catch(() => {}); } else cli.logout().catch(() => {}); }
};
JOB_KIND.kmail = "📧 Email (Kerio)";
// Είσοδος στο webmail ΟΠΩΣ Ο ΑΝΘΡΩΠΟΣ: καρτέλα στο παρασκήνιο → πλαίσια ονόματος/κωδικού → «Είσοδος» → αναμονή.
// Επιστρέφει {ok, tabId, base, token} (token = το cookie TOKEN_CONNECT_WEBMAIL που στέλνει και το ίδιο το webmail ως X-Token)
// ή {ok:false, msg} με το μήνυμα λάθους της σελίδας.
async function kerioUiLogin(bases, user, pass) {
  let tab = null, msg = "";
  for (const base of bases) {
    tab = await chrome.tabs.create({ url: base + "/webmail/login/", active: false }).catch(() => null);
    if (!tab) continue;
    for (let i = 0; i < 40; i++) { await new Promise((r) => setTimeout(r, 400)); const t = await chrome.tabs.get(tab.id).catch(() => null); if (!t) break; if (t.status === "complete") break; }
    // τα πλαίσια μπορεί να εμφανιστούν λίγο μετά τη φόρτωση (σελίδα JavaScript)
    let r = null;
    for (let k = 0; k < 20 && !(r && r.done); k++) {
      await new Promise((rs) => setTimeout(rs, 500));
      try { [r] = (await chrome.scripting.executeScript({ target: { tabId: tab.id }, args: [user, pass], func: (user, pass) => {
        const vis = (e) => !!(e && e.offsetParent !== null && !e.disabled);
        const pw = [...document.querySelectorAll('input[type="password"]')].find(vis);
        if (!pw) return { done: !/\/login/.test(location.pathname), url: location.pathname };
        const all = [...document.querySelectorAll('input:not([type="hidden"]):not([type="password"]):not([type="checkbox"]):not([type="radio"]):not([type="submit"]):not([type="button"])')].filter(vis);
        const un = all.find((e) => /user|login|name|mail/i.test((e.name || "") + " " + (e.id || "") + " " + (e.autocomplete || ""))) || all[0];
        if (!un) return { done: false };
        const set = (el, v) => { const d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value"); d.set.call(el, v); el.dispatchEvent(new Event("input", { bubbles: true })); el.dispatchEvent(new Event("change", { bubbles: true })); };
        set(un, user); set(pw, pass);
        const btn = [...document.querySelectorAll('button, input[type="submit"], [role="button"], a')].filter(vis).find((b) => /^(είσοδος|σύνδεση|log ?in|sign ?in|login)$/i.test(String(b.value || b.textContent || "").trim())) || (pw.form && pw.form.querySelector('[type="submit"]'));
        if (btn) btn.click(); else if (pw.form) pw.form.requestSubmit ? pw.form.requestSubmit() : pw.form.submit(); else pw.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", keyCode: 13, bubbles: true }));
        return { done: true, clicked: !!btn };
      } })) || []; r = r && r.result; } catch (e) { r = null; }
    }
    // αναμονή: έξω από τη σελίδα εισόδου + cookie TOKEN (μόνο αν βρέθηκαν τα πλαίσια· αλλιώς επόμενη διεύθυνση)
    if (!(r && r.done)) { msg = msg || "δεν βρέθηκαν τα πλαίσια εισόδου στη σελίδα " + base; chrome.tabs.remove(tab.id).catch(() => {}); continue; }
    for (let i = 0; i < 40; i++) {
      await new Promise((rs) => setTimeout(rs, 500));
      let st = null;
      try { [st] = (await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => {
        const tk = (document.cookie.match(/(?:^|;\s*)TOKEN_CONNECT_WEBMAIL=([^;]+)/) || [])[1] || "";
        const err = [...document.querySelectorAll('[class*="error" i], [class*="warning" i], [role="alert"], .x-form-invalid-msg')].map((e) => (e.innerText || "").trim()).filter(Boolean).join(" ").slice(0, 120);
        const names = document.cookie.split(";").map((c) => c.split("=")[0].trim()).filter(Boolean).join(",");
        // διάγνωση (χωρίς τιμές): τι πλαίσια/κουμπιά έχει η σελίδα
        const diag = { path: location.pathname, title: document.title.slice(0, 40), inputs: [...document.querySelectorAll("input")].slice(0, 12).map((e) => (e.type || "") + ":" + (e.name || e.id || "") + (e.offsetParent === null ? "(κρυφό)" : "") + (e.value ? "(έχει)" : "")).join(" "), buttons: [...document.querySelectorAll('button, input[type="submit"], [role="button"]')].slice(0, 8).map((b) => String(b.value || b.textContent || "").trim().slice(0, 20)).join(" | "), text: (document.body && document.body.innerText || "").replace(/\s+/g, " ").slice(0, 160) };
        return { tk: decodeURIComponent(tk), login: /\/login/.test(location.pathname) && !!document.querySelector('input[type="password"]'), err, origin: location.origin, names, diag };
      } })) || []; st = st && st.result; } catch (e) { st = null; }
      if (st && st.tk && !st.login) return { ok: true, tabId: tab.id, base: st.origin, token: st.tk };
      if (st && !st.login && !st.tk && i > 16) { msg = "μπήκε στο webmail, αλλά δεν βρέθηκε το token (cookies: " + (st.names || "—") + ")"; break; }
      if (st && st.err) msg = st.err;
      if (st && st.diag) kerioUiLogin.diag = { ...st.diag, filled: r, base };
      if (st && st.login && i > 12 && st.err) break;
    }
    chrome.tabs.remove(tab.id).catch(() => {});
  }
  return { ok: false, msg };
}
// fetch ΜΕΣΑ από την καρτέλα του webmail (ίδια προέλευση, τα cookies της σύνδεσης)
function kerioTabFetch(tabId) {
  const run = async (func, args) => { const [r] = await chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", args, func }); return r && r.result; };
  const f = async (url, o) => {
    const res = await run(async (url, method, headers, body) => { try { const r = await fetch(url, { method, headers, body, credentials: "include" }); return { status: r.status, text: await r.text() }; } catch (e) { return { status: 0, text: "", err: String(e) }; } }, [url, (o && o.method) || "GET", (o && o.headers) || {}, (o && typeof o.body === "string") ? o.body : null]);
    if (!res || res.err) throw new Error((res && res.err) || "καρτέλα Kerio");
    return { status: res.status, ok: res.status < 400, json: async () => JSON.parse(res.text || "null") };
  };
  f.upload = async (url, tok, bytes, name, type) => run(async (url, tok, b64, name, type) => { try { const bin = atob(b64), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
      const fd = new FormData(); fd.append("newFile.bin", new Blob([u], { type }), name); const r = await fetch(url, { method: "POST", headers: { "X-Token": tok }, body: fd, credentials: "include" }); return await r.json(); } catch (e) { return { error: { message: String(e) } }; } }, [url, tok, b64e(bytes), name, type]);
  return f;
}
// 🗂 8/11: τωρινοί ασθενείς → Αρχείο Ασθενών. Παραδόχαρτο (oncall_patients) + τελευταία λίστα ΝΠΣ + στοιχεία ΝΠΣ (3 ημέρες)
// → pdxCur.buildCurrentRows → POST /api/patients/bulk (ανά 200). Μόνο ασθενείς με ΑΜΚΑ ή ΑΜ (χωρίς διπλούς σε επανάληψη).
// payload: { only: <server βάσης>, dry?: true (μόνο μέτρηση) } → result: μόνο αριθμοί (τα ονόματα μένουν στον server της κλινικής).
async function pdxCurSource() {
  return jobsInApp(async () => { try {
    if (typeof sb6 === "undefined") return { skip: true };
    const [a, l, e] = await Promise.all([
      sb6.from("oncall_patients").select("key,is_extra,record").limit(5000),
      sb6.from("oncall_jobs").select("payload,updated_at").eq("kind", "npslist").eq("status", "done").order("id", { ascending: false }).limit(1),
      sb6.from("oncall_jobs").select("payload").eq("kind", "npsenrich").eq("status", "done").gte("created_at", new Date(Date.now() - 3 * 864e5).toISOString()).order("id", { ascending: true }).limit(20)]);
    if (a.error) return { err: "Παραδόχαρτο: " + a.error.message };
    const K = ["name", "fname", "father", "amka", "am", "dx", "comorb", "surgery", "surgeryCustom", "surgery2", "surgery2Custom", "podDate"];
    const pdx = (a.data || []).map((r) => { const o = {}; K.forEach((k) => { if (r.record && r.record[k] != null) o[k] = r.record[k]; }); return { key: r.key, is_extra: r.is_extra, record: o }; });
    const res = l.data && l.data[0] && l.data[0].payload && l.data[0].payload.result;
    const nps = res && Array.isArray(res.rows) && (res.dpt || "3449") === "3449" ? res.rows.map((r) => ({ name: r.name, am: r.am, amka: r.amka })) : [];
    const enr = {}; (e.data || []).forEach((x) => { const P = (x.payload && x.payload.result && x.payload.result.pts) || {}; Object.keys(P).forEach((n) => { const v = P[n] || {}; enr[n] = { amka: v.amka, am: v.am, dx: v.dx }; }); });
    return { pdx, nps, enr, npsAt: l.data && l.data[0] && l.data[0].updated_at };
  } catch (x) { return { err: x.message }; } }, [], 30000);
}
JOB_RUNNERS.pdxsync = async (job) => {
  const p = job.payload || {};
  if (typeof pdxCur === "undefined") return { status: "failed", note: "🗂 λείπει το pdxcur.js" };
  const src = await pdxCurSource().catch((e) => ({ err: e.message }));
  if (!src || src.err) return { status: "failed", note: "🗂 δεν διαβάστηκαν οι ασθενείς: " + ((src && src.err) || "δεν βρέθηκε ανοιχτό Παραδόχαρτο") };
  const R = pdxCur.buildCurrentRows(src);
  const sum = { pdx: src.pdx.length, nps: src.nps.length, npsAt: src.npsAt || null, rows: R.rows.length, skipped: R.skipped.length, conflicts: R.conflicts.length, created: 0, updated: 0, errors: 0 };
  if (!p.dry) for (let i = 0; i < R.rows.length; i += 200) {
    const r = await pdxDbReq("POST", "/api/patients/bulk", { rows: R.rows.slice(i, i + 200) }, "pdxsync");
    let j = null; try { j = JSON.parse((r && r.json) || "null"); } catch (e) {}
    if (!r || !r.ok || r.status !== 200 || !j) return { status: "failed", note: "🗂 η βάση δεν δέχτηκε τους ασθενείς: " + ((r && (r.err || r.status)) || "χωρίς απάντηση"), result: sum };
    sum.created += j.created || 0; sum.errors += j.errors || 0; sum.updated += (j.n || 0) - (j.created || 0) - (j.errors || 0);
  }
  const why = (L) => { const o = {}; L.forEach((x) => { o[x.why] = (o[x.why] || 0) + 1; }); return Object.keys(o).map((k) => k + ": " + o[k]).join(", "); };
  return { status: "done", note: "🗂 τωρινοί ασθενείς" + (p.dry ? " (δοκιμή, χωρίς εγγραφή)" : "") + ": " + R.rows.length + " προς τη βάση" + (p.dry ? "" : " · νέοι " + sum.created + " · ενημερώθηκαν " + sum.updated + (sum.errors ? " · σφάλματα " + sum.errors : "")) + (R.skipped.length ? " · εκτός " + R.skipped.length + " (" + why(R.skipped) + ")" : "") + (R.conflicts.length ? " · ⚠ συγκρούσεις " + R.conflicts.length + " (" + why(R.conflicts) + ")" : ""), result: sum };
};
JOB_KIND.pdxsync = "🗂 Τωρινοί ασθενείς → Αρχείο Ασθενών";
JOB_KIND.evoradnet = "🔎 Evorad: διευθύνσεις εικόνων αξονικής (μόνο ανάγνωση)";
JOB_RUNNERS.evoradimg = async (job) => {
  const p = job.payload || {};
  if (!p.listOnly && (!p.pub || !p.pub.n)) return { status: "failed", note: "λείπει το κλειδί της συσκευής" };
  // καθάρισμα παλιών κρυπτογραφημένων εικόνων (όσες δεν άνοιξαν)
  jobsInApp(async () => { try { const old = new Date(Date.now() - 2 * 3600e3).toISOString(); const r = await sb6.from("oncall_jobs").select("id,payload").eq("kind", "evoradimg").lt("updated_at", old).limit(20); for (const j of r.data || []) if (j.payload && j.payload.result && j.payload.result.enc) await sb6.from("oncall_jobs").update({ status: "dismissed", payload: { name: j.payload.name, expired: true } }).eq("id", j.id); return { ok: true }; } catch (e) { return { err: String(e) }; } }, []).catch(() => {});
  const f = await JOB_RUNNERS.evoradfind({ ...job, payload: { name: "", pid: "", probe: false, from: new Date().toLocaleDateString("en-GB"), to: new Date().toLocaleDateString("en-GB") } });   // μόνο άνοιγμα + σύνδεση
  if (f.status !== "done" && !/εξετάσεις/.test(f.note || "")) return f;
  const { efbotEvoradUrl: u0 } = await chrome.storage.local.get("efbotEvoradUrl");
  const origin = new URL(u0 || "http://172.16.1.26:2080/index.jsp").origin;
  const tab = await botSiteFind(origin);
  if (!tab) return { status: "failed", note: "ο Evorad έκλεισε" };
  // όλα τα δεδομένα του πίνακα (DataTables)
  // απευθείας το API της σελίδας (ίδιο αίτημα με την «Αναζήτηση»): λατινικά πρώτα, μετά ελληνικά
  const G = { Α: "A", Β: "V", Γ: "G", Δ: "D", Ε: "E", Ζ: "Z", Η: "I", Θ: "TH", Ι: "I", Κ: "K", Λ: "L", Μ: "M", Ν: "N", Ξ: "X", Ο: "O", Π: "P", Ρ: "R", Σ: "S", Τ: "T", Υ: "Y", Φ: "F", Χ: "CH", Ψ: "PS", Ω: "O" };
  const toLat = (t) => String(t || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().replace(/ΟΥ/g, "OU").replace(/ΑΙ/g, "AI").replace(/ΕΙ/g, "EI").replace(/ΟΙ/g, "OI").replace(/ΜΠ/g, "MP").replace(/ΝΤ/g, "NT").replace(/[Α-Ω]/g, (c) => G[c] || "");
  const sur = String(p.name || "").trim().split(/\s+/)[0];
  const today = new Date().toISOString().slice(0, 10);
  let all = [], apiNote = "";
  // παραλλαγές μεταγραφής (Η→I/H, Β→V/B, Υ→Y/I/U, Χ→CH/H/X) — ο Evorad γράφει αλλού αλλιώς
  // 8/11: τόνοι/διαλυτικά φεύγουν (Ϊ=Ι), ΜΠ→B, ΝΤ→D, ΓΚ/ΓΓ→G· στο τέλος 3 πρώτα γράμματα + έλεγχος «σκελετού» (Β/V, Η/I, Υ/I/U, CH/H…)
  const surG = String(sur).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase();
  const L0 = toLat(surG), V = new Set([L0]);
  const mpb = (x) => x.replace(/MP/g, "B").replace(/NT/g, "D"), gk = (x) => x.replace(/GK|GG/g, "G");
  V.add(mpb(L0)); V.add(gk(mpb(L0))); V.add(surG);
  for (const b of [L0, mpb(L0)]) { V.add(b.replace(/V/g, "B")); V.add(b.replace(/Y/g, "I")); V.add(b.replace(/I/g, "H")); V.add(b.replace(/CH/g, "H")); V.add(b.replace(/CH/g, "X")); V.add(b.replace(/OI|EI/g, "I")); }
  const tryList = [...V].filter(Boolean).slice(0, 12);
  const evSk = (t) => { let x = String(t || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase(); x = /[Α-Ω]/.test(x) ? toLat(x) : x;
    return x.replace(/OU/g, "U").replace(/MP/g, "B").replace(/NT/g, "D").replace(/GK|GG/g, "G").replace(/CH|KH/g, "H").replace(/KS/g, "X").replace(/TH/g, "8").replace(/PH/g, "F").replace(/PS/g, "Q").replace(/AI/g, "E").replace(/EI|OI/g, "I")
      .replace(/H/g, "").replace(/V/g, "B").replace(/W/g, "O").replace(/C/g, "K").replace(/J/g, "Z").replace(/[YU]/g, "I").replace(/[^A-Z0-9]/g, "").replace(/(.)\1+/g, "$1"); };
  const wantSk = evSk(surG);
  for (let pass = 0; pass < 2 && !all.length; pass++) {
  if (pass === 1) { await chrome.tabs.update(tab.id, { url: origin + "/ris/exams/exams.jsp" }).catch(() => {}); await E.sleep(3500); }   // ανανέωση συνεδρίας της σελίδας και ξανά
  for (const nm of tryList) {
    const r = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: "MAIN", args: [nm, today], func: async (nm, today) => {
      try {
        const res = await fetch(location.origin + "/api/getExams?name=" + encodeURIComponent(nm) + "&fromDate=2005-01-01&toDate=" + today + "&", { credentials: "include" });
        const j = await res.json(); const d = Array.isArray(j) ? j : (j.data || j.aaData || []);
        return d.map((d) => ({ examid: d.examid, date: d.examdate, mod: d.exammodalitytype, desc: d.studydescription || "", first: d.firstname || "", last: d.lastname || "", amka: String(d.amka || ""), pid: String(d.patientid || ""), pid2: String(d.secondarypatientid || ""), birth: d.birthdate || "" }));
      } catch (e) { return { err: String(e.message || e) }; }
    } }).then((x) => x[0] && x[0].result).catch((e) => ({ err: e.message }));
    if (!Array.isArray(r)) { apiNote = (r && r.err) || "χωρίς απάντηση"; continue; }
    if (r.length) { all = r; break; }
  }
  }
  // τελευταία προσπάθεια: 3 πρώτα γράμματα (λατινικά με B/D και ελληνικά) + φιλτράρισμα με «σκελετό» επωνύμου
  if (!all.length && wantSk.length >= 3) for (const pre of [...new Set([mpb(L0).slice(0, 3), L0.slice(0, 3), surG.slice(0, 3)])]) {
    const r = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: "MAIN", args: [pre, today], func: async (nm, today) => {
      try { const res = await fetch(location.origin + "/api/getExams?name=" + encodeURIComponent(nm) + "&fromDate=2005-01-01&toDate=" + today + "&", { credentials: "include" });
        const j = await res.json(); const d = Array.isArray(j) ? j : (j.data || j.aaData || []);
        return d.slice(0, 3000).map((d) => ({ examid: d.examid, date: d.examdate, mod: d.exammodalitytype, desc: d.studydescription || "", first: d.firstname || "", last: d.lastname || "", amka: String(d.amka || ""), pid: String(d.patientid || ""), pid2: String(d.secondarypatientid || ""), birth: d.birthdate || "" }));
      } catch (e) { return { err: String(e.message || e) }; } } }).then((x) => x[0] && x[0].result).catch((e) => ({ err: e.message }));
    tryList.push(pre + "…");
    if (Array.isArray(r)) { const hit = r.filter((x) => evSk(x.last) === wantSk); if (hit.length) { all = hit; break; } }
  }
  if (!all.length) return { status: "failed", note: "δεν βρέθηκαν εξετάσεις στον Evorad για «" + sur + "» (δοκιμές: " + tryList.join(", ") + ", 2 περάσματα)" + (apiNote ? " (" + apiNote + ")" : "") };
  // 🔎 8/11: ελεύθερη αναζήτηση από το κινητό (ο γιατρός διαλέγει μόνος του τον ασθενή) — όλοι οι συνεπώνυμοι, με ονοματεπώνυμο
  if (p.listOnly && p.free) {
    const fw = String(p.name || "").trim().split(/\s+/).slice(1).join(" "); let L1 = all;
    if (fw) { const f0 = evSk(fw).slice(0, 3); const h = all.filter((x) => evSk(x.first).startsWith(f0)); if (h.length) L1 = h; }
    const L = L1.slice().sort((a, b) => String(b.date).localeCompare(String(a.date))).slice(0, 80).map((x) => ({ examid: x.examid, date: String(x.date || "").slice(0, 16), mod: x.mod, desc: x.desc, last: x.last, first: x.first, birth: String(x.birth || "").slice(0, 10) }));
    return { status: "done", note: "🩻 Evorad (αναζήτηση «" + String(p.name).slice(0, 30) + "»): " + L.length + " εξετάσεις", result: { exams: L, verify: { free: true } } };
  }
  const amka = String(p.amka || "");
  let am = String(p.am || "");
  const people = [...new Set(all.map((x) => x.amka || x.pid || (x.last + " " + x.first)))];
  // 🆔 πολλοί συνεπώνυμοι και χωρίς ΑΜ/ΑΜΚΑ → ΑΜ από το ΝΠΣ (ο Evorad έχει τον ΑΜ ως Patient ID / Δευτ. κωδικό ασθενή)
  if (!amka && !am && people.length > 1) { am = await bgReadAmFromEmr(p.name || job.name).catch(() => ""); if (am) bgMark("ΑΜ από ΝΠΣ"); }
  let mine = [], verify = {};
  // ο ΑΜΚΑ συχνά είναι γραμμένος ως «Patient ID» (χωρίς να λέει ΑΜΚΑ) → ελέγχονται όλα τα πεδία ταυτότητας
  const dig = (v) => String(v || "").replace(/\D/g, "");
  if (amka) { mine = all.filter((x) => dig(x.amka) === amka || dig(x.pid) === amka || dig(x.pid2) === amka); if (mine.length) verify = { id: mine.some((x) => dig(x.amka) === amka) ? "ΑΜΚΑ" : "ΑΜΚΑ (ως Patient ID)", name: true }; }
  if (!mine.length && am) { mine = all.filter((x) => amEq(x.pid, am) || amEq(x.pid2, am)); if (mine.length) verify = { id: "ΑΜ", name: true }; }
  // ΑΜΚΑ = ΗΗΜΜΕΕ + 5 ψηφία: αν ο Evorad δεν έχει ΑΜΚΑ, ταίριασμα ημερομηνίας γέννησης (επώνυμο ήδη ίδιο από την αναζήτηση)
  const bOf = (b) => { const m = /(\d{4})\D?(\d{2})\D?(\d{2})/.exec(String(b || "")) || null; if (m) return m[3] + m[2] + m[1].slice(2); const g = /(\d{2})\D(\d{2})\D(\d{2,4})/.exec(String(b || "")); return g ? g[1] + g[2] + g[3].slice(-2) : ""; };
  if (!mine.length && /^\d{11}$/.test(amka)) { const bd = amka.slice(0, 6); mine = all.filter((x) => !x.amka && bOf(x.birth) === bd); if (mine.length && new Set(mine.map((x) => x.first)).size === 1) verify = { id: "ημ. γέννησης (από ΑΜΚΑ)", name: true }; else mine = []; }
  if (!mine.length && !amka && !am && people.length === 1) { mine = all; verify = { name: true }; }
  // ημ. εισαγωγής (Παραδόχαρτο, ΗΗ/ΜΜ/ΕΕΕΕ): η ακτινογραφία θώρακος γίνεται συνήθως την ημέρα της εισαγωγής
  const adm = (() => { const m = /(\d{1,2})\/(\d{1,2})\/(\d{4})/.exec(String(p.ad || "")); return m ? m[3] + "-" + m[2].padStart(2, "0") + "-" + m[1].padStart(2, "0") : ""; })();
  const dayDiff = (d) => { const a = Date.parse(String(d || "").slice(0, 10)), b = Date.parse(adm); return isNaN(a) || isNaN(b) ? 99 : Math.round((a - b) / 864e5); };
  const isXr = (x) => /^(DX|CR|XR)$/i.test(x.mod || "");
  const atAdm = (x) => adm && isXr(x) && dayDiff(x.date) >= -1 && dayDiff(x.date) <= 1;
  const whoOf = (arr) => new Set(arr.map((x) => (x.last + " " + x.first).trim()));
  // ονοματεπώνυμο: το μικρό όνομα του Παραδόχαρτου (μεταγραμμένο) — με ή χωρίς επιβεβαίωση από την ημ. εισαγωγής
  if (!mine.length) {
    const fn = String(p.fname || "").trim() || String(p.name || "").trim().split(/\s+/).slice(1).join(" ");
    let cand = [];
    if (fn) { const f0 = toLat(fn).split(/\s+/)[0].slice(0, 4); cand = all.filter((x) => String(x.first || "").toUpperCase().replace(/[^A-Z]/g, "").startsWith(f0.replace(/[^A-Z]/g, "")) || toLat(x.first || "").startsWith(f0)); }
    const candAdm = cand.filter(atAdm);
    if (candAdm.length && whoOf(candAdm).size === 1) { const w = [...whoOf(candAdm)][0]; mine = cand.filter((x) => (x.last + " " + x.first).trim() === w); verify = { id: "μικρό όνομα + ημ. εισαγωγής", name: true }; }
    else if (cand.length && whoOf(cand).size === 1) { mine = cand; verify = { id: "ονοματεπώνυμο", name: true, weak: true }; }
    else if (!fn && adm) {   // χωρίς μικρό όνομα: ΕΝΑΣ μόνο συνεπώνυμος με ακτινογραφία την ημέρα εισαγωγής
      const a = all.filter(atAdm);
      if (a.length && whoOf(a).size === 1) { const w = [...whoOf(a)][0]; mine = all.filter((x) => (x.last + " " + x.first).trim() === w); verify = { id: "ημ. εισαγωγής", name: true, weak: true }; }
    }
  }
  if (!mine.length) {
    const who = [...new Set(all.map((x) => (x.last + " " + x.first).trim()))].slice(0, 6).join(", ");
    const nA = all.filter((x) => x.amka).length, nB = all.filter((x) => bOf(x.birth)).length;
    return { status: "failed", note: all.length ? (amka || am ? "στον Evorad υπάρχουν εξετάσεις με αυτό το επώνυμο (" + who + ") αλλά ΚΑΝΕΝΑΣ με τον ίδιο " + (amka ? "ΑΜΚΑ ή ημ. γέννησης" : "ΑΜ") + " — δεν στάλθηκε τίποτα (εγγραφές με ΑΜΚΑ: " + nA + "/" + all.length + ", με ημ. γέννησης: " + nB + "/" + all.length + ")" : "βρέθηκαν " + people.length + " διαφορετικοί ασθενείς (" + who + ") — χρειάζεται ΑΜΚΑ στον ασθενή του Παραδόχαρτου για να διαλέξω σωστά") : "δεν βρέθηκαν εξετάσεις στον Evorad" };
  }
  // 🖥 8/11: μόνο η λίστα εξετάσεων του (ταυτοποιημένου) ασθενή — για «Άνοιγμα στον υπολογιστή» από το κινητό. Χωρίς εικόνες.
  if (p.listOnly) {
    const L = mine.slice().sort((a, b) => String(b.date).localeCompare(String(a.date))).slice(0, 60).map((x) => ({ examid: x.examid, date: String(x.date || "").slice(0, 16), mod: x.mod, desc: x.desc, last: x.last, first: x.first }));
    return { status: "done", note: "🩻 Evorad: " + L.length + " εξετάσεις (" + (verify.id || "όνομα") + ")", result: { exams: L, verify } };
  }
  const xr = mine.filter(isXr).sort((a, b) => String(b.date).localeCompare(String(a.date)));
  const chest = xr.filter((x) => /θ[ωώ]ρακ|thorax|chest|πνευμ/i.test(x.desc));
  // της τρέχουσας νοσηλείας πρώτα (από την ημ. εισαγωγής −1 και μετά), αλλιώς η πιο πρόσφατη
  const cur = (arr) => adm ? arr.filter((x) => dayDiff(x.date) >= -1) : arr;
  const ex = (cur(chest)[0] || cur(xr)[0] || chest[0] || xr[0]);
  const old = adm && dayDiff(ex && ex.date) < -1;
  if (!ex) return { status: "failed", note: "ο ασθενής έχει " + mine.length + " εξετάσεις στον Evorad αλλά καμία απλή ακτινογραφία (DX/CR)" };
  // σειρές + viewer
  const ser = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: "MAIN", args: [ex.examid], func: async (examid) => {
    try { const r = await (await fetch(location.origin + "/api/getSeries?examuid=" + encodeURIComponent(examid), { credentials: "include" })).json(); return (r.data || []).map((d) => ({ ref: d.examinationref, jfx: d.jfxuid, n: (d.imageNames || []).length, prot: d.protocolname || "", desc: d.description || "", thumb: d.img || "" })); } catch (e) { return { err: e.message }; }
  } }).then((r) => r[0] && r[0].result).catch((e) => ({ err: e.message }));
  if (!Array.isArray(ser) || !ser.length) return { status: "failed", note: "Evorad: δεν ήρθαν οι σειρές της εξέτασης (" + (ser && ser.err || "κενό") + ")" };
  const s0 = ser.find((x) => /pa|ap|chest|thorax|θ[ωώ]ρ/i.test(x.prot + " " + x.desc)) || ser[0];
  const vurl = origin + "/viewers/static/index.jsp?&examid=" + encodeURIComponent(s0.ref) + "&id=" + encodeURIComponent(ex.examid) + "&seriesid=" + encodeURIComponent(s0.jfx) + "&keyImage=false&input=";
  const vt = await chrome.tabs.create({ windowId: tab.windowId, url: vurl, active: false }).catch(() => null);
  let shot = null, how = "", viewerProbe = null;
  if (vt) {
    chrome.tabs.update(vt.id, { autoDiscardable: false }).catch(() => {});
    for (let i = 0; i < 30 && !shot; i++) {
      await E.sleep(1000);
      const r = await chrome.scripting.executeScript({ target: { tabId: vt.id, allFrames: true }, func: async () => {
        const big = (w, h) => w * h >= 300 * 300;
        const cv = [...document.querySelectorAll("canvas")].filter((c) => big(c.width, c.height)).sort((a, b) => b.width * b.height - a.width * a.height)[0];
        const toJpeg = (src, w, h) => { const k = Math.min(1, 2200 / Math.max(w, h)); const c = document.createElement("canvas"); c.width = Math.round(w * k); c.height = Math.round(h * k); const x = c.getContext("2d"); x.fillStyle = "#000"; x.fillRect(0, 0, c.width, c.height); x.drawImage(src, 0, 0, c.width, c.height); return c.toDataURL("image/jpeg", 0.88); };
        try {
          const im = [...document.images].filter((i) => big(i.naturalWidth, i.naturalHeight) && !/logo|evorad\.png|ikh\.png/i.test(i.src)).sort((a, b) => b.naturalWidth * b.naturalHeight - a.naturalWidth * a.naturalHeight)[0];
          if (im) return { how: "img " + im.naturalWidth + "x" + im.naturalHeight, data: toJpeg(im, im.naturalWidth, im.naturalHeight) };
          if (cv) { const d = cv.getContext("2d"); if (d) { const px = d.getImageData(cv.width >> 1, cv.height >> 1, 1, 1).data; if (px[0] + px[1] + px[2] === 0 && !cv.__efbotWaited) { cv.__efbotWaited = 1; return null; } } return { how: "canvas " + cv.width + "x" + cv.height, data: toJpeg(cv, cv.width, cv.height) }; }
        } catch (e) { return { err: e.message }; }
        return null;
      } }).catch((e) => [{ result: { err: e.message } }]);
      const hit = (r || []).map((x) => x && x.result).find((x) => x && x.data);
      if (hit) { shot = hit.data; how = hit.how; }
    }
    if (p.probeViewer || !shot) {
      const vr = await chrome.scripting.executeScript({ target: { tabId: vt.id, allFrames: true }, func: async () => {
        const strip = (u) => { try { const x = new URL(u, location.href); return x.origin + x.pathname + (x.search ? "?" + [...x.searchParams.keys()].join("&") : ""); } catch (e) { return ""; } };
        const cv = [...document.querySelectorAll("canvas")].map((c) => { let ctx = "?"; try { ctx = c.getContext("webgl2") ? "webgl2" : c.getContext("webgl") ? "webgl" : "2d"; } catch (e) { ctx = "err"; } return c.width + "x" + c.height + ":" + ctx + ":" + (c.id || c.className || ""); });
        const res = performance.getEntriesByType("resource").map((e) => strip(e.name) + " [" + e.initiatorType + " " + Math.round(e.transferSize / 1024) + "KB]").filter((u) => !/\.css|\.woff|fonts|i18n/i.test(u));
        const src = {};
        for (const sc of [...document.scripts].filter((x) => x.src && !/jquery|bootstrap|moment/i.test(x.src)).slice(0, 8)) {
          try { const t = await (await fetch(sc.src, { credentials: "include" })).text(); src[strip(sc.src)] = t.split(/\n/).map((l, i) => [i + 1, l.trim()]).filter(([, l]) => /api\/|getImage|getInstance|wado|dicom|\.jpe?g|\.png|imageNames|drawImage|src\s*=|url\s*:|ajax|fetch\(|XMLHttpRequest|cornerstone|loadImage/i.test(l)).slice(0, 50).map(([i, l]) => i + ": " + l.slice(0, 200)); } catch (e) { src[sc.src] = ["σφάλμα " + e.message]; }
        }
        return { url: strip(location.href), title: document.title, canvas: cv, imgs: [...document.images].map((i) => strip(i.currentSrc || i.src) + " " + i.naturalWidth + "x" + i.naturalHeight).slice(0, 12), iframes: [...document.querySelectorAll("iframe,embed,object,applet")].map((f) => f.tagName + " " + strip(f.src || f.data || f.code || "")).slice(0, 6), res: res.slice(-40), src, text: (document.body && document.body.innerText || "").replace(/\s+/g, " ").replace(/\d{5,}/g, "#").slice(0, 300) };
      } }).then((r) => r.map((x) => x && x.result)).catch((e) => [{ err: e.message }]);
      viewerProbe = vr;
    }
    chrome.tabs.remove(vt.id).catch(() => {});
  }
  if (!shot && s0.thumb) { shot = "data:image/png;base64," + s0.thumb.replace(/^data:[^,]+,/, ""); how = "μόνο μικρογραφία 128×128 (ο viewer δεν έδωσε εικόνα)"; }
  const vpSmall = viewerProbe ? JSON.stringify(viewerProbe).slice(0, 12000) : "";
  if (!shot) return { status: "failed", note: "Evorad: ο viewer δεν έδωσε εικόνα" };
  // κρυπτογράφηση για το κινητό
  const mime = /^data:([^;]+);/.exec(shot)[1], bytes = Uint8Array.from(atob(shot.split(",")[1]), (c) => c.charCodeAt(0));
  const pub = await crypto.subtle.importKey("jwk", { kty: "RSA", n: p.pub.n, e: p.pub.e, alg: "RSA-OAEP-256", ext: true }, { name: "RSA-OAEP", hash: "SHA-256" }, false, ["encrypt"]);
  const aes = await crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, true, ["encrypt"]);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, aes, bytes));
  const wk = new Uint8Array(await crypto.subtle.encrypt({ name: "RSA-OAEP" }, pub, new Uint8Array(await crypto.subtle.exportKey("raw", aes))));
  const b64 = (u) => { let s = ""; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); };
  const date = String(ex.date || "").slice(0, 10).split("-").reverse().join("/");
  const meta = { date, type: ex.mod, desc: s0.prot || ex.desc || "", verify, how, more: xr.length - 1, old: !!old };
  if (p.probeViewer) return { status: "done", note: "🔎 viewer: " + how, result: { viewer: viewerProbe, series: ser.map((x) => ({ n: x.n, prot: x.prot })), at: Date.now() } };
  if (viewerProbe) chrome.storage.local.set({ efbotViewerProbe: { at: Date.now(), v: viewerProbe } }).catch(() => {});
  if (vpSmall) chrome.storage.session.set({ efbotVpLast: vpSmall }).catch(() => {});
  return { status: "done", note: "🫁 " + date + (meta.old ? " ⚠ πριν την εισαγωγή" : "") + " " + ex.mod + (meta.desc ? " " + meta.desc : "") + " · " + (verify.id ? (verify.weak ? "≈ " : "✓ ") + verify.id : "≈ όνομα") + " · " + how + " · κρυπτογραφημένη για τη συσκευή που τη ζήτησε", result: { enc: { wk: b64(wk), iv: b64(iv), ct: b64(ct) }, mime, meta, vp: vpSmall || undefined, at: Date.now() } };
};
// 📞 Κατάλογος «Κλήσης για εκτίμηση»: ανοίγει τη «Νέα κλήση για εκτίμηση» ενός ασθενή, διαβάζει ΟΛΕΣ τις ειδικότητες
// (autocomplete appForm:doctorSpec) και, για κάθε μία, τα υποτμήματα του πεδίου που εμφανίζεται μετά την επιλογή.
// ΚΑΜΙΑ «Υποβολή αιτήματος»: μόνο επιλογές σε μη αποθηκευμένη φόρμα, που χάνονται όταν φύγει από τη σελίδα.
JOB_RUNNERS.consultcat = async (job) => {
  const p = job.payload || {};
  const tab = await bgEmrTab();
  if (!tab || tab.err) return { status: "failed", note: tab?.err || "δεν άνοιξε ο φάκελος" };
  const lg = await bgEnsureLogin(tab.id);
  if (!lg.ok) return { status: "failed", note: lg.err };
  const { efbot: st } = await chrome.storage.local.get("efbot");
  try { await bgOpenPatient(tab, job.name, st); }
  catch (e) { return { status: "failed", note: "άνοιγμα ασθενή: " + e.message }; }
  bgMark("άνοιγμα ασθενή"); await bgSettle(tab.id, 1200);
  if (!(await emrClickText(tab.id, /^κλ[ηή]σ[ηή]\s+για\s+εκτ[ιί]μησ[ηή]$/))) return { status: "failed", note: "δεν βρέθηκε «Κλήση για εκτίμηση»" };
  if (!(await emrClickText(tab.id, /^ν[εέ]α\s+κλ[ηή]σ[ηή]\s+για\s+εκτ[ιί]μησ[ηή]$/))) return { status: "failed", note: "δεν βρέθηκε «Νέα κλήση για εκτίμηση»" };
  await E.sleep(1500);
  const X = async (func, args = []) => { const r = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: "MAIN", args, func }).catch((e) => [{ result: { err: e.message } }]); return r[0] && r[0].result; };
  // λίστα ειδικοτήτων: κουμπί ▼ του autocomplete → li του panel
  const listAc = async (base) => {
    await X((base) => { const b = document.getElementById(base + "_button"); if (!b) return; ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach((t) => b.dispatchEvent(new (t.startsWith("pointer") ? PointerEvent : MouseEvent)(t, { bubbles: true, cancelable: true, view: window }))); }, [base]);
    for (let i = 0; i < 16; i++) {
      await E.sleep(400);
      const r = await X((base) => { const pn = document.getElementById(base + "_panel"); if (!pn || pn.offsetParent === null && getComputedStyle(pn).display === "none") return null;
        const li = [...pn.querySelectorAll("li")].map((l) => (l.getAttribute("data-item-label") || l.innerText || "").replace(/\s+/g, " ").trim()).filter(Boolean); return li.length ? li : null; }, [base]);
      if (r) return r;
    }
    return [];
  };
  const pickAc = async (base, label) => X((base, label) => {
    const pn = document.getElementById(base + "_panel"); if (!pn) return false;
    const li = [...pn.querySelectorAll("li")].find((l) => (l.getAttribute("data-item-label") || l.innerText || "").replace(/\s+/g, " ").trim() === label);
    if (!li) return false;
    ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach((t) => li.dispatchEvent(new (t.startsWith("pointer") ? PointerEvent : MouseEvent)(t, { bubbles: true, cancelable: true, view: window })));
    return true;
  }, [base, label]);
  const closeAc = () => X(() => { document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })); document.querySelectorAll(".ui-autocomplete-panel").forEach((p) => (p.style.display = "none")); });
  // πεδία (εκτός παραπέμποντα/ειδικότητας) που εμφανίζονται μετά την επιλογή ειδικότητας
  const otherFields = () => X(() => {
    const vis = (e) => e && e.getBoundingClientRect().width > 0;
    const lab = (e) => { const l = e.id && document.querySelector('label[for="' + CSS.escape(e.id) + '"],label[for="' + CSS.escape(e.id.replace(/_input$/, "")) + '"]'); if (l) return l.innerText.trim(); const td = e.closest("td"); return td && td.previousElementSibling ? td.previousElementSibling.innerText.trim() : ""; };
    const out = [];
    for (const w of document.querySelectorAll(".ui-selectonemenu, .ui-autocomplete, select")) {
      const id = w.id || ""; if (!/^appForm:/.test(id) || /referringDoctor|doctorSpec|patientsTable|j_id\d+$/.test(id) || !vis(w)) continue;
      if (w.tagName === "SELECT" && w.closest(".ui-selectonemenu")) continue;
      const kind = w.classList.contains("ui-selectonemenu") ? "som" : w.classList.contains("ui-autocomplete") ? "ac" : "sel";
      const sel = kind === "som" ? w.querySelector("select") : kind === "sel" ? w : null;
      const opts = sel ? [...sel.options].map((o) => o.text.replace(/\s+/g, " ").trim()).filter((t) => t && !/^-+|επιλέξτε|επιλογή$/i.test(t)) : null;
      out.push({ id, kind, label: lab(w.querySelector("input") || w).slice(0, 60), opts });
    }
    return out;
  });
  const before = JSON.stringify(((await otherFields()) || []).map((f) => f.id));
  const specs = await listAc("appForm:doctorSpec"); await closeAc();
  if (!specs.length) return { status: "failed", note: "δεν διαβάστηκε η λίστα ειδικοτήτων" };
  const only = p.only ? new RegExp(p.only, "i") : null;
  const out = []; let field = null, prevSig = null;
  const specVal = () => X(() => { const i = document.getElementById("appForm:doctorSpec_input"); return i ? i.value.replace(/\s+/g, " ").trim() : ""; });
  const readDeps = async () => {
    const f = ((await otherFields()) || []).filter((x) => !before.includes('"' + x.id + '"') || /τμ[ηή]μα|υποτμ|μον[αά]δα|ιατρε[ιί]ο/i.test(x.label));
    const t = f.find((x) => /τμ[ηή]μα|υποτμ|μον[αά]δα|ιατρε[ιί]ο/i.test(x.label)) || f[0];
    if (!t) return null;
    if (t.kind === "ac") { const l = await listAc(t.id.replace(/_input$/, "")); await closeAc(); return l.length ? { t, l } : null; }
    return t.opts && t.opts.length ? { t, l: t.opts } : null;
  };
  { const r0 = await readDeps(); if (r0) prevSig = JSON.stringify(r0.l); }   // η αρχική (αφιλτράριστη) λίστα δεν μετρά
  for (const sp of specs.slice(0, 150)) {
    if (only && !only.test(sp)) continue;
    await listAc("appForm:doctorSpec");
    if (!(await pickAc("appForm:doctorSpec", sp))) { out.push({ spec: sp, err: "επιλογή" }); await closeAc(); continue; }
    // Περιμένουμε: (1) η ειδικότητα να γραφτεί στο πεδίο, (2) η λίστα τμημάτων να ΑΛΛΑΞΕΙ από την προηγούμενη και
    // (3) να μείνει ίδια σε δύο διαδοχικές αναγνώσεις. Αν δεν αλλάξει σε 12″, την κρατάμε σημειωμένη ως «ίδια».
    let deps = null, last = null, same = 0, flag = "";
    for (let i = 0; i < 24; i++) {
      await E.sleep(500);
      if ((await specVal()) !== sp) continue;
      const r = await readDeps(); if (!r) continue;
      const sig = JSON.stringify(r.l);
      if (sig === last) same++; else { same = 0; last = sig; }
      if (same >= 1 && (sig !== prevSig || i >= 22)) { deps = r.l; field = { id: r.t.id, kind: r.t.kind, label: r.t.label }; if (sig === prevSig) flag = "ίδια με την προηγούμενη"; break; }
    }
    if (deps) prevSig = JSON.stringify(deps);
    out.push(Object.assign({ spec: sp, deps: deps || [] }, flag ? { warn: flag } : {}, deps ? {} : { err: "δεν διαβάστηκαν" }));
  }
  const nDeps = out.reduce((s, x) => s + (x.deps ? x.deps.length : 0), 0);
  return { status: "done", note: `📞 κατάλογος εκτιμήσεων: ${out.length} ειδικότητες · ${nDeps} υποτμήματα` + (field ? ` · πεδίο «${field.label || field.id}»` : " · ⚠ δεν βρέθηκε πεδίο τμήματος"), result: { specs: out, field, at: Date.now() } };
};
// ===== 📞 Κλήση για εκτίμηση: συμπλήρωση της φόρμας στο ΝΠΣ (ΧΩΡΙΣ «Υποβολή αιτήματος» — την πατά γιατρός) =====
// payload: {spec:"ΠΝΕΥΜΟΝΟΛΟΓΟΣ-ΦΥΜΑΤΙΟΛΟΓΟΣ", dept:"3432 - …", text:"κλινικές πληροφορίες", referrer:"επώνυμο θεράποντα"}
async function pfExec(tabId, func, args = []) { const r = await chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", args, func }).catch((e) => [{ result: { err: e.message } }]); return r[0] && r[0].result; }
async function pfAcOpen(tabId, base) {
  await pfExec(tabId, (base) => { const b = document.getElementById(base + "_button"); if (!b) return; ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach((t) => b.dispatchEvent(new (t.startsWith("pointer") ? PointerEvent : MouseEvent)(t, { bubbles: true, cancelable: true, view: window }))); }, [base]);
  for (let i = 0; i < 16; i++) {
    await E.sleep(400);
    const n = await pfExec(tabId, (base) => { const pn = document.getElementById(base + "_panel"); return pn ? pn.querySelectorAll("li").length : 0; }, [base]);
    if (n) return n;
  }
  return 0;
}
// επιλογή γραμμής autocomplete: mode "eq" = ίδιο κείμενο, "has" = περιέχει όλες τις λέξεις (χωρίς τόνους/κεφαλαία)
async function pfAcPick(tabId, base, want, mode) {
  return pfExec(tabId, (base, want, mode) => {
    const nz = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().replace(/\s+/g, " ").trim();
    const pn = document.getElementById(base + "_panel"); if (!pn) return { err: "panel" };
    const lis = [...pn.querySelectorAll("li")].map((l) => ({ l, t: (l.getAttribute("data-item-label") || l.innerText || "").replace(/\s+/g, " ").trim() }));
    const w = nz(want), words = w.split(" ").filter((x) => x.length >= 3);
    let hit;
    if (mode === "name") {
      // ονοματεπώνυμο: κάθε λέξη που δόθηκε (≥3 γράμματα) πρέπει να είναι αρχή μιας λέξης του ιατρού (Δουρούμη/Δουρούμης → ΔΟΥΡΟΥΜΗΣ).
      // Αν ταιριάζουν πολλοί, ΔΕΝ μαντεύει.
      const stem = (k) => k.length > 4 ? k.replace(/[ΣΗΑΟ]$/, "") : k;
      const hits = lis.filter((x) => { const ws = nz(x.t).split(/[\s,.-]+/); return words.length && words.every((k) => ws.some((y) => y.startsWith(stem(k)))); });
      if (hits.length > 1) { const ex = hits.filter((x) => nz(x.t).split(/[\s,.-]+/)[0].startsWith(stem(words[0]))); if (ex.length === 1) hit = ex[0]; else return { err: "ταιριάζουν " + hits.length + " ιατροί για «" + want + "»: " + hits.slice(0, 4).map((x) => x.t).join(" | "), n: lis.length }; }
      else hit = hits[0];
    } else hit = mode === "eq" ? lis.find((x) => nz(x.t) === w) : lis.find((x) => words.length && words.every((k) => nz(x.t).includes(k)));
    if (!hit) return { err: "δεν βρέθηκε «" + want + "»", n: lis.length };
    ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach((t) => hit.l.dispatchEvent(new (t.startsWith("pointer") ? PointerEvent : MouseEvent)(t, { bubbles: true, cancelable: true, view: window })));
    return { ok: true, label: hit.t };
  }, [base, want, mode || "eq"]);
}
const JOB_CONSULT_INNER = async (job) => {
  const p = job.payload || {};
  if (!p.spec) return { status: "failed", note: "λείπει η ειδικότητα" };
  const tab = await bgEmrTab();
  if (!tab || tab.err) return { status: "failed", note: tab?.err || "δεν άνοιξε ο φάκελος" };
  const lg = await bgEnsureLogin(tab.id);
  if (!lg.ok) return { status: "failed", note: lg.err };
  const { efbot: st } = await chrome.storage.local.get("efbot");
  try { await bgOpenPatient(tab, job.name, st); }
  catch (e) { return { status: "failed", note: "άνοιγμα ασθενή: " + e.message }; }
  bgMark("άνοιγμα ασθενή"); await bgSettle(tab.id, 1200);
  if (!(await emrClickText(tab.id, /^κλ[ηή]σ[ηή]\s+για\s+εκτ[ιί]μησ[ηή]$/))) return { status: "failed", note: "δεν βρέθηκε «Κλήση για εκτίμηση» στο μενού του ασθενή" };
  if (!(await emrClickText(tab.id, /^ν[εέ]α\s+κλ[ηή]σ[ηή]\s+για\s+εκτ[ιί]μησ[ηή]$/))) return { status: "failed", note: "δεν άνοιξε η «Νέα κλήση για εκτίμηση»" };
  await bgSettle(tab.id, 1500);
  const out = [], warn = [];
  // 1) Παραπέμπων ιατρός = ο θεράπων, με ΠΛΗΡΕΣ όνομα: πρώτα η αντιστοίχιση κωδικού → ονοματεπώνυμο του bot (ίδια με το εξιτήριο),
  //    αλλιώς ό,τι έστειλε το Παραδόχαρτο. Επιλέγεται από τη λίστα του ΝΠΣ μόνο αν ταιριάζει ΕΝΑΣ ιατρός (το πεδίο παίρνει το πλήρες όνομα της λίστας).
  const refWant = (!p.referrerEdited && bgMapTherapist(st?.settings, p.therapist)) || p.referrer || bgMapTherapist(st?.settings, p.therapist) || "";
  if (refWant) {
    const n = await pfAcOpen(tab.id, "appForm:referringDoctor");
    const r = n ? await pfAcPick(tab.id, "appForm:referringDoctor", refWant, "name") : { err: "δεν άνοιξε η λίστα ιατρών" };
    if (r && r.ok) out.push("παραπέμπων: " + r.label); else warn.push("παραπέμπων: " + (r && r.err || "—"));
    await bgSettle(tab.id, 800);
  } else warn.push("παραπέμπων: δεν δόθηκε θεράπων");
  // 2) Ειδικότητα
  const n2 = await pfAcOpen(tab.id, "appForm:doctorSpec");
  const r2 = n2 ? await pfAcPick(tab.id, "appForm:doctorSpec", p.spec, "eq") : { err: "δεν άνοιξε η λίστα ειδικοτήτων" };
  if (!r2 || !r2.ok) return { status: "failed", note: "ειδικότητα: " + (r2 && r2.err || "—") };
  out.push("ειδικότητα: " + r2.label);
  // 3) Τμήμα: περιμένουμε να γεμίσει η λίστα της ειδικότητας και επιλέγουμε το τμήμα από τις ρυθμίσεις
  if (p.dept) {
    let r3 = null;
    for (let i = 0; i < 20 && !(r3 && r3.ok); i++) {
      await E.sleep(600);
      r3 = await pfExec(tab.id, (dept) => {
        const nz = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().replace(/\s+/g, " ").trim();
        const w = document.getElementById("appForm:departmentTo"); if (!w) return { err: "δεν βρέθηκε το πεδίο τμήματος" };
        const sel = w.querySelector("select"); if (!sel) return { err: "χωρίς λίστα" };
        const o = [...sel.options].find((x) => nz(x.text) === nz(dept)) || [...sel.options].find((x) => nz(x.text).startsWith(nz(dept).split(" ")[0] + " "));
        if (!o) return { err: "το τμήμα «" + dept + "» δεν είναι (ακόμα) στη λίστα", n: sel.options.length };
        // PrimeFaces selectOneMenu: άνοιγμα και κλικ στη γραμμή (ώστε να τρέξει και το ajax της επιλογής)
        const trig = w.querySelector(".ui-selectonemenu-trigger") || w;
        ["mousedown", "mouseup", "click"].forEach((t) => trig.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window })));
        const pn = document.getElementById("appForm:departmentTo_panel") || document.getElementById("appForm:departmentTo_items")?.closest(".ui-selectonemenu-panel");
        const li = pn && [...pn.querySelectorAll("li")].find((x) => nz(x.getAttribute("data-label") || x.innerText) === nz(o.text));
        if (li) ["mousedown", "mouseup", "click"].forEach((t) => li.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window })));
        else { sel.value = o.value; sel.dispatchEvent(new Event("change", { bubbles: true })); const lb = w.querySelector(".ui-selectonemenu-label"); if (lb) lb.textContent = o.text; }
        return { ok: true, label: o.text };
      }, [p.dept]);
    }
    if (r3 && r3.ok) out.push("τμήμα: " + r3.label); else warn.push("τμήμα: " + (r3 && r3.err || "—"));
    await bgSettle(tab.id, 800);
  } else warn.push("τμήμα: δεν έχει οριστεί στις ρυθμίσεις (📞 Κλήσεις για εκτίμηση)");
  // 4) Κλινικές πληροφορίες
  if (p.text) {
    const r4 = await pfExec(tab.id, (txt) => { const t = document.getElementById("appForm:clinicalInfo"); if (!t) return { err: "δεν βρέθηκε το πεδίο" }; t.focus(); t.value = txt; ["input", "change", "keyup", "blur"].forEach((e) => t.dispatchEvent(new Event(e, { bubbles: true }))); return { ok: true, n: t.value.length }; }, [String(p.text).slice(0, 3900)]);
    if (r4 && r4.ok) out.push("κλινικές πληροφορίες: " + r4.n + " χαρακτήρες"); else warn.push("κλινικές πληροφορίες: " + (r4 && r4.err || "—"));
  } else warn.push("κλινικές πληροφορίες: κενές");
  // έλεγχος: τι γράφει τελικά η φόρμα
  const chk = await pfExec(tab.id, () => ({ ref: document.getElementById("appForm:referringDoctor_input")?.value || "", spec: document.getElementById("appForm:doctorSpec_input")?.value || "", dept: document.querySelector("#appForm\\:departmentTo .ui-selectonemenu-label")?.innerText || "", date: document.getElementById("appForm:requestCreationDate_input")?.value || "" }));
  // ΔΕΝ φέρνουμε το παράθυρο του bot μπροστά: κάποιος μπορεί να δουλεύει στον υπολογιστή (και να το κλείσει)
  try { await chrome.tabs.update(tab.id, { active: true }); } catch (e) {}
  const note = "📞 Η φόρμα συμπληρώθηκε — ΔΕΝ υποβλήθηκε. Ελέγξτε στον υπολογιστή και πατήστε «Υποβολή αιτήματος».\n" + out.join(" · ") + (warn.length ? "\n⚠ " + warn.join(" · ") : "");
  return { status: "done", note, result: { check: chk, warn }, push: ["📞 Κλήση για εκτίμηση έτοιμη", (job.name || "") + " · " + p.spec + (warn.length ? " · ⚠ " + warn.length : "") + " — λείπει μόνο η «Υποβολή αιτήματος»"] };
};
// ===== 🧾 Παραγγελία εξετάσεων στο Medilabi (μέσα στον φάκελο) — ΧΩΡΙΣ «Καταχώρηση» (την πατά γιατρός) =====
// payload: {tests:["Γενική αίματος",…], packs:[{name, medilabi:"ΜΙΚΡΟ", tests}], aliases:{όνομα: "όρος αναζήτησης Medilabi"}}
// Για κάθε εξέταση: αναζήτηση → τικ στο σωστό αποτέλεσμα → «προσθήκη» στη λίστα. Τα προφίλ Medilabi πατιούνται όπως είναι.
const MED_ALIAS = { "α/α κοιλιας f": "ΚΟΙΛΙΑΣ|Α/Α ΚΟΙΛΙΑΣ F", "α/α κοιλιας p": "ΚΟΙΛΙΑΣ|Α/Α ΚΟΙΛΙΑΣ P", "α/α θωρακος f": "ΘΩΡΑΚΟΣ|Α/Α ΘΩΡΑΚΟΣ F", "α/α θωρακος p": "ΘΩΡΑΚΟΣ|Α/Α ΘΩΡΑΚΟΣ P", "ct θωρακος": "ΘΩΡΑΚΟΣ|CT ΘΩΡΑΚΟΣ", "psa": "PSA|Ειδικό προστατικό αντιγόνο ( PSA )", "psa ολικο": "PSA|Ειδικό προστατικό αντιγόνο ( PSA )", "free psa": "PSA|free - PSA", "ελευθερο psa": "PSA|free - PSA", "λογος psa": "PSA|Ratio PSA (%)", "γενικη αιματος": "ΑΙΜΟΔΙΑΓΡΑΜΜΑ", "αιμοδιαγραμμα": "ΑΙΜΟΔΙΑΓΡΑΜΜΑ", "ουρια": "ΟΥΡΙΑ", "κρεατινινη": "ΚΡΕΑΤΙΝΙΝΗ", "k": "ΚΑΛΙΟ", "na": "ΝΑΤΡΙΟ", "crp": "CRP", "pt - inr": "INR|INR", "pt-inr": "INR|INR", "inr": "INR|INR", "aptt": "APTT", "γενικη ουρων": "ΓΕΝΙΚΗ ΕΞΕΤΑΣΗ ΟΥΡΩΝ", "καλλιεργεια ουρων": "ΚΑΛΛΙΕΡΓΕΙΑ ΟΥΡΩΝ", "καλλιεργεια αιματος": "ΑΙΜΟΚΑΛΛΙΕΡΓΕΙΑ", "ομαδα - διασταυρωση": "ΟΜΑΔΑ", "ca": "ΑΣΒΕΣΤΙΟ ΟΛΙΚΟ", "ασβεστιο": "ΑΣΒΕΣΤΙΟ ΟΛΙΚΟ", "mg": "ΜΑΓΝΗΣΙΟ", "p": "ΦΩΣΦΟΡ", "γλυκοζη": "ΓΛΥΚΟΖΗ|ΓΛΥΚΟΖΗ (GLU)" };
const nzG = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/\s+/g, " ").trim();
async function medFrameExec(tabId, func, args = []) {
  const r = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, world: "MAIN", args, func }).catch(() => []);
  return (r || []).map((x) => x && x.result).filter((x) => x != null)[0];
}
async function medSig(tabId) {
  return medFrameExec(tabId, () => { if (!/OrderTests/i.test(location.pathname)) return null; return document.body ? document.body.innerText.length + ":" + document.querySelectorAll("input").length + ":" + (document.forms[0] && document.forms[0].__VIEWSTATE ? document.forms[0].__VIEWSTATE.value.length : 0) : null; });
}
async function medPostback(tabId, target, term) {
  const before = await medSig(tabId);
  const r = await medFrameExec(tabId, (target, term) => {
    if (!/OrderTests/i.test(location.pathname)) return null;
    if (/btnDone/i.test(target)) return "blocked";
    if (term != null) { const i = document.getElementById("ctl00_ContentPage_txtSearch"); if (!i) return "no-search"; i.value = term; }
    if (typeof window.__doPostBack !== "function") return "no-postback";
    setTimeout(() => window.__doPostBack(target, ""), 0); return "ok";
  }, [target, term == null ? null : term]);
  if (r !== "ok") return r || "no-frame";
  for (let i = 0; i < 100; i++) { await E.sleep(150); const now = await medSig(tabId); if (now && now !== before) { await bgSettle(tabId, 900); return "ok"; } }
  return "nochange";
}

// ⏱ Χρονομέτρηση/χαρτογράφηση δικτύου του ΝΠΣ (μόνο ανάγνωση): ποιες σελίδες/αιτήματα φορτώθηκαν και πόσο κράτησαν.
// Σκοπός: να φανεί πού χάνεται ο χρόνος και ποια βήματα μπορούν να γίνουν με απευθείας αίτημα αντί για «κλικ».
async function emrNetSnap(tabId, t0) {
  try {
    const r = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, args: [t0 || 0], func: (t0) => {
      const strip = (u) => { try { const x = new URL(u); return x.pathname.replace(/\d{4,}/g, "•") + (x.search ? "?" + [...x.searchParams.keys()].join("&") : ""); } catch (e) { return ""; } };
      const nav = performance.getEntriesByType("navigation")[0];
      const base = performance.timeOrigin;
      const res = performance.getEntriesByType("resource").filter((e) => base + e.startTime >= t0 && /xmlhttprequest|fetch|iframe|frame|other|navigation/.test(e.initiatorType) || /\.aspx|\/api\/|\.ashx|\.asmx|\.svc/i.test(e.name)).filter((e) => base + e.startTime >= t0)
        .map((e) => e.initiatorType.slice(0, 5) + " " + strip(e.name) + " " + Math.round(e.duration) + "ms").slice(-40);
      return { doc: strip(location.href) + (nav ? " (" + Math.round(nav.duration) + "ms)" : ""), res };
    } });
    return (r || []).map((x) => x && x.result).filter(Boolean).slice(0, 8);
  } catch (e) { return [{ err: e.message }]; }
}
// 🧾 Άνοιγμα της φόρμας παραγγελίας του Medilabi για τον ασθενή (ΝΠΣ → «Παραγγελία Εξετάσεων»). Επιστρέφει {tab, otab}
// ή αποτέλεσμα αποτυχίας ({status, note}). Χρησιμοποιείται από την παραγγελία και από την «προετοιμασία» (orderprep).
async function orderOpenForm(job) {
  const tab = await bgEmrTab();
  if (!tab || tab.err) return { status: "failed", note: tab?.err || "δεν άνοιξε ο φάκελος" };
  const lg = await bgEnsureLogin(tab.id);
  if (!lg.ok) return { status: "failed", note: lg.err };
  const { efbot: st } = await chrome.storage.local.get("efbot");
  try { await bgOpenPatient(tab, job.name, st); }
  catch (e) { return { status: "failed", note: "άνοιγμα ασθενή: " + e.message }; }
  bgMark("άνοιγμα ασθενή");
  // Καταγραφή της διεύθυνσης με την οποία το ΝΠΣ ανοίγει το Medilabi στο πλαίσιο (RedirectRequest.aspx…): στο ανώνυμο παράθυρο
  // το Chrome μπλοκάρει τα cookies του πλαισίου (άλλος διακομιστής) → το Medilabi πέφτει στη Login.aspx. Τότε η ίδια διεύθυνση
  // ανοίγει σε ΔΙΚΗ ΤΗΣ καρτέλα (ίδιο παράθυρο), όπου τα cookies κρατιούνται.
  const medNav = [];
  const onNav = (d) => { if (d.tabId === tab.id && d.frameId !== 0 && /medilabi/i.test(d.url) && !/Login\.aspx/i.test(d.url)) medNav.push(d.url); };
  chrome.webNavigation.onBeforeNavigate.addListener(onNav);
  let clicked;
  try { clicked = await emrClickText(tab.id, /^παραγγελ[ιί]α\s+εξετ|^παραγγελ[ιί]ες\s+εξετ/, true); }
  catch (e) { chrome.webNavigation.onBeforeNavigate.removeListener(onNav); throw e; }
  if (!clicked) { chrome.webNavigation.onBeforeNavigate.removeListener(onNav); return { status: "failed", note: "δεν βρέθηκε «Παραγγελία Εξετάσεων»" }; }
  // η φόρμα του Medilabi ανοίγει σε πλαίσιο του φακέλου — ή (σε κάποιες ρυθμίσεις) σε νέο παράθυρο/καρτέλα
  let ready = false, otab = tab.id, topTried = "";
  const tabs0 = new Set((await chrome.tabs.query({}).catch(() => [])).map((t) => t.id));
  const isForm = () => (/OrderTests/i.test(location.pathname) && document.getElementById("ctl00_ContentPage_txtSearch")) ? 1 : null;
  const onLogin = async (tid) => ((await chrome.scripting.executeScript({ target: { tabId: tid, allFrames: true }, func: () => /medilabi/i.test(location.pathname) && /Login\.aspx/i.test(location.pathname) }).catch(() => [])) || []).some((x) => x && x.result);
  try {
   // Το Medilabi μερικές φορές κολλά στο RedirectRequest.aspx (χωρίς φόρμα, χωρίς σύνδεση): μία αυτόματη ξαναπροσπάθεια
   for (let attempt = 0; attempt < 2 && !ready; attempt++) {
    if (attempt) {
      if (topTried || otab !== tab.id) break;
      const cleaned = await bgEmrClean(tab.id); medNav.length = 0;
      // ⛔ 8/11: μετά το καθάρισμα (ξαναφόρτωμα) ο «τρέχων ασθενής» του ΝΠΣ μπορεί να είναι ΑΛΛΟΣ (κοινός λογαριασμός) → ξανά άνοιγμα ΤΟΥ ασθενή πριν το κλικ
      if (cleaned) { try { await bgOpenPatient(tab, job.name, st); bgMark("ξανά άνοιγμα ασθενή"); } catch (e) { break; } }
      if (!(await emrClickText(tab.id, /^παραγγελ[ιί]α\s+εξετ|^παραγγελ[ιί]ες\s+εξετ/, true))) break;
      bgMark("ξανά άνοιγμα φόρμας (κόλλησε)");
    }
    for (let i = 0; i < (attempt ? 130 : 90) && !ready; i++) {
      await new Promise((r) => setTimeout(r, 150));   // ⚡ έλεγχος φόρμας ανά 150ms (ίδιο όριο ~20″)
      if (jobAbortId) throw new Error("ακυρώθηκε από το Παραδόχαρτο");
      ready = !!(await medFrameExec(otab, isForm));
      if (ready) break;
      // ⚡ κόλλημα στο RedirectRequest.aspx (φορτωμένο, χωρίς φόρμα): ξαναπροσπάθεια σε ~3″ αντί για ~13″ αναμονής
      if (!attempt && i >= 20 && i % 4 === 0 && otab === tab.id && !topTried) {
        const stuck = ((await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: () => /RedirectRequest\.aspx/i.test(location.pathname) && document.readyState === "complete" && !document.forms.length ? (performance.now() > 2500 ? 1 : 0) : 0 }).catch(() => [])) || []).some((x) => x && x.result === 1);
        if (stuck) { bgMark("Medilabi κόλλησε στο RedirectRequest"); break; }
      }
      // 8/11: μετά από ~6″ χωρίς φόρμα (όχι RedirectRequest): καταγραφή πλαισίων + νέα προσπάθεια (πριν: αναμονή ως 13,5″)
      if (!attempt && i === 40 && otab === tab.id && !topTried) {
        const fr = ((await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: () => location.host.replace(/^www\./, "").slice(0, 14) + location.pathname.replace(/\d{4,}/g, "•").slice(-34) + ":" + document.readyState.slice(0, 4) + (document.forms.length ? "f" : "") }).catch(() => [])) || []).map((x) => x && x.result).filter((x) => x && /medilabi|aspx/i.test(x));
        bgMark("χωρίς φόρμα 6″ [" + fr.join(" ").slice(0, 60) + "]"); break;
      }
      if (!topTried && medNav.length && i >= 6 && await onLogin(tab.id)) {
        topTried = medNav[0];
        const t2 = await chrome.tabs.create({ windowId: tab.windowId, url: topTried, active: false }).catch(() => null);
        if (t2) { otab = t2.id; orderTabSeen.set(t2.id, Date.now()); chrome.storage.session.set({ efbotFormOpen: { tabId: t2.id, at: Date.now(), early: 1, job: job.id } }).catch(() => {}); }
        continue;
      }
      if (i % 8 === 7) {
        const nt = (await chrome.tabs.query({}).catch(() => [])).find((t) => !tabs0.has(t.id) && t.id !== otab && /OrderTests|Medilabi/i.test(t.url || t.pendingUrl || ""));
        if (nt) { ready = !!(await medFrameExec(nt.id, isForm)); if (ready) otab = nt.id; }
      }
    }
   }
  } finally { chrome.webNavigation.onBeforeNavigate.removeListener(onNav); }
  if (!ready && topTried && otab !== tab.id) {
    const lg2 = await onLogin(otab);
    chrome.tabs.remove(otab).catch(() => {});
    return { status: "failed", note: "🔬 το Medilabi ζητά σύνδεση" + (lg2 ? " και σε δική του καρτέλα (η διεύθυνση του ΝΠΣ ισχύει μία φορά ή θέλει κωδικό Medilabi)" : " · η καρτέλα δεν έφτασε στη φόρμα") + " · πλαίσιο: " + topTried.replace(/\?.*$/, "").replace(/^https?:\/\/[^/]+/, "") };
  }
  if (!ready) {
    // διάγνωση: τι υπάρχει στη σελίδα (πλαίσια, διευθύνσεις, μήνυμα) — για να διορθωθεί στοχευμένα
    const fr = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: () => location.pathname.replace(/\d{4,}/g, "•") + (document.querySelector("[role=alert],.alert,.error,.validation-summary-errors") ? " ⚠" + (document.querySelector("[role=alert],.alert,.error,.validation-summary-errors").innerText || "").slice(0, 80) : "") }).then((r) => r.map((x) => x.result).filter(Boolean)).catch(() => []);
    const nt = (await chrome.tabs.query({}).catch(() => [])).filter((t) => !tabs0.has(t.id)).map((t) => String(t.url || t.pendingUrl || "").replace(/\?.*$/, ""));
    return { status: "failed", note: "δεν άνοιξε η φόρμα του Medilabi μέσα σε 20″ · πλαίσια: " + (fr.slice(0, 6).join(" | ") || "—") + (nt.length ? " · νέες καρτέλες: " + nt.join(", ") : "") };
  }
  // 🧾 η καρτέλα της φόρμας ΔΕΝ κλείνει από τον «καθαριστή» καρτελών όσο δουλεύεται (early = όχι ακόμα σε έλεγχο: δεν καθαρίζεται)
  try { await chrome.storage.session.set({ efbotFormOpen: { tabId: otab, at: Date.now(), early: 1, job: job.id } }); } catch (e) {}
  try { const u = medNav[0] ? new URL(medNav[0]) : null; if (u) chrome.storage.local.set({ efbotMedNav: { at: Date.now(), path: u.pathname, keys: [...u.searchParams.keys()], n: medNav.length, all: medNav.slice(0, 4).map((x) => { try { const v = new URL(x); return v.pathname + "?" + [...v.searchParams.keys()].join("&"); } catch (e) { return ""; } }) } }); } catch (e) {}
  return { tab, otab };
}
const ORDER_IS_FORM = () => (/OrderTests/i.test(location.pathname) && document.getElementById("ctl00_ContentPage_txtSearch")) ? 1 : null;
// 🪪 Έλεγχος ασθενή στη φόρμα OrderTests του Medilabi (ΜΟΝΟ ανάγνωση): ποιος ασθενής φαίνεται στη φόρμα; Αποτρέπει
// καταχώρηση εξετάσεων σε συνονόματο/λάθος ασθενή. Το DOM της κεφαλίδας ασθενή ΔΕΝ είναι γνωστό → γενική ανάγνωση:
// στοιχεία με id «ασθενή/ονόματος/ΑΜΚΑ», γραμμές με ετικέτα (Ασθενής/Ονοματεπώνυμο/Επώνυμο/Όνομα/ΑΜΚΑ/Α.Μ.) και η αρχή
// του κειμένου της σελίδας. Δεύτερο σήμα: η μπάρα ασθενή του ΝΠΣ (#appForm:content > nav > ol) — π.χ. σύγκριση ΑΜΚΑ.
async function medPatRead(otab, npsTab) {
  const fr = await chrome.scripting.executeScript({ target: { tabId: otab, allFrames: true }, world: "MAIN", func: () => {
    if (!/medilabi/i.test(location.href) && !/OrderTests/i.test(location.pathname)) return null;   // ΟΧΙ το πλαίσιο του ΝΠΣ
    const vis = (e) => { const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0 && getComputedStyle(e).visibility !== "hidden"; };
    const tx = (e) => String(/^(INPUT|TEXTAREA)$/.test(e.tagName) ? e.value : e.tagName === "SELECT" ? ((e.options[e.selectedIndex] || {}).text || "") : (e.innerText || e.textContent || "")).replace(/\s+/g, " ").trim();
    const BAD = /grvTests|dgProf|vrdDialog|txtSearch|lstTest|grvSel/i;
    const bad = (e) => { for (let x = e, k = 0; x && k < 15; x = x.parentElement, k++) if (x.id && BAD.test(x.id)) return true; return false; };
    const nz = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase();
    const f = [], seen = new Set();
    const add = (o) => { o.t = String(o.t || "").slice(0, 140); const k = o.id + "|" + o.lab + "|" + o.t; if (!o.t || seen.has(k) || f.length >= 40) return; seen.add(k); f.push(o); };
    for (const e of document.querySelectorAll("[id]")) {
      if (!/pat|asthen|name|onom|amka|eponym|surn|lblam|fullname/i.test(e.id) || /grvTests|dgProf|txtSearch|vrdDialog/i.test(e.id) || e.children.length > 4) continue;
      const hid = e.type === "hidden"; if ((!hid && !vis(e)) || bad(e)) continue;
      const t = tx(e); if (t.length <= 140) add({ id: e.id.slice(-50), lab: "", t, hid: hid ? 1 : 0 });
    }
    const LRE = /^(ΑΣΘΕΝΗΣ|ΟΝΟΜΑΤΕΠΩΝΥΜΟ|ΕΠΩΝΥΜΟ|ΟΝΟΜΑ|Α\.?\s?Μ\.?\s?Κ\.?\s?Α\.?|Α\.?\s?Μ\.?)(?![Α-ΩA-Z])\s*[:：]?\s*(.*)$/;
    for (const e of document.querySelectorAll("td,th,span,label,div,b,strong,dt,dd,p,li")) {
      if (e.children.length > 3 || !vis(e) || bad(e)) continue;
      const t = tx(e); if (!t || t.length > 140) continue;
      const m = LRE.exec(nz(t)); if (!m) continue;
      let v = m[2].trim();
      if (!v) { const fo = e.tagName === "LABEL" && e.htmlFor && document.getElementById(e.htmlFor); const nx = fo || e.nextElementSibling; v = nx && !bad(nx) ? tx(nx) : ""; }
      add({ id: e.id ? e.id.slice(-50) : "", lab: m[1].replace(/\s/g, ""), t: v, row: t.slice(0, 80) });
    }
    return { u: location.pathname.slice(-40), f, head: (document.body ? document.body.innerText : "").replace(/\s+/g, " ").trim().slice(0, 500) };
  } }).catch(() => []);
  const frames = (fr || []).map((x) => x && x.result).filter(Boolean);
  let nps = "";
  if (npsTab) try { const r = await chrome.scripting.executeScript({ target: { tabId: npsTab, frameIds: [0] }, func: () => { const ol = document.querySelector("#appForm\\:content > nav > ol"); return ol ? (ol.innerText || ol.textContent || "").replace(/\s+/g, " ").trim().slice(0, 200) : ""; } }); nps = (r && r[0] && r[0].result) || ""; } catch (e) {}
  return { f: frames.flatMap((x) => x.f), head: frames.map((x) => x.head).filter(Boolean).join(" ‖ ").slice(0, 600), nps, nf: frames.length };
}
// Καθαρή συνάρτηση (δοκιμάζεται στο tests/t_medpat.js): info {f:[{id, lab, t, hid}], head, nps} + όνομα εργασίας →
// {st: "ok" | "mismatch" | "ok-head" | "unknown", why, seen}. «ok-head» = το όνομα φάνηκε ΜΟΝΟ στο γενικό κείμενο της σελίδας
// (όχι σε πεδίο ασθενή) → ΔΕΝ αρκεί για αυτόματη έγκριση, μετρά όπως το «unknown» (προειδοποίηση στην έγκριση).
function medPatMatch(info, jobName) {
  const HG = { A: "Α", B: "Β", E: "Ε", Z: "Ζ", H: "Η", I: "Ι", K: "Κ", M: "Μ", N: "Ν", O: "Ο", P: "Ρ", T: "Τ", Y: "Υ", X: "Χ" }, GR = /[Α-Ω]/;
  // χωρίς τόνους/διαλυτικά, κεφαλαία (ς→Σ), λατινικά «σωσίες» μέσα σε ελληνικές λέξεις → ελληνικά (ΠΕTΙΔΗΣ με λατινικό T)
  const words = (s) => (String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().match(/[A-ZΑ-Ω]+/g) || []).map((w) => GR.test(w) ? w.replace(/[A-Z]/g, (c) => HG[c] || c) : w);
  const toks = [...new Set(words(jobName).filter((w) => w.length >= 3))];
  const f = (info && info.f) || [], head = (info && info.head) || "", nps = (info && info.nps) || "";
  const STOP = new Set(["ΑΣΘΕΝΗΣ", "ΑΣΘΕΝΟΥΣ", "ΟΝΟΜΑ", "ΕΠΩΝΥΜΟ", "ΟΝΟΜΑΤΕΠΩΝΥΜΟ", "ΠΑΤΡΩΝΥΜΟ", "ΜΗΤΡΩΝΥΜΟ", "ΑΜΚΑ", "ΗΛΙΚΙΑ", "ΦΥΛΟ", "ΑΡΡΕΝ", "ΘΗΛΥ", "ΑΝΔΡΑΣ", "ΓΥΝΑΙΚΑ", "ΕΤΩΝ", "ΕΤΗ", "ΗΜΕΡΟΜΗΝΙΑ", "ΓΕΝΝΗΣΗΣ", "ΚΛΙΝΗ", "ΘΑΛΑΜΟΣ", "ΚΛΙΝΙΚΗ", "ΤΜΗΜΑ", "ΠΑΡΑΓΓΕΛΙΑ", "ΠΑΡΑΓΓΕΛΙΑΣ", "ΕΞΕΤΑΣΗ", "ΕΞΕΤΑΣΕΙΣ", "ΙΑΤΡΟΣ", "ΚΑΤΑΣΤΑΣΗ", "ΣΤΟΙΧΕΙΑ", "ΠΛΗΡΟΦΟΡΙΕΣ", "ΤΗΛ", "ΤΗΛΕΦΩΝΟ", "ΔΙΕΥΘΥΝΣΗ", "ΑΣΦΑΛΙΣΤΙΚΟΣ", "ΦΟΡΕΑΣ", "ΕΟΠΥΥ", "ΜΗΤΡΩΟΥ", "ΑΡΙΘΜΟΣ", "ΕΙΣΑΓΩΓΗΣ", "ΝΟΣΗΛΕΙΑΣ", "ΤΟΥ", "ΤΗΣ", "NAME", "PATIENT", "SURNAME", "FIRST", "LAST"]);
  const SKIP = /badge|ehHeader_lblUser|doc|iatr|user|login|phys|oper|test|prof|exam|clinic|klin|dept|tmhm|ward|search|btn|lnk|chk|vrd|type|categ|status|kind|class/i;
  // s = ισχυρό πεδίο ασθενή, w = γενικό «όνομα», n = ΑΜΚΑ/ΑΜ, "" = αγνοείται. Ετικέτα: ΜΟΝΟ ακριβώς αυτές οι λέξεις
  // (όχι «Όνομα χρήστη», «Όνομα εξέτασης», «Επώνυμο ιατρού» — έλεγχος 5/11)
  const kind = (x) => {
    if (x.hid) return "";
    const l = words(x.lab).join(""); if (l) return /^(ΑΜΚΑ|ΑΜ)$/.test(l) ? "n" : /^(ΑΣΘΕΝΗΣ|ΟΝΟΜΑΤΕΠΩΝΥΜΟ|ΕΠΩΝΥΜΟ|ΟΝΟΜΑΤΕΠΩΝΥΜΟΑΣΘΕΝΟΥΣ|ΕΠΩΝΥΜΟΑΣΘΕΝΟΥΣ)$/.test(l) ? "s" : /^ΟΝΟΜΑ(ΑΣΘΕΝΟΥΣ)?$/.test(l) ? "w" : "";
    const id = String(x.id || ""); if (!id || SKIP.test(id)) return "";
    if (/amka|lblam(?![a-z])/i.test(id)) return "n"; if (/patient(name|surname|fullname)?$|patname|lblpat|asthen|eponym|surname|fullname|onomatep/i.test(id)) return "s"; return /name$|onoma$|lblname|lblonom/i.test(id) ? "w" : "";
  };
  // 🎯 ΠΡΑΓΜΑΤΙΚΗ μορφή Medilabi (δοκιμή #560, 5/11): «ΝΕΑ ΠΑΡΑΓΓΕΛΙΑ ΕΞΕΤΑΣΕΩΝ <ΕΠΩΝΥΜΟ ΟΝΟΜΑ> (A.M.: <κωδικός>)» στο
  // ctl00_ehHeader_divEMRHeader· ο ίδιος κωδικός = «Κωδικός Ασθενή» στη μπάρα του ΝΠΣ. Το «ΟΝΟΜΑ: …» της κεφαλίδας είναι ο ΧΡΗΣΤΗΣ.
  const NZ = (t) => String(t || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase();
  const hm = /ΠΑΡΑΓΓΕΛΙΑ\s+ΕΞΕΤΑΣΕΩΝ\s+(.+?)\s*\(\s*[AΑ]\s*\.?\s*[MΜ]\s*\.?\s*:\s*(\d{4,})\s*\)/.exec(NZ(f.map((x) => x.t).concat([head]).join(" ‖ ")));
  if (hm) {
    const code = hm[2], npsCode = (/ΚΩΔΙΚΟΣ\s+ΑΣΘΕΝΗ\s*:\s*(\d+)/.exec(NZ(nps)) || [])[1] || "";
    const nm = words(hm[1]).filter((w) => w.length >= 2 && !STOP.has(w)), set = new Set(nm);
    const seenS = "ΑΣΘΕΝΗΣ: " + hm[1].trim() + " (Α.Μ. " + code + ")" + (npsCode ? (npsCode === code ? " = ΝΠΣ" : " ≠ ΝΠΣ " + npsCode) : "");
    const X = (st, why) => ({ st, why: why + (npsCode === code ? " + Α.Μ. ΝΠΣ" : ""), seen: seenS, am: [code] });
    if (npsCode && npsCode !== code) return { st: "mismatch", why: "Α.Μ. φόρμας ≠ Α.Μ. ασθενή ΝΠΣ", seen: seenS, am: [code] };
    if (!toks.length) return X(npsCode === code ? "ok" : "unknown", "χωρίς όνομα εργασίας");
    const fullT = toks.filter((t) => set.has(t)), extra = nm.filter((w) => w.length >= 3 && !toks.includes(w));
    if (toks.length === 1) return fullT.length ? X("ok", "επώνυμο") : X("mismatch", "άλλο όνομα στη φόρμα (" + nm.slice(0, 3).join(" ") + ")");
    if (fullT.length === toks.length) return extra.length ? X("unknown", "και άλλο όνομα (" + extra.slice(0, 3).join(" ") + ")") : X("ok", "όνομα");
    if (!fullT.length || extra.length) return X("mismatch", (fullT.length ? "ίδιο " + fullT.join(" ") + ", άλλο όνομα" : "άλλο όνομα") + " στη φόρμα (" + extra.slice(0, 3).join(" ") + ")");
    return X("unknown", "μερικό όνομα (" + fullT.join(" ") + ")");
  }
  const S = [], W = [], N = [];
  for (const x of f) { const k = kind(x); if (k === "s") S.push(x); else if (k === "w") W.push(x); else if (k === "n") N.push(x); }
  const nameF = S.concat(W), U = new Set(nameF.flatMap((x) => words(x.t)));
  const seen = nameF.concat(N).map((x) => (x.lab ? x.lab + ": " : "") + x.t).join(" · ").slice(0, 160);
  const seenH = () => seen || head.slice(0, 160);
  // ΑΜΚΑ: Medilabi ↔ μπάρα ΝΠΣ (αν φαίνεται και στα δύο)
  const d11 = (s) => String(s || "").match(/(?<!\d)\d{11}(?!\d)/g) || [];
  const am1 = new Set(N.concat(S).flatMap((x) => d11(x.t))), am2 = new Set(d11(nps));
  const amOk = am1.size > 0 && am2.size > 0 && [...am1].some((a) => am2.has(a));
  if (am1.size && am2.size && !amOk) return { st: "mismatch", why: "ΑΜΚΑ φόρμας ≠ ΑΜΚΑ ΝΠΣ", seen };
  if (!toks.length) return { st: amOk ? "ok" : "unknown", why: amOk ? "ΑΜΚΑ" : "χωρίς όνομα εργασίας", seen: seenH() };
  // ΑΥΣΤΗΡΟ (έλεγχος 5/11): «ok» ΜΟΝΟ αν ΟΛΕΣ οι λέξεις του ονόματος φαίνονται ολόκληρες ΚΑΙ καμία άλλη λέξη-όνομα στα
  // πεδία ασθενή (όχι αρχικά, όχι «μερικό όνομα»). Ίδιο επώνυμο + άλλο όνομα (π.χ. συνώνυμος, πατρώνυμο) → unknown = χειροκίνητα.
  const scr = GR.test(toks[0]);
  const fw = (x) => words(String(x.t).split(/[0-9:/|(·]/)[0]).filter((w) => w.length >= 2 && !STOP.has(w) && GR.test(w) === scr);
  const foreign = nameF.flatMap(fw).filter((w) => !toks.includes(w));
  const full = toks.filter((t) => U.has(t));
  const fg = foreign.filter((w) => w.length >= 3), R = (st, why) => ({ st, why: why + (amOk ? " + ΑΜΚΑ" : ""), seen, am: [...am1] });
  if (toks.length === 1 && full.length) return R("ok", "επώνυμο");   // μόνο επώνυμο στην εντολή: συνώνυμος δεν ξεχωρίζει (γνωστό όριο)
  if (full.length === toks.length) return fg.length ? R("unknown", "και άλλο όνομα στη φόρμα (" + [...new Set(fg)].slice(0, 3).join(" ") + ")") : R("ok", "όνομα");
  if (fg.length) return { st: "mismatch", why: (full.length ? "ίδιο " + full.join(" ") + ", άλλο όνομα" : "άλλο όνομα") + " στη φόρμα (" + [...new Set(fg)].slice(0, 3).join(" ") + ")", seen, am: [...am1] };
  if (full.length) return R(amOk ? "ok" : "unknown", "μερικό όνομα (" + full.join(" ") + ")");
  if (amOk) return R("ok", "ΑΜΚΑ ίδιο με ΝΠΣ");
  const H = new Set(words(head)); if (toks.every((t) => H.has(t))) return { st: "ok-head", why: "μόνο στο κείμενο της σελίδας", seen: seenH(), am: [...am1] };
  return { st: "unknown", why: nameF.length ? "πεδία χωρίς όνομα" : "δεν βρέθηκαν στοιχεία ασθενούς", seen: seenH(), am: [...am1] };
}
async function medPatCheck(otab, npsTab, jobName) {
  try {
    const info = await medPatRead(otab, npsTab);
    const m = medPatMatch(info, jobName);
    const mask = (s) => String(s || "").replace(/\d{7}(\d{4})/g, "•••$1");   // ΑΜΚΑ δεν ταξιδεύει ολόκληρο σε σημειώσεις/ειδοποιήσεις
    // ΑΜΚΑ της φόρμας: μόνο hash (για σύγκριση στην έγκριση χωρίς τη μπάρα του ΝΠΣ, που μπορεί να δείχνει πια άλλον)
    let amH = ""; try { if ((m.am || []).length) amH = [...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode([...m.am].sort().join(","))))].map((x) => x.toString(16).padStart(2, "0")).join("").slice(0, 24); } catch (e) {}
    return { st: m.st, why: m.why, amH, seen: mask(m.seen).slice(0, 160), nps: mask(info.nps).slice(0, 120), nf: info.nf,
      cand: info.f.slice(0, 12).map((x) => ({ id: x.id || "", t: mask((x.lab ? x.lab + ": " : "") + (x.t || "")).slice(0, 80) + (x.hid ? " (κρυφό)" : "") })) };
  } catch (e) { return { st: "unknown", why: "σφάλμα ανάγνωσης: " + String(e.message || e).slice(0, 60), seen: "", nps: "" }; }
}
const MED_PT_WARN = "⚠ δεν επιβεβαιώθηκε ο ασθενής στη φόρμα Medilabi — έλεγξε πριν την έγκριση";
const medPtBad = (job, mp) => "⛔ ΛΑΘΟΣ ΑΣΘΕΝΗΣ στη φόρμα Medilabi — ζητήθηκε: " + (job.name || "?") + " · η φόρμα δείχνει: " + (mp.seen || "—") + " (" + (mp.why || "") + ")";
// ⚡ Προετοιμασία: μόλις ανοίξει στο κινητό το φύλλο παραγγελίας, το bot ανοίγει ήδη τον ασθενή και τη φόρμα του Medilabi.
// Όταν έρθει η παραγγελία (ίδιος ασθενής, ≤6′, καμία άλλη εργασία ΝΠΣ στο μεταξύ) μένει μόνο η συμπλήρωση (~2″).
const ORDER_PREP_MS = 6 * 60000;
// ⚡ 8/11: μετά την προετοιμασία η παραγγελία έρχεται σε λίγα δευτερόλεπτα· το «ξύπνημα» realtime μετρήθηκε να αργεί 8–18″ →
// έλεγχος ουράς ανά 3″ για όσο ισχύει η έτοιμη φόρμα (έως 6′), μόνο όταν το bot δεν δουλεύει.
let prepPollT = null, prepPollUntil = 0;
function prepPollStart() {
  prepPollUntil = Date.now() + ORDER_PREP_MS;
  if (prepPollT) return;
  prepPollT = setInterval(() => { if (Date.now() > prepPollUntil) { clearInterval(prepPollT); prepPollT = null; return; } if (!jobsBusy) jobsTick(true).catch(() => {}); }, 3000);
}
JOB_RUNNERS.orderprep = async (job) => {
  const o = await orderOpenForm(job);
  if (o.status) return { ...o, status: "dismissed" };
  // 🪪 ποιος ασθενής φαίνεται στη φόρμα (και διάγνωση του DOM: cand = υποψήφια πεδία {id, t})
  const mp = await medPatCheck(o.otab, o.tab.id, job.name);
  if (mp.st === "mismatch") return { status: "dismissed", note: medPtBad(job, mp), result: { medPt: mp } };   // λάθος ασθενής: ΔΕΝ κρατιέται ως «έτοιμη»
  await chrome.storage.session.set({ efbotOrderPrep: { name: String(job.name || ""), tabId: o.tab.id, otab: o.otab, at: Date.now() } });
  prepPollStart();
  // 🔎 8/11: πεδία ημερομηνίας/ώρας της φόρμας (μόνο ανάγνωση) — για το «Αύριο πρωί = 08:00»
  const dt = await medFrameExec(o.otab || o.tab.id, () => {
    if (!/OrderTests/i.test(location.pathname)) return null;
    const vis = (e) => { const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0; };
    const lbl = (c) => { const l = c.id && document.querySelector('label[for="' + CSS.escape(c.id) + '"]'); const td = c.closest("td"); const prev = td && td.previousElementSibling; return String((l && l.innerText) || (prev && prev.innerText) || (c.closest("tr") || {}).innerText || "").replace(/\s+/g, " ").trim().slice(0, 60); };
    return [...document.querySelectorAll("input,select")].filter((e) => vis(e) && !/hidden|checkbox|radio|submit|button|image/.test(e.type) && (/date|time|hour|minute|ημερ|ωρα|ώρα|ora|dt/i.test(e.id + " " + e.name) || /ημερομην|ώρα|ωρα/i.test(lbl(e)))).map((e) => ({ id: e.id.replace(/^ctl00_ContentPage_/, ""), t: e.tagName.toLowerCase() + ":" + e.type, v: String(e.value || "").slice(0, 30), l: lbl(e), opts: e.tagName === "SELECT" ? [...e.options].slice(0, 6).map((x) => x.text).join("|") : "" })).slice(0, 12);
  }).catch(() => null);
  return { status: "done", note: "⚡ φόρμα Medilabi έτοιμη για παραγγελία · 🪪 " + mp.st + (mp.seen ? " «" + mp.seen.slice(0, 80) + "»" : ""), result: { medPt: mp, dtFields: dt } };
};
JOB_KIND.orderprep = "⚡ Προετοιμασία παραγγελίας";
async function orderPrepTake(job) {
  const { efbotOrderPrep: pr } = await chrome.storage.session.get("efbotOrderPrep");
  if (!pr) return null;
  await chrome.storage.session.remove("efbotOrderPrep");
  const nz = (x) => String(x || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().replace(/\s+/g, " ").trim();
  if (nz(pr.name) !== nz(job.name) || Date.now() - pr.at > ORDER_PREP_MS) return null;
  const tab = await chrome.tabs.get(pr.tabId).catch(() => null), ot = await chrome.tabs.get(pr.otab).catch(() => null);
  if (!tab || !ot) return null;
  const ok = await medFrameExec(pr.otab, ORDER_IS_FORM).catch(() => null);
  return ok ? { tab, otab: pr.otab } : null;
}
const JOB_ORDER_INNER = async (job) => {
  const p = job.payload || {};
  const tests = (p.tests || []).map(String).filter(Boolean), packs = (p.packs || []).filter((x) => x && x.medilabi);
  if (!tests.length && !packs.length) return { status: "failed", note: "καμία εξέταση" };
  // 🖨 6/11: απεικονιστικές → το παραπεμπτικό A4 (PrintHtml) ΔΕΝ κλείνει· τυπώνεται στον κανονικό εκτυπωτή A4 αυτού του υπολογιστή
  printA4Want = tests.concat(packs.map((x) => x.medilabi || x.name || "")).some(isImgTest) ? { until: Date.now() + 6 * 60000, job: job.id, name: job.name || "" } : null;
  let tab, otab;
  const pr = await orderPrepTake(job);
  if (pr) { tab = pr.tab; otab = pr.otab; bgMark("φόρμα έτοιμη από πριν"); prepPollUntil = 0; }
  else { const o = await orderOpenForm(job); if (o.status) return o; tab = o.tab; otab = o.otab; bgMark("φόρμα Medilabi"); }
  const isForm = ORDER_IS_FORM;
  // 🪪 ΠΡΙΝ από οποιαδήποτε συμπλήρωση: είναι ο σωστός ασθενής στη φόρμα; λάθος → σταματά (καμία εξέταση, καμία έγκριση)
  const medPt = await medPatCheck(otab, tab.id, job.name);
  bgMark("ασθενής φόρμας: " + medPt.st);
  if (medPt.st === "mismatch") return { status: "failed", note: medPtBad(job, medPt) + " — δεν συμπληρώθηκε τίποτα", result: { medPt } };

  const ok = [], miss = [], amb = [];
  // 1) έτοιμα προφίλ Medilabi
  for (const pk of packs) {
    const tgt = await medFrameExec(otab, (name) => {
      if (!/OrderTests/i.test(location.pathname)) return null;
      const nz = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().trim();
      const a = [...document.querySelectorAll("a[id*='dgProf'][href^='javascript:__doPostBack']")].find((x) => nz(x.innerText) === nz(name));
      const m = a && /__doPostBack\('([^']+)'/.exec(a.getAttribute("href")); return m ? m[1] : "";
    }, [pk.medilabi]);
    if (!tgt) { miss.push("προφίλ " + pk.medilabi); continue; }
    const r = await medPostback(otab, tgt);
    if (r === "ok") ok.push("📦 " + pk.medilabi); else miss.push("προφίλ " + pk.medilabi + " (" + r + ")");
  }
  // 2) εξετάσεις μία-μία
  const aliases = Object.assign({}, MED_ALIAS); for (const [k, v] of Object.entries(p.aliases || {})) aliases[nzG(k)] = v;
  // ⚡ ΓΕΦΥΡΑ: όλες οι εξετάσεις με απευθείας αιτήματα (fetch) μέσα από το πλαίσιο του Medilabi — όχι 2 ξαναφορτώματα
  // σελίδας ανά εξέταση. Στο τέλος το πλαίσιο παίρνει ΜΙΑ φορά την τελική σελίδα, ώστε η «Καταχώρηση» (έγκριση) να δουλεύει
  // κανονικά. Σε οποιοδήποτε πρόβλημα → ο παλιός τρόπος για όσες έμειναν. ΠΟΤΕ btnDone εδώ.
  let todo = tests.slice(), bridgeDiag = null;
  try {
    // «ΟΝΟΜΑ @@ ΤΜΗΜΑ» (6/11): η εξέταση διαλέγεται ΜΕΣΑ στο τμήμα του Medilabi (π.χ. INR Αιματολογικού ≠ INR Αιμόστασης)
    const PATHS = (p.paths && typeof p.paths === "object") ? p.paths : {};
    const plan = tests.map((t) => { const [nm0, lab] = String(t).split(/\s*@@\s*/); const [term, want] = String(aliases[nzG(nm0)] || nm0).split("|"); const pth = !lab && !aliases[nzG(nm0)] && PATHS[t] ? String(PATHS[t]) : ""; return { t, term, want: want || term, lab: lab || pth, fromPath: !!pth }; });
    const br = await medFrameExec(otab, async (plan) => {
      if (!/OrderTests/i.test(location.pathname) || !document.forms[0]) return null;
      const enc = (str) => { let out = ""; for (const ch of String(str)) { const c = ch.codePointAt(0); if (c < 0x80) { out += encodeURIComponent(ch).replace(/%20/g, "+"); continue; }
        let b; if (c >= 0x391 && c <= 0x3a9) b = c - 0x391 + 0xc1; else if (c >= 0x3b1 && c <= 0x3ce) b = c - 0x3b1 + 0xe1; else b = { 0x386: 0xa2, 0x388: 0xb8, 0x389: 0xb9, 0x38a: 0xba, 0x38c: 0xbc, 0x38e: 0xbe, 0x38f: 0xbf, 0x390: 0xc0, 0x3aa: 0xda, 0x3ab: 0xdb, 0x3ac: 0xdc, 0x3ad: 0xdd, 0x3ae: 0xde, 0x3af: 0xdf, 0x3b0: 0xe0 }[c];
        out += b != null ? "%" + b.toString(16).toUpperCase().padStart(2, "0") : encodeURIComponent(ch); } return out; };
      const csr = String(document.characterSet || "").toLowerCase();
      const iso7 = /8859-7|iso-ir-126|greek/.test(csr), w1253 = /1253/.test(csr);
      const cs = iso7 ? "iso-8859-7" : w1253 ? "windows-1253" : document.characterSet;
      // ISO-8859-7 = ίδια byte με windows-1253 για τα γράμματα· διαφέρει μόνο το «Ά» (0xB6 αντί 0xA2)
      const enc7 = (x) => enc(String(x).replace(/Ά/g, "\u0000A")).replace(/%00A/g, "%B6");
      const E8 = iso7 ? enc7 : w1253 ? enc : (x) => encodeURIComponent(String(x)).replace(/%20/g, "+");
      const nz = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().replace(/\s+/g, " ").trim();
      let doc = document, html = null, action = new URL(document.forms[0].getAttribute("action") || location.href, location.href).href;
      const fields = (d, set) => { const f = d.forms[0], out = [];
        for (const e of f.querySelectorAll("input,select,textarea")) { const nm = e.getAttribute("name"); if (!nm || e.disabled) continue; const ty = (e.getAttribute("type") || "text").toLowerCase();
          if (/^(submit|image|button|reset|file)$/.test(ty)) continue;
          if ((ty === "checkbox" || ty === "radio")) { if (set[nm] !== undefined) continue; if (e.hasAttribute("checked") || (d === document && e.checked)) out.push([nm, e.getAttribute("value") || "on"]); continue; }
          if (e.tagName === "SELECT") { const o = e.querySelector("option[selected]") || e.querySelector("option"); if (o) out.push([nm, o.getAttribute("value") ?? o.textContent]); continue; }
          if (set[nm] !== undefined || nm === "__EVENTTARGET" || nm === "__EVENTARGUMENT") continue;
          out.push([nm, d === document ? e.value : (e.getAttribute("value") || e.textContent || "")]); }
        return out; };
      const post = async (target, set, arg) => {
        const body = fields(doc, set).concat(Object.entries(set)).concat([["__EVENTTARGET", target], ["__EVENTARGUMENT", arg || ""]]).map(([k, v]) => E8(k) + "=" + E8(v)).join("&");
        const r = await fetch(action, { method: "POST", credentials: "include", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body });
        if (!r.ok) throw new Error("HTTP " + r.status);
        html = new TextDecoder(cs).decode(await r.arrayBuffer());
        const d2 = new DOMParser().parseFromString(html, "text/html");
        if (!d2.forms[0] || !/OrderTests/i.test(r.url)) throw new Error("απρόσμενη απάντηση");
        doc = d2; action = new URL(d2.forms[0].getAttribute("action") || r.url, r.url).href;
      };
      const sName = (doc.getElementById("ctl00_ContentPage_txtSearch") || {}).name || "ctl00$ContentPage$txtSearch";
      const ok = [], amb = [], miss = [], done = [], diag = [];
      const dg = (d, tag) => { try { const ids = [...d.querySelectorAll("[id]")].map((e) => e.id).filter((i) => /grv|Search|lnk|Tests|Prof|err|msg/i.test(i)).slice(0, 25); const t = (d.querySelector("title") || {}).textContent || ""; const er = [...d.querySelectorAll("[id*=msg],[class*=error],[id*=lblError],[id*=lblMsg]")].map((e) => (e.textContent || "").trim()).filter(Boolean).join(" | ").slice(0, 200);
        diag.push(tag + " title=" + t.trim().slice(0, 40) + " len=" + (html ? html.length : 0) + " cs=" + cs + " ids=" + ids.join(",") + (er ? " err=" + er : "")); } catch (e) {} };
      dg(document, "αρχή");
      const pbOf = (a) => { const m = /__doPostBack\('([^']+)','([^']*)'\)/.exec(a.getAttribute("href") || ""); return m ? [m[1], m[2]] : null; };
      const rowsOf = (d) => [...d.querySelectorAll("input[type=checkbox][id*='grvTests'][id$='chkTest']")].map((c) => ({ c, t: ((c.closest("tr") || c.parentElement).textContent || "").replace(/\s+/g, " ").trim() }));
      // ⚡ 7/11: ΟΜΑΔΙΚΑ ανά τμήμα — ένα άνοιγμα τμήματος + ΜΙΑ «Προσθήκη» για όλες τις εξετάσεις της σελίδας (πριν: 2 αιτήματα ανά εξέταση)
      { const G = {}; for (const x of plan) if (x.fromPath) (G[x.lab] ||= []).push(x);
        for (const [lab, xs] of Object.entries(G)) {
          try {
            let lost = "", from = -1, prev = "";
            for (const seg of String(lab).split(/\s*›\s*/)) { const L = [...doc.querySelectorAll("a[id*='dgLabs']")]; if (prev) from = L.findIndex((a) => nz(a.textContent) === nz(prev));
              const ix = L.findIndex((a, i) => i > from && nz(a.textContent) === nz(seg)); const lp = ix >= 0 && pbOf(L[ix]); if (!lp) { lost = seg; break; } await post(lp[0], {}, lp[1]); prev = seg; }
            if (lost) { for (const x of xs) x.lab = ""; continue; }   // → κανονική αναζήτηση πιο κάτω
            const want = new Map(xs.map((x) => [nz(x.want), x])); const pg = new Set(["Page$1"]);
            for (let g = 0; g < 30 && want.size; g++) {
              const rows = rowsOf(doc), by = {}; for (const r of rows) { const k = nz(r.t); if (want.has(k)) (by[k] ||= []).push(r); }
              const one = Object.entries(by).filter(([, rr]) => rr.length === 1);
              if (one.length) { const set = {}; for (const [, rr] of one) set[rr[0].c.getAttribute("name")] = rr[0].c.getAttribute("value") || "on";
                await post("ctl00$ContentPage$lnkAddTests", set);
                for (const [k, rr] of one) { const x = want.get(k); ok.push(x.want + " = " + rr[0].t); done.push(x.t); want.delete(k); } }
              for (const [k, rr] of Object.entries(by)) if (rr.length > 1 && want.has(k)) { const x = want.get(k); x.lab = ""; want.delete(k); }   // διπλό όνομα → ο κανονικός (προσεκτικός) τρόπος
              if (!want.size) break;
              const nx = [...doc.querySelectorAll("a")].map(pbOf).find((q) => q && /grvTests/i.test(q[0]) && /^Page\$\d+$/.test(q[1]) && !pg.has(q[1])); if (!nx) break; pg.add(nx[1]); await post(nx[0], {}, nx[1]);
            }
            for (const x of want.values()) x.lab = "";   // δεν βρέθηκε στο τμήμα → αναζήτηση
          } catch (e) { for (const x of xs) if (!done.includes(x.t)) x.lab = ""; }
        }
      }
      // ⚡ 8/11: η «Προσθήκη» στέλνει στο πλαίσιο αναζήτησης τον ΕΠΟΜΕΝΟ όρο → αν η απάντηση φέρει ήδη τα αποτελέσματά του
      // (ΑΚΡΙΒΕΣ όνομα, μία γραμμή) γλιτώνει μία αναζήτηση ανά εξέταση· αλλιώς κανονική αναζήτηση όπως πριν
      let preTerm = null, preHits = 0, preOn = null, preBad = 0;   // preOn: null=άγνωστο · true=η επαλήθευση δουλεύει · false=όχι προ-αναζήτηση
      // κείμενο της φόρμας ΕΚΤΟΣ από αποτελέσματα αναζήτησης/τμήματα/κεφαλίδα = οι επιλεγμένες εξετάσεις → επαλήθευση ότι η «Προσθήκη» έπιασε
      const selTxt = (d) => { try { const f = d.forms[0].cloneNode(true); f.querySelectorAll("[id*='grvTests'],[id*='dgLabs'],[id*='ehHeader'],[id*='msgBox'],[id*='msgInfo'],script,style,option").forEach((e) => e.remove()); return nz(f.textContent); } catch (e) { return ""; } };
      const inSel = (d, t) => { const k = nz(t); return !!k && selTxt(d).includes(k); };
      const nextTerm = (i) => { for (let j = i + 1; j < plan.length; j++) { const y = plan[j]; if (!done.includes(y.t) && !y.lab) return y.term; } return null; };
      for (const [xi, x] of plan.entries()) {
        if (done.includes(x.t)) continue;
        if (x.lab) {   // μέσα στο τμήμα: κλικ στο τμήμα (αριστερή λίστα) → όλες οι σελίδες → ΑΚΡΙΒΕΣ όνομα, αλλιώς ❓ (ποτέ μάντεμα)
          let lost = "";
          { let from = -1, prev = "";   // υποκατηγορία = η ΠΡΩΤΗ ομώνυμη γραμμή ΜΕΤΑ το τμήμα (μπορεί να έχει ίδιο όνομα με το τμήμα)
            for (const seg of String(x.lab).split(/\s*›\s*/)) { let L = [...doc.querySelectorAll("a[id*='dgLabs']")]; if (prev) from = L.findIndex((a) => nz(a.textContent) === nz(prev));
              const ix = L.findIndex((a, i) => i > from && nz(a.textContent) === nz(seg)); const lp = ix >= 0 && pbOf(L[ix]); if (!lp) { lost = seg; break; } await post(lp[0], {}, lp[1]); prev = seg; } }
          if (lost) { amb.push(x.t + " → δεν βρέθηκε το τμήμα «" + lost + "»"); done.push(x.t); continue; }
          let hit = rowsOf(doc).filter((r) => nz(r.t) === nz(x.want)); const pg = new Set(["Page$1"]); let g = 0;
          while (!hit.length && ++g < 30) { const nx = [...doc.querySelectorAll("a")].map(pbOf).find((q) => q && /grvTests/i.test(q[0]) && /^Page\$\d+$/.test(q[1]) && !pg.has(q[1])); if (!nx) break; pg.add(nx[1]); await post(nx[0], {}, nx[1]); hit = rowsOf(doc).filter((r) => nz(r.t) === nz(x.want)); }
          if (hit.length !== 1) { amb.push(x.t + " → " + (hit.length ? "διπλή" : "δεν βρέθηκε") + " στο τμήμα"); done.push(x.t); continue; }
          await post("ctl00$ContentPage$lnkAddTests", { [hit[0].c.getAttribute("name")]: hit[0].c.getAttribute("value") || "on" });
          ok.push(x.want + " (" + x.lab + ") = " + hit[0].t); done.push(x.t); continue;
        }
        let pre = false;
        if (preTerm === x.term) { const r0 = rowsOf(doc).filter((r) => nz(r.t) === nz(x.want)); if (r0.length === 1) { pre = true; preHits++; } }
        preTerm = null;
        if (!pre) await post("ctl00$ContentPage$lnkSearchTest", { [sName]: x.term });
        if (!done.length) dg(doc, "μετά-αναζήτηση");
        const rows = [...doc.querySelectorAll("input[type=checkbox][id*='grvTests'][id$='chkTest']")].map((c) => ({ c, t: ((c.closest("tr") || c.parentElement).textContent || "").replace(/\s+/g, " ").trim() }));
        if (!rows.length) { miss.push(x.t + " (δεν βρέθηκε «" + x.term + "»)"); done.push(x.t); continue; }
        const w = nz(x.want);
        let hit = rows.filter((r) => nz(r.t) === w);
        if (!hit.length) hit = rows.filter((r) => nz(r.t).startsWith(w + " ") || nz(r.t).startsWith(w));
        if (hit.length > 1) { const sh = hit.slice().sort((a, b) => a.t.length - b.t.length); if (sh[0].t.length < sh[1].t.length) hit = [sh[0]]; }
        if (hit.length !== 1) { amb.push(x.t + " → " + (hit.length ? hit : rows).slice(0, 6).map((r) => r.t).join(" | ")); done.push(x.t); continue; }
        const nt = preOn === true ? nextTerm(xi) : null, hName = hit[0].c.getAttribute("name"), hVal = hit[0].c.getAttribute("value") || "on", hT = hit[0].t;
        const wasIn = inSel(doc, hT);
        await post("ctl00$ContentPage$lnkAddTests", { [hName]: hVal, [sName]: nt || x.term });
        const got = !wasIn && inSel(doc, hT);
        if (preOn === null) preOn = got;   // 1η προσθήκη (κανονικός τρόπος): φαίνεται η εξέταση στις επιλεγμένες; → ενεργοποίηση
        else if (nt && !got) {   // η «Προσθήκη» με τον επόμενο όρο ΔΕΝ έπιασε → ξανά με τον παλιό τρόπο και τέλος η προ-αναζήτηση
          preBad++; preOn = false;
          await post("ctl00$ContentPage$lnkSearchTest", { [sName]: x.term });
          const h2 = rowsOf(doc).filter((r) => nz(r.t) === nz(hT));
          if (h2.length !== 1) { amb.push(x.t + " → ξαναπροσθήκη: δεν βρέθηκε ξανά"); done.push(x.t); preTerm = null; continue; }
          await post("ctl00$ContentPage$lnkAddTests", { [h2[0].c.getAttribute("name")]: h2[0].c.getAttribute("value") || "on", [sName]: x.term });
          preTerm = null; ok.push(x.t + " = " + hT); done.push(x.t); continue;
        }
        preTerm = nt;
        ok.push(x.t + " = " + hT); done.push(x.t);
      }
      diag.push("προ-αναζήτηση " + preHits + " · επαλήθευση " + preOn + (preBad ? " · αποτυχία " + preBad : ""));
      if (!ok.length) return { failed: true, diag };   // τίποτα δεν μπήκε: η σελίδα ΔΕΝ πειράζεται, συνεχίζει ο παλιός τρόπος
      if (html) { document.open(); document.write(html); document.close(); }
      return { ok, amb, miss, done, diag };
    }, [plan]);
    if (br && br.diag) bridgeDiag = br.diag;
    if (br && br.done) { ok.push(...br.ok); amb.push(...br.amb); miss.push(...br.miss); todo = tests.filter((t) => !br.done.includes(t)); bgMark("γέφυρα Medilabi " + br.done.length + " εξετ."); }
    // η σελίδα ξαναγράφτηκε: να είναι έτοιμη πριν από ό,τι ακολουθεί
    for (let i = 0; i < 40; i++) { if (await medFrameExec(otab, isForm)) break; await new Promise((r) => setTimeout(r, 100)); }
  } catch (e) { bgMark("γέφυρα: " + String(e.message || e).slice(0, 30)); }
  for (const t of todo) {
    const [term, want] = String(aliases[nzG(String(t).split(/\s*@@\s*/)[0])] || String(t).split(/\s*@@\s*/)[0]).split("|");
    const r = await medPostback(otab, "ctl00$ContentPage$lnkSearchTest", term);
    if (r !== "ok" && r !== "nochange") { miss.push(t + " (" + r + ")"); continue; }
    const pick = await medFrameExec(otab, (term) => {
      if (!/OrderTests/i.test(location.pathname)) return null;
      const nz = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().replace(/\s+/g, " ").trim();
      const rows = [...document.querySelectorAll("input[type=checkbox][id*='grvTests'][id$='chkTest']")].map((c) => ({ c, t: ((c.closest("tr") || c.parentElement).innerText || "").replace(/\s+/g, " ").trim() }));
      if (!rows.length) return { n: 0 };
      const w = nz(term);
      let hit = rows.filter((x) => nz(x.t) === w);
      if (!hit.length) hit = rows.filter((x) => nz(x.t).startsWith(w + " ") || nz(x.t).startsWith(w));
      if (hit.length > 1) { const sh = hit.slice().sort((a, b) => a.t.length - b.t.length); if (sh[0].t.length < sh[1].t.length) hit = [sh[0]]; }
      if (hit.length !== 1) return { n: rows.length, amb: (hit.length ? hit : rows).slice(0, 6).map((x) => x.t) };
      if (!hit[0].c.checked) hit[0].c.click();
      return { n: rows.length, ok: hit[0].t };
    }, [want || term]);
    if (!pick || !pick.n) { miss.push(t + " (δεν βρέθηκε «" + term + "»)"); continue; }
    if (!pick.ok) { amb.push(t + " → " + (pick.amb || []).join(" | ")); continue; }
    const r2 = await medPostback(otab, "ctl00$ContentPage$lnkAddTests");
    if (r2 === "ok") ok.push(t + " = " + pick.ok); else miss.push(t + " (προσθήκη: " + r2 + ")");
  }
  // 🩸 «Είδος δείγματος» (π.χ. Αιμοκαλλιέργεια): εντολή χρήστη → «Αίμα». Μόνο κενές επιλογές (-Είδος Δείγματος-), όχι όσες έχει διαλέξει κάποιος.
  try {
    const sp = await medFrameExec(otab, () => {
      if (!/OrderTests/i.test(location.pathname)) return null;
      const nz = (x) => String(x || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().replace(/\s+/g, " ").trim();
      const out = [];
      for (const sel of document.querySelectorAll("select")) {
        const opts = [...sel.options]; if (!opts.some((o) => /ΕΙΔΟΣ ΔΕΙΓΜΑΤΟΣ/.test(nz(o.text)))) continue;
        const cur = sel.options[sel.selectedIndex]; if (cur && !/ΕΙΔΟΣ ΔΕΙΓΜΑΤΟΣ|^-?$/.test(nz(cur.text))) continue;
        const pick = opts.find((o) => nz(o.text) === "ΑΙΜΑ") || opts.find((o) => nz(o.text) === "ΠΕΡΙΦΕΡΙΚΟ ΑΙΜΑ") || opts.find((o) => /^(ΠΕΡΙΦΕΡΙΚΟ )?ΑΙΜΑ\b/.test(nz(o.text)) && !/ΟΥΡΑ|ΥΓΡΟ/.test(nz(o.text)));
        const row = nz((sel.closest("tr") || sel.parentElement || {}).textContent).slice(0, 60);
        if (!pick) { out.push({ row, err: "χωρίς «Αίμα»" }); continue; }
        sel.value = pick.value; sel.dispatchEvent(new Event("change", { bubbles: true }));
        out.push({ row, v: pick.text.trim(), pb: /__doPostBack/.test(sel.getAttribute("onchange") || "") });
      }
      return out;
    });
    if (sp && sp.length) { const okN = sp.filter((x) => x.v).length; if (okN) ok.push("🩸 είδος δείγματος: Αίμα" + (okN > 1 ? " ×" + okN : "")); for (const x of sp.filter((x) => x.err)) miss.push("είδος δείγματος (" + x.err + ")"); if (sp.some((x) => x.pb)) await bgSettle(otab, 3000); }
  } catch (e) {}
  // ΔΕΝ φέρνουμε το παράθυρο του bot μπροστά: κάποιος μπορεί να δουλεύει στον υπολογιστή (και να το κλείσει)
  try { await chrome.tabs.update(tab.id, { active: true }); } catch (e) {}
  const note = "🧾 Συμπληρώθηκε — περιμένει έγκριση (με την έγκριση το bot πατά «Καταχώρηση»).\n✓ " + (ok.join(" · ") || "—") + (miss.length ? "\n⚠ δεν μπήκαν: " + miss.join(" · ") : "") + (amb.length ? "\n❓ πολλές επιλογές: " + amb.join(" ‖ ") : "") + (medPt.st !== "ok" ? "\n" + MED_PT_WARN + (medPt.seen ? " (φαίνεται: " + medPt.seen.slice(0, 80) + ")" : "") : "");
  if (!ok.length) return { status: "failed", note: note.replace("περιμένει έγκριση (με την έγκριση το bot πατά «Καταχώρηση»)", "δεν μπήκε καμία εξέταση"), result: { bridgeDiag, medPt } };
  // 🖨 πώς τυπώνει το Medilabi το barcode μετά την «Καταχώρηση» (μόνο ανάγνωση κώδικα της σελίδας)
  let printInfo = null;
  try { printInfo = await medFrameExec(otab, async () => {
    if (!/OrderTests/i.test(location.pathname)) return null;
    const RE = /print|barcode|etiket|ετικ|label|window\.open|showModalDialog|localhost|127\.0\.0\.1|ActiveX|zebra|zpl|websocket|qz\./i;
    const snip = (t, max) => { const out = []; let m; const re = new RegExp(RE.source, "gi"); while ((m = re.exec(t)) && out.length < max) { out.push(t.slice(Math.max(0, m.index - 90), m.index + 140).replace(/\s+/g, " ")); re.lastIndex = m.index + 140; } return out; };
    const nz = (x) => String(x || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
    const btn = [...document.querySelectorAll("input[type=submit],input[type=button],button,a")].find((e) => nz(e.value || e.innerText) === "καταχωρηση");
    const inl = [...document.scripts].filter((x) => !x.src).map((x) => x.textContent).join("\n");
    const srcs = [...document.scripts].filter((x) => x.src).map((x) => x.src.replace(location.origin, ""));
    const files = [];
    for (const u of srcs.filter((u) => !/jquery|bootstrap|ajax\/libs|WebResource|ScriptResource/i.test(u)).slice(0, 8)) {
      try { const t = await (await fetch(u, { credentials: "include" })).text(); const sn = snip(t, 4); if (sn.length) files.push({ u: u.slice(0, 80), sn }); } catch (e) {}
    }
    return { btn: btn ? { id: btn.id, onclick: (btn.getAttribute("onclick") || btn.getAttribute("href") || "").slice(0, 300), type: btn.type || btn.tagName } : null,
      inline: snip(inl, 10), srcs: srcs.slice(0, 20), files, forms: [...document.forms].map((f) => (f.getAttribute("action") || "").slice(0, 80) + " target=" + (f.target || "")),
      opener: !!window.opener, top: window.top === window };
  }); } catch (e) { printInfo = { err: e.message }; }
  return { status: "review", note, result: { ok, miss, amb, tabId: otab, npsTab: tab.id, medPt, filledAt: Date.now(), bridgeDiag, printInfo }, push: ["🧾 Παραγγελία για έγκριση", (job.name || "") + " · " + ok.length + " ✓" + (miss.length + amb.length ? " · ⚠ " + (miss.length + amb.length) : "") + " — έγκριση από το Παραδόχαρτο"] };
};
// ===== 📅 Ημ. εισαγωγής (οθόνη «Εικόνα κλινικής») + ΑΜ (μπάρα στοιχείων ασθενούς) — ΜΟΝΟ ανάγνωση =====
// payload: {names:[ονόματα για ΑΜ], am:true|false}. Επιστρέφει {rows:[{name, room, bed, admit, …}], headers:[…], am:{όνομα: ΑΜ}}.
async function emrHeaderRead(tabId) {
  return pfExec(tabId, () => {
    const out = [];
    for (const e of document.querySelectorAll("a, span, td, div, label")) {
      if (e.children.length > 2) continue;
      const r = e.getBoundingClientRect(); if (!r.width || r.top > 320) continue;
      const t = (e.innerText || "").replace(/\s+/g, " ").trim(); const m = /^([^:]{2,40}?)\s*:\s*(.{1,60})$/.exec(t);
      if (m && !out.some((x) => x.label === m[1])) out.push({ label: m[1].trim(), value: m[2].trim() });
    }
    return out.slice(0, 30);
  });
}
JOB_RUNNERS.clinicview = async (job) => {
  const p = job.payload || {};
  const tab = await bgEmrTab();
  if (!tab || tab.err) return { status: "failed", note: tab?.err || "δεν άνοιξε ο φάκελος" };
  const lg = await bgEnsureLogin(tab.id);
  if (!lg.ok) return { status: "failed", note: lg.err };
  const res = { rows: [], headers: [], am: {}, amka: {}, hdr: [] };
  if (await bgEmrListVis(tab.id) !== 1) await bgEmrToList(tab.id);
  res.clinic = await emrClinicEnsure(tab.id, true).catch((e) => ({ err: e.message }));
  // 1) «Εικόνα κλινικής»
  // το ΝΠΣ ΔΕΝ έχει «Εικόνα κλινικής» (έλεγχος 5/11): πραγματικό στοιχείο «Συνολική Εικόνα Νοσηλευομένων» (Μαζικές Διαδικασίες)
  let okV = await emrClickText(tab.id, /συνολικ[ηή]\s+ε[ιί]κ[οό]να\s+νοσηλευ[οό]μ/);
  if (okV === false) {   // ανοίγει το υπομενού «Μαζικές Διαδικασίες» (hover + click) και ξαναψάχνει
    await pfExec(tab.id, () => { const m = [...document.querySelectorAll("a, [role=menuitem], .ui-menuitem-link")].find((e) => /^μαζικ[εέ]ς\s+διαδικασ[ιί]ες$/i.test((e.innerText || e.textContent || "").trim())); if (!m) return false;
      for (const t of ["pointerover", "mouseover", "mouseenter", "pointerenter"]) m.dispatchEvent(new (t.startsWith("pointer") ? PointerEvent : MouseEvent)(t, { bubbles: true, cancelable: true, view: window })); return true; }).catch(() => false);
    await E.sleep(700); okV = await emrClickText(tab.id, /συνολικ[ηή]\s+ε[ιί]κ[οό]να\s+νοσηλευ[οό]μ/);
  }
  if (okV === false && (await emrClickText(tab.id, /^διαχε[ιί]ριση\s+κλινικ[ηή]ς$/))) { await E.sleep(800); okV = await emrClickText(tab.id, /συνολικ[ηή]\s+ε[ιί]κ[οό]να\s+νοσηλευ[οό]μ/); }
  if (okV === false) okV = await emrClickText(tab.id, /^ε[ιί]κ[οό]να\s+κλινικ[ηή]ς$/);
  if (okV === false) okV = await emrClickText(tab.id, /ε[ιί]κ[οό]να\s+(της\s+)?κλινικ|clinic\s*view|κατάσταση\s+κλινικ/);
  // στο ΝΠΣ βρίσκεται μέσα στο μενού «Διαχείριση Κλινικής»: άνοιγμα μενού και ξανά αναζήτηση
  if (okV === false && (await emrClickText(tab.id, /^διαχε[ιί]ριση\s+κλινικ[ηή]ς$/))) {
    await E.sleep(800);
    okV = await emrClickText(tab.id, /ε[ιί]κ[οό]να\s+(της\s+)?κλινικ/);
    if (okV === false) {   // τι έχει μέσα το μενού (μόνο ετικέτες)
      const sub = await pfExec(tab.id, () => [...document.querySelectorAll("a, [role=menuitem], .ui-menuitem-link")].filter((e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; })
        .map((e) => (e.innerText || e.textContent || "").replace(/\s+/g, " ").trim()).filter((t) => t && t.length < 50 && !/\d{4,}/.test(t)).filter((t, i, a) => a.indexOf(t) === i).slice(0, 60));
      res.submenu = sub || [];
    }
  }
  res.viewState = String(okV);
  if (okV === false) {   // μόνο ετικέτες μενού/κουμπιών (χωρίς ονόματα ασθενών: <40 χαρ., χωρίς πολλά ψηφία)
    const cand = await pfExec(tab.id, () => [...document.querySelectorAll("a, button, [role=menuitem], [role=tab], .ui-menuitem-link, .ui-commandlink")]
      .map((e) => (e.innerText || e.textContent || "").replace(/\s+/g, " ").trim()).filter((t) => t && t.length < 40 && !/\d{4,}/.test(t)).filter((t, i, a) => a.indexOf(t) === i).slice(0, 80));
    res.menu = cand || [];
  }
  await E.sleep(1500);
  const tbl = await pfExec(tab.id, () => {
    const nz = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
    let best = null;
    for (const t of document.querySelectorAll("table")) {
      if (!t.getBoundingClientRect().width) continue;
      const hs = [...t.querySelectorAll("thead th, thead td")].map((h) => (h.innerText || "").replace(/\s+/g, " ").trim());
      if (!hs.some((h) => /εισαγ/.test(nz(h)))) continue;
      const rows = [...t.querySelectorAll("tbody tr")].map((tr) => [...tr.children].map((c) => (c.innerText || "").replace(/\s+/g, " ").trim())).filter((r) => r.some(Boolean));
      if (!best || rows.length > best.rows.length) best = { hs, rows };
    }
    return best;
  });
  if (tbl && !Array.isArray(tbl.hs)) res.tableErr = String(tbl.err || tbl.error || "η ανάγνωση του πίνακα δεν απάντησε").slice(0, 120);   // πριν: «reading 'findIndex'» (#510)
  if (tbl && Array.isArray(tbl.hs)) {
    res.headers = tbl.hs;
    const ix = (re) => tbl.hs.findIndex((h) => re.test(h.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase()));
    const iName = ix(/ον\/?νυμο|ονοματεπ|ασθεν/), iAdm = ix(/εισαγ/), iRoom = ix(/θαλαμ/), iBed = ix(/κλιν/), iAm = ix(/α\.?\s?μ\.?$|μητρ/);
    res.rows = tbl.rows.map((r) => ({ name: r[iName] || "", admit: r[iAdm] || "", room: iRoom >= 0 ? r[iRoom] : "", bed: iBed >= 0 ? r[iBed] : "", am: iAm >= 0 ? r[iAm] : "" })).filter((x) => x.name);
  }
  // 2) ΑΜ από τη μπάρα του ασθενή (άνοιγμα ενός-ενός)
  const names = (p.names || []).slice(0, 40);
  if (p.am !== false && names.length) {
    const { efbot: st } = await chrome.storage.local.get("efbot");
    for (const nm of names) {
      try { await bgOpenPatient(tab, nm, st); } catch (e) { res.am[nm] = { err: e.message.slice(0, 80) }; continue; }
      await bgSettle(tab.id, 1200);
      const h = (await emrHeaderRead(tab.id)) || [];
      if (!res.hdr.length) res.hdr = h.map((x) => ({ label: x.label, len: x.value.length, digits: (x.value.match(/\d/g) || []).length }));
      // ΑΜ νοσοκομείου = 8 ψηφία· ΑΜΚΑ = 11 ψηφία. ΠΡΟΣΟΧΗ: η ετικέτα «ΑΜΚΑ» αρχίζει κι αυτή από «ΑΜ».
      const lab = (x) => x.label.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/ς/g, "σ").replace(/[.\s]/g, "");
      const digits = (v, n) => { const m = String(v || "").match(new RegExp("(?:^|\\D)(\\d{" + n + "})(?!\\d)")); return m ? m[1] : ""; };
      const amkaH = h.find((x) => /^αμκα/.test(lab(x)));
      const amH = h.find((x) => /^κωδικοσασθεν/.test(lab(x))) || h.find((x) => /^(αμ|αρμητρ|αριθμοσμητρ|μητρωο)$|^(αρμητρ|αριθμοσμητρ|μητρωο)/.test(lab(x)) && !/^αμκα/.test(lab(x)));
      res.am[nm] = (amH && digits(amH.value, 8)) || null;
      res.amka[nm] = (amkaH && digits(amkaH.value, 11)) || null;
    }
  }
  const nAm = Object.values(res.am).filter((v) => typeof v === "string" && v).length;
  if (res.tableErr && !res.rows.length) return { status: "failed", note: "📅 Εικόνα κλινικής: " + res.tableErr, result: res };
  return { status: "done", note: `📅 Εικόνα κλινικής: ${res.rows.length} ασθενείς${res.rows.length ? " (με ημ. εισαγωγής)" : tbl ? "" : " — ⚠ δεν βρέθηκε πίνακας με «Εισαγωγή» (" + res.viewState + ")" + (res.menu && res.menu.length ? " · μενού: " + res.menu.filter((t) => /κλινικ|εικον|ασθεν|λιστ|θαλαμ|κλιν/i.test(t)).slice(0, 12).join(" | ") : "") + (res.submenu && res.submenu.length ? " · μέσα στη «Διαχείριση Κλινικής»: " + res.submenu.slice(0, 25).join(" | ") : "")}` + (names.length ? ` · ΑΜ: ${nAm}/${names.length}` + (nAm ? "" : " — ετικέτες μπάρας: " + res.hdr.map((x) => x.label).join(", ")) : ""), result: { ...res, at: Date.now() } };
};


// 🔎 ΜΟΝΟ περιήγηση (ΠΟΤΕ «Καταχώρηση»): ανοίγει τη φόρμα Medilabi (ασθενής δοκιμών), προσθέτει μία-μία τις εξετάσεις
// και καταγράφει ΤΙ ΝΕΟ εμφανίζεται (ερωτήσεις/επιλογές π.χ. αντιβίωση, καθετήρας, παράθυρα). Στο τέλος κλείνει χωρίς καταχώρηση.
JOB_RUNNERS.medqprobe = async (job) => {
  const p = job.payload || {};
  if (!/ΜΠΕΓΟ/i.test(String(job.name || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase())) return { status: "failed", note: "μόνο στον ασθενή δοκιμών (ΜΠΕΓΟΣ)" };
  const o = await orderOpenForm(job); if (o.status) return o;
  const otab = o.otab;
  const snap = () => medFrameExec(otab, () => {
    if (!/OrderTests/i.test(location.pathname)) return null;
    const vis = (e) => { const b = e.getBoundingClientRect(); const cs = getComputedStyle(e); return b.width > 0 && b.height > 0 && cs.visibility !== "hidden"; };
    const clean = (t) => String(t || "").replace(/\s+/g, " ").trim();
    const lab = (e) => { const l = e.id && document.querySelector('label[for="' + CSS.escape(e.id) + '"]'); const tr = e.closest("tr,li,div"); return clean((l && l.innerText) || (tr && tr.innerText) || e.title || e.name).slice(0, 120); };
    const out = [];
    for (const e of document.querySelectorAll("select,input,textarea")) {
      if (!vis(e) || /grvTests|txtSearch|__/.test(e.id || e.name || "")) continue;
      const ty = e.tagName === "SELECT" ? "select" : (e.type || "text").toLowerCase();
      if (/^(submit|button|hidden|image)$/.test(ty)) continue;
      out.push({ k: (e.id || e.name || "") , ty, l: lab(e), opt: ty === "select" ? [...e.options].map((x) => clean(x.text)).slice(0, 15) : undefined, v: ty === "checkbox" || ty === "radio" ? e.checked : undefined });
    }
    const dlg = [...document.querySelectorAll("[id*=Dialog],[id*=dialog],[id*=Popup],[id*=popup],[id*=msgBox],[role=dialog],.modal")].filter(vis).map((d) => ({ id: d.id, t: clean(d.innerText).slice(0, 600) }));
    return { ctl: out, dlg };
  });
  const s0snap = (await snap()) || { ctl: [], dlg: [] };
  const aliases = Object.assign({}, MED_ALIAS);
  const tests = (p.tests && p.tests.length ? p.tests : ["Καλλιέργεια ούρων", "Αιμοκαλλιέργεια", "Γενική ούρων", "ΚΑΛΛΙΕΡΓΕΙΑ ΑΚΡΟΥ ΚΑΘΕΤΗΡΑ", "PSA", "CRP", "PT-INR"]).slice(0, 15);
  // Όπως η «γέφυρα» της παραγγελίας: αναζήτηση + προσθήκη με fetch μέσα από το πλαίσιο, σε αντίγραφο της σελίδας.
  // Η πραγματική σελίδα ΔΕΝ αλλάζει (χωρίς document.write), ΠΟΤΕ btnDone. Καταγράφει νέα πεδία/μηνύματα μετά από κάθε προσθήκη.
  const plan = tests.map((t) => { const [term, want] = String(aliases[nzG(t)] || t).split("|"); return { t, term, want: want || term }; });
  const pr = await medFrameExec(otab, async (plan) => {
    if (!/OrderTests/i.test(location.pathname) || !document.forms[0]) return null;
    const enc = (str) => { let out = ""; for (const ch of String(str)) { const c = ch.codePointAt(0); if (c < 0x80) { out += encodeURIComponent(ch).replace(/%20/g, "+"); continue; }
      let b; if (c >= 0x391 && c <= 0x3a9) b = c - 0x391 + 0xc1; else if (c >= 0x3b1 && c <= 0x3ce) b = c - 0x3b1 + 0xe1; else b = { 0x386: 0xa2, 0x388: 0xb8, 0x389: 0xb9, 0x38a: 0xba, 0x38c: 0xbc, 0x38e: 0xbe, 0x38f: 0xbf, 0x390: 0xc0, 0x3aa: 0xda, 0x3ab: 0xdb, 0x3ac: 0xdc, 0x3ad: 0xdd, 0x3ae: 0xde, 0x3af: 0xdf, 0x3b0: 0xe0 }[c];
      out += b != null ? "%" + b.toString(16).toUpperCase().padStart(2, "0") : encodeURIComponent(ch); } return out; };
    const csr = String(document.characterSet || "").toLowerCase();
    const iso7 = /8859-7|iso-ir-126|greek/.test(csr), w1253 = /1253/.test(csr);
    const cs = iso7 ? "iso-8859-7" : w1253 ? "windows-1253" : document.characterSet;
    const enc7 = (x) => enc(String(x).replace(/Ά/g, "\u0000A")).replace(/%00A/g, "%B6");
    const E8 = iso7 ? enc7 : w1253 ? enc : (x) => encodeURIComponent(String(x)).replace(/%20/g, "+");
    const nz = (s) => String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().replace(/\s+/g, " ").trim();
    const clean = (t) => String(t || "").replace(/\s+/g, " ").trim();
    let doc = document, html = null, action = new URL(document.forms[0].getAttribute("action") || location.href, location.href).href;
    const fields = (d, set) => { const f = d.forms[0], out = [];
      for (const e of f.querySelectorAll("input,select,textarea")) { const nm = e.getAttribute("name"); if (!nm || e.disabled) continue; const ty = (e.getAttribute("type") || "text").toLowerCase();
        if (/^(submit|image|button|reset|file)$/.test(ty)) continue;
        if ((ty === "checkbox" || ty === "radio")) { if (set[nm] !== undefined) continue; if (e.hasAttribute("checked") || (d === document && e.checked)) out.push([nm, e.getAttribute("value") || "on"]); continue; }
        if (e.tagName === "SELECT") { const o = e.querySelector("option[selected]") || e.querySelector("option"); if (o) out.push([nm, o.getAttribute("value") ?? o.textContent]); continue; }
        if (set[nm] !== undefined || nm === "__EVENTTARGET" || nm === "__EVENTARGUMENT") continue;
        out.push([nm, d === document ? e.value : (e.getAttribute("value") || e.textContent || "")]); }
      return out; };
    const post = async (target, set) => {
      if (/btnDone/i.test(target)) throw new Error("blocked");
      const body = fields(doc, set).concat(Object.entries(set)).concat([["__EVENTTARGET", target], ["__EVENTARGUMENT", ""]]).map(([k, v]) => E8(k) + "=" + E8(v)).join("&");
      const r = await fetch(action, { method: "POST", credentials: "include", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body });
      if (!r.ok) throw new Error("HTTP " + r.status);
      html = new TextDecoder(cs).decode(await r.arrayBuffer());
      const d2 = new DOMParser().parseFromString(html, "text/html");
      if (!d2.forms[0] || !/OrderTests/i.test(r.url)) throw new Error("απρόσμενη απάντηση");
      doc = d2; action = new URL(d2.forms[0].getAttribute("action") || r.url, r.url).href;
    };
    const ctls = (d) => [...d.forms[0].querySelectorAll("select,input,textarea")].filter((e) => { const ty = (e.getAttribute("type") || "text").toLowerCase(); const id = e.id || e.getAttribute("name") || ""; return !/^(submit|button|hidden|image)$/.test(ty) && !/grvTests|txtSearch|__/.test(id); })
      .map((e) => { const l = e.id && d.querySelector('label[for="' + CSS.escape(e.id) + '"]'); const tr = e.closest("tr,li,div"); const ty = e.tagName === "SELECT" ? "select" : (e.getAttribute("type") || "text").toLowerCase();
        return { k: e.id || e.getAttribute("name") || "", ty, l: clean((l && l.textContent) || (tr && tr.textContent) || e.getAttribute("title") || "").slice(0, 120), opt: ty === "select" ? [...e.querySelectorAll("option")].map((o) => clean(o.textContent)).slice(0, 15) : undefined }; });
    const msgs = (d) => [...d.querySelectorAll("[id*=Dialog],[id*=dialog],[id*=Popup],[id*=popup],[id*=msg],[id*=Msg],[id*=lblError],[id*=vrd],[role=dialog],.modal")].map((x) => ({ id: x.id, t: clean(x.textContent).slice(0, 500) })).filter((x) => x.t);
    const alerts = (h) => (String(h || "").match(/alert\((['"])(.{3,300}?)\1\)/g) || []).slice(0, 5);
    const key = (c) => c.k + "|" + c.l;
    const base = ctls(doc); let seen = new Set(base.map(key)), seenMsg = new Set(msgs(doc).map((m) => m.id + m.t));
    const sName = (doc.getElementById("ctl00_ContentPage_txtSearch") || {}).name || "ctl00$ContentPage$txtSearch";
    const res = [];
    for (const x of plan) {
      try {
        await post("ctl00$ContentPage$lnkSearchTest", { [sName]: x.term });
        const rows = [...doc.querySelectorAll("input[type=checkbox][id*='grvTests'][id$='chkTest']")].map((c) => ({ c, t: clean((c.closest("tr") || c.parentElement).textContent) }));
        if (!rows.length) { res.push({ t: x.t, err: "δεν βρέθηκε «" + x.term + "»" }); continue; }
        const w = nz(x.want); let hit = rows.filter((r) => nz(r.t) === w); if (!hit.length) hit = rows.filter((r) => nz(r.t).startsWith(w));
        if (hit.length > 1) { const sh = hit.slice().sort((a, b) => a.t.length - b.t.length); hit = [sh[0]]; }
        if (!hit.length) { res.push({ t: x.t, err: "όχι ακριβές", list: rows.slice(0, 8).map((r) => r.t) }); continue; }
        await post("ctl00$ContentPage$lnkAddTests", { [hit[0].c.getAttribute("name")]: hit[0].c.getAttribute("value") || "on", [sName]: x.term });
        const now = ctls(doc), nw = now.filter((c) => !seen.has(key(c))); seen = new Set(now.map(key));
        const ms = msgs(doc).filter((m) => !seenMsg.has(m.id + m.t)); ms.forEach((m) => seenMsg.add(m.id + m.t));
        res.push({ t: x.t, as: hit[0].t, nw, dlg: ms, al: alerts(html) });
      } catch (e) { res.push({ t: x.t, err: String(e.message || e).slice(0, 80) }); }
    }
    return { res, base };
  }, [plan]).catch((e) => ({ err: String(e.message || e) }));
  const res = (pr && pr.res) || [{ t: "—", err: (pr && pr.err) || "δεν απάντησε το πλαίσιο του Medilabi" }];
  const s0 = (pr && pr.base) ? { ctl: pr.base, dlg: [] } : s0snap;
  // σενάρια/κείμενα της σελίδας που μιλούν για αντιβίωση/καθετήρα (μόνο ανάγνωση)
  const hints = await medFrameExec(otab, () => { const t = document.documentElement.innerHTML; const re = /αντιβι|καθετ|antibio|cathet|ερωτηματολ|question/gi; const out = []; let m; while ((m = re.exec(t)) && out.length < 25) { out.push(t.slice(Math.max(0, m.index - 120), m.index + 160).replace(/\s+/g, " ")); re.lastIndex = m.index + 200; } return out; }).catch(() => null);
  // κλείσιμο ΧΩΡΙΣ καταχώρηση: η καρτέλα του φακέλου γυρνά στην αρχική (η φόρμα χάνεται)
  try { if (otab !== o.tab.id) await chrome.tabs.remove(otab); } catch (e) {}
  try { await bgEmrClean(o.tab.id, true); } catch (e) {}
  const brief = res.map((x) => x.err ? x.t + ": ✗ " + x.err + (x.list && x.list.length ? " [" + x.list.slice(0, 4).join(" | ") + "]" : "") : x.t + ": " + (x.nw.length ? x.nw.map((c) => c.l.slice(0, 50) + (c.opt ? " [" + c.opt.join("/") + "]" : "")).join(" ; ") : "—") + (x.dlg && x.dlg.length ? " · ΜΗΝΥΜΑ: " + x.dlg.map((d) => d.t.slice(0, 160)).join(" | ") : "") + (x.al && x.al.length ? " · alert: " + x.al.join(" | ").slice(0, 200) : "")).join("\n");
  return { status: "done", note: "🔎 Medilabi ερωτήσεις ανά εξέταση (χωρίς καταχώρηση):\n" + brief, result: { res, hints, base: s0 } };
};
JOB_KIND.medqprobe = "🔎 Medilabi: ερωτήσεις εξετάσεων";
// 📚 Κατάλογος εξετάσεων Medilabi (εργαστηριακές + απεικονιστικές: Α/Α, CT, υπέρηχοι…) για το νέο φύλλο παραγγελίας.
// Αναζητήσεις με fetch σε ΑΝΤΙΓΡΑΦΟ της φόρμας (όπως η γέφυρα) — καμία προσθήκη, ΠΟΤΕ «Καταχώρηση». Μόνο ασθενής δοκιμών.
JOB_RUNNERS.medcat = async (job) => {
  if (!/ΜΠΕΓΟ/i.test(String(job.name || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase())) return { status: "failed", note: "μόνο στον ασθενή δοκιμών (ΜΠΕΓΟΣ)" };
  const o = await orderOpenForm(job); if (o.status) return o;
  const terms = ((job.payload || {}).terms && job.payload.terms.length) ? job.payload.terms : ["Α/Α", "CT", "ΥΠΕΡΗΧ", "TRIPLEX", "MRI", "ΜΑΓΝΗΤ", "ΚΑΛΛΙΕΡΓ", "ΑΚΤΙΝ", ..."ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ".split(""), ..."ABCDEFGHIKLMNOPRSTUVWXYZ".split("")];
  const r = await medFrameExec(o.otab, async (terms) => {
    if (!/OrderTests/i.test(location.pathname) || !document.forms[0]) return null;
    const enc = (str) => { let out = ""; for (const ch of String(str)) { const c = ch.codePointAt(0); if (c < 0x80) { out += encodeURIComponent(ch).replace(/%20/g, "+"); continue; }
      let b; if (c >= 0x391 && c <= 0x3a9) b = c - 0x391 + 0xc1; else if (c >= 0x3b1 && c <= 0x3ce) b = c - 0x3b1 + 0xe1; else b = { 0x386: 0xa2, 0x388: 0xb8, 0x389: 0xb9, 0x38a: 0xba, 0x38c: 0xbc, 0x38e: 0xbe, 0x38f: 0xbf, 0x390: 0xc0, 0x3aa: 0xda, 0x3ab: 0xdb, 0x3ac: 0xdc, 0x3ad: 0xdd, 0x3ae: 0xde, 0x3af: 0xdf, 0x3b0: 0xe0 }[c];
      out += b != null ? "%" + b.toString(16).toUpperCase().padStart(2, "0") : encodeURIComponent(ch); } return out; };
    const csr = String(document.characterSet || "").toLowerCase(), iso7 = /8859-7|iso-ir-126|greek/.test(csr), w1253 = /1253/.test(csr);
    const cs = iso7 ? "iso-8859-7" : w1253 ? "windows-1253" : document.characterSet;
    const E8 = iso7 ? (x) => enc(String(x).replace(/Ά/g, "\u0000A")).replace(/%00A/g, "%B6") : w1253 ? enc : (x) => encodeURIComponent(String(x)).replace(/%20/g, "+");
    const base = document, action = new URL(base.forms[0].getAttribute("action") || location.href, location.href).href;
    const fields = (d, set) => { const out = []; for (const e of d.forms[0].querySelectorAll("input,select,textarea")) { const nm = e.getAttribute("name"); if (!nm || e.disabled) continue; const ty = (e.getAttribute("type") || "text").toLowerCase();
      if (/^(submit|image|button|reset|file|checkbox|radio)$/.test(ty)) continue; if (e.tagName === "SELECT") { const o = e.querySelector("option[selected]") || e.querySelector("option"); if (o) out.push([nm, o.getAttribute("value") ?? o.textContent]); continue; }
      if (set[nm] !== undefined || nm === "__EVENTTARGET" || nm === "__EVENTARGUMENT") continue; out.push([nm, e.value]); } return out; };
    const sName = (base.getElementById("ctl00_ContentPage_txtSearch") || {}).name || "ctl00$ContentPage$txtSearch";
    const names = new Map(); const per = {};
    for (const t of terms) {
      try {
        const body = fields(base, { [sName]: t }).concat([[sName, t], ["__EVENTTARGET", "ctl00$ContentPage$lnkSearchTest"], ["__EVENTARGUMENT", ""]]).map(([k, v]) => E8(k) + "=" + E8(v)).join("&");
        const res = await fetch(action, { method: "POST", credentials: "include", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body });
        const d2 = new DOMParser().parseFromString(new TextDecoder(cs).decode(await res.arrayBuffer()), "text/html");
        const rows = [...d2.querySelectorAll("input[type=checkbox][id*='grvTests'][id$='chkTest']")].map((c) => String((c.closest("tr") || c.parentElement).textContent || "").replace(/\s+/g, " ").trim()).filter(Boolean);
        per[t] = rows.length; for (const x of rows) names.set(x, (names.get(x) || 0) + 1);
      } catch (e) { per[t] = -1; }
    }
    return { tests: [...names.keys()].sort((a, b) => a.localeCompare(b, "el")), per };
  }, [terms]).catch((e) => ({ err: String(e.message || e) }));
  try { await bgEmrClean(o.tab.id, true); } catch (e) {}
  if (!r || !r.tests) return { status: "failed", note: "📚 " + ((r && r.err) || "δεν απάντησε το πλαίσιο του Medilabi") };
  const img = r.tests.filter((t) => /^(Α\/Α|CT|ΥΠΕΡΗΧ|U\/?S|TRIPLEX|MRI|ΜΑΓΝΗΤ)|ΑΚΤΙΝΟΓΡ/i.test(t));
  return { status: "done", note: "📚 κατάλογος Medilabi: " + r.tests.length + " εξετάσεις · απεικονιστικές " + img.length, result: { tests: r.tests, per: r.per, at: Date.now() } };
};
JOB_KIND.medcat = "📚 Medilabi: κατάλογος εξετάσεων";
// 📚 6/11 (εντολή χρήστη): κατάλογος ΑΚΡΙΒΩΣ όπως στο Medilabi — ανά τμήμα/κατηγορία (αριστερή λίστα dgLabs), με όλες τις σελίδες
// του πίνακα. ΜΟΝΟ ανάγνωση: postbacks πλοήγησης (κατηγορία/σελίδα), ΠΟΤΕ «Προσθήκη»/«Καταχώρηση». Ασθενής: ο δοκιμαστικός ή
// (payload.readonly) οποιοσδήποτε νοσηλευόμενος — η φόρμα κλείνει χωρίς τίποτα.
JOB_RUNNERS.medcat2 = async (job) => {
  const nm = String(job.name || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase();
  if (!/ΜΠΕΓΟ/.test(nm) && !(job.payload || {}).readonly) return { status: "failed", note: "μόνο ασθενής δοκιμών ή readonly" };
  const o = await orderOpenForm(job); if (o.status) return o;
  const r = await medFrameExec(o.otab, async () => {
    if (!/OrderTests/i.test(location.pathname) || !document.forms[0]) return null;
    const enc = (str) => { let out = ""; for (const ch of String(str)) { const c = ch.codePointAt(0); if (c < 0x80) { out += encodeURIComponent(ch).replace(/%20/g, "+"); continue; }
      let b; if (c >= 0x391 && c <= 0x3a9) b = c - 0x391 + 0xc1; else if (c >= 0x3b1 && c <= 0x3ce) b = c - 0x3b1 + 0xe1; else b = { 0x386: 0xa2, 0x388: 0xb8, 0x389: 0xb9, 0x38a: 0xba, 0x38c: 0xbc, 0x38e: 0xbe, 0x38f: 0xbf, 0x390: 0xc0, 0x3aa: 0xda, 0x3ab: 0xdb, 0x3ac: 0xdc, 0x3ad: 0xdd, 0x3ae: 0xde, 0x3af: 0xdf, 0x3b0: 0xe0 }[c];
      out += b != null ? "%" + b.toString(16).toUpperCase().padStart(2, "0") : encodeURIComponent(ch); } return out; };
    const csr = String(document.characterSet || "").toLowerCase(), iso7 = /8859-7|iso-ir-126|greek/.test(csr), w1253 = /1253/.test(csr);
    const cs = iso7 ? "iso-8859-7" : w1253 ? "windows-1253" : document.characterSet;
    const E8 = iso7 ? (x) => enc(String(x).replace(/Ά/g, "\u0000A")).replace(/%00A/g, "%B6") : w1253 ? enc : (x) => encodeURIComponent(String(x)).replace(/%20/g, "+");
    const cl = (x) => String(x || "").replace(/\s+/g, " ").trim();
    let doc = document, action = new URL(document.forms[0].getAttribute("action") || location.href, location.href).href;
    const fields = (d) => { const out = []; for (const e of d.forms[0].querySelectorAll("input,select,textarea")) { const n = e.getAttribute("name"); if (!n || e.disabled) continue; const ty = (e.getAttribute("type") || "text").toLowerCase();
      if (/^(submit|image|button|reset|file|checkbox|radio)$/.test(ty)) continue; if (e.tagName === "SELECT") { const op = e.querySelector("option[selected]") || e.querySelector("option"); if (op) out.push([n, op.getAttribute("value") ?? op.textContent]); continue; }
      if (n === "__EVENTTARGET" || n === "__EVENTARGUMENT") continue; out.push([n, d === document ? e.value : (e.getAttribute("value") || "")]); } return out; };
    const post = async (target, arg) => {
      const body = fields(doc).concat([["__EVENTTARGET", target], ["__EVENTARGUMENT", arg || ""]]).map(([k, v]) => E8(k) + "=" + E8(v)).join("&");
      const res = await fetch(action, { method: "POST", credentials: "include", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body });
      if (!res.ok) throw new Error("HTTP " + res.status);
      const d2 = new DOMParser().parseFromString(new TextDecoder(cs).decode(await res.arrayBuffer()), "text/html");
      if (!d2.forms[0] || !/OrderTests/i.test(res.url)) throw new Error("απρόσμενη απάντηση");
      doc = d2; action = new URL(d2.forms[0].getAttribute("action") || res.url, res.url).href;
    };
    const pbOf = (a) => { const m = /__doPostBack\('([^']+)','([^']*)'\)/.exec(a.getAttribute("href") || a.getAttribute("onclick") || ""); return m ? [m[1], m[2]] : null; };
    const labs = (d) => [...d.querySelectorAll("a[id*='dgLabs']")].map((a) => { const pb = pbOf(a); const box = a.closest("div"); const pl = box ? parseInt((box.getAttribute("style") || "").match(/padding-left:\s*(\d+)/)?.[1] || "0", 10) : 0;
      return pb && cl(a.textContent) ? { t: cl(a.textContent), tg: pb[0], ar: pb[1], lvl: pl } : null; }).filter(Boolean);
    const rows = (d) => [...d.querySelectorAll("input[type=checkbox][id*='grvTests'][id$='chkTest']")].map((c) => { const tr = c.closest("tr"); const cells = tr ? [...tr.children].map((td) => cl(td.textContent)).filter(Boolean) : [];
      return { t: cl((tr || c.parentElement).textContent), cells }; });
    const pages = (d) => [...d.querySelectorAll("a")].map(pbOf).filter((p) => p && /grvTests/i.test(p[0]) && /^Page\$/.test(p[1]));
    const sel0 = (() => { const a = doc.querySelector("a[id*='dgLabs'][style*='bold'], [id*='dgLabs'] .selected a"); return a ? cl(a.textContent) : ""; })();
    // δέντρο: κλικ σε τμήμα → ανοίγουν οι υποκατηγορίες του (μόνο όσο είναι ανοιχτό) → τις περνάμε ΑΜΕΣΩΣ, μετά το επόμενο τμήμα
    const L0 = labs(doc), tops = L0.map((x) => x.t), topSet = new Set(tops), cats = [], log = [];
    const t0 = Date.now(); let left = 0;
    const grab = async () => { const all = rows(doc); const donePg = new Set(["Page$1"]); let guard = 0;
      for (;;) { const nx = pages(doc).find((p) => !donePg.has(p[1]) && /^Page\$\d+$/.test(p[1])); if (!nx || ++guard > 40) break; donePg.add(nx[1]); await post(nx[0], nx[1]); all.push(...rows(doc)); }
      return { tests: all.map((x) => x.t), pg: donePg.size, cells: all.slice(0, 2).map((x) => x.cells) }; };
    const click = async (name) => { const c = labs(doc).find((x) => x.t === name); if (!c) return false; await post(c.tg, c.ar); return true; };
    for (let i = 0; i < tops.length; i++) {
      const top = tops[i]; if (Date.now() - t0 > 200000) { left = tops.length - i; break; }
      try {
        if (!(await click(top))) { log.push("χάθηκε: " + top); continue; }
        // υποκατηγορίες = οι γραμμές που μπήκαν ΑΜΕΣΩΣ μετά το τμήμα (μπορεί να έχουν ίδιο όνομα με τμήμα — π.χ. «ΥΠΟΛΟΓΙΣΤΙΚΗΣ ΤΟΜΟΓΡΑΦΙΑΣ»)
        const kidsAt = () => { const L = labs(doc), i = L.findIndex((x) => x.t === top), extra = L.length - tops.length; return i < 0 || extra <= 0 ? [] : L.slice(i + 1, i + 1 + extra); };
        const K0 = kidsAt();
        const g0 = await grab(); if (g0.tests.length) cats.push({ lab: top, dep: top, path: top, tests: g0.tests, n: g0.tests.length, pg: g0.pg, cells: g0.cells });
        for (let j = 0; j < K0.length; j++) {
          const kid = K0[j].t;
          try {
            let K = kidsAt(); if (!K[j] || K[j].t !== kid) { await click(top); K = kidsAt(); }
            if (!K[j] || K[j].t !== kid) { log.push("χάθηκε: " + top + " › " + kid); continue; }
            await post(K[j].tg, K[j].ar);
            const g = await grab(); cats.push({ lab: kid, dep: top, path: top + " › " + kid, tests: g.tests, n: g.tests.length, pg: g.pg, cells: g.cells });
          } catch (e) { log.push(kid + ": " + String(e.message || e).slice(0, 50)); }
        }
      } catch (e) { log.push(top + ": " + String(e.message || e).slice(0, 60)); }
    }
    return { cats, log, sel0, labs0: tops, cut: left };
  }).catch((e) => ({ err: String(e.message || e) }));
  try { await bgEmrClean(o.tab.id, true); } catch (e) {}
  if (!r || !r.cats) return { status: "failed", note: "📚 " + ((r && r.err) || "δεν απάντησε το πλαίσιο του Medilabi") };
  const tests = [...new Set(r.cats.flatMap((c) => c.tests))].sort((a, b) => a.localeCompare(b, "el"));
  return { status: "done", note: "📚 Medilabi ανά τμήμα: " + r.cats.length + " κατηγορίες · " + tests.length + " εξετάσεις" + (r.cut ? " · ⚠ έμειναν " + r.cut : "") + (r.log.length ? " · " + r.log.slice(0, 4).join(" · ") : ""), result: { cats: r.cats, tests, labs0: r.labs0, log: r.log, at: Date.now() } };
};
JOB_KIND.medcat2 = "📚 Medilabi: κατάλογος ανά τμήμα";

// 📦 6/11: έτοιμα προφίλ (πακέτα) του Medilabi — ΜΟΝΟ ανάγνωση της λίστας προφίλ της φόρμας παραγγελίας (ασθενής δοκιμών),
// χωρίς κανένα κλικ/καταχώριση. Ό,τι γράφει κάθε γραμμή (όνομα + περιγραφή/εξετάσεις αν υπάρχουν) γυρίζει στο Παραδόχαρτο.
JOB_RUNNERS.medprof = async (job) => {
  if (!/ΜΠΕΓΟ/i.test(String(job.name || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase())) return { status: "failed", note: "μόνο στον ασθενή δοκιμών (ΜΠΕΓΟΣ)" };
  const o = await orderOpenForm(job); if (o.status) return o;
  const r = await medFrameExec(o.otab, () => {
    if (!/OrderTests/i.test(location.pathname)) return null;
    const T = (x) => String(x && (x.innerText || x.textContent) || "").replace(/\s+/g, " ").trim();
    const links = [...document.querySelectorAll("a[id*='dgProf']")];
    const out = links.map((a) => { const tr = a.closest("tr"); const cells = tr ? [...tr.children].map(T).filter(Boolean) : []; return { name: T(a), title: a.getAttribute("title") || "", row: cells.join(" | ").slice(0, 400) }; }).filter((x) => x.name);
    const tbl = links[0] && links[0].closest("table"); const head = tbl ? T(tbl.querySelector("tr")).slice(0, 200) : "";
    return { profiles: out, head };
  }).catch((e) => ({ err: String(e.message || e) }));
  try { await bgEmrClean(o.tab.id, true); } catch (e) {}
  if (!r || !r.profiles) return { status: "failed", note: "📦 " + ((r && r.err) || "δεν βρέθηκε η λίστα προφίλ στη φόρμα του Medilabi") };
  return { status: "done", note: "📦 Medilabi: " + r.profiles.length + " έτοιμα προφίλ", result: { profiles: r.profiles, head: r.head, at: Date.now() } };
};
JOB_KIND.medprof = "📦 Medilabi: έτοιμα προφίλ";
JOB_LIMIT_S.medprof = 150;
const JOB_APPROVE = {};
JOB_APPROVE.rx = (job) => (job.payload && job.payload.test) ? { status: "dismissed", note: "🧪 δοκιμαστική — ΔΕΝ καταχωρείται" } : self.EFEpres.approve(job);   // 📱 «Καταχώριση» μόνο από το κινητό, μετά από έλεγχο (5/11) — ΠΟΤΕ αυτόματα
JOB_APPROVE.ref = (job) => (job.payload && job.payload.test) ? { status: "dismissed", note: "🧪 δοκιμαστική — ΔΕΝ καταχωρείται" } : self.EFEpres.refApprove(job);   // 📋 ίδιοι έλεγχοι με τη συνταγή — ΠΟΤΕ αυτόματα
JOB_APPROVE.discharge = async (job) => {
  if (job.payload && job.payload.test) return { status: "dismissed", note: "🧪 δοκιμαστική — ΔΕΝ αποθηκεύεται" };   // ⛔ 8/11
  const r = job.payload?.result || {};
  if (!r.tabId) return { status: "failed", note: "δεν βρέθηκε η φόρμα" };
  const now = await bgReadDischarge(r.tabId);
  if (!now) return { status: "failed", note: "η φόρμα εξιτηρίου δεν είναι πια ανοιχτή στο παράθυρο του bot" };
  if (now.patient !== r.patient || now.opinion !== r.opinion || now.doctor !== r.doctor) return { status: "failed", note: "η φόρμα άλλαξε μετά τον έλεγχο — δεν αποθηκεύτηκε" };
  const { efbot } = await chrome.storage.local.get("efbot");
  const sel = efbot?.settings?.emrSaveSel;
  if (!sel) return { status: "approved", note: "εγκρίθηκε — η αποθήκευση γίνεται ακόμα από τον υπολογιστή (παράθυρο του bot)", push: ["✅ Εξιτήριο εγκρίθηκε", `${job.name}: πατήστε Αποθήκευση στο παράθυρο του bot στον υπολογιστή`] };
  return { status: "approved", note: "εγκρίθηκε" };
};
// 🔎 Μήνυμα επιβεβαίωσης του Medilabi μετά την «Καταχώρηση» (ctl00_ContentPage_vrdDialog, κουμπί btnContinueToOrder).
// ΜΟΝΟ ανάγνωση: κείμενο, κουμπιά, πίνακες. null = δεν φαίνεται.
async function medVrdRead(tabId) {
  return medFrameExec(tabId, () => {
    if (!/OrderTests/i.test(location.pathname)) return { gone: true };
    const vis = (e) => { if (!e) return false; const b = e.getBoundingClientRect(); const cs = getComputedStyle(e); return b.width > 0 && b.height > 0 && cs.visibility !== "hidden" && cs.display !== "none"; };
    const btn = document.getElementById("ctl00_ContentPage_vrdDialog_btnContinueToOrder");
    let box = document.getElementById("ctl00_ContentPage_vrdDialog");
    if (!box && btn) { box = btn; for (let k = 0; k < 8 && box.parentElement; k++) { box = box.parentElement; if ((box.innerText || "").replace(/\s+/g, " ").trim().length > 40) break; } }
    const shown = vis(btn) || (vis(box) && [...(box ? box.querySelectorAll("input,button,a") : [])].some(vis));
    if (!shown) return null;
    const clean = (t) => String(t || "").replace(/[ \t]+/g, " ").replace(/\n\s*\n+/g, "\n").trim();
    const text = clean(box ? box.innerText : "").slice(0, 2500);
    const btns = [...(box ? box.querySelectorAll("input[type=submit],input[type=button],button,a") : [])].filter(vis).map((e) => ({ id: e.id || "", v: (e.value || e.innerText || e.title || "").trim().slice(0, 40), on: (e.getAttribute("onclick") || e.getAttribute("href") || "").slice(0, 200) }));
    const rows = box ? [...box.querySelectorAll("tr")].filter(vis).map((tr) => [...tr.children].map((c) => clean(c.innerText).slice(0, 60))).filter((r) => r.some(Boolean)).slice(0, 30) : [];
    const title = clean((box && (box.querySelector("[id$=lblTitle],[id$=Title],h1,h2,h3,.title,th") || {}).innerText) || "").slice(0, 120);
    const done = [...document.querySelectorAll("input[type=submit],input[type=button],button,a")].filter(vis).some((e) => /^καταχ[ωώ]ρηση$/i.test((e.value || e.innerText || "").trim()));
    return { title, text, btns, rows, cont: btn ? { v: (btn.value || btn.innerText || "").trim(), vis: vis(btn) } : null, formBtnVisible: done };
  }).catch((e) => ({ err: String(e.message || e).slice(0, 120) }));
}
// 🧾 Έγκριση παραγγελίας από το κινητό: η φόρμα του Medilabi πρέπει να είναι ακόμα ανοιχτή στο παράθυρο του bot.
// Βήμα 1: πατιέται ΜΟΝΟ το κουμπί «Καταχώρηση». Αν το Medilabi βγάλει μήνυμα (vrdDialog) → ΔΕΝ λέμε «καταχωρήθηκε»:
// η εργασία γυρνά σε «review» με το κείμενο του μηνύματος για ΔΕΥΤΕΡΗ έγκριση από το κινητό.
// Βήμα 2 (stage «vrd»): πατιέται ΜΟΝΟ το btnContinueToOrder του μηνύματος και ελέγχεται τι έγινε.
JOB_APPROVE.order = async (job) => {
  if (job.payload && job.payload.test) return { status: "dismissed", note: "🧪 δοκιμαστική παραγγελία — ΔΕΝ καταχωρείται ποτέ" };   // ⛔ 8/11
  const r = job.payload?.result || {};
  if (!r.tabId) return { status: "failed", note: "δεν βρέθηκε η φόρμα της παραγγελίας" };
  const t = await chrome.tabs.get(r.tabId).catch(() => null);
  if (!t) return { status: "failed", note: "η φόρμα παραγγελίας έκλεισε στο παράθυρο του bot — στείλτε ξανά την παραγγελία" };
  const t0w = t.windowId;
  // 🪪 ξανά-έλεγχος ασθενή ΑΜΕΣΩΣ πριν από κάθε κλικ: λάθος → άρνηση· ήταν «ok» και τώρα όχι → άρνηση·
  // άγνωστο και πριν και τώρα → επιτρέπεται (η χειροκίνητη έγκριση είδε την προειδοποίηση)
  // επανέλεγχος ΧΩΡΙΣ τη μπάρα του ΝΠΣ (η καρτέλα ΝΠΣ μπορεί στο μεταξύ να άνοιξε άλλον ασθενή για άλλη εργασία — έλεγχος 5/11)
  const pt = await medPatCheck(r.tabId, null, job.name), pt0 = (r.medPt || {}).st;
  if ((r.medPt || {}).amH && pt.amH && pt.amH !== r.medPt.amH) pt.st = "mismatch", pt.why = "ο ΑΜΚΑ της φόρμας άλλαξε από τη συμπλήρωση";
  else if ((r.medPt || {}).amH && pt.amH === r.medPt.amH && pt.st !== "mismatch") pt.st = "ok";   // ίδιος ΑΜΚΑ φόρμας με τη συμπλήρωση
  if (pt.st === "mismatch") return { status: "failed", note: medPtBad(job, pt) + " — ΔΕΝ πατήθηκε «Καταχώρηση»", result: { ...r, medPt2: pt } };
  if (pt0 === "ok" && pt.st !== "ok") return { status: "failed", note: "⛔ ο ασθενής στη φόρμα Medilabi δεν επιβεβαιώνεται πια (πριν: ok, τώρα: " + pt.st + (pt.seen ? " «" + pt.seen.slice(0, 80) + "»" : "") + ") — ΔΕΝ πατήθηκε «Καταχώρηση», ελέγξτε στο Medilabi", result: { ...r, medPt2: pt } };
  if (r.stage === "vrd") {
    const v = await medVrdRead(r.tabId);
    // 8/11 (εντολή χρήστη «πάτα ό,τι χρειάζεται»): το μήνυμα έκλεισε ήδη (το OK είχε πατηθεί, το Medilabi άργησε) → συνεχίζει
    // με τα επόμενα βήματα (Ειδικές Πληροφορίες, έλεγχος ότι καταχωρίστηκε) — ΟΧΙ ξανά «Καταχώρηση» από την αρχή
    if (v && v.gone && !v.err && (await medFrameExec(r.tabId, () => /OrderTests/i.test(location.pathname)).catch(() => false))) return medOrderAfter(job, r, t0w, { vrdGone: true });
    if (!v || v.gone || v.err) return { status: "failed", note: "το μήνυμα του Medilabi δεν είναι πια ανοιχτό — ελέγξτε την παραγγελία στο Medilabi" + (v && v.err ? " (" + v.err + ")" : "") };
    if (r.vrd && r.vrd.text && v.text !== r.vrd.text) return { status: "review", note: "⚠ το μήνυμα του Medilabi άλλαξε — δείτε το ξανά πριν την έγκριση", result: { ...r, vrd: v, vrdAt: Date.now() }, push: ["⚠ Παραγγελία: νέο μήνυμα Medilabi", (job.name || "") + " · " + String(v.text).slice(0, 90)] };
    const sig0 = await medSig(r.tabId);
    if (self.efDeadJobs && self.efDeadJobs.has(job.id)) return { status: "failed", note: "⏱ η έγκριση έληξε πριν το πάτημα — ΔΕΝ πατήθηκε «Καταχώρηση» στο Medilabi" };
    const ck = await medFrameExec(r.tabId, () => { const b = document.getElementById("ctl00_ContentPage_vrdDialog_btnContinueToOrder"); if (!b || b.getBoundingClientRect().width <= 0) return false; b.click(); return true; });
    if (!ck) return { status: "failed", note: "δεν βρέθηκε το κουμπί του μηνύματος — πατήστε το στον υπολογιστή" };
    for (let i = 0; i < 60; i++) { await E.sleep(250); const now = await medSig(r.tabId); if (now && now !== sig0) break; }
    return medOrderAfter(job, r, t0w, { vrd: v });
  }
  const before = await medSig(r.tabId);
  if (self.efDeadJobs && self.efDeadJobs.has(job.id)) return { status: "failed", note: "⏱ η έγκριση έληξε πριν το πάτημα — ΔΕΝ πατήθηκε «Καταχώρηση» στο Medilabi" };
  const res = await medFrameExec(r.tabId, () => {
    if (!/OrderTests/i.test(location.pathname)) return null;
    const nz = (s) => String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/\s+/g, " ").trim();
    const els = [...document.querySelectorAll("input[type=submit],input[type=button],button,a")].filter((e) => { const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0; });
    const lab = (e) => (e.value || e.innerText || e.title || "").trim();
    const b = els.find((e) => /^καταχωρηση$/.test(nz(lab(e))));
    if (!b) return { err: "nobtn", list: els.map(lab).filter((x) => x && x.length < 40).slice(0, 25) };
    b.click(); return { ok: true };
  });
  if (!res) return { status: "failed", note: "η φόρμα του Medilabi δεν είναι πια ανοιχτή — στείλτε ξανά την παραγγελία" };
  if (res.err) return { status: "failed", note: "δεν βρέθηκε το κουμπί «Καταχώρηση» — πατήστε το στον υπολογιστή · κουμπιά: " + (res.list || []).join(" | ") };
  for (let i = 0; i < 60; i++) { await E.sleep(250); const now = await medSig(r.tabId); if (now && now !== before) break; }
  await bgSettle(r.tabId, 2500);
  const v = await medVrdRead(r.tabId);
  // ✅ Μήνυμα «Μη προβλεπόμενες εξετάσεις βάσει πρωτοκόλλων» (reflex κ.λπ.): εντολή χρήστη — τσεκάρονται ΟΛΕΣ οι
  // εξετάσεις που επιτρέπει το μήνυμα και πατιέται OK αμέσως (χωρίς 2η έγκριση). Άλλα, άγνωστα μηνύματα → 2η έγκριση όπως πριν.
  if (v && !v.gone && !v.err && /πρωτοκ[οό]λλ|reflex|δε συνιστ[αά]ται|Επιλ[εέ]ξτε τις εξετ[αά]σεις/i.test(v.text || "")) {
    const sig0 = await medSig(r.tabId);
    if (self.efDeadJobs && self.efDeadJobs.has(job.id)) return { status: "failed", note: "⏱ η έγκριση έληξε πριν το πάτημα — ΔΕΝ πατήθηκε «Καταχώρηση» στο Medilabi" };
    const ck = await medFrameExec(r.tabId, () => {
      const b = document.getElementById("ctl00_ContentPage_vrdDialog_btnContinueToOrder");
      if (!b || b.getBoundingClientRect().width <= 0) return null;
      // το πλαίσιο του μηνύματος: id vrdDialog, αλλιώς ο πρώτος πρόγονος του κουμπιού που έχει checkbox (πριν: b.closest("div") → άδειο → 0 τσεκ!)
      let box = document.getElementById("ctl00_ContentPage_vrdDialog");
      if (!box || !box.querySelector("input[type=checkbox]")) { let e = b; for (let k = 0; k < 12 && e.parentElement; k++) { e = e.parentElement; if (e.querySelector("input[type=checkbox]")) { box = e; break; } } }
      let cbs = box ? [...box.querySelectorAll("input[type=checkbox]")] : [];
      if (!cbs.length) cbs = [...document.querySelectorAll("input[type=checkbox][id*='vrd'],input[type=checkbox][name*='vrd']")];
      const lbl = (c) => { const l = c.id && document.querySelector('label[for="' + CSS.escape(c.id) + '"]'); const tr = c.closest("tr"); return String((l && l.innerText) || (tr && tr.innerText) || c.parentElement.innerText || "").replace(/\s+/g, " ").trim().slice(0, 80); };
      let n = 0; const dis = [], on = [];
      for (const c of cbs) {
        if (c.disabled) { dis.push(lbl(c)); continue; }
        if (!c.checked) { c.click(); if (!c.checked) { c.checked = true; c.dispatchEvent(new Event("change", { bubbles: true })); } n++; }
        on.push(lbl(c));
      }
      b.click(); return { n, dis, on, total: cbs.length };
    });
    if (ck) {
      for (let i = 0; i < 60; i++) { await E.sleep(250); const now = await medSig(r.tabId); if (now && now !== sig0) break; }
      return medOrderAfter(job, { ...r, stage: "vrd" }, t0w, { vrd: v, vrdAuto: ck.n, vrdDis: ck.dis || [], vrdOn: ck.on || [], vrdTotal: ck.total || 0 });
    }
  }
  if (v && !v.gone && !v.err) {
    const lbl = (v.cont && v.cont.v) || "OK";
    return { status: "review", note: "⚠ ΔΕΝ ολοκληρώθηκε ακόμα: το Medilabi ζητά επιβεβαίωση — «" + String(v.text || v.title || "").replace(/\s+/g, " ").slice(0, 200) + "» · με τη δεύτερη έγκριση το bot πατά «" + lbl + "»", result: { ...r, stage: "vrd", vrd: v, vrdAt: Date.now() }, push: ["⚠ Παραγγελία: χρειάζεται 2η έγκριση", (job.name || "") + " · " + String(v.text || "").replace(/\s+/g, " ").slice(0, 90)] };
  }
  return medOrderAfter(job, r, t0w, {});
};
// 📝 «Παρακαλώ συμπληρώστε τις Ειδικές Πληροφορίες της παραγγελίας» (π.χ. CRP): εντολή χρήστη 04/11 —
// OK στο μήνυμα → ερωτηματολόγιο: ΟΛΑ τα dropdown «Όχι» → τσεκ «Υπογραφή ιατρού» → τσεκ «Φλεβοκαθετήρας» (ή «Αντιβιοτικά»)
// → «Αποθήκευση». Ό,τι δεν ταιριάζει ακριβώς → σταματά και αναφέρει (καμία εικασία).
async function medSpecialInfo(tabId) {
  const out = { steps: [] };
  const wait = async (sig0, ms = 9000) => { for (let i = 0; i < ms / 150; i++) { await new Promise((x) => setTimeout(x, 150)); const now = await medSig(tabId); if (now && now !== sig0) break; } await bgSettle(tabId, 2000); };
  // 1) το μήνυμα
  const m = await medFrameExec(tabId, () => {
    const q = (id) => document.getElementById(id), vis = (e) => !!e && e.getBoundingClientRect().width > 0 && getComputedStyle(e).visibility !== "hidden";
    for (const pre of ["ctl00_msgInfo", "ctl00_msgBoxMessage"]) {
      const t = ((q(pre + "_lblMessage") || {}).innerText || "").replace(/\s+/g, " ").trim();
      if (/ειδικ\S*\s+πληροφορ/i.test(t) && vis(q(pre + "_btnButton1"))) return { pre, t };
    }
    return null;
  });
  if (!m) return null;
  out.msg = m.t;
  let sig0 = await medSig(tabId);
  await medFrameExec(tabId, (pre) => { const b = document.getElementById(pre + "_btnButton1"); if (b) b.click(); return true; }, [m.pre]);
  await wait(sig0); out.steps.push("OK μηνύματος");
  // 2) dropdown «Όχι» / checkboxes — ένα-ένα (μπορεί να κάνουν postback)
  for (let k = 0; k < 40; k++) {
    sig0 = await medSig(tabId);
    const r = await medFrameExec(tabId, () => {
      const vis = (e) => { const b = e.getBoundingClientRect(); const cs = getComputedStyle(e); return b.width > 0 && b.height > 0 && cs.visibility !== "hidden" && cs.display !== "none"; };
      const nz = (x) => String(x || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/\s+/g, " ").trim();
      const lbl = (c) => { const l = c.id && document.querySelector('label[for="' + CSS.escape(c.id) + '"]'); const tr = c.closest("tr"); return String((l && l.innerText) || (tr && tr.innerText) || (c.parentElement && c.parentElement.innerText) || c.id || "").replace(/\s+/g, " ").trim().slice(0, 90); };
      const pb = (e) => /__doPostBack/.test(e.getAttribute("onchange") || e.getAttribute("onclick") || "");
      // περιοχή «Ειδικές Πληροφορίες»: το μικρότερο ορατό στοιχείο με τον τίτλο που περιέχει πεδία
      let area = null;
      for (const e of document.querySelectorAll("div,fieldset,table,span,td")) {
        if (!vis(e) || !/ειδικ\S*\s+πληροφορ|ερωτηματολογ/i.test(e.innerText || "")) continue;
        if (!e.querySelector("select,input[type=checkbox]")) continue;
        if (!area || area.contains(e)) area = e;
      }
      const root = area || document;
      // 8/11 (εντολή χρήστη): τα «Όχι» είναι στην ενότητα «Κατάσταση ασθενούς κατά τη δειγματοληψία» — και αν είναι έξω από την περιοχή
      const inState = (x) => { for (let e = x.parentElement, i = 0; e && i < 8; e = e.parentElement, i++) if (/κατασταση ασθενους/.test(nz(e.innerText).slice(0, 400))) return true; return false; };
      const sels = [...new Set([...root.querySelectorAll("select"), ...[...document.querySelectorAll("select")].filter(inState)])].filter((x) => vis(x) && !x.disabled);
      for (const x of sels) {
        const o = [...x.options].find((o) => /^(οχι|oxi)$/.test(nz(o.text)));   // 8/11: και λατινικό «OXI» (Χειρουργική επέμβαση: OXI / NAI<72h / NAI<24h)
        if (!o || x.value === o.value) continue;
        x.value = o.value; x.dispatchEvent(new Event("change", { bubbles: true }));
        return { did: "όχι: " + lbl(x), pb: pb(x), area: !!area };
      }
      // ✍ 8/11 (εντολή χρήστη): το υποχρεωτικό πλαίσιο κειμένου → «-» (μόνο κενά πλαίσια· μέσα στην περιοχή, ή textarea αν δεν βρέθηκε περιοχή)
      // «Αιτιολόγηση εξετάσεων / Πιθανή νόσος» (υποχρεωτικό) — βρίσκεται και έξω από την περιοχή
      const why = [...document.querySelectorAll("textarea,input[type=text]")].filter((x) => /αιτιολογ|πιθανη νοσ/.test(nz(lbl(x)) + " " + nz(x.id) + " " + nz(x.placeholder)));
      const txs = [...why, ...(area ? area.querySelectorAll("textarea,input[type=text]") : document.querySelectorAll("textarea"))].filter((x) => vis(x) && !x.disabled && !x.readOnly && !String(x.value || "").trim());
      if (txs.length) { const x = txs[0]; x.focus(); x.value = "-"; x.dispatchEvent(new Event("input", { bubbles: true })); x.dispatchEvent(new Event("change", { bubbles: true })); x.blur(); return { did: "κείμενο «-»: " + lbl(x), pb: pb(x), area: !!area }; }
      const cbs = [...root.querySelectorAll("input[type=checkbox]")].filter((x) => vis(x) && !x.disabled);
      // υπογραφή ιατρού: πρώτα στην περιοχή, αλλιώς οπουδήποτε στη σελίδα (μπορεί να είναι έξω από το πλαίσιο)
      const allCb = [...document.querySelectorAll("input[type=checkbox]")].filter((x) => vis(x) && !x.disabled);
      const sig = cbs.find((x) => /υπογραφ/.test(nz(lbl(x)))) || allCb.find((x) => /υπογραφ|ψηφιακ\S* υπογρ/.test(nz(lbl(x))));
      const sigExists = !!sig || /υπογραφ/.test(nz(document.body.innerText));
      if (sig && !sig.checked) { sig.click(); if (!sig.checked) { sig.checked = true; sig.dispatchEvent(new Event("change", { bubbles: true })); } return { did: "τσεκ: " + lbl(sig), pb: pb(sig), area: !!area }; }
      const pick = cbs.filter((x) => /φλεβοκαθετ|αντιβιοτ/.test(nz(lbl(x))));
      if (pick.length && !pick.some((x) => x.checked)) { const c = pick.find((x) => /φλεβοκαθετ/.test(nz(lbl(x)))) || pick[0]; c.click(); if (!c.checked) { c.checked = true; c.dispatchEvent(new Event("change", { bubbles: true })); } return { did: "τσεκ: " + lbl(c), pb: pb(c), area: !!area }; }
      return { done: true, area: !!area, nSel: sels.length, nCb: cbs.length, sig: !!sig, sigExists, pick: pick.length,
        labels: [...sels.map((x) => "▾ " + lbl(x) + " = " + (x.options[x.selectedIndex] || {}).text), ...cbs.map((x) => (x.checked ? "☑ " : "☐ ") + lbl(x))].slice(0, 30) };
    });
    if (!r) { out.err = "η φόρμα δεν απαντά"; return out; }
    if (r.done) { Object.assign(out, { area: r.area, nSel: r.nSel, nCb: r.nCb, labels: r.labels, sigOk: r.sig, sigExists: r.sigExists, pickN: r.pick }); break; }
    out.steps.push(r.did);
    if (r.pb) await wait(sig0, 6000); else await new Promise((x) => setTimeout(x, 120));
  }
  // ασφάλεια: χωρίς υπογραφή ιατρού ή χωρίς κανένα πεδίο → ΔΕΝ αποθηκεύουμε
  // χωρίς πεδίο υπογραφής σε αυτό το ερωτηματολόγιο (π.χ. μόνο checkboxes): αρκεί το τσεκ (φλεβοκαθετήρας/αντιβιοτικά)
  if ((!out.sigOk && (out.sigExists || !out.pickN)) || !(out.nSel || out.nCb)) { out.err = "δεν βρέθηκε το ερωτηματολόγιο όπως περιγράφηκε (υπογραφή ιατρού: " + (out.sigOk ? "ναι" : "όχι") + ")"; return out; }
  // 3) Αποθήκευση (ΠΟΤΕ άλλο κουμπί)
  sig0 = await medSig(tabId);
  const sv = await medFrameExec(tabId, () => {
    const vis = (e) => { const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0; };
    const nz = (x) => String(x || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/\s+/g, " ").trim();
    const all = [...document.querySelectorAll("input[type=submit],input[type=button],input[type=image],button,a")].filter(vis);
    const txt = (e) => nz(e.value || e.innerText || e.title || e.alt || "");
    // 8/11: και «Αποθήκευση πληροφοριών/στοιχείων…» (ΠΟΤΕ «Καταχώρηση»/«Ακύρωση»/«Διαγραφή»)
    const b = all.find((e) => /^αποθηκευση( ειδικων πληροφοριων)?$/.test(txt(e))) || all.find((e) => /^αποθηκευσ/.test(txt(e)) && !/καταχωρ|ακυρ|διαγραφ/.test(txt(e)));
    if (!b) return null; b.click(); return (b.value || b.innerText || b.title || "").trim() || "αποθήκευση";
  });
  if (!sv && out.sigOk && out.steps.some((x) => /κείμενο «-»/.test(x))) {
    // 8/11: σε αυτή τη μορφή η φόρμα δεν έχει ξεχωριστή «Αποθήκευση» — τα πεδία είναι μέρος της παραγγελίας → ξανά «Καταχώρηση» (από τον καλούντα)
    out.steps.push("χωρίς ξεχωριστή «Αποθήκευση»"); out.saved = true; out.noSave = true;
  }
  if (!sv && !out.saved) {
    // 🔎 8/11: τι υπάρχει σε ΚΑΘΕ πλαίσιο της σελίδας (μόνο ανάγνωση) — για να διορθωθεί με σιγουριά
    const dg = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, world: "MAIN", func: () => {
      const vis = (e) => { const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0; };
      const t = (e) => String(e.value || e.innerText || e.title || e.alt || e.getAttribute("aria-label") || "").replace(/\s+/g, " ").trim().slice(0, 50);
      const cl = [...document.querySelectorAll("input[type=submit],input[type=button],input[type=image],button,a,[onclick]")].filter(vis).map((e) => e.tagName.toLowerCase() + (e.id ? "#" + e.id.replace(/^ctl00_ContentPage_/, "") : "") + "«" + t(e) + "»").slice(0, 30);
      const fl = [...document.querySelectorAll("textarea,select,input[type=text],input[type=checkbox],input[type=radio]")].filter(vis).map((e) => e.tagName.toLowerCase() + ":" + (e.type || "") + (e.id ? "#" + e.id.replace(/^ctl00_ContentPage_/, "") : "") + (e.checked ? "☑" : "")).slice(0, 20);
      return { u: location.pathname.slice(-40), cl, fl };
    } }).catch(() => []);
    out.diag = (dg || []).map((x) => x && x.result).filter(Boolean);
    out.err = "δεν βρέθηκε κουμπί «Αποθήκευση» · " + JSON.stringify(out.diag).slice(0, 700); return out;
  }
  if (sv) { await wait(sig0); out.steps.push("«" + sv + "»"); out.saved = true; }
  return out;
}
async function medOrderAfter(job, r, t0w, extra) {
  await bgSettle(r.tabId, 2500);
  // 📝 Ειδικές Πληροφορίες (εντολή χρήστη): συμπλήρωση + αποθήκευση, και ξανά «Καταχώρηση» αν η φόρμα την ζητά ακόμα
  let spec = null;
  try {
    spec = await medSpecialInfo(r.tabId);
    if (spec && spec.saved) {
      const again = await medFrameExec(r.tabId, () => {
        const vis = (e) => { const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0; };
        const b = [...document.querySelectorAll("input[type=submit],input[type=button],button,a")].filter(vis).find((e) => /^καταχ[ωώ]ρηση$/i.test((e.value || e.innerText || "").trim()) || /btnDone$/.test(e.id || ""));
        return b ? (b.click(), true) : false;
      });
      if (!again && spec.noSave) { spec.saved = false; spec.err = "δεν βρέθηκε ούτε «Αποθήκευση» ούτε «Καταχώρηση»"; }
      if (again) { const s0 = await medSig(r.tabId); for (let i = 0; i < 60; i++) { await E.sleep(250); const now = await medSig(r.tabId); if (now && now !== s0) break; } await bgSettle(r.tabId, 2500); spec.steps.push("ξανά «Καταχώρηση»"); }
    }
    if (spec && !spec.saved) return { status: "review", note: "⚠ ΔΕΝ ολοκληρώθηκε: το Medilabi ζητά «Ειδικές Πληροφορίες» και " + (spec.err || "δεν συμπληρώθηκαν") + " — συμπληρώστε τις στον υπολογιστή · βρέθηκαν: " + (spec.labels || []).join(" · ").slice(0, 400), result: { ...r, spec }, push: ["⚠ Παραγγελία: Ειδικές Πληροφορίες", (job.name || "") + " — " + (spec.err || "")] };
  } catch (e) { spec = { err: e.message }; }
  if (spec) extra = Object.assign({}, extra || {}, { spec });
  // 🖨 Μήνυμα του Medilabi μετά την καταχώρηση (κουμπί «OK»): ο γιατρός πατά OK και τότε φεύγει το barcode.
  // Το bot πατά OK ΜΟΝΟ αν το μήνυμα είναι επιβεβαίωση επιτυχίας/εκτύπωσης — ΠΟΤΕ σε ερώτηση/προειδοποίηση (π.χ. «υπάρχει ήδη…»).
  let mbox = null;
  try {
    const readBox = () => medFrameExec(r.tabId, () => {
      if (!/OrderTests/i.test(location.pathname)) return null;
      const q = (id) => document.getElementById(id);
      for (const pre of ["ctl00_msgBoxMessage", "ctl00_msgInfo"]) {
        const b1 = q(pre + "_btnButton1"), b2 = q(pre + "_btnButton2");
        const vis = (e) => !!e && e.getBoundingClientRect().width > 0 && getComputedStyle(e).visibility !== "hidden";
        if (!vis(b1) && !vis(b2)) continue;
        return { pre, title: ((q(pre + "_lblTitle") || {}).innerText || "").trim(), msg: ((q(pre + "_lblMessage") || {}).innerText || "").replace(/\s+/g, " ").trim().slice(0, 300),
          b1: vis(b1) ? { v: b1.value, on: (b1.getAttribute("onclick") || "").slice(0, 300) } : null, b2: vis(b2) ? { v: b2.value, on: (b2.getAttribute("onclick") || "").slice(0, 300) } : null };
      }
      return null;
    });
    mbox = await readBox();
    if (mbox) {
      const txt = (mbox.title + " " + mbox.msg).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
      const okText = /καταχωρ|επιτυχ|ολοκληρ|barcode|εκτυπ|ετικετ|αποθηκ/.test(txt);
      const risky = /ηδη|υπαρχει|διπλ|θελετε|συνεχ|σφαλμ|λαθ|error|προσοχ|warning|ακυρ/.test(txt);
      const onlyOk = mbox.b1 && /^ok$/i.test(String(mbox.b1.v).trim()) && !mbox.b2;
      if (onlyOk && okText && !risky) {
        const sig0 = await medSig(r.tabId);
        await medFrameExec(r.tabId, (pre) => { const b = document.getElementById(pre + "_btnButton1"); if (b) b.click(); return true; }, [mbox.pre]);
        for (let i = 0; i < 40; i++) { await new Promise((x) => setTimeout(x, 150)); const now = await medSig(r.tabId); if (now && now !== sig0) break; }
        await bgSettle(r.tabId, 2000);
        mbox.clicked = true;
      } else mbox.clicked = false;
    }
  } catch (e) { mbox = { err: e.message }; }
  // 🖨 μετά την καταχώρηση: τι προσπάθησε να ανοίξει/τυπώσει η σελίδα (για το barcode)
  let printAfter = null;
  try { printAfter = await medFrameExec(r.tabId, () => {
    const RE = /print|barcode|etiket|ετικ|label|window\.open|showModalDialog|localhost|127\.0\.0\.1|ActiveX|zebra|zpl|websocket|qz\./i;
    const inl = [...document.scripts].filter((x) => !x.src).map((x) => x.textContent).join("\n");
    const out = []; let m; const re = new RegExp(RE.source, "gi"); while ((m = re.exec(inl)) && out.length < 12) { out.push(inl.slice(Math.max(0, m.index - 90), m.index + 160).replace(/\s+/g, " ")); re.lastIndex = m.index + 160; }
    const ifr = [...document.querySelectorAll("iframe,frame,object,embed")].map((f) => (f.src || f.data || "").replace(location.origin, "").slice(0, 120));
    const btns = [...document.querySelectorAll("input[type=submit],input[type=button],button,a")].filter((e) => { const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0; }).map((e) => (e.value || e.innerText || "").trim()).filter((t) => t && t.length < 40).slice(0, 30);
    // κλήση προς τον «Barcode Print Spooler» που έβαλε η σελίδα + αν την έκανε ήδη (performance entries)
    const calls = [...inl.matchAll(/Send(Order|Raw)BarcodesToBarcodePrintSpooler\s*\(\s*['"]([^'"]+)['"]/g)].map((m) => ({ kind: m[1], url: new URL(m[2], location.href).href }));
    const bc = [...document.scripts].filter((x) => !x.src && /barcode|spooler/i.test(x.textContent)).map((x) => x.textContent.replace(/\s+/g, " ").slice(0, 600));
    const ent = performance.getEntriesByType("resource").filter((e) => /spool|barcode|127\.0\.0\.1|localhost/i.test(e.name)).map((e) => ({ u: e.name.slice(0, 120), st: e.responseStatus || 0, ms: Math.round(e.duration) }));
    let ls = []; try { ls = Object.keys(localStorage).slice(0, 20); } catch (e) {}
    return { path: location.pathname, scripts: out, frames: ifr, btns, calls, bc, ent, cookies: document.cookie.split(";").map((c) => c.split("=")[0].trim()).filter(Boolean).slice(0, 20), ls };
  }); } catch (e) { printAfter = { err: e.message }; }
  // 🖨 Αν η σελίδα ζήτησε εκτύπωση barcode αλλά ΔΕΝ έγινε η κλήση (π.χ. μπλοκαρίστηκε στο παράθυρο του bot), τη στέλνει το bot.
  // Μόνο αν δεν υπάρχει ήδη αίτημα προς την ίδια διεύθυνση (για να μη βγουν διπλά barcode).
  try {
    for (const c of (printAfter && printAfter.calls) || []) {
      if (c.kind !== "Order") continue;
      const did = (printAfter.ent || []).some((e) => e.u && c.url.startsWith(e.u.slice(0, 60)));
      if (did) { c.sent = "η σελίδα το έστειλε"; continue; }
      const rr = await fetch(c.url, { method: "GET" }).then(async (x) => ({ st: x.status, t: (await x.text()).slice(0, 120) })).catch((e) => ({ err: String(e.message || e).slice(0, 80) }));
      c.sent = "από το bot"; c.res = rr;
      if (rr.err || rr.st >= 400) {   // ξανά μέσα από τη σελίδα (με τη σύνδεση του Medilabi)
        c.res2 = await medFrameExec(r.tabId, async (u) => { try { const x = await fetch(u, { credentials: "include" }); return { st: x.status, t: (await x.text()).slice(0, 120) }; } catch (e) { return { err: String(e.message || e).slice(0, 80) }; } }, [c.url]);
      }
    }
  } catch (e) {}
  try { printAfter = Object.assign(printAfter || {}, { tabs: (await chrome.tabs.query({}).catch(() => [])).filter((t) => t.windowId === (t0w || -1) || /print|barcode|etiket/i.test(t.url || "")).map((t) => String(t.url || t.pendingUrl || "").replace(/\?.*$/, "").slice(0, 100)) }); } catch (e) {}
  const msg = await medFrameExec(r.tabId, () => { const e = document.querySelector("[id*='lblMessage'],[id*='lblMsg'],[id*='msgBox'],.alert,.validation-summary-errors,[role=alert]"); return e ? (e.innerText || "").replace(/\s+/g, " ").trim().slice(0, 200) : ""; });
  if (printAfter) printAfter.mbox = mbox;
  // ⛔ 8/11: το Medilabi ζητά ΑΚΟΜΑ στοιχεία μετά την «Καταχώρηση» (π.χ. «συμπληρώστε τις Ειδικές Πληροφορίες») → ΔΕΝ καταχωρίστηκε.
  // Πριν γραφόταν «✅ καταχωρήθηκε» (ΜΠΙΣΥΛΛΑΣ/VELIU 8/11): ποτέ ξανά επιτυχία χωρίς επιβεβαίωση.
  if (mbox && mbox.clicked === false && /συμπληρωσ|ειδικ\S*\s+πληροφορ|υποχρεωτ|απαιτειται|δεν (εχει|εγινε)|σφαλμ/i.test(String(mbox.msg || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase())) {
    const left = ((extra && extra.spec && extra.spec.labels) || []).filter((x) => /^▾ .* = -$/.test(x)).map((x) => x.slice(2, 60));
    return { status: "failed", note: "⚠ ΔΕΝ καταχωρίστηκε: το Medilabi ζητά ακόμα «" + String(mbox.msg).slice(0, 120) + "»" + (left.length ? " · κενά: " + left.join(" · ") : "") + " — ολοκληρώστε την στον υπολογιστή (η φόρμα έμεινε ανοιχτή)", result: { ...r, printAfter: Object.assign(printAfter || {}, extra || {}) }, push: ["⚠ Παραγγελία ΔΕΝ καταχωρίστηκε", (job.name || "") + " — το Medilabi ζητά ακόμα στοιχεία"] };
  }
  const mnote = mbox && mbox.msg ? " · Medilabi: «" + mbox.msg.slice(0, 120) + "»" + (mbox.clicked ? " (OK ✓)" : mbox.clicked === false ? " — ⚠ δεν πατήθηκε OK (πατήστε το στον υπολογιστή)" : "") : "";
  const pc = ((printAfter && printAfter.calls) || []).find((c) => c.kind === "Order");
  const pnote = !pc ? " · 🖨 η σελίδα δεν ζήτησε barcode" : pc.sent === "η σελίδα το έστειλε" ? " · 🖨 barcode στάλθηκε" : (pc.res && pc.res.st < 400) || (pc.res2 && pc.res2.st < 400) ? " · 🖨 barcode στάλθηκε από το bot" : " · ⚠ barcode δεν στάλθηκε";
  // ✔ Έλεγχος ότι όντως ολοκληρώθηκε: αν φαίνεται ακόμα μήνυμα ή η φόρμα με «Καταχώρηση», ΔΕΝ γράφουμε «καταχωρήθηκε».
  const vAfter = await medVrdRead(r.tabId);
  if (printAfter) Object.assign(printAfter, extra || {}, { vAfter });
  // 8/11: το «Μη προβλεπόμενες εξετάσεις…» φαίνεται ακόμα (το Medilabi άργησε ή ξαναεμφανίστηκε) → τσεκ ό,τι επιτρέπεται + OK ΜΙΑ ακόμα φορά
  if (vAfter && !vAfter.gone && !vAfter.err && !(extra && extra.vrdRetry) && /πρωτοκ[οό]λλ|reflex|δε συνιστ[αά]ται|Επιλ[εέ]ξτε τις εξετ[αά]σεις/i.test(vAfter.text || "")) {
    const s0 = await medSig(r.tabId);
    const ck = await medFrameExec(r.tabId, () => {
      const b = document.getElementById("ctl00_ContentPage_vrdDialog_btnContinueToOrder"); if (!b || b.getBoundingClientRect().width <= 0) return null;
      const box = document.getElementById("ctl00_ContentPage_vrdDialog") || document; let n = 0;
      for (const c of box.querySelectorAll("input[type=checkbox]")) { if (c.disabled || c.checked) continue; c.click(); if (!c.checked) { c.checked = true; c.dispatchEvent(new Event("change", { bubbles: true })); } n++; }
      b.click(); return { n };
    });
    if (ck) { for (let i = 0; i < 60; i++) { await E.sleep(250); const now = await medSig(r.tabId); if (now && now !== s0) break; } await bgSettle(r.tabId, 3000);
      return medOrderAfter(job, r, t0w, Object.assign({}, extra || {}, { vrdRetry: true, vrdRetryChecked: ck.n })); }
  }
  if (vAfter && !vAfter.gone && !vAfter.err) return { status: "review", note: "⚠ ΔΕΝ ολοκληρώθηκε: το Medilabi δείχνει ακόμα μήνυμα — «" + String(vAfter.text || "").replace(/\s+/g, " ").slice(0, 200) + "»", result: { ...r, stage: "vrd", vrd: vAfter, vrdAt: Date.now(), printAfter }, push: ["⚠ Παραγγελία: ξανά μήνυμα Medilabi", (job.name || "") + " · " + String(vAfter.text || "").replace(/\s+/g, " ").slice(0, 90)] };
  if (vAfter === null && printAfter && (printAfter.btns || []).some((x) => /^καταχ[ωώ]ρηση$/i.test(x))) return { status: "approved", note: "⚠ πατήθηκε, αλλά η σελίδα δείχνει πάλι φόρμα με «Καταχώρηση» — η καταχώρηση ΔΕΝ επιβεβαιώνεται· ελέγξτε στο Medilabi" + (msg ? " · «" + msg + "»" : ""), result: { ...(job.payload?.result || {}), printAfter } };
  try { const { efbotLabWatch: w = {} } = await chrome.storage.local.get("efbotLabWatch"); w[String(job.name || "")] = Date.now() + 8 * 3600e3; await chrome.storage.local.set({ efbotLabWatch: w }); } catch (e) {}
  return { status: "approved", note: "✅ καταχωρήθηκε στο Medilabi" + (extra && extra.spec && extra.spec.saved ? " · 📝 Ειδικές Πληροφορίες: " + extra.spec.steps.slice(1).join(" · ").slice(0, 300) : "") + (msg && !mnote ? " · «" + msg + "»" : "") + mnote + pnote + (extra && extra.vrdDis && extra.vrdDis.length ? " · ⚠ ΔΕΝ ΜΠΗΚΑΝ (το Medilabi δεν επιτρέπει επιλογή): " + extra.vrdDis.join(" · ").slice(0, 200) : "") + (extra && extra.vrdTotal === 0 && extra.vrdAuto != null ? " · ⚠ στο μήνυμα του Medilabi δεν βρέθηκαν κουτάκια — ελέγξτε ότι μπήκαν όλες" : "") + (extra && extra.vrdAuto != null ? " · ☑ προειδοποίηση Medilabi: OK αυτόματα" + (extra.vrdAuto ? " (+" + extra.vrdAuto + " τσεκ)" : "") + (extra.vrd && extra.vrd.text ? " — «" + String(extra.vrd.text).replace(/Επιλ[εέ]ξτε τις εξετ[αά]σεις[\s\S]*$/i, "").replace(/Μη προβλεπόμενες εξετάσεις βάσει πρωτοκόλλων/i, "").replace(/\s+/g, " ").trim().slice(0, 160) + "»" : "") : ""), push: (extra && ((extra.vrdDis && extra.vrdDis.length) || (extra.vrdTotal === 0 && extra.vrdAuto != null))) ? ["⚠ Παραγγελία: ΔΕΝ μπήκαν όλες", (job.name || "") + " · " + ((extra.vrdDis || []).join(", ") || "ελέγξτε στο Medilabi").slice(0, 120)] : ["✅ Παραγγελία καταχωρήθηκε", (job.name || "") + (msg ? " · " + msg.slice(0, 80) : "")], result: { ...(job.payload?.result || {}), printAfter } };
}
// ίδια κανονικοποίηση/αντιστοίχιση με το medilabi.js (εδώ δεν υπάρχει DOM, μόνο κείμενο)
function Medilabi_norm(s) { return String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/ς/g, "σ").replace(/\s+/g, " ").trim(); }
// Αντιστοίχιση με το ΕΠΩΝΥΜΟ (πρώτη λέξη στο Medilabi). Αν το επώνυμο υπάρχει πολλές φορές,
// δοκιμάζει το μικρό όνομα (πρώτα γράμματα). Αν μένει αμφίβολο, δεν μαντεύει.
function labsMatch(name, list) {
  const toks = Medilabi_norm(name).replace(/[(),.;]/g, " ").split(/\s+/).filter((t) => t.length >= 2);
  if (!toks.length) return { hits: 0 };
  const words = (p) => Medilabi_norm(p.name).replace(/[(),.;]/g, " ").split(/\s+/).filter(Boolean);
  const sameSurname = (w, t) => w[0] === t || w[0].split("-").includes(t) || t.split("-").includes(w[0]);
  // επώνυμο = πρώτη λέξη του Παραδόχαρτου· αν δεν ταιριάζει πουθενά, δοκιμάζονται οι υπόλοιπες λέξεις
  let sur = toks[0], hits = list.filter((p) => sameSurname(words(p), sur));
  if (!hits.length) for (const t of toks.slice(1)) { const h = list.filter((p) => sameSurname(words(p), t)); if (h.length) { sur = t; hits = h; break; } }
  if (hits.length <= 1) return { hits: hits.length, item: hits[0] || null, surname: sur };
  const rest = Medilabi_norm(name).replace(/[(),.;]/g, " ").split(/\s+/).filter((t) => t && t !== sur);
  for (const len of [99, 3, 2]) {
    if (!rest.length) break;
    const h = hits.filter((p) => { const w = words(p).slice(1); return rest.every((t) => w.some((x) => x.startsWith(t.slice(0, len)))); });
    if (h.length === 1) return { hits: 1, item: h[0], surname: sur };
    if (h.length > 1) hits = h;
  }
  return { hits: hits.length, item: null, surname: sur, dup: true };
}


JOB_RUNNERS.order = (job) => JOB_ORDER_INNER(job);

JOB_RUNNERS.consult = (job) => JOB_CONSULT_INNER(job);

// ===== 🔬 Medilabi: αναζήτηση ασθενή (και παλιών) + «σύνολο ιστορικού» — ΜΟΝΟ ανάγνωση =====
// FindPatient.aspx (χαρτογραφήθηκε 2/11): txtName, txtID, wdpBirthdate, txtAMKA, ακτίνες εμβέλειας
// (rbtnWardPatients / rbtnPatientVisits / rbtnRecentPatients / rbtnAllWardPatients / rbtnAllPatients), btnSearch.
// payload: {q: "ΕΠΩΝΥΜΟ ΟΝΟΜΑ" ή ΑΜΚΑ, scope: "all"|"ward"}. Επιστρέφει ασθενείς + ό,τι μοιάζει με βιοψία/PDF στο ιστορικό.
JOB_RUNNERS.medbx = async (job) => {
  const p = job.payload || {}, cfg = await labsCfg(), base = cfg.base || LABS_BASE;
  // το Medilabi ψάχνει με ΚΕΦΑΛΑΙΑ χωρίς τόνους (πριν: «Λιακκης» → 0 αποτελέσματα)
  const q = String(p.q || job.name || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().replace(/\s+/g, " ").trim(); if (!q && !p.pid && !(p.f && (p.f.name || p.f.amka || p.f.am || p.f.bdate))) return { status: "failed", note: "χωρίς όνομα ή ΑΜΚΑ" };
  const attr = (tag, a) => { const m = tag.match(new RegExp("\\b" + a + "\\s*=\\s*(\"([^\"]*)\"|'([^']*)'|([^\\s>]+))", "i")); return m ? (m[2] ?? m[3] ?? m[4] ?? "") : ""; };
  const unent = (v) => String(v || "").replace(/&amp;/g, "&").replace(/&#43;/g, "+").replace(/&#47;/g, "/").replace(/&quot;/g, '"').replace(/&lt;/g, "<").replace(/&gt;/g, ">");
  const clean = (h) => String(h || "").replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim();
  const pts = []; let msg = "", gridOk = !!p.pid, pager = { tgt: "", args: [] }, pageNow = 1;
  if (p.pid) pts.push({ pid: String(p.pid), row: String(p.row || "") });   // ⚡ ήδη γνωστός ασθενής (από την αναζήτηση): κατευθείαν στο ιστορικό
  else {
  let g = await labsGet(base + "FindPatient.aspx");
  if (/Login\.aspx/i.test(g.url)) { const a = await medilabiAutoLogin(base); if (!a.ok) return { status: "failed", note: "🔬 Medilabi: χρειάζεται σύνδεση — " + (a.msg || "") }; g = await labsGet(base + "FindPatient.aspx"); }
  const fm = g.html.match(/<form\b([^>]*)>([\s\S]*?)<\/form>/i);
  if (!fm) return { status: "failed", note: "🔬 δεν βρέθηκε η φόρμα αναζήτησης του Medilabi" };
  const isAm = /^\d{8}$/.test(q.replace(/\s/g, ""));   // ΑΜ ασθενή (8 ψηφία) → πεδίο κωδικού/μητρώου της φόρμας, αν υπάρχει
  let amDone = false;
  const parts = [], isAmka = /^\d{11}$/.test(q.replace(/\s/g, "")), scope = p.scope === "ward" ? "rbtnAllWardPatients" : "rbtnAllPatients";
  let radioDone = false, btn = null, amkaField = false; const txtIds = [];
  const F = p.f || {}, D = (x) => String(x || "").replace(/\D/g, ""), NZ = (x) => String(x || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().replace(/\s+/g, " ").trim();
  for (const i of fm[2].matchAll(/<input\b([^>]*)>/gi)) {
    const ty = (attr(i[1], "type") || "text").toLowerCase(), nm = attr(i[1], "name"), id = attr(i[1], "id"), v = unent(attr(i[1], "value"));
    if (!nm) continue;
    if (ty === "hidden") { if (nm !== "__EVENTTARGET" && nm !== "__EVENTARGUMENT") parts.push([nm, v]); continue; }
    if (ty === "submit") { if (/btnSearch$/.test(id)) btn = [nm, v]; continue; }
    if (ty === "radio") { if (id.endsWith(scope)) { parts.push([nm, v || id.replace(/^.*_/, "")]); radioDone = true; } continue; }
    if (ty === "checkbox") { if (/\bchecked\b/i.test(i[1]) && !/chkSample/.test(id)) parts.push([nm, v || "on"]); continue; }
    // φίλτρα από το Παραδόχαρτο (5/11): χωριστά πεδία f.name / f.amka / f.am — αλλιώς το q όπως πριν
    if (ty === "text" || !ty) txtIds.push(id.replace(/^.*_/, "") + (v ? "=" + v.slice(0, 12) : ""));
    if (/amka$/i.test(id) || /amka$/i.test(nm)) { parts.push([nm, D(F.amka) || (isAmka ? q.replace(/\s/g, "") : "")]); amkaField = true; }
    else if (F.bdate && /Birthdate/i.test(id) && !/clientState/i.test(id + nm)) parts.push([nm, F.bdate]);
    else if (/txtName$/i.test(id)) parts.push([nm, F.name ? NZ([isAmka || isAm ? "" : q, F.name].join(" ")) : (isAmka || isAm ? "" : q)]);   // κείμενο αναζήτησης + φίλτρο ονόματος μαζί
    else if ((isAm || D(F.am)) && !amDone && /txt(Patient)?(ID|Code|Kodikos|AM|Mitroo|Record|RecordNo|FileNo|File|MRN|No|PatientNo|HospitalNo|ExternalID|ExtID)$/i.test(id)) { parts.push([nm, D(F.am) || q.replace(/\s/g, "")]); amDone = true; }
    else parts.push([nm, v]);
  }
  if (!btn) return { status: "failed", note: "🔬 δεν βρέθηκε το κουμπί «Αναζήτηση» του Medilabi" };
  // 6/11: ΑΜΚΑ χωρίς δικό του πεδίο στη φόρμα → στο πεδίο κειμένου (όνομα) — το Medilabi ψάχνει και εκεί
  if ((D(F.amka) || isAmka) && !amkaField) { const ix = parts.findIndex(([k]) => /txtName$/i.test(k)); if (ix >= 0) parts[ix][1] = D(F.amka) || q.replace(/\s/g, ""); }
  self.__medFindDiag = "πεδία: " + txtIds.slice(0, 12).join(", ") + (amkaField ? " · ΑΜΚΑ σε δικό του πεδίο" : " · ΑΜΚΑ στο όνομα");
  if ((isAm || D(F.am)) && !amDone) { const ids = [...fm[2].matchAll(/<input\b[^>]*\bid\s*=\s*"([^"]+)"[^>]*type\s*=\s*"?text/gi)].map((m) => m[1].replace(/^.*_/, "")).slice(0, 12); return { status: "failed", note: "🔬 το Medilabi δεν έχει πεδίο ΑΜ στην αναζήτηση (πεδία: " + ids.join(", ") + ") — δοκιμάστε όνομα ή ΑΜΚΑ" }; }
  const body = parts.map(([k, v]) => enc1253(k) + "=" + enc1253(v)).concat(["__EVENTTARGET=", "__EVENTARGUMENT=", enc1253(btn[0]) + "=" + enc1253(btn[1])]).join("&");
  const res = await fetch(new URL(attr(fm[1], "action") || "FindPatient.aspx", g.url).href, { method: "POST", credentials: "include", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body });
  let html = new TextDecoder("windows-1253").decode(await res.arrayBuffer());
  // 📄 σελίδες του πίνακα (GridView «Page$N»): πόσες υπάρχουν + μετάβαση στη σελίδα p.page (ίδιο με το κλικ στην αρίθμηση)
  // pager: όρισμα (Page$N / Page$Next…) + κείμενο του συνδέσμου («3», «...», «>»)
  const pagerOf = (h) => { const out = new Map(); let tgt = ""; for (const m of h.matchAll(/__doPostBack\((?:&#39;|')([^'&]*grdSearchResults[^'&]*)(?:&#39;|'),\s*(?:&#39;|')(Page\$[^'&]+)(?:&#39;|')\)[^>]*>([^<]*)</g)) { tgt = m[1]; if (!out.has(m[2])) out.set(m[2], unent(m[3]).trim()); } return { tgt, args: [...out].map(([a, t]) => ({ a, t })) }; };
  const numOf = (x) => (/^Page\$(\d+)$/.exec(x.a) || [])[1];
  pager = pagerOf(html); pageNow = 1;
  const want = +p.page || 1;
  // σελίδα > 1: μόνο συνδέσμους που ΥΠΑΡΧΟΥΝ στην τρέχουσα σελίδα (EventValidation) — αλλιώς βήματα μέσω «...» (π.χ. 1 → 11 → 14)
  for (let hop = 0; hop < 6 && want !== pageNow && pager.tgt; hop++) {
    const nums = pager.args.map(numOf).filter(Boolean).map(Number);
    const step = nums.includes(want) ? want : (want > pageNow ? Math.max(...nums.filter((x) => x > pageNow && x < want)) : Math.min(...nums.filter((x) => x < pageNow && x > want)));
    if (!isFinite(step)) break;
    const pf = html.match(/<form\b([^>]*)>([\s\S]*?)<\/form>/i); if (!pf) break;
    // νέα hidden (viewstate) + ΤΑ ΙΔΙΑ κριτήρια αναζήτησης (textbox/radio δεν μένουν στο ViewState)
    const hidM = new Map([...pf[2].matchAll(/<input\b([^>]*)>/gi)].filter((i) => (attr(i[1], "type") || "").toLowerCase() === "hidden" && attr(i[1], "name") && !/^__EVENT/.test(attr(i[1], "name"))).map((i) => [attr(i[1], "name"), unent(attr(i[1], "value"))]));
    const kv = parts.filter(([k]) => !hidM.has(k)).concat([...hidM]).map(([k, v]) => enc1253(k) + "=" + enc1253(v));
    const rp = await fetch(new URL(attr(pf[1], "action") || "FindPatient.aspx", res.url || g.url).href, { method: "POST", credentials: "include", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: kv.concat(["__EVENTTARGET=" + enc1253(pager.tgt), "__EVENTARGUMENT=" + enc1253("Page$" + step)]).join("&") });
    const h2 = new TextDecoder("windows-1253").decode(await rp.arrayBuffer());
    if (!/grdSearchResults|splSearch/i.test(h2) || /Login\.aspx/i.test(rp.url || "")) break;
    html = h2; pageNow = step; const np = pagerOf(html); if (np.tgt) pager = np;
  }
  if (want > 1 && pageNow !== want) msg = "📄 η σελίδα " + want + " δεν άνοιξε — δείχνω τη " + pageNow + "η";
  gridOk = /grdSearchResults|splSearch/i.test(html) && !/Login\.aspx/i.test(res.url || "");
  // 6/11: ένας μόνο ασθενής → το Medilabi μπορεί να πάει κατευθείαν στη σελίδα του (PatientID στη διεύθυνση)
  { const rid = (String(res.url || "").match(/PatientID=(\d+)/i) || [])[1];
    if (rid) { const lbl = (html.match(/<span[^>]*id="[^"]*(?:PatientName|PatName|lblName|lblPatient|PatientInfo|lblFullName)[^"]*"[^>]*>([\s\S]*?)<\/span>/i) || [])[1]
        || (clean(html).match(/(?:Ονοματεπώνυμο|Ασθενής|ΑΣΘΕΝΗΣ)\s*:?\s*([Α-ΩΆ-ΏA-Z][Α-ΩΆ-ΏA-Z .'-]{3,60})/) || [])[1] || "";
      const am = (clean(html).match(/Α\.?Μ\.?Κ\.?Α\.?\s*:?\s*(\d{11})/) || [])[1] || "";
      pts.push({ pid: rid, post: "", row: (clean(lbl) || "Ασθενής") + (am ? " · ΑΜΚΑ " + am : "") }); } }
  self.__medFindMsg = clean(((html.match(/<span[^>]*id="[^"]*(?:lblMsg|lblMessage|lblError|lblInfo)[^"]*"[^>]*>([\s\S]*?)<\/span>/i) || [])[1]) || "").slice(0, 120);
  // ασθενείς: γραμμές με σύνδεσμο PatientResults/PatientID (ή postback) — κρατάμε όνομα/στοιχεία της γραμμής
  const seen = new Set();
  for (const tr of html.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)) {
    // PatientID: από σύνδεσμο, αλλιώς από το κρυφό πεδίο της γραμμής (hfldPatient_ID — έτσι το δίνει η FindPatient.aspx)
    const pid = (tr[1].match(/PatientID=([^"'&\s]+)/i) || [])[1]
      || ((tr[1].match(/<input\b[^>]*hfldPatient_ID[^>]*>/i) || [""])[0].match(/\bvalue\s*=\s*["']?(\d+)/i) || [])[1];
    const pb = (tr[1].match(/__doPostBack\(&#39;([^&]+)&#39;|__doPostBack\('([^']+)'/) || []);
    const oc = /onclick|href=/i.test(tr[1]);
    if (!pid && !pb[0] && !oc) continue;
    const txt = clean(tr[1]).slice(0, 160), key = pid || txt;
    if (seen.has(key)) continue; seen.add(key);
    if (!/\d{1,2}\/\d{1,2}\/\d{2,4}/.test(txt) && !pid) continue;   // επικεφαλίδες/μενού
    pts.push({ pid: pid || "", post: pb[1] || pb[2] || "", row: txt, html: pts.length < 2 ? tr[1].replace(/\s+/g, " ").replace(/\d{8,}/g, (d) => d.slice(0, 2) + "…").slice(0, 1500) : undefined });
    if (pts.length >= (p.find ? 60 : 12)) break;
  }
  // γραμμές χωρίς PatientID: άνοιγμα με το postback της γραμμής (όπως το κλικ στο όνομα) → διεύθυνση/σύνδεσμος με PatientID
  const rf = html.match(/<form\b([^>]*)>([\s\S]*?)<\/form>/i);
  if (rf) for (const pt of pts.filter((x) => !x.pid && x.post).slice(0, 3)) {
    try {
      const hid = [...rf[2].matchAll(/<input\b([^>]*)>/gi)].filter((i) => (attr(i[1], "type") || "").toLowerCase() === "hidden" && attr(i[1], "name") && !/^__EVENT/.test(attr(i[1], "name"))).map((i) => enc1253(attr(i[1], "name")) + "=" + enc1253(unent(attr(i[1], "value"))));
      const r2 = await fetch(new URL(attr(rf[1], "action") || "FindPatient.aspx", res.url || g.url).href, { method: "POST", credentials: "include", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: hid.concat(["__EVENTTARGET=" + enc1253(pt.post), "__EVENTARGUMENT="]).join("&") });
      const h2 = new TextDecoder("windows-1253").decode(await r2.arrayBuffer());
      pt.pid = (String(r2.url).match(/PatientID=([^&]+)/i) || h2.match(/PatientID=([^"'&\s]+)/i) || [])[1] || "";
      pt.via = r2.url.replace(/^.*\//, "").replace(/\?.*$/, "");
    } catch (e) { pt.err = e.message; }
  }
  { const pm = msg; msg = clean((html.match(/id="ctl00_msg(?:BoxMessage|Info)_lbl[^"]*"[^>]*>([\s\S]*?)</i) || [])[1] || ""); if (pm) msg = (msg ? msg + " · " : "") + pm; }
  }
  // σελίδες: αριθμοί από τα «Page$N» (+ «...» = κι άλλες)
  // αριθμημένες σελίδες = σύνδεσμοι με κείμενο-αριθμό· «...»/«>»/Next/Last μετά την τρέχουσα = υπάρχουν κι άλλες
  const pages = (pager.args || []).filter((x) => numOf(x) && /^\d+$/.test(x.t)).map((x) => +numOf(x));
  const maxP = Math.max(pageNow, ...pages);
  const pgInfo = { page: pageNow, pages: [...new Set(pages.concat(pageNow))].sort((a, b) => a - b), more: (pager.args || []).some((x) => /^Page\$(Next|Last)$/i.test(x.a) ? true : (numOf(x) && !/^\d+$/.test(x.t) && +numOf(x) > maxP)) };
  if (p.find) return { status: "done", pts, msg, gridOk, pg: pgInfo };   // μόνο οι υποψήφιοι ασθενείς (χωρίς ιστορικό)
  // ιστορικό: για τους πρώτους (μοναδικούς) ασθενείς, ό,τι μοιάζει με βιοψία / έγγραφο / PDF (σύνδεσμοι, onclick, εικονίδια)
  const RX = /βιοψ|ιστολογ|παθολογοαν|παθολογανατ|κυτταρολογ|biops|histo|patholog|cytolog/i;
  const hist = [];
  for (const pt of pts.filter((x) => x.pid).slice(0, 3)) {
    const h = await labsGet(base + "PatientResults.aspx?PatientID=" + encodeURIComponent(pt.pid));
    const docs = [];
    for (const m of h.html.matchAll(/<(a|input|img|span|div|td|button)\b([^>]*)>/gi)) {
      const at = m[2]; if (!/pdf|report|show|print|open\(|download|attach|\.aspx\?/i.test(at)) continue;
      if (/RV\.hormone|ΟΔΗΓΙ|\.docx?\b/i.test(at)) continue;
      docs.push((m[1] + " " + at.replace(/\s+/g, " ")).replace(/\d{6,}/g, (d) => d.slice(0, 2) + "…").slice(0, 260));
      if (docs.length >= 25) break;
    }
    const t = clean(h.html);
    const near = [...t.matchAll(/.{0,60}(βιοψ|ιστολογ|παθολογοαν|παθολογανατ|κυτταρολογ|biops|histo|patholog)\S*.{0,80}/gi)].map((x) => x[0]).slice(0, 12);
    // 🔬 κείμενο απάντησης: ό,τι ακολουθεί κάθε τίτλο «ΒΙΟΨΙΑ (…)» / «ΠΑΘΟΛΟΓΟΑΝΑΤΟΜΙΚΟ (…)» / «ΚΥΤΤΑΡΟΛΟΓΙΚΗ (…)» (έως 3500 χαρ.)
    const bx = [], seenBx = new Set();
    for (const m of t.matchAll(/(ΒΙΟΨΙΑ|ΠΑΘΟΛΟΓΟΑΝΑΤΟΜΙΚ\S*|ΚΥΤΤΑΡΟΛΟΓ\S*|ΙΣΤΟΛΟΓ\S*)\s*\(([^)]{2,90})\)?/g)) {
      const text = t.slice(m.index, m.index + 3500), key = m[0] + "|" + text.slice(m[0].length, m[0].length + 160);
      if (seenBx.has(key)) continue; seenBx.add(key); bx.push({ title: m[0], text, pre: t.slice(Math.max(0, m.index - 60), m.index) });
      if (bx.length >= 8) break;
    }
    // 🔬 πίνακας αποτελεσμάτων: γραμμές «ΒΙΟΨΙΑ (…)» με τα κελιά ανά ημερομηνία (άδειο = δεν βγήκε, «[Εκκρ.]» = εκκρεμεί, κείμενο/σύνδεσμος = βγήκε)
    const rowsBx = [];
    try {
      const hdr = (h.html.match(/<tr\b[^>]*>(?:(?!<\/tr>)[\s\S])*?\d{2}\/\d{2}\/\d{2,4}\s+\d{1,2}:\d{2}[\s\S]*?<\/tr>/i) || [""])[0];
      const dates = [...clean(hdr).matchAll(/(\d{2}\/\d{2}\/\d{2,4})\s+\d{1,2}:\d{2}/g)].map((m) => m[1]);
      for (const tr of h.html.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)) {
        const tds = [...tr[1].matchAll(/<td\b([^>]*)>([\s\S]*?)<\/td>/gi)]; if (tds.length < 2) continue;
        const name = clean(tds[0][2]); if (!/^(ΒΙΟΨΙΑ|ΠΑΘΟΛΟΓΟΑΝΑΤ|ΚΥΤΤΑΡΟΛΟΓ|ΙΣΤΟΛΟΓ)/i.test(name) || name.length > 120) continue;
        const cells = tds.slice(1, 1 + Math.max(dates.length, 1)).map((c, i) => { const inner = c[2]; const lk = (inner.match(/(?:href|onclick)\s*=\s*["']([^"']{4,300})["']/i) || c[1].match(/onclick\s*=\s*["']([^"']{4,300})["']/i) || [])[1] || "";
          // συνημμένο (εικονίδιο/σύνδεσμος μέσα στο κελί) → κρατάμε και κάθε href/onclick/src που μοιάζει με έγγραφο
          const att = [...inner.matchAll(/(?:href|onclick|src)\s*=\s*["']([^"']{4,300})["']/gi)].map((m) => unent(m[1]).replace(/&#39;/g, "'")).filter((x) => /pdf|report|attach|doc|show|open|view|download|__doPostBack|\.aspx/i.test(x) && !/\.(png|gif|jpg)$/i.test(x));
          return { d: dates[i] || "", v: clean(inner).slice(0, 200) || (att.length ? "📎" : ""), link: (att[0] || unent(lk).replace(/&#39;/g, "'")) }; });
        rowsBx.push({ name, cells });
        if (rowsBx.length >= 20) break;
      }
    } catch (e) {}
    hist.push({ row: pt.row, pid: pt.pid, size: Math.round(h.html.length / 1024), bx, rowsBx, docs, near, tabs: [...h.html.matchAll(/<(?:a|span|li|td)\b[^>]*>\s*([^<]{3,40})\s*<\/(?:a|span|li|td)>/gi)].map((x) => x[1].trim()).filter((x) => /ιστορικ|σύνολο|συνολο|αποτελέσμ|ιστολογ|παθολογ|pdf|έγγραφ/i.test(x)).slice(0, 20) });
  }
  const nb = hist.reduce((a, h) => a + h.near.length, 0), nd = hist.reduce((a, h) => a + h.docs.length, 0);
  return { status: "done", note: `🔬 Medilabi «${q.slice(0, 3)}…» (${p.scope === "ward" ? "κλινική" : "νοσοκομείο"}): ${pts.length} ασθενείς` + (msg ? " · " + msg.slice(0, 80) : "") + (hist.length ? ` · ιστορικό: ${nb} αναφορές βιοψίας, ${nd} έγγραφα/σύνδεσμοι` : ""), result: { pts, hist, at: Date.now() } };
};
JOB_KIND.medbx = "🔬 Medilabi: βιοψίες ασθενή";
// 🔎 Medilabi: αναζήτηση ΟΠΟΙΟΥΔΗΠΟΤΕ ασθενή του νοσοκομείου (όνομα/ΑΜ/ΑΜΚΑ) → υποψήφιοι · και εργαστηριακά ενός (PatientID). Μόνο ανάγνωση.
JOB_RUNNERS.medfind = async (job) => {
  const p = job.payload || {};
  let r = await JOB_RUNNERS.medbx({ id: 0, name: "", payload: { q: p.q, f: p.f, page: p.page, scope: p.scope === "ward" ? "ward" : "all", find: true } });
  if (!r || r.status !== "done") return r || { status: "failed", note: "🔎 Medilabi δεν απάντησε" };
  let pts = (r.pts || []).filter((x) => x.pid).slice(0, 60).map((x) => ({ pid: x.pid, row: x.row }));
  // 6/11: ΑΜΚΑ χωρίς αποτέλεσμα → ημερομηνία γέννησης από τα 6 πρώτα ψηφία του ΑΜΚΑ (ΗΗΜΜΕΕ) και κρατάμε τις γραμμές που δείχνουν τον ΑΜΚΑ
  const am = String((p.f && p.f.amka) || p.q || "").replace(/\D/g, "");
  let via = "";
  if (!pts.length && /^\d{11}$/.test(am)) {
    const dd = am.slice(0, 2), mm = am.slice(2, 4), yy = +am.slice(4, 6), yyyy = (yy > new Date().getFullYear() % 100 ? 1900 : 2000) + yy;
    if (+dd >= 1 && +dd <= 31 && +mm >= 1 && +mm <= 12) {
      const r2 = await JOB_RUNNERS.medbx({ id: 0, name: "", payload: { q: "", f: { bdate: dd + "/" + mm + "/" + yyyy }, scope: "all", find: true } });
      const all = r2 && r2.status === "done" ? (r2.pts || []).filter((x) => x.pid) : [];
      const hit = all.filter((x) => String(x.row || "").replace(/\D/g, "").includes(am));
      pts = (hit.length ? hit : all.length <= 15 ? all : []).slice(0, 60).map((x) => ({ pid: x.pid, row: x.row }));
      via = " · μέσω ημ. γέννησης " + dd + "/" + mm + "/" + yyyy + ": " + all.length + " ασθενείς" + (hit.length ? ", " + hit.length + " με τον ΑΜΚΑ" : all.length > 15 ? " (πολλοί — γράψτε και επώνυμο)" : "");
      if (r2) r = Object.assign({}, r, { msg: r.msg || r2.msg });
    }
  }
  if (!pts.length && self.__medFindMsg) via += " · Medilabi: «" + self.__medFindMsg + "»";
  return { status: "done", note: "🔎 Medilabi: " + pts.length + " ασθενείς" + via + (!pts.length && self.__medFindDiag ? " · " + self.__medFindDiag : "") + (r.pg && r.pg.pages.length > 1 ? " · σελίδα " + r.pg.page + "/" + Math.max(...r.pg.pages) + (r.pg.more ? "+" : "") : "") + (r.msg ? " · " + r.msg.slice(0, 80) : ""), result: { pts, pg: r.pg } };
};
JOB_KIND.medfind = "🔎 Medilabi: αναζήτηση ασθενή";
JOB_RUNNERS.medpt = async (job) => {
  const p = job.payload || {}, cfg = await labsCfg(), base = cfg.base || LABS_BASE;
  if (!p.pid) return { status: "failed", note: "χωρίς ασθενή" };
  const u = base + "PatientResults.aspx?PatientID=" + encodeURIComponent(p.pid);
  let r = await labsGet(u);
  if (/Login\.aspx/i.test(r.url)) { const a = await medilabiAutoLogin(base); if (!a.ok) return { status: "failed", note: "🧪 Medilabi: χρειάζεται σύνδεση — " + (a.msg || "") }; r = await labsGet(u); }
  const pr = await offscreenParse("results", r.html, todayDDMMYY());
  const all = pr && pr.all;
  if (!all || !(all.dates || []).length) return { status: "done", note: "🧪 χωρίς αποτελέσματα", result: { all: { dates: [], rows: [] } } };
  return { status: "done", note: "🧪 " + all.dates.length + " λήψεις", result: { all } };
};
JOB_KIND.medpt = "🧪 Medilabi: εργαστηριακά ασθενή";
// 🗺 Medilabi: ΧΑΡΤΟΓΡΑΦΗΣΗ «απευθείας παραγγελίας» — ΜΟΝΟ GET, κανένα POST, κανένα __doPostBack, ΠΟΤΕ btnDone.
// Ερωτήματα: (1) υπάρχει στη WebEMR (δική του σύνδεση του bot, χρήστης ward) σύνδεσμος «Νέα παραγγελία» για τον ασθενή;
// (2) ανοίγει η MedilabiEPSMY/OrderTests.aspx χωρίς το RedirectRequest του ΝΠΣ (ή πέφτει σε Login/σφάλμα);
// (3) ποια ΟΝΟΜΑΤΑ παραμέτρων έχει το RedirectRequest.aspx του ΝΠΣ (efbotMedNav, χωρίς τιμές).
JOB_RUNNERS.medordermap = async (job) => {
  const p = job.payload || {}, cfg = await labsCfg(), base = cfg.base || LABS_BASE;
  if (!/ΜΠΕΓΟ/i.test(String(job.name || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase())) return { status: "failed", note: "μόνο στον ασθενή δοκιμών (ΜΠΕΓΟΣ)" };
  const pid = String(p.pid || ""); if (!/^\d{4,9}$/.test(pid)) return { status: "failed", note: "χωρίς PatientID Medilabi" };
  const strip = (h) => String(h || "").replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ");
  const mask = (s) => String(s || "").replace(/\d{6,}/g, (d) => d.slice(0, 2) + "…");
  const RX = /order|παραγγ|neworder|OrderTests|RedirectRequest|requisit|αίτημα|αιτημα|εντολ/i;
  const links = (html, from) => {
    const out = [];
    for (const m of strip(html).matchAll(/<(a|input|button|area|form|iframe)\b([^>]*)>([^<]{0,80})/gi)) {
      const at = m[2], tx = m[3].replace(/\s+/g, " ").trim();
      if (!RX.test(at + " " + tx)) continue;
      out.push({ from, tag: m[1].toLowerCase(), t: tx.slice(0, 60), a: mask(at.replace(/\s+/g, " ")).slice(0, 220) });
      if (out.length >= 30) break;
    }
    return out;
  };
  const T0 = Date.now(), res = { ms: {}, pages: [] };
  const get = async (label, url) => {
    const t = Date.now(); let r; try { r = await labsGet(url); } catch (e) { res.pages.push({ label, err: e.message }); return null; }
    res.ms[label] = Date.now() - t;
    const title = ((r.html.match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [])[1] || "").replace(/\s+/g, " ").trim().slice(0, 60);
    res.pages.push({ label, url: String(r.url || "").replace(/\?.*$/, ""), qkeys: (() => { try { return [...new URL(r.url).searchParams.keys()]; } catch (e) { return []; } })(), title, len: r.html.length, login: /Login\.aspx/i.test(r.url) || /type=["']?password/i.test(r.html), links: links(r.html, label) });
    return r;
  };
  // (1) WebEMR του bot: ιστορικό ασθενή + αρχική (μενού/κεφαλίδα grvLinks)
  let r1 = await get("WebEMR PatientResults", base + "PatientResults.aspx?PatientID=" + encodeURIComponent(pid));
  if (r1 && /Login\.aspx/i.test(r1.url)) { const a = await medilabiAutoLogin(base); res.login = a.msg; if (a.ok) r1 = await get("WebEMR PatientResults (2)", base + "PatientResults.aspx?PatientID=" + encodeURIComponent(pid)); }
  await get("WebEMR FindPatient", base + "FindPatient.aspx");
  // (2) EPSMY χωρίς παραμέτρους ΝΠΣ (μόνο GET· αναμένεται Login ή σφάλμα — αυτό ακριβώς θέλουμε να μάθουμε)
  const root = base.replace(/Medilabi\/WebEMR\/?$/i, "");
  for (const u of ["MedilabiEPSMY/OrderTests.aspx", "MedilabiEPSMY/Default.aspx", "MedilabiEPSMY/Login.aspx"]) await get("EPSMY " + u.split("/").pop(), root + u);
  // (3) ονόματα παραμέτρων του RedirectRequest (από την τελευταία παραγγελία μέσω ΝΠΣ — χωρίς τιμές)
  try { const { efbotMedNav: mn } = await chrome.storage.local.get("efbotMedNav"); if (mn) res.medNav = { path: mn.path, keys: mn.keys, all: mn.all, ageMin: Math.round((Date.now() - mn.at) / 60000) }; } catch (e) {}
  res.total = Date.now() - T0;
  const nL = res.pages.reduce((a, x) => a + ((x.links || []).length), 0);
  return { status: "done", note: "🗺 Medilabi απευθείας παραγγελία (μόνο GET): " + res.pages.map((x) => x.label + (x.err ? " ✗" : x.login ? " 🔒login" : " ✓" + (x.links.length ? "(" + x.links.length + ")" : ""))).join(" · ") + " · σύνδεσμοι παραγγελίας: " + nL + (res.medNav ? " · RedirectRequest keys: " + (res.medNav.keys || []).join(",") : "") + " · " + res.total + "ms", result: res };
};
JOB_KIND.medordermap = "🗺 Medilabi: χαρτογράφηση απευθείας παραγγελίας (μόνο ανάγνωση)";
JOB_LIMIT_S.medordermap = 60;
// ===== 🔬 ΣΑΡΩΣΗ ΒΙΟΨΙΩΝ: για κάθε ασθενή (κλινική + εξιτήρια 45 ημερών) → βιοψίες ⏳ εκκρεμεί / ✓ βγήκε + κείμενο.
// Ταυτοποίηση: με ΑΜΚΑ όταν υπάρχει· με όνομα ΜΟΝΟ γραμμές της ΟΥΡΟΛΟΓΙΚΗΣ. Αποτέλεσμα κρυπτογραφημένο (κλειδί κλινικής).
// Ειδοποίηση όταν μια βιοψία που ήταν ⏳ βγει. Αυτόματα ξανά κάθε 12 ώρες με την τελευταία λίστα ασθενών.
const MEDBX_INNER = JOB_RUNNERS.medbx;
const bxNz = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().replace(/\s+/g, " ").trim();
JOB_RUNNERS.bxscan = async (job) => {
  const p = job.payload || {};
  const pts = (p.pts || []).filter((x) => x && (x.name || x.amka || x.am)).slice(0, 120);
  if (!pts.length) return { status: "failed", note: "🔬 καμία λίστα ασθενών" };
  // 🔐 πρώτα το κλειδί (όπως το bxpdf): αλλιώς 5′ σάρωσης και αποτυχία στο τέλος (έλεγχος 5/11)
  try { await imgClinicKey(); } catch (e) { return { status: "failed", note: "🔐 " + (e && e.message || e) }; }
  if (!p.auto && !p.search) await chrome.storage.local.set({ efbotBxPts: { pts, at: Date.now() } });
  const { efbotBxState: prevState = {} } = await chrome.storage.local.get("efbotBxState");
  const res = [], newly = [];
  let i = 0;
  for (const pt of pts) {
    i++;
    if (i % 3 === 1) imgNote(job.id, `🔬 ${i}/${pts.length} ασθενείς · ${Math.round((i - 1) / pts.length * 100)}%`);
    const q = /^\d{11}$/.test(String(pt.amka || "")) ? String(pt.amka) : String(pt.name || "").trim() || (/^\d{8}$/.test(String(pt.am || "")) ? String(pt.am) : "");
    let r; try { r = await MEDBX_INNER({ id: job.id, name: pt.name, payload: { q, scope: "all", find: true } }); } catch (e) { r = { status: "failed", note: e.message }; }
    // ταυτοποίηση: ΑΜΚΑ/ΑΜ = ακριβές· με όνομα ΜΟΝΟ γραμμές ουρολογικής νοσηλείας (το πολύ 2 ασθενείς)
    const cands = ((r && r.pts) || []).filter((x) => x.pid && (/^\d{8}$|^\d{11}$/.test(q) || /ΟΥΡΟΛΟΓ/.test(bxNz(x.row)))).slice(0, 2);
    const items = [];
    for (const c of cands) { try { const x = await bxItemsForPid(c.pid); for (const b of (x.items || [])) if (!items.some((y) => y.key === b.key)) items.push(b); } catch (e) {} }
    if (!p.search) for (const b of items) { const k = bxNz(pt.name) + "|" + b.key; if (prevState[k] === "p" && !b.pending) newly.push(pt.name + ": " + b.what); prevState[k] = b.pending ? "p" : "d"; }
    res.push({ name: pt.name, amka: pt.amka ? "•••" + String(pt.amka).slice(-3) : "", items, err: r && r.status === "failed" ? String(r.note || "").slice(0, 120) : "" });
  }
  if (!p.search) await chrome.storage.local.set({ efbotBxState: prevState, efbotBxLast: Date.now() });
  let enc; try { enc = await fsSealJson({ at: Date.now(), res }); } catch (e) { return { status: "failed", note: "🔐 " + e.message }; }
  const nP = res.reduce((a, x) => a + x.items.filter((b) => b.pending).length, 0), nD = res.reduce((a, x) => a + x.items.filter((b) => !b.pending).length, 0);
  return { status: "done", note: `🔬 ${pts.length} ασθενείς · ⏳ ${nP} εκκρεμούν · ✓ ${nD} βγήκαν` + (newly.length ? ` · 🆕 ${newly.length}` : ""), result: { enc, nP, nD, n: pts.length },
    push: newly.length ? ["🔬 Βγήκε αποτέλεσμα βιοψίας", newly.slice(0, 4).join(" · ") + " — Παραδόχαρτο → Εργαλεία → 🔬 Βιοψίες"] : undefined };
};
JOB_KIND.bxscan = "🔬 Βιοψίες: έλεγχος";
// ⚡ Αναζήτηση ασθενή στο Medilabi (1 αίτημα): υποψήφιοι με «ουρολογική νοσηλεία» ναι/όχι (από τη γραμμή του Medilabi)
JOB_RUNNERS.bxfind = async (job) => {
  const p = job.payload || {};
  const r = await MEDBX_INNER({ id: job.id, name: "", payload: { q: p.q, f: p.f, page: p.page, scope: "all", find: true } });
  // 0 ασθενείς ΧΩΡΙΣ σωστή σελίδα αποτελεσμάτων (π.χ. το Medilabi αυτού του υπολογιστή δεν είναι συνδεδεμένο) → σε άλλο bot, όχι «0»
  if ((!r || r.status !== "done" || !(r.pts || []).length) && +((job.payload || {}).hopped || 0) < 1 && await otherBotReady()) return { status: "new", moved: true, zero: true };   // 0 → δεύτερη γνώμη από άλλο bot (ο ίδιος υπολογιστής έδινε σταθερά 0)
  if (!r || r.status !== "done") return { status: "failed", note: (r && r.note) || "απέτυχε" };
  if (!r.gridOk && !(r.pts || []).length) return { status: "failed", note: "🔎 το Medilabi δεν έδωσε σελίδα αναζήτησης (σύνδεση;)" };
  const cands = (r.pts || []).filter((x) => x.pid || x.post).map((x) => ({ pid: x.pid, row: x.row, uro: /ΟΥΡΟΛΟΓ/.test(bxNz(x.row)) }));
  let enc; try { enc = await fsSealJson({ at: Date.now(), q: p.q, cands, pg: r.pg }); } catch (e) { return { status: "failed", note: "🔐 " + e.message }; }
  return { status: "done", note: "🔎 " + cands.length + " ασθενείς · " + String((await labsCfg()).base || LABS_BASE).replace(/^https?:\/\//, "").split("/").slice(0, 2).join("/") + (r.msg ? " · " + r.msg.slice(0, 60) : ""), result: { enc, n: cands.length } };
};
JOB_KIND.bxfind = "🔎 Medilabi: αναζήτηση ασθενή";
// ⚡ Βιοψίες ΕΝΟΣ ασθενή. Η σελίδα PatientResults δείχνει από προεπιλογή ΜΟΝΟ την τρέχουσα νοσηλεία (ddlProfile «Νοσηλείας»)
// → postback σε «Σύνολο ιστορικού» (0) και, αν υπάρχει, φίλτρο φόρμας στο παθολογοανατομικό. Πίνακας Infragistics: όνομα εξέτασης
// = <a class='link' onclick=E(..)>, τιμές = <a onclick=EXTRA_INFO(..)> ή «[Εκκρ.]» (εκκρεμεί) / «[Παραγγ.]» (παραγγέλθηκε).
const BX_NAME = /ΒΙΟΨΙΑ|ΠΑΘΟΛΟΓΟΑΝΑΤ|ΠΑΘΟΛΟΓΑΝΑΤ|ΚΥΤΤΑΡΟΛΟΓ|ΙΣΤΟΛΟΓ|ΙΣΤΟΠΑΘ|ΤΟΜΗ ΚΑΤΑΨΥΞ|ΑΝΟΣΟΪΣΤΟΧΗΜ|ΑΝΟΣΟΙΣΤΟΧΗΜ|PAP\b/;
function aspForm(html, pageUrl) {
  const attr = (tag, a) => { const m = tag.match(new RegExp("\\b" + a + "\\s*=\\s*(\"([^\"]*)\"|'([^']*)'|([^\\s>]+))", "i")); return m ? (m[2] ?? m[3] ?? m[4] ?? "") : ""; };
  const unent = (v) => String(v || "").replace(/&amp;/g, "&").replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/&lt;/g, "<").replace(/&gt;/g, ">");
  const fm = html.match(/<form\b([^>]*)>([\s\S]*?)<\/form>/i); if (!fm) return null;
  const parts = [], sels = {};
  for (const i of fm[2].matchAll(/<input\b([^>]*)>/gi)) {
    const ty = (attr(i[1], "type") || "text").toLowerCase(), nm = attr(i[1], "name"); if (!nm || /^__EVENT/.test(nm)) continue;
    if (/^(submit|image|button|file)$/.test(ty)) continue;
    if ((ty === "checkbox" || ty === "radio") && !/\bchecked\b/i.test(i[1])) continue;
    parts.push([nm, unent(attr(i[1], "value")) || (ty === "checkbox" ? "on" : "")]);
  }
  for (const sm of fm[2].matchAll(/<select\b([^>]*)>([\s\S]*?)<\/select>/gi)) { const nm = attr(sm[1], "name"); if (!nm) continue; const opts = [...sm[2].matchAll(/<option\b([^>]*)>([^<]*)/gi)].map((o) => ({ v: unent(attr(o[1], "value")), t: o[2].trim(), sel: /\bselected\b/i.test(o[1]) })); sels[nm] = opts; const o = opts.find((x) => x.sel) || opts[0]; if (o) parts.push([nm, o.v]); }
  const action = new URL(unent(attr(fm[1], "action")) || pageUrl, pageUrl).href;
  return { parts, sels, action, async post(target, set) {
    const ps = parts.map(([k, v]) => [k, set && k in set ? set[k] : v]);
    const body = ps.map(([k, v]) => enc1253(k) + "=" + enc1253(v)).concat(["__EVENTTARGET=" + enc1253(target || ""), "__EVENTARGUMENT="]).join("&");
    const r = await fetch(action, { method: "POST", credentials: "include", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body });
    return { url: r.url, html: new TextDecoder("windows-1253").decode(await r.arrayBuffer()) };
  } };
}
function bxGridParse(html) {
  const clean = (x) => String(x || "").replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim();
  const nz = (t) => String(t || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase();
  // ημερομηνίες στηλών (επικεφαλίδα του πίνακα, με τη σειρά των στηλών)
  const hdr = (html.match(/mkr:columnHeaderRow[\s\S]*?<\/tr>/i) || [""])[0];
  const dates = [...hdr.matchAll(/<th\b[^>]*>([\s\S]*?)<\/th>/gi)].map((m) => (clean(m[1]).match(/\d{1,2}\/\d{1,2}\/\d{2,4}(?:\s+\d{1,2}:\d{2})?/) || [""])[0]).filter(Boolean);
  const out = new Map();
  for (const tr of html.matchAll(/<tr\b[^>]*>\s*<td>\s*<input\b[^>]*gridCheckBox[\s\S]*?(?=<tr\b[^>]*>\s*<td>\s*<input\b[^>]*gridCheckBox|<\/tbody>\s*<\/table>\s*<\/div>\s*<\/td>\s*<\/tr>\s*<\/tbody>|$)/gi)) {
    const row = tr[0];
    const a0 = row.match(/<a\b[^>]*class=['"]?link['"]?[^>]*>([\s\S]*?)<\/a>/i); if (!a0) continue;
    const nm = clean(a0[1]); if (!nm || nm.length > 140 || !BX_NAME.test(nz(nm))) continue;
    const inner = row.slice(row.indexOf("unfixedDiv") > 0 ? row.indexOf("unfixedDiv") : row.indexOf(a0[0]) + a0[0].length);
    const cells = [...inner.matchAll(/<td\b([^>]*?)(?:\/>|>([\s\S]*?)<\/td>)/gi)].filter((c) => /data-ig=/.test(c[1])).map((c) => c[2] || "");
    // ΚΑΘΕ κελί (ημερομηνία) μετρά: το ίδιο παρασκεύασμα μπορεί να έχει αναφορές σε πολλές ημερομηνίες (π.χ. 12/09/25 και 21/10/26)
    const k0 = nz(nm).replace(/\s+/g, " ");
    cells.forEach((c, i) => {
      const doc = (c.match(/PreviewDoc\((\d+)\)/) || [])[1] || "";
      const st = doc || /checkmark\.png/.test(c) ? "done" : /\[Εκκρ/.test(c) ? "pend" : /\[Παραγγ/.test(c) ? "ord" : (clean(c) ? "done" : "");
      if (!st) return;
      const date = dates[i] || "";
      const k = k0 + "|" + (doc || st + date.split(" ")[0]);
      if (!out.has(k)) out.set(k, { rank: st === "done" ? 3 : st === "pend" ? 2 : 1, st, doc, date, txt: clean(c).replace(/^\[.*?\]$/, "").slice(0, 200), what: nm });
    });
  }
  // ΕΝΑ αποτέλεσμα ανά αναφορά: πολλά παρασκευάσματα του ίδιου αιτήματος έχουν ΤΟ ΙΔΙΟ PDF (DocID) → μία γραμμή με όλα τα σημεία·
  // όσα εκκρεμούν, ομαδοποιούνται ανά ημερομηνία δείγματος
  const short = (w) => w.replace(/^ΒΙΟΨΙΑ\s*\(\s*/i, "").replace(/\.?\s*\)\s*$/, "") || w;
  const grp = new Map();
  for (const x of out.values()) {
    const g = x.doc ? "d" + x.doc : "p" + x.st + "|" + x.date.split(" ")[0];
    const cur = grp.get(g) || { parts: [], x };
    cur.parts.push(short(x.what)); if (!cur.x.date && x.date) cur.x.date = x.date; grp.set(g, cur);
  }
  return [...grp.entries()].map(([g, { parts, x }]) => ({ key: g + "|" + nz(parts.join(",")), what: [...new Set(parts)].join(" · "), parts: [...new Set(parts)], date: x.date.split(" ")[0], pending: x.st !== "done", ordered: x.st === "ord", text: x.txt, docId: x.doc, link: x.doc ? "PDFViewerPopUp.aspx?DocID=" + x.doc : "" }));
}
async function bxItemsForPid(pid) {
  const p = { pid };
  const cfg = await labsCfg(), base = cfg.base || LABS_BASE, url = base + "PatientResults.aspx?PatientID=" + encodeURIComponent(p.pid);
  let g = await labsGet(url);
  if (/Login\.aspx/i.test(g.url)) { const a = await medilabiAutoLogin(base); if (!a.ok) return { status: "failed", note: "🔬 Medilabi: χρειάζεται σύνδεση" }; g = await labsGet(url); }
  let f = aspForm(g.html, g.url), how = "νοσηλεία";
  const profName = f && Object.keys(f.sels).find((k) => /ddlProfile$/.test(k));
  if (profName && (f.sels[profName] || []).some((o) => o.v === "0")) { try { const r = await f.post(profName, { [profName]: "0" }); if (r.html.length > 2000) { g = r; f = aspForm(g.html, g.url); how = "όλο το ιστορικό"; } } catch (e) {} }
  // φίλτρο φόρμας στο παθολογοανατομικό (μικρότερη σελίδα), αν υπάρχει τέτοια φόρμα στο ιστορικό
  const formName = f && Object.keys(f.sels).find((k) => /ddlForm$/.test(k));
  const nz = (t) => String(t || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase();
  const pf = formName ? (f.sels[formName] || []).filter((o) => BX_NAME.test(nz(o.t))) : [];
  let items = bxGridParse(g.html);
  // ΜΟΝΟ τα φιλτραρισμένα στο παθολογοανατομικό (όχι και η γενική σελίδα: τα ίδια ξανά = διπλά)
  if (pf.length) { const all = []; for (const o of pf.slice(0, 4)) { try { const r = await f.post(formName, { [formName]: o.v, ...(profName ? { [profName]: "0" } : {}) }); all.push(...bxGridParse(r.html)); } catch (e) {} } if (all.length) items = all; }
  { const seen = new Map(); for (const it of items) { const k = it.docId ? "d" + it.docId : it.key; const prev = seen.get(k); if (!prev) seen.set(k, it); else prev.parts = [...new Set([...(prev.parts || []), ...(it.parts || [])])], prev.what = prev.parts.join(" · "); } items = [...seen.values()]; }
  items = items.map((b) => Object.assign(b, { pid: p.pid }));
  return { items, how, forms: pf.map((o) => o.t.slice(0, 30)) };
}
JOB_RUNNERS.bxget = async (job) => {
  const p = job.payload || {};
  if (!p.pid) return { status: "failed", note: "χωρίς ασθενή" };
  const r = await bxItemsForPid(p.pid); if (r.status) return r;
  const items = r.items;
  if (!items.length && +(p.hopped || 0) < 1 && await otherBotReady()) return { status: "new", moved: true, zero: true };   // 0 βιοψίες → επιβεβαίωση από άλλο bot
  let enc; try { enc = await fsSealJson({ at: Date.now(), res: [{ name: String(p.label || ""), items }] }); } catch (e) { return { status: "failed", note: "🔐 " + e.message }; }
  const nP = items.filter((b) => b.pending).length;
  return { status: "done", note: "🔬 " + items.length + " παρασκευάσματα (" + (items.length - nP) + " βγήκαν, " + nP + " εκκρεμούν) · " + r.how + (r.forms.length ? " · φόρμες: " + r.forms.join(", ") : ""), result: { enc, n: items.length } };
};
JOB_KIND.bxget = "🔬 Medilabi: βιοψίες ασθενή";
// 👋 «Ποιος είμαι;» — ειδοποίηση στην οθόνη ΑΥΤΟΥ του υπολογιστή, για να του δοθεί όνομα από το κινητό (Γωνιακός/Μεσαίος/Πόρτα)
JOB_RUNNERS.botwho = async (job) => {
  const me = await botId(), nm = String((job.payload || {}).label || "");
  try { await chrome.notifications.create("efbot-who-" + Date.now(), { type: "basic", iconUrl: chrome.runtime.getURL("icons/icon128.png"), title: "👋 ef-bot: ΑΥΤΟΣ ο υπολογιστής" + (nm ? " = «" + nm + "»" : ""), message: "Κωδικός " + me.slice(-5) + " — δείτε στο κινητό ποιο όνομα να του δώσετε.", priority: 2, requireInteraction: true }); } catch (e) { try { notify("👋 ef-bot: ΑΥΤΟΣ ο υπολογιστής" + (nm ? " = «" + nm + "»" : ""), "Κωδικός " + me.slice(-5), true); } catch (x) {} }
  // 6/11: μεγάλο μήνυμα σε ΚΑΘΕ καρτέλα Παραδόχαρτου + η πρώτη έρχεται μπροστά (οι ειδοποιήσεις των Windows συχνά δεν φαίνονται)
  const code = me.slice(-5), nm2 = nm.replace(/[<>&"']/g, "");
  const tabs = (await chrome.tabs.query({ url: APP_HOSTS.map((h) => `https://${h}/*`) }).catch(() => [])).filter((t) => !t.incognito);
  let shown = 0;
  for (const t of tabs) {
    const [r] = await chrome.scripting.executeScript({ target: { tabId: t.id }, world: "MAIN", args: [code, nm2], func: (code, nm) => { try { const d = document.createElement("div"); d.id = "efbotWho";
      d.style.cssText = "position:fixed;inset:0;z-index:2147483647;background:rgba(10,132,255,.95);color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;font:700 44px system-ui;text-align:center;padding:20px";
      d.innerHTML = "<div style='font-size:90px'>👋</div><div>ΑΥΤΟΣ ο υπολογιστής</div><div style='font-size:28px;margin-top:12px;opacity:.9'>κωδικός …" + code + (nm ? " · τώρα: «" + nm + "»" : "") + "</div><div style='font-size:18px;margin-top:24px;opacity:.8'>(κλείνει σε 60″ ή με κλικ)</div>";
      d.onclick = () => d.remove(); document.getElementById("efbotWho")?.remove(); document.body.appendChild(d); setTimeout(() => d.remove(), 60000); return true; } catch (e) { return false; } } }).catch(() => [null]);
    if (r && r.result) shown++;
  }
  if (tabs[0]) { try { await chrome.windows.update(tabs[0].windowId, { focused: true, state: "normal" }); await chrome.tabs.update(tabs[0].id, { active: true }); } catch (e) {} }
  else { try { const w = await chrome.windows.create({ url: APP_URL, focused: true, state: "normal" }); } catch (e) {} }
  return { status: "done", note: "👋 στον υπολογιστή " + code + ": " + (shown ? shown + " καρτέλα/ες Παραδόχαρτου (μπλε οθόνη)" : "καμία καρτέλα Παραδόχαρτου — άνοιξε νέο παράθυρο") };
};
// 🎛 Κέντρο ελέγχου (Παραδόχαρτο → Υπολογιστές bot): ενέργειες ΜΟΝΟ σε αυτόν τον υπολογιστή (payload.only) — καμία καταχώριση πουθενά
JOB_RUNNERS.botctl = async (job) => {
  const p = job.payload || {}, op = String(p.op || ""), me = await botId();
  if (onlyBotOf(p) !== me) return { status: "failed", note: "🎛 μόνο με στόχο συγκεκριμένο υπολογιστή" };
  const busy = jobRunningId && jobRunningId !== job.id;
  if (op === "appreload") { let n = 0; for (const t of (await chrome.tabs.query({ url: `https://${APP_HOSTS[0]}/*` }).catch(() => [])).filter((t) => !t.incognito)) { await chrome.tabs.reload(t.id).catch(() => {}); n++; } if (!n) await chrome.tabs.create({ url: APP_URL, active: false }).catch(() => {}); return { status: "done", note: "🎛 Παραδόχαρτο: " + (n ? "ανανεώθηκαν " + n + " καρτέλες" : "άνοιξε νέα καρτέλα") }; }
  if (op === "sys") { sysMem.at = 0; await sysMemRefresh(true); const m = sysMem; if (!m.at) return { status: "failed", note: "🎛 το βοηθητικό Windows δεν απάντησε" };
    return { status: "done", note: "🎛 CPU " + m.cpu + "% · RAM ελεύθερη " + (m.free / 1024).toFixed(1) + "/" + (m.ram / 1024).toFixed(1) + " GB · Chrome " + (m.cr ? m.cr.n + " διεργασίες, " + (m.cr.mb / 1024).toFixed(1) + " GB" : "—") + (m.dfree >= 0 ? " · δίσκος C ελεύθερος " + m.dfree + " GB" : "") + " · ανοιχτός " + m.upH + " ώρες" }; }
  if (op === "reboot") { if (busy) return { status: "failed", note: "🎛 τρέχει εργασία — όχι επανεκκίνηση τώρα" }; const r = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "reboot", sec: 120 }).catch((e) => ({ ok: false, err: e.message }));
    return r && r.ok ? { status: "done", note: "♻ Τα Windows θα κάνουν επανεκκίνηση σε 2′ (μήνυμα στην οθόνη). Μετά: είσοδος στα Windows → ανοίγουν μόνα τους το πρόγραμμα ενημέρωσης και το Chrome." } : { status: "failed", note: "♻ " + ((r && r.err) || "το βοηθητικό Windows δεν απάντησε (θέλει ενημέρωση;)") }; }
  if (op === "rebootcancel") { const r = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "rebootcancel" }).catch((e) => ({ ok: false, err: e.message })); return { status: r && r.ok ? "done" : "failed", note: r && r.ok ? "✋ Ακυρώθηκε η επανεκκίνηση" : "✋ " + ((r && r.err) || "δεν υπήρχε προγραμματισμένη επανεκκίνηση") }; }
  if (op === "sttinstall" || op === "sttstatus") { const r = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op }).catch((e) => ({ ok: false, err: e.message }));
    if (!r || !r.ok) return { status: "failed", note: "🎤 " + ((r && r.err) || "το βοηθητικό των Windows δεν απάντησε (θέλει ενημέρωση;)") };
    return { status: "done", note: "🎤 Whisper: " + (op === "sttinstall" ? "η εγκατάσταση ξεκίνησε στο παρασκήνιο (~600 MB)" : (r.status || "—") + " · whisper-cli " + (r.exe ? "✓" : "✗") + " · μοντέλο " + Math.round((r.model || 0) / 1048576) + " MB" + (r.part ? " (λήψη " + Math.round(r.part / 1048576) + " MB)" : "") + " · πυρήνες " + (r.cores || "?")), result: r }; }
  if (op === "printers") { const r = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "printers" }).catch((e) => ({ ok: false, err: e.message })); if (!r || !r.ok) return { status: "failed", note: "🖨 " + ((r && r.err) || "το βοηθητικό Windows δεν απάντησε (θέλει ενημέρωση;)") };
    const L = (r.printers || []).map((x) => (x.def ? "⭐ " : "") + x.name + (x.off ? " (εκτός σύνδεσης)" : x.err > 2 ? " (σφάλμα " + x.err + ")" : "")); return { status: "done", note: "🖨 " + (L.join(" · ") || "κανένας εκτυπωτής") + (printA4Log ? " · τελευταία A4: " + (printA4Log.ok ? "✓ " + printA4Log.printer : "✗ " + printA4Log.err) : "") }; }
  if (op === "tidy") {   // 🧹 ασφαλές καθάρισμα: «κοίμισμα» καρτελών στο παρασκήνιο (ξαναφορτώνουν μόλις τις ανοίξεις) + κλείσιμο ανώνυμων παραθύρων του bot όταν δεν δουλεύει
    if (busy) return { status: "failed", note: "🎛 τρέχει εργασία — ξαναδοκιμάστε σε λίγο" };
    sysMem.at = 0; await sysMemRefresh(true); const f0 = sysMem.free;
    let nd = 0; for (const t of await chrome.tabs.query({}).catch(() => [])) { if (t.active || t.discarded || t.audible || t.incognito || t.pinned) continue; let h = ""; try { h = new URL(t.url || "").host; } catch (e) {} if (APP_HOSTS.includes(h) || CLIN_HOSTS.test(t.url || "")) continue; if (await chrome.tabs.discard(t.id).catch(() => null)) nd++; }
    const ni = await botIncogReset().catch(() => 0);
    const tr = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "trim" }).catch(() => null);
    await E.sleep(4000); sysMem.at = 0; await sysMemRefresh(true); const f1 = sysMem.free;
    return { status: "done", note: "🧹 κοιμήθηκαν " + nd + " καρτέλες, έκλεισαν " + (+ni || 0) + " παράθυρα bot" + (tr && tr.ok ? " · συμπιέστηκε η μνήμη " + tr.n + " προγραμμάτων" : "") + (f0 > 0 && f1 > 0 ? " · RAM ελεύθερη " + (f0 / 1024).toFixed(1) + " → " + (f1 / 1024).toFixed(1) + " GB" : "") }; }
  if (op === "printclear") { const r = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "printclear", printer: p.printer ? String(p.printer) : "" }).catch((e) => ({ ok: false, err: e.message }));
    if (!r || !r.ok) return { status: "failed", note: "🖨 " + ((r && r.err) || "το βοηθητικό Windows δεν απάντησε (θέλει ενημέρωση;)") };
    sysExt.at = 0; sysMem.at = 0; await sysMemRefresh(true);
    return { status: "done", note: "🖨 καθαρίστηκαν " + r.removed + " εκτυπώσεις" + (r.failed ? " · " + r.failed + " άλλου χρήστη (θέλουν διαχειριστή)" : "") + (p.printer ? " από «" + p.printer + "»" : "") }; }
  if (op === "ctupdate") { const r = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "ctupdate" }).catch((e) => ({ ok: false, err: e.message }));
    return { status: r && r.ok ? "done" : "failed", note: r && r.ok ? "🩻 εντολή ενημέρωσης CT Viewer: ✓" + (r.running ? " · η εφαρμογή είναι ΑΝΟΙΧΤΗ — θα ενημερωθεί μόλις κλείσει" : " · ενημέρωση μέσα σε 1–3′") : "🩻 " + ((r && r.err) || "χωρίς απάντηση") }; }
  if (op === "dbinstall") { const r = await chrome.runtime.sendNativeMessage("gr.efbot.vault", Object.assign({ op: "dbinstall" }, /^(satellite|main)$/.test(String(p.role || "")) ? { role: p.role, pc: String(p.pc || "").slice(0, 40) } : {})).catch((e) => ({ ok: false, err: e.message }));
    return { status: r && r.ok ? "done" : "failed", note: "🗂 Αρχείο Ασθενών: " + (r && r.ok ? "✅ σε λειτουργία · " + r.patients + " ασθενείς" : "✗ " + ((r && r.err) || "χωρίς απάντηση")) + "\n" + [].concat((r && r.steps) || []).join("\n") }; }
  if (op === "dbshortcut") { const r = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "dbshortcut" }).catch((e) => ({ ok: false, err: e.message }));
    return { status: r && r.ok ? "done" : "failed", note: "🗂 " + (r && r.ok ? [].concat(r.steps || []).join(" · ") : ((r && r.err) || "χωρίς απάντηση")) }; }
  // 📧 8/11: ΜΟΝΟ ανάγνωση — διεύθυνση (χωρίς παραμέτρους) καρτελών webmail (Kerio κ.λπ.)· τίποτα άλλο από άλλες καρτέλες
  if (op === "mailtab") { const L = []; for (const t of await chrome.tabs.query({}).catch(() => [])) { let u; try { u = new URL(t.url || t.pendingUrl || ""); } catch (e) { continue; }
      if (/kerio|webmail|^mail\.|\/webmail\b|\/mail\b/i.test(u.hostname + u.pathname) || /kerio/i.test(t.title || "")) L.push(u.origin + u.pathname.split("/").slice(0, 3).join("/") + (t.incognito ? " (ανώνυμο)" : "")); }
    return { status: "done", note: "📧 " + (L.length ? [...new Set(L)].join(" · ") : "καμία καρτέλα webmail ανοιχτή") }; }
  if (op === "mailbm") { const r = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "mailbm" }).catch((e) => ({ ok: false, err: e.message }));
    return { status: r && r.ok ? "done" : "failed", note: "📧 bookmarks: " + (r && r.ok ? ((r.items || []).map((x) => (x.name ? x.name + " → " : "") + x.url).join(" · ") || "κανένα webmail") : ((r && r.err) || "χωρίς απάντηση")) }; }
  if (op === "drives") { const r = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "drives", probe: p.probe ? String(p.probe).slice(0, 300) : null }).catch((e) => ({ ok: false, err: e.message }));
    return { status: r && r.ok ? "done" : "failed", note: "💿 " + (r && r.ok ? JSON.stringify({ net: r.net, probe: r.probe, drives: r.drives, cdrom: r.cdrom }).slice(0, 3000) : ((r && r.err) || "χωρίς απάντηση")) }; }
  if (op === "fsreset") { try { fsPort && fsPort.disconnect(); } catch (e) {} fsPort = null;
    const r = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "fsreset" }).catch((e) => ({ ok: false, err: e.message }));
    return { status: r && r.ok ? "done" : "failed", note: "🧹 βοηθητικά αρχείων: " + (r && r.ok ? "έκλεισαν " + r.killed : "✗ " + ((r && r.err) || "χωρίς απάντηση")) }; }
  if (op === "dbcall") { const r = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "dbcall", method: String(p.method || "GET"), path: String(p.path || "/health"), body: p.body === undefined ? null : p.body, who: "botctl" }).catch((e) => ({ ok: false, err: e.message }));
    return { status: r && r.ok ? "done" : "failed", note: "🗂 " + (r && r.ok ? r.status + " " + String(r.json || "").slice(0, 1500) : ((r && r.err) || "χωρίς απάντηση")) }; }
  if (op === "ctinstall") { const r = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "ctinstall", force: !!p.force }).catch((e) => ({ ok: false, err: e.message }));
    return { status: r && r.ok ? "done" : "failed", note: "🩻 εγκατάσταση CT Viewer: " + (r && r.ok ? "✅" : "✗ " + ((r && r.err) || "χωρίς απάντηση")) + "\n" + [].concat((r && r.steps) || []).join("\n") }; }
  if (op === "ctlog") { const r = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "ctlog" }).catch((e) => ({ ok: false, err: e.message })); if (!r || !r.ok) return { status: "failed", note: "🩻 " + ((r && r.err) || "χωρίς απάντηση") };
    return { status: "done", note: "🩻 εφαρμογή: " + (r.ver || "—") + (r.exe === false ? " ⚠ λείπει το exe" : "") + (r.running ? " · ανοιχτή" : " · κλειστή") + "\n" + [].concat(r.upd || []).join("\n") + "\nδεξί κλικ: " + (r.cmd || "ΔΕΝ είναι γραμμένο") + "\nσυντόμευση εφαρμογής: " + ((r.lnk || []).join(", ") || "ΔΕΝ υπάρχει (δεν έχει εγκατασταθεί)") + "\n" + [].concat(r.log || []).join("\n") }; }
  if (op === "health") { sysExt.at = 0; sysMem.at = 0; await sysMemRefresh(true); netLat.at = 0; await netLatRefresh().catch(() => {}); const x = sysExt, L = [];
    if (!x.at) return { status: "failed", note: "🩺 το βοηθητικό Windows δεν απάντησε (θέλει ενημέρωση;)" };
    const pq = (x.pq || []).filter((q) => q.jobs || q.off || q.err > 2); L.push("🖨 " + (pq.length ? pq.map((q) => q.name + ": " + (q.jobs ? q.jobs + " στην ουρά" + (q.old ? " (" + q.old + " κολλημένες >10′)" : "") : "") + (q.off ? " εκτός σύνδεσης" : "") + (q.err > 2 ? " σφάλμα " + q.err : "")).join(" · ") : "όλα καθαρά"));
    L.push("🛡 Defender: " + (!x.def || x.def.err ? "άγνωστο" : (x.def.on && x.def.rt ? "ενεργός" : "⚠ ΑΝΕΝΕΡΓΟΣ") + " · ορισμοί " + x.def.sigD + " ημ." + (x.def.thr ? " · ⚠ " + x.def.thr + " απειλές (7 ημ.)" : "")));
    L.push("🔄 Windows: " + (sysMem.reboot ? "⚠ περιμένουν επανεκκίνηση" : "ενημερωμένα") + (x.wuDays >= 0 ? " · τελευταία ενημέρωση πριν " + x.wuDays + " ημ." : "") + " · αυτόματη είσοδος " + (x.autologon ? "ναι" : "όχι"));
    L.push("🕒 ρολόι: " + (netLat.skew == null ? "άγνωστο" : Math.abs(netLat.skew) <= 30 ? "σωστό" : "⚠ " + (netLat.skew > 0 ? "μπροστά " : "πίσω ") + Math.abs(netLat.skew) + "″"));
    L.push("🌐 " + Object.keys(netLat.v || {}).map((n) => n + " " + (netLat.v[n] < 0 ? "✗" : netLat.v[n] + "ms")).join(" · "));
    return { status: "done", note: "🩺 " + L.join("\n") }; }
  if (op === "appopen") { await chrome.tabs.create({ url: APP_URL, active: true }).catch(() => {}); return { status: "done", note: "🎛 άνοιξε το Παραδόχαρτο (" + APP_URL + ")" }; }
  if (op === "emrrelog") { if (busy) return { status: "failed", note: "🎛 τρέχει εργασία — ξαναδοκιμάστε σε λίγο" }; const n = await botIncogReset(); return { status: "done", note: "🎛 ΝΠΣ: νέα σύνδεση στην επόμενη εργασία (" + n + " ανώνυμα παράθυρα έκλεισαν)" }; }
  if (op === "update") { updNudgeAt = 0; updSeenAt = 1; const res = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "update" }).catch((e) => ({ ok: false, err: e.message })); return { status: res && res.ok ? "done" : "failed", note: "🎛 ενημέρωση: " + (res && res.ok ? "ξεκίνησε το πρόγραμμα ενημέρωσης" : String((res && res.err) || "χωρίς απάντηση")) }; }
  if (op === "restart") { if (busy) return { status: "failed", note: "🎛 τρέχει εργασία — όχι επανεκκίνηση τώρα" }; setTimeout(() => chrome.runtime.reload(), 3000); return { status: "done", note: "🎛 επανεκκίνηση του bot σε 3″" }; }
  return { status: "failed", note: "🎛 άγνωστη ενέργεια" };
};
JOB_KIND.botctl = "🎛 Κέντρο ελέγχου bot";
JOB_KIND.botwho = "👋 Αναγνώριση υπολογιστή";
// 🩺 Διάγνωση φόρτου ΑΥΤΟΥ του υπολογιστή (μόνο ανάγνωση): CPU/μνήμη/διεργασίες + παράθυρα/καρτέλες του bot
JOB_RUNNERS.sysdiag = async (job) => {
  const me = await botId();
  const wins = await chrome.windows.getAll({ populate: true }).catch(() => []);
  const { efbotOwnWins: own = [] } = await chrome.storage.session.get("efbotOwnWins").catch(() => ({}));
  const hosts = {}; let tabs = 0, botTabs = 0, botWins = 0, discarded = 0;
  for (const w of wins) { const mine = w.incognito || own.includes(w.id); if (mine) botWins++;
    for (const t of w.tabs || []) { tabs++; if (mine) botTabs++; if (t.discarded) discarded++; let h = ""; try { h = new URL(t.url || t.pendingUrl || "").hostname; } catch (e) {} if (mine) hosts[h] = (hosts[h] || 0) + 1; } }
  const sys = await chrome.runtime.sendNativeMessage("gr.efbot.vault", { op: "sysinfo" }).catch((e) => ({ ok: false, err: e.message }));
  const al = await chrome.alarms.getAll().catch(() => []);
  const { efbot: stD } = await chrome.storage.local.get("efbot").catch(() => ({}));
  const { efbotComorbState: cst = "" } = await chrome.storage.session.get("efbotComorbState").catch(() => ({}));
  const comorb = { auto: !!stD?.settings?.comorbAuto, notReady: stD ? comorbNotReady(stD) : "?", lease: leaseOk, busy: comorbBusy, state: String(cst).slice(0, 160), fakelosAmka: !!((stD?.workflows || []).find((x) => x.id === "fakelos_amka") && !untaughtSteps((stD.workflows || []).find((x) => x.id === "fakelos_amka"))) };
  const r = { bot: me, v: chrome.runtime.getManifest().version, wins: wins.length, tabs, botWins, botTabs, discarded, botHosts: hosts, alarms: al.map((a) => a.name + "/" + a.periodInMinutes), sys, envFails: envFails.length, comorb, at: Date.now() };
  return { status: "done", note: "🩺 " + me.slice(-5) + ": CPU " + (sys && sys.ok ? sys.cpu + "% · RAM ελεύθερη " + sys.freeMb + "/" + sys.ramMb + " MB · Chrome " + sys.chrome.n + " διεργ. " + sys.chrome.mb + " MB" : "—") + " · καρτέλες " + tabs + " (bot " + botTabs + ")" + " · 🩺 αυτόματο " + (comorb.auto ? "ναι" : "όχι") + (comorb.lease ? " (κεντρικός)" : "") + (comorb.notReady ? " · ⚠ " + comorb.notReady : "") + (comorb.fakelosAmka ? "" : " · ΑΜΚΑ φακέλου: χωρίς εκμάθηση") + (comorb.state ? " · «" + comorb.state + "»" : "") + (sys && sys.psKinds ? " · PowerShell: " + Object.entries(sys.psKinds).sort((a, b) => b[1] - a[1]).map(([k, n]) => k + "×" + n).join(", ") : ""), result: r };
};
JOB_KIND.sysdiag = "🩺 Διάγνωση υπολογιστή";
// 📄 PDF αποτελεσμάτων ασθενή από το Medilabi (PatientResults → «Εξαγωγή PDF»), κρυπτογραφημένο στο img-enc όπως τα αρχεία
JOB_RUNNERS.bxpdf = async (job) => {
  const p = job.payload || {}, cfg = await labsCfg(), base = cfg.base || LABS_BASE;
  if (!p.pid) return { status: "failed", note: "📄 χωρίς αναγνωριστικό ασθενή — κάνε ξανά «Έλεγχος τώρα»" };
  imgCleanup();
  let ck; try { ck = await imgClinicKey(); } catch (e) { return { status: "failed", note: "🔐 " + e.message }; }
  const attr = (tag, a) => { const m = tag.match(new RegExp("\\b" + a + "\\s*=\\s*(\"([^\"]*)\"|'([^']*)'|([^\\s>]+))", "i")); return m ? (m[2] ?? m[3] ?? m[4] ?? "") : ""; };
  const unent = (v) => String(v || "").replace(/&amp;/g, "&").replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/&lt;/g, "<").replace(/&gt;/g, ">");
  let g = await labsGet(base + "PatientResults.aspx?PatientID=" + encodeURIComponent(p.pid));
  if (/Login\.aspx/i.test(g.url)) { const a = await medilabiAutoLogin(base); if (!a.ok) return { status: "failed", note: "📄 Medilabi: χρειάζεται σύνδεση" }; g = await labsGet(base + "PatientResults.aspx?PatientID=" + encodeURIComponent(p.pid)); }
  const fm = g.html.match(/<form\b([^>]*)>([\s\S]*?)<\/form>/i);
  if (!fm) return { status: "failed", note: "📄 δεν βρέθηκε η σελίδα αποτελεσμάτων" };
  const parts = [];
  for (const i of fm[2].matchAll(/<input\b([^>]*)>/gi)) {
    const ty = (attr(i[1], "type") || "text").toLowerCase(), nm = attr(i[1], "name"); if (!nm || /^__EVENT/.test(nm)) continue;
    if (/^(submit|image|button|file)$/.test(ty)) continue;
    if ((ty === "checkbox" || ty === "radio") && !/\bchecked\b/i.test(i[1])) continue;
    parts.push([nm, unent(attr(i[1], "value")) || (ty === "checkbox" ? "on" : "")]);
  }
  for (const sm of fm[2].matchAll(/<select\b([^>]*)>([\s\S]*?)<\/select>/gi)) { const nm = attr(sm[1], "name"); if (!nm) continue; const o = sm[2].match(/<option\b[^>]*\bselected\b[^>]*>/i) || sm[2].match(/<option\b[^>]*>/i); if (o) parts.push([nm, unent(attr(o[0], "value"))]); }
  const action = new URL(unent(attr(fm[1], "action")) || "PatientResults.aspx", g.url).href;
  const tryPost = async (target) => {
    const body = parts.map(([k, v]) => enc1253(k) + "=" + enc1253(v)).concat(["__EVENTTARGET=" + enc1253(target), "__EVENTARGUMENT="]).join("&");
    const r = await fetch(action, { method: "POST", credentials: "include", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body });
    const buf = new Uint8Array(await r.arrayBuffer()), ct = r.headers.get("content-type") || "";
    if (/pdf/i.test(ct) || (buf[0] === 0x25 && buf[1] === 0x50 && buf[2] === 0x44 && buf[3] === 0x46)) return { pdf: buf };
    const html = new TextDecoder("windows-1253").decode(buf);
    // μερικές φορές η απάντηση ανοίγει το PDF σε νέο παράθυρο: ψάχνουμε τη διεύθυνση
    const m = html.match(/(?:window\.open|location(?:\.href)?\s*=)\s*\(?\s*['"]([^'"]+)['"]/i) || html.match(/['"]([^'"]*\.(?:pdf|ashx)[^'"]*)['"]/i) || html.match(/['"]([^'"]*(?:Report|Pdf|Export)[A-Za-z]*\.aspx[^'"]*)['"]/i);
    if (m) { const u = new URL(unent(m[1]), r.url).href; const r2 = await fetch(u, { credentials: "include" }); const b2 = new Uint8Array(await r2.arrayBuffer()); if (/pdf/i.test(r2.headers.get("content-type") || "") || (b2[0] === 0x25 && b2[1] === 0x50)) return { pdf: b2 }; return { diag: "παράθυρο " + u.replace(/\d{5,}/g, "…").slice(-80) + " → " + (r2.headers.get("content-type") || "?") }; }
    return { diag: ct + " · " + html.length + "B" };
  };
  let res = null, diag = [];
  // 📄 αναφορά βιοψίας: PreviewDoc(DocID) → PDFViewerPopUp.aspx?DocID=… (σελίδα με το PDF μέσα· ψάχνουμε τη διεύθυνση του αρχείου)
  const docId = (String(p.link || "").match(/DocID=(\d+)/i) || [])[1] || p.docId;
  if (docId) {
    try {
      const u0 = new URL("PDFViewerPopUp.aspx?DocID=" + docId, g.url).href;
      const r0 = await fetch(u0, { credentials: "include" }); const b0 = new Uint8Array(await r0.arrayBuffer());
      if (/pdf/i.test(r0.headers.get("content-type") || "") || (b0[0] === 0x25 && b0[1] === 0x50 && b0[2] === 0x44 && b0[3] === 0x46)) res = b0;
      else { const h0 = new TextDecoder("windows-1253").decode(b0);
        const cand = [...h0.matchAll(/(?:src|data|href)\s*=\s*["']([^"']+)["']/gi)].map((m) => unent(m[1])).filter((x) => /pdf|ashx|Doc|Blob|View|Show|Get/i.test(x) && !/\.(css|js|png|gif|jpg)(\?|$)/i.test(x));
        for (const c of cand.slice(0, 6)) { try { const r1 = await fetch(new URL(c, r0.url).href, { credentials: "include" }); const b1 = new Uint8Array(await r1.arrayBuffer()); if (/pdf/i.test(r1.headers.get("content-type") || "") || (b1[0] === 0x25 && b1[1] === 0x50 && b1[2] === 0x44 && b1[3] === 0x46)) { res = b1; break; } } catch (e) {} }
        if (!res) diag.push("DocID: " + h0.length + "B " + cand.slice(0, 4).join(" ").replace(/\d{5,}/g, "•").slice(0, 160)); }
    } catch (e) { diag.push("DocID: " + e.message); }
    if (!res) return { status: "failed", note: "📄 η αναφορά δεν ήρθε ως PDF (" + diag.join(" · ").slice(0, 220) + ")" };
  }
  if (!res && p.link) {
    try {
      const pb = String(p.link).match(/__doPostBack\(\s*['"]([^'"]+)['"]/);
      const wo = String(p.link).match(/(?:window\.open|open)\(\s*['"]([^'"]+)['"]/) || (/^(?!javascript:)[^\s]+$/i.test(p.link) ? [0, p.link] : null);
      if (pb) { const r = await tryPost(pb[1]); if (r.pdf) res = r.pdf; else diag.push("κελί: " + r.diag); }
      else if (wo) { const u = new URL(wo[1], g.url).href; const r2 = await fetch(u, { credentials: "include" }); const b2 = new Uint8Array(await r2.arrayBuffer()); if (/pdf/i.test(r2.headers.get("content-type") || "") || (b2[0] === 0x25 && b2[1] === 0x50)) res = b2; else diag.push("κελί: " + (r2.headers.get("content-type") || "?")); }
    } catch (e) { diag.push("κελί: " + e.message); }
    if (!res) return { status: "failed", note: "📄 η αναφορά της βιοψίας δεν ήρθε ως PDF (" + diag.join(" · ").slice(0, 200) + ")" };
  }
  if (!res && p.link) return { status: "failed", note: "📄 —" };
  for (const t of (res ? [] : ["ctl00$splt$tmpl1$RightPanelContent$btnPDFLastFive", "ctl00$splt$tmpl1$RightPanelContent$btnPDFAll"])) {
    try { const r = await tryPost(t); if (r.pdf) { res = r.pdf; break; } diag.push(t.split("$").pop() + ": " + r.diag); } catch (e) { diag.push(e.message); }
  }
  if (!res) return { status: "failed", note: "📄 το Medilabi δεν έδωσε PDF (" + diag.join(" · ").slice(0, 300) + ")" };
  const sealed = await imgSeal(ck.key, res); await imgUpload(job.id + "/0.bin", sealed);
  const env = { e: 1, kid: ck.kid, d: b64e(await imgSeal(ck.key, new TextEncoder().encode(JSON.stringify({ files: [{ n: "apotelesmata.pdf", c: 0, o: 0, l: res.length }], src: "Medilabi" })))) };
  return { status: "done", note: "📄 PDF " + Math.round(res.length / 1024) + " KB (κρυπτογραφημένο)", result: { idx: env, chunks: 1 } };
};
JOB_KIND.bxpdf = "📄 Medilabi: PDF αποτελεσμάτων";
// αυτόματος έλεγχος κάθε 12 ώρες (με την τελευταία λίστα ασθενών που έστειλε το Παραδόχαρτο)
alarmEnsure("efbot-bx", { delayInMinutes: 5, periodInMinutes: 10 });
chrome.alarms.onAlarm.addListener(async (a) => {
  if (a.name !== "efbot-bx") return;
  try {
    const { efbotBxPts: L, efbotBxLast: last = 0 } = await chrome.storage.local.get(["efbotBxPts", "efbotBxLast"]);
    if (!L || !L.pts || !L.pts.length) return;
    // 8/11 (απόφαση χρήστη): ΜΙΑ φορά κάθε βράδυ ΑΡΓΑ — 01:00 (01:00–03:59 αν ήταν απασχολημένος/κλειστός)· αλλιώς μόνο «↻ Έλεγχος τώρα»
    { const n = new Date(), h = n.getHours(), t1 = new Date(n); t1.setHours(1, 0, 0, 0); if (h < 1 || h >= 4 || last >= t1.getTime()) return; }
    // ΜΟΝΟ ο κεντρικός υπολογιστής (μίσθωση): αλλιώς κάθε bot έφτιαχνε τη δική του (διπλός έλεγχος #539/#540, 5/11)
    if (!(await leaseHeld().catch(() => false))) return;
    await chrome.storage.local.set({ efbotBxLast: Date.now() });
    await jobsInsert({ name_key: "zzz_bx", name: "🔬 Βιοψίες (αυτόματα)", room: null, kind: "bxscan", payload: { pts: L.pts, auto: true }, status: "new" });
  } catch (e) {}
});

// ===== 🩻 Φάκελος απεικονιστικών της κλινικής → κινητό, κρυπτογραφημένα =====
// Το βοηθητικό «gr.efbot.files» (tools/efbot-files.ps1) διαβάζει ΜΟΝΟ μέσα στο C:\OUROLOGIKI_KLINIKH. Το bot βρίσκει τον
// φάκελο του ασθενή (ελληνικά↔λατινικά, όπως ο viewer), διαβάζει τα DICOM, τα κρυπτογραφεί με το ΚΛΕΙΔΙ ΚΛΙΝΙΚΗΣ
// (AES-GCM, ίδια μορφή με το pdxCK: iv(12)+ct) και τα ανεβάζει προσωρινά στο img-enc/<εργασία>/. Η βάση/αποθήκη βλέπει
// μόνο κρυπτογραφημένα· ονόματα αρχείων/φακέλων μπαίνουν στο κρυπτογραφημένο ευρετήριο. Το κινητό τα σβήνει μόλις τα πάρει,
// και το bot σβήνει ό,τι μένει πάνω από 6 ώρες.
let fsPort = null; const fsWait = []; let fsIdleT = 0, fsBuilding = false;
// 🪶 ΜΝΗΜΗ: το βοηθητικό κρατά ευρετήριο ~380.000 εγγραφών (εκατοντάδες MB). Όταν δεν χρησιμοποιείται για 4′ κλείνει
// (το ευρετήριο μένει στον δίσκο και φορτώνει ξανά όταν χρειαστεί) — εκτός αν χτίζει ευρετήριο (νύχτα).
function fsIdleArm() { clearTimeout(fsIdleT); fsIdleT = setTimeout(() => { if (fsWait.length || jobRunningKind === "imgmap" || sideRunningId) return fsIdleArm(); if (fsBuilding) return fsIdleArm(); try { fsPort && fsPort.disconnect(); } catch (e) {} fsPort = null; }, 240000); }
function fsCall(msg, ms = 60000) {
  return new Promise((res0) => {
    const res = (m) => { try { if (m && typeof m === "object" && "building" in m) fsBuilding = !!m.building; } catch (e) {} fsIdleArm(); res0(m); };
    if (!fsPort) {
      try { fsPort = chrome.runtime.connectNative("gr.efbot.files"); } catch (e) { return res({ ok: false, err: "δεν υπάρχει το βοηθητικό απεικονιστικών" }); }
      fsPort.onMessage.addListener((m) => { const w = fsWait.shift(); if (w) { clearTimeout(w.t); w.res(m); } });
      fsPort.onDisconnect.addListener(() => { const er = (chrome.runtime.lastError && chrome.runtime.lastError.message) || "κόπηκε η σύνδεση με το βοηθητικό"; fsPort = null; while (fsWait.length) { const w = fsWait.shift(); clearTimeout(w.t); w.res({ ok: false, err: /not found|specified native/i.test(er) ? "το βοηθητικό απεικονιστικών δεν έχει εγκατασταθεί ακόμα (το εγκαθιστά μόνο του το πρόγραμμα ενημερώσεων σε ≤10′)" : er }); } });
    }
    const w = { res, t: setTimeout(() => { const i = fsWait.indexOf(w); if (i >= 0) fsWait.splice(i, 1); try { fsPort && fsPort.disconnect(); } catch (e) {} fsPort = null; res({ ok: false, err: "το βοηθητικό δεν απάντησε" }); }, ms) };
    fsWait.push(w);
    try { fsPort.postMessage(msg); } catch (e) { fsWait.splice(fsWait.indexOf(w), 1); clearTimeout(w.t); fsPort = null; res({ ok: false, err: e.message }); }
  });
}
// ίδια κανονικοποίηση ονομάτων με τον viewer (ct.html): ελληνικά ↔ greeklish, τυπογραφικά λάθη
const imgDeacc = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
const IMG_GR2 = [["ου", "u"], ["αι", "e"], ["ει", "i"], ["οι", "i"], ["υι", "i"], ["αυ", "av"], ["ευ", "ev"], ["μπ", "b"], ["ντ", "d"], ["γκ", "g"], ["γγ", "g"], ["τσ", "ts"], ["τζ", "tz"]];
const IMG_GR1 = { α: "a", β: "v", γ: "g", δ: "d", ε: "e", ζ: "z", η: "i", θ: "th", ι: "i", κ: "k", λ: "l", μ: "m", ν: "n", ξ: "x", ο: "o", π: "p", ρ: "r", σ: "s", ς: "s", τ: "t", υ: "i", φ: "f", χ: "ch", ψ: "ps", ω: "o" };
function imgSkel(s) {
  let t = imgDeacc(s).replace(/[^a-zα-ω]+/g, " ");
  for (const [a, b] of IMG_GR2) t = t.split(a).join(b);
  t = t.replace(/[α-ω]/g, (c) => IMG_GR1[c] || "");
  t = t.replace(/ou/g, "u").replace(/kh|ch/g, "h").replace(/th/g, "t").replace(/ph/g, "f").replace(/ks/g, "x").replace(/c/g, "k")
    .replace(/[yj]/g, "i").replace(/w/g, "v").replace(/b/g, "v").replace(/ee|ie|ei|oi/g, "i").replace(/oo/g, "u").replace(/ai/g, "e").replace(/dh/g, "d");
  return t.replace(/(.)\1+/g, "$1").trim();
}
function imgLev(a, b) { if (a === b) return 0; if (!a) return b.length; if (!b) return a.length; let p = Array.from({ length: b.length + 1 }, (_, i) => i); for (let i = 1; i <= a.length; i++) { const c = [i]; for (let j = 1; j <= b.length; j++) c[j] = Math.min(p[j] + 1, c[j - 1] + 1, p[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); p = c; } return p[b.length]; }
function imgNameScore(target, surname) {
  const sn = imgSkel(surname).replace(/ /g, ""); if (sn.length < 3) return 0;
  let best = 0;
  for (const w of imgSkel(target).split(" ").filter((x) => x.length >= 3)) {
    if (w === sn) return 3;
    if (imgLev(w, sn) <= (sn.length >= 7 ? 2 : 1)) best = Math.max(best, 2);
    else if (w.length >= 4 && w.includes(sn)) best = Math.max(best, 1);
  }
  return best;
}
const IMG_NOT = /\.(jpe?g|png|gif|bmp|txt|htm|html|xml|pdf|exe|ini|inf|dll|ico|js|css|json|zip|rar|7z|lnk|db|log|mp4|avi|doc|docx|xls|xlsx|bat|cmd|sys|cab|msi|url|autorun)$/i;
const imgIsCand = (rel, size) => { const n = String(rel).split("\\").pop(); return size > 128 && !IMG_NOT.test(n) && !/^dicomdir$/i.test(n) && !/^(thumbs\.db|desktop\.ini)$/i.test(n); };
// κλειδί κλινικής για το bot: το «τυλιγμένο» αντίγραφο (oncall_keys kind=bot) ανοίγει με το ιδιωτικό κλειδί του υπολογιστή
let imgCK = null;
async function myXfer() {
  const { efbotXferKey: k } = await V.get("efbotXferKey");
  if (!k || !k.priv || !k.pub) return null;
  const pub = { kty: k.pub.kty, n: k.pub.n, e: k.pub.e, alg: "RSA-OAEP-256", ext: true };
  return { k, pub, fp: await xferFingerprint(pub) };
}
async function imgClinicKey() {
  if (imgCK && Date.now() - imgCK.at < 30 * 60000) return imgCK;
  const me = await myXfer();
  // το αντίγραφο ΑΥΤΟΥ του υπολογιστή (γραμμή bot με το δικό του αποτύπωμα· παλιές βάσεις: η μοναδική γραμμή bot)
  const row = await jobsInApp(async (fp) => { try { if (typeof sb6 === "undefined") return { skip: true }; const r = await sb6.from("oncall_keys").select("kid,wrapped,fp").eq("kind", "bot"); const L = r.data || []; const m = L.find((x) => x.fp === fp && x.wrapped) || (L.length === 1 ? L[0] : null); return m ? { kid: m.kid, wrapped: m.wrapped } : { none: true }; } catch (e) { return { err: String(e) }; } }, [me ? me.fp : ""]);
  let raw = null, kid = row && row.kid;
  if (row && row.wrapped && me) { try { const priv = await crypto.subtle.importKey("jwk", me.k.priv, { name: "RSA-OAEP", hash: "SHA-256" }, false, ["decrypt"]); raw = new Uint8Array(await crypto.subtle.decrypt({ name: "RSA-OAEP" }, priv, b64d(row.wrapped))); } catch (e) { raw = null; } }
  // εφεδρικό: αντίγραφο στο χρηματοκιβώτιο (DPAPI) — από προηγούμενο άνοιγμα ή από τον κεντρικό υπολογιστή (αυτόματη μεταφορά)
  if (!raw) { const { efbotClinicKey: v } = await V.get("efbotClinicKey").catch(() => ({})); if (v && v.raw && (!kid || v.kid === kid)) { raw = b64d(v.raw); kid = v.kid; } }
  if (!raw) throw new Error("το αντίγραφο κλειδιού του bot δεν ανοίγει — Ρυθμίσεις → Κρυπτογράφηση → «δώσε κλειδί στο bot» ξανά");
  try { const { efbotClinicKey: v } = await V.get("efbotClinicKey").catch(() => ({})); if (!v || v.kid !== kid) await V.set({ efbotClinicKey: { kid, raw: b64e(raw), at: Date.now() } }); } catch (e) {}
  imgCK = { kid, key: await crypto.subtle.importKey("raw", raw, "AES-GCM", false, ["encrypt"]), raw, at: Date.now() };
  return imgCK;
}
// ===== 🖥 Πολλοί υπολογιστές: αυτόματη, κρυπτογραφημένη μεταφορά κωδικών =====
// 1) Κάθε υπολογιστής καταχωρεί το δημόσιο κλειδί του στο oncall_keys (kind 'bot') — η βάση το επιτρέπει ΜΟΝΟ σε διαχειριστή.
// 2) Ο έτοιμος υπολογιστής που κρατά τη «μίσθωση» βλέπει τα νέα κλειδιά και στέλνει αυτόματα: κλειδί κλινικής (τυλιγμένο στη
//    γραμμή) + όλους τους κωδικούς του χρηματοκιβωτίου, κρυπτογραφημένα με RSA-OAEP/AES-GCM για εκείνο το κλειδί (oncall_labs
//    efbot|sync|<αποτύπωμα>). 3) Ο νέος τα ανοίγει με το ιδιωτικό του, τα γράφει στο δικό του DPAPI και σβήνει τη γραμμή.
// Αφαίρεση υπολογιστή = σβήσιμο της γραμμής του από Ρυθμίσεις → Κρυπτογράφηση (δεν παίρνει τίποτα ξανά).
let botSyncAt = 0;
function credMerge(cur0, inc) {
  const cur = cur0 && typeof cur0 === "object" ? cur0 : {};
  for (const [h, v] of Object.entries(inc || {})) {
    const m = new Map();
    for (const a of [...[].concat(cur[h] || []), ...[].concat(v || [])]) { if (!a || !a.user || !a.pass) continue; const id = String(a.user).toLowerCase(), o = m.get(id); if (!o || (+a.ts || 0) > (+o.ts || 0)) m.set(id, a); }
    const order = [].concat(cur[h] || []).map((a) => a && String(a.user || "").toLowerCase());
    cur[h] = [...m.values()].sort((x, y) => { const i = order.indexOf(String(x.user).toLowerCase()), k = order.indexOf(String(y.user).toLowerCase()); return (i < 0 ? 99 : i) - (k < 0 ? 99 : k); }).slice(0, 12);
  }
  return cur;
}
async function credHash() {
  try { const v = await V.get(["efbotCredByHost", "efbotEmrCred", "efbotLabsCred", "efbotPdxCred"]); const s = JSON.stringify([Object.entries(v.efbotCredByHost || {}).sort().map(([h, l]) => [h, [].concat(l || []).map((a) => a && [String(a.user).toLowerCase(), a.ts || 0]).sort()]), (v.efbotEmrCred || {}).ts || 0, (v.efbotLabsCred || {}).ts || 0, (v.efbotPdxCred || {}).ts || 0]);
    const d = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s))); return [...d.slice(0, 8)].map((b) => b.toString(16).padStart(2, "0")).join(""); } catch (e) { return ""; }
}
async function botSyncTick() {
  if (Date.now() - botSyncAt < 90000) return; botSyncAt = Date.now();
  const st = await V.status().catch(() => ({ mode: "?" })); if (st.mode !== "dpapi") return;
  // κλειδί υπολογιστή (ίδιο με του κινητού: efbotXferKey)
  let me = await myXfer();
  if (!me) { try { const kp = await crypto.subtle.generateKey({ name: "RSA-OAEP", modulusLength: 3072, publicExponent: new Uint8Array([1, 0, 1]), hash: "SHA-256" }, true, ["encrypt", "decrypt"]); await V.set({ efbotXferKey: { priv: await crypto.subtle.exportKey("jwk", kp.privateKey), pub: await crypto.subtle.exportKey("jwk", kp.publicKey), at: Date.now() } }); me = await myXfer(); } catch (e) { return; } }
  if (!me) return;
  const id = await botId(), ready = await botReady();
  // α) καταχώριση του δικού μου κλειδιού (μία φορά)
  // (αν ο διαχειριστής τον «Αφαίρεσε», δεν ξανακαταχωρείται μόνος του)
  const { efbotKeyReg: reg } = await chrome.storage.local.get("efbotKeyReg");
  const ra = await jobsInApp(async (fp, pub, label, wasReg) => { try { if (typeof sb6 === "undefined" || !(await sb6.auth.getSession()).data.session) return { skip: true };
    const r = await sb6.from("oncall_keys").select("id").eq("kind", "bot").eq("fp", fp).limit(1); if (r.data && r.data.length) return { ok: true, exists: true };
    if (wasReg) return { removed: true };
    const x = await sb6.from("oncall_keys").insert({ kind: "bot", user_id: null, label, pub, fp, kid: null, wrapped: null }); return { ok: !x.error, err: x.error && x.error.message };
  } catch (e) { return { err: String(e) }; } }, [me.fp, me.pub, "Bot υπολογιστή · " + id, reg === me.fp]);
  if (ra && ra.ok && reg !== me.fp) await chrome.storage.local.set({ efbotKeyReg: me.fp });
  if (ra && ra.removed) return;   // αφαιρέθηκε από τον διαχειριστή
  // β) παραλαβή (όσο δεν είμαι έτοιμος, ή μία φορά την ώρα για ανανέωση)
  const got = await jobsInApp(async (key) => { try { if (typeof sb6 === "undefined") return { skip: true }; const r = await sb6.from("oncall_labs").select("data").eq("name_key", key).maybeSingle(); return { d: r.data && r.data.data }; } catch (e) { return { err: String(e) }; } }, ["efbot|sync|" + me.fp]);
  if (got && got.d && got.d.wk) {
    try {
      const priv = await crypto.subtle.importKey("jwk", me.k.priv, { name: "RSA-OAEP", hash: "SHA-256" }, false, ["decrypt"]);
      const rawK = new Uint8Array(await crypto.subtle.decrypt({ name: "RSA-OAEP" }, priv, b64d(got.d.wk)));
      const ak = await crypto.subtle.importKey("raw", rawK, "AES-GCM", false, ["decrypt"]);
      const o = JSON.parse(new TextDecoder().decode(await crypto.subtle.decrypt({ name: "AES-GCM", iv: b64d(got.d.iv) }, ak, b64d(got.d.ct))));
      const patch = {}; for (const k of ["efbotEmrCred", "efbotLabsCred", "efbotPdxCred", "efbotClinicKey"]) if (o[k]) patch[k] = o[k];
      if (Object.keys(patch).length) await V.set(patch);
      // 🔀 κωδικοί ανά σύστημα: ΣΥΓΧΩΝΕΥΣΗ (όχι αντικατάσταση) — για τον ίδιο χρήστη κρατά τον νεότερο
      if (o.efbotCredByHost && typeof o.efbotCredByHost === "object") await V.update("efbotCredByHost", (cur0) => credMerge(cur0, o.efbotCredByHost));
      if (o.emrUser) { const { efbot } = await chrome.storage.local.get("efbot"); if (efbot) { efbot.settings = efbot.settings || {}; if (!efbot.settings.emrUser) efbot.settings.emrUser = o.emrUser; await chrome.storage.local.set({ efbot }); } }
      botReadyC.at = 0; imgCK = null;
      await jobsInApp(async (key) => { try { await sb6.from("oncall_labs").delete().eq("name_key", key); return { ok: true }; } catch (e) { return { err: String(e) }; } }, ["efbot|sync|" + me.fp]);
      notify("🖥 Κωδικοί από τον κεντρικό υπολογιστή", "Πάρθηκαν κρυπτογραφημένα — αυτός ο υπολογιστής μπορεί πλέον να κάνει εργασίες", false);
    } catch (e) { pdxDiag && pdxDiag("sync:open " + e.message); }
  }
  // γ) αποστολή σε νέους υπολογιστές: μόνο ο έτοιμος που κρατά τη μίσθωση
  const credH = await credHash();
  const { efbotSyncSent: sent0 = {} } = await chrome.storage.local.get("efbotSyncSent");
  { const { efbotCredMig: mg } = await chrome.storage.local.get("efbotCredMig"); if (!mg) await chrome.storage.local.set({ efbotCredMig: 1, efbotCredNew: Date.now() }); }   // 0.20.6: μία φορά όλοι μοιράζουν ό,τι έχουν
  const { efbotCredNew: cNew = 0 } = await chrome.storage.local.get("efbotCredNew");
  const changedHere = !Object.keys(sent0).length || Object.values(sent0).some((v) => typeof v !== "object" || v.h !== credH);
  if (!ready || !((await leaseHeld()) || (cNew && Date.now() - cNew < 7 * 864e5 && changedHere))) return;   // ο κεντρικός — ή όποιος πήρε νέους κωδικούς
  let ck; try { ck = await imgClinicKey(); } catch (e) { ck = null; }
  const rows = await jobsInApp(async (fp) => { try { if (typeof sb6 === "undefined") return { skip: true }; const r = await sb6.from("oncall_keys").select("id,fp,pub,label,wrapped,created_at").eq("kind", "bot").neq("fp", fp); return { L: r.data || [] }; } catch (e) { return { err: String(e) }; } }, [me.fp]);
  const { efbotSyncSent: sent = {} } = await chrome.storage.local.get("efbotSyncSent");
  for (const r of (rows && rows.L) || []) {
    if (!r.pub || !r.pub.n || !r.fp) continue;
    const sAt = typeof sent[r.fp] === "object" ? sent[r.fp].at : sent[r.fp], sH = typeof sent[r.fp] === "object" ? sent[r.fp].h : "";
    if (sAt && Date.now() - sAt < 24 * 3600e3 && r.wrapped && sH === credH) continue;   // ανανέωση μία φορά τη μέρα — ή αμέσως όταν αλλάξουν οι κωδικοί
    try {
      const pub = await crypto.subtle.importKey("jwk", { kty: "RSA", n: r.pub.n, e: r.pub.e, alg: "RSA-OAEP-256", ext: true }, { name: "RSA-OAEP", hash: "SHA-256" }, false, ["encrypt"]);
      const vals = await V.get(["efbotCredByHost", "efbotEmrCred", "efbotLabsCred", "efbotPdxCred"]).catch(() => ({}));
      const { efbot } = await chrome.storage.local.get("efbot");
      const bundle = { ...vals, emrUser: efbot?.settings?.emrUser || "", efbotClinicKey: ck && ck.raw ? { kid: ck.kid, raw: b64e(ck.raw), at: Date.now() } : null, from: me.fp, at: Date.now() };
      const rawK = crypto.getRandomValues(new Uint8Array(32)), ak = await crypto.subtle.importKey("raw", rawK, "AES-GCM", false, ["encrypt"]), iv = crypto.getRandomValues(new Uint8Array(12));
      const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, ak, new TextEncoder().encode(JSON.stringify(bundle))));
      const wk = new Uint8Array(await crypto.subtle.encrypt({ name: "RSA-OAEP" }, pub, rawK));
      const wrapped = ck && ck.raw ? b64e(new Uint8Array(await crypto.subtle.encrypt({ name: "RSA-OAEP" }, pub, ck.raw))) : null;
      const w = await jobsInApp(async (rid, fp, data, wrapped, kid) => { try {
        const a = await sb6.from("oncall_labs").upsert({ name_key: "efbot|sync|" + fp, name: "ef-bot sync", pid: null, data, updated_at: new Date().toISOString() }, { onConflict: "name_key" });
        if (a.error) return { err: a.error.message };
        if (wrapped) await sb6.from("oncall_keys").update({ wrapped, kid, approved_at: new Date().toISOString() }).eq("id", rid);
        return { ok: true }; } catch (e) { return { err: String(e) }; } }, [r.id, r.fp, { wk: b64e(wk), iv: b64e(iv), ct: b64e(ct), from: me.fp, at: Date.now() }, wrapped, ck ? ck.kid : null]);
      if (w && w.ok) {
        const first = !sent[r.fp]; sent[r.fp] = { at: Date.now(), h: credH }; await chrome.storage.local.set({ efbotSyncSent: sent });
        if (first) labsPushPhone("🖥 Νέος υπολογιστής του bot πήρε τους κωδικούς", (r.label || "υπολογιστής") + " · αποτύπωμα " + r.fp + " — αν δεν τον αναγνωρίζεις: Ρυθμίσεις → Κρυπτογράφηση → Αφαίρεση").catch(() => {});
      }
    } catch (e) {}
  }
}
async function imgSeal(key, bytes) { const iv = crypto.getRandomValues(new Uint8Array(12)); const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, bytes)); const o = new Uint8Array(12 + ct.length); o.set(iv); o.set(ct, 12); return o; }
async function imgNote(id, note) { await jobsInApp(async (id, note) => { try { if (typeof sb6 === "undefined") return { skip: true }; await sb6.from("oncall_jobs").update({ note }).eq("id", id).eq("status", "running"); return { ok: true }; } catch (e) { return { err: String(e) }; } }, [id, note]).catch(() => {}); }
async function imgUpload(path, u8) {
  const r = await jobsInApp(async (path, b64) => {
    try { if (typeof sb6 === "undefined") return { skip: true };
      const bin = atob(b64), a = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i);
      const up = await sb6.storage.from("img-enc").upload(path, new Blob([a], { type: "application/octet-stream" }), { upsert: true, contentType: "application/octet-stream" });
      return up.error ? { err: up.error.message } : { ok: true };
    } catch (e) { return { err: String(e) }; }
  }, [path, b64e(u8)], 120000);
  if (!r || !r.ok) throw new Error("ανέβασμα: " + ((r && r.err) || "το Παραδόχαρτο δεν είναι ανοιχτό στον υπολογιστή του bot"));
}
// καθάρισμα: ό,τι έμεινε στο img-enc πάνω από 6 ώρες
async function imgCleanup() {
  await jobsInApp(async () => {
    try { if (typeof sb6 === "undefined") return { skip: true };
      const top = await sb6.storage.from("img-enc").list("", { limit: 200 }); const old = Date.now() - 6 * 3600e3;
      for (const d of (top.data || [])) { if (d.id) continue; const f = await sb6.storage.from("img-enc").list(d.name, { limit: 1000 });
        const rm = (f.data || []).filter((x) => x.created_at && Date.parse(x.created_at) < old).map((x) => d.name + "/" + x.name); if (rm.length) await sb6.storage.from("img-enc").remove(rm); }
      return { ok: true };
    } catch (e) { return { err: String(e) }; }
  }, []).catch(() => {});
}
// 1) αναζήτηση φακέλου ασθενή: {name, amka?, am?} → υποψήφιοι φάκελοι με αρχεία/μέγεθος/υποφακέλους (σειρές)
JOB_RUNNERS.imgdir = async (job) => {
  const p = job.payload || {};
  const surname = String(p.name || job.name || "").trim().split(/\s+/)[0] || "";
  if (imgSkel(surname).replace(/ /g, "").length < 3) return { status: "failed", note: "χρειάζεται επώνυμο ασθενή" };
  const ping = await fsFresh();
  if (!ping.ok) return { status: "failed", note: "🩻 " + (ping.err || "το βοηθητικό απεικονιστικών δεν απαντά") };
  if (!ping.bases) return { status: "failed", note: "🩻 στον υπολογιστή τρέχει ακόμα παλιό βοηθητικό απεικονιστικών (v" + (ping.v || "?") + ") — το πρόγραμμα ενημερώσεων το ανανεώνει σε ≤10′, ξαναδοκιμάστε", result: { roots: ping.roots || [], bases: [], hv: ping.v || 0 } };
  if (!ping.roots || !ping.roots.length) return { status: "failed", note: "🩻 δεν βρέθηκε φάκελος «ΟΥΡΟΛΟΓΙΚ…/OUROLOGIK…» στους δίσκους και στους κοινόχρηστους φακέλους δικτύου του υπολογιστή του bot · ψάχτηκαν: " + ((ping.bases || []).slice(0, 12).join(" | ") || "—"), result: { roots: [], bases: ping.bases || [], hv: ping.v || 0 } };
  bgMark("ρίζες: " + ping.roots.join(" | "));
  imgNote(job.id, "🔎 ψάχνω στους φακέλους της κλινικής… (" + ping.roots.length + " ρίζ" + (ping.roots.length === 1 ? "α" : "ες") + ")");
  // ⚡ πρώτα το έτοιμο ευρετήριο (κρατιέται ζεστό από το alarm efbot-fsidx): ~1″ αντί για περπάτημα όλου του δίσκου (~2′)
  let r = null;
  if (ping.idx !== false) {
    const f = await fsCall({ op: "fsfind", q: surname }, 30000);
    if (f.ok && (f.n || 0) > 0) { r = { ok: true, dirs: (f.hits || []).filter((h) => h.dir).map((h) => ({ ri: h.ri, rel: h.rel, name: h.name, t: h.t, depth: String(h.rel || "").split("\\").length })) }; bgMark("ευρετήριο " + r.dirs.length + " φάκελοι (" + f.n + " εγγραφές" + (f.building ? ", ανανεώνεται" : "") + ")"); }
  }
  if (!r) {
    r = await fsCall({ op: "fsdirs", depth: 4 }, 180000);
    if (!r.ok) return { status: "failed", note: "🩻 " + r.err };
    bgMark("φάκελοι " + (r.dirs || []).length);
  }
  // όπως ο viewer: φάκελοι με το επώνυμο· αν υπάρχει ακριβές, τα «μέρος λέξης» φεύγουν· υποφάκελοι μέσα σε ήδη βρεμένο αγνοούνται
  let found = (r.dirs || []).map((d) => ({ ...d, sc: imgNameScore(d.name, surname) })).filter((d) => d.sc > 0);
  const top = Math.max(0, ...found.map((f) => f.sc));
  found = found.filter((f) => f.sc >= (top === 3 ? 2 : 1)).sort((a, b) => b.sc - a.sc || a.depth - b.depth || b.t - a.t);
  const keep = []; for (const f of found) { if (!keep.some((k) => k.ri === f.ri && (f.rel + "\\").toLowerCase().startsWith((k.rel + "\\").toLowerCase()))) keep.push(f); if (keep.length >= Math.min(20, Math.max(1, +p.max || 8))) break; }
  if (!keep.length) return { status: "done", note: `🩻 δεν βρέθηκε φάκελος «${surname}» στο ${ping.roots.join(", ")}`, result: { cands: [], roots: ping.roots } };
  const cands = [];
  for (const f of keep) {
    imgNote(job.id, `📁 βρέθηκαν ${keep.length} φάκελο${keep.length === 1 ? "ς" : "ι"} — μετρώ εικόνες ${cands.length + 1}/${keep.length} · ${Math.round(cands.length / keep.length * 100)}%`);
    const l = await fsCall({ op: "fslist", ri: f.ri, rel: f.rel }, 120000);
    const files = (l.ok ? l.files : []).filter((x) => imgIsCand(x.rel, x.size));
    const subs = {}; const base = f.rel.length + 1;
    for (const x of files) { const rest = x.rel.slice(base), seg = rest.includes("\\") ? rest.split("\\")[0] : ""; const s = subs[seg] || (subs[seg] = { n: 0, b: 0 }); s.n++; s.b += x.size; }
    cands.push({ ri: f.ri, rel: f.rel, sc: f.sc, t: f.t, n: files.length, mb: Math.round(files.reduce((a, x) => a + x.size, 0) / 1048576 * 10) / 10,
      subs: Object.entries(subs).filter(([k]) => k).map(([k, v]) => ({ rel: f.rel + "\\" + k, name: k, n: v.n, mb: Math.round(v.b / 1048576 * 10) / 10 })).sort((a, b) => b.n - a.n).slice(0, 20) });
  }
  return { status: "done", note: `🩻 ${cands.length} φάκελο${cands.length === 1 ? "ς" : "ι"} για «${surname}»`, result: { cands, roots: ping.roots } };
};
JOB_KIND.imgdir = "🩻 Απεικονιστικά: φάκελος ασθενή";
// 🗺 Αυτόματη ταυτοποίηση ασθενών ↔ φακέλων απεικονιστικών (φάκελοι ειδικευόμενων: OUROLOGIKH KLINIKH/<ειδικευόμενος>/<επώνυμο…>).
// Από το ευρετήριο (γρήγορο). «Σίγουρο» μόνο όταν ΕΝΑΣ φάκελος ταιριάζει ακριβώς στο επώνυμο (και στο μικρό όνομα αν υπάρχουν
// συνεπώνυμοι) ΚΑΙ περιέχει εικόνες. Αποτέλεσμα κρυπτογραφημένο με το κλειδί κλινικής. payload {pts:[{key,name,fname,ad}]}.
// ΑΜ ασθενή από το Παραδόχαρτο (record.am) — για ταυτοποίηση φακέλων απεικονιστικών με βεβαιότητα
async function imgAmMap(keys) {
  const r = await jobsInApp(async (keys) => { try { if (typeof sb6 === "undefined") return { skip: true }; const x = await sb6.from("oncall_patients").select("key,record").in("key", keys); const o = {}; for (const row of (x.data || [])) { const a = String((row.record || {}).am || "").replace(/\D/g, ""); if (a.length >= 4) o[row.key] = a; } return { o }; } catch (e) { return { o: {} }; } }, [keys]).catch(() => null);
  return (r && r.o) || {};
}
// PatientID (0010,0020) από την αρχή ενός αρχείου DICOM (explicit ή implicit VR, little endian)
function dicomPatientId(u) {
  for (let i = 0; i + 8 < u.length; i++) {
    if (u[i] !== 0x10 || u[i + 1] !== 0x00 || u[i + 2] !== 0x20 || u[i + 3] !== 0x00) continue;
    let len, off;
    const vr = String.fromCharCode(u[i + 4], u[i + 5]);
    if (/^[A-Z]{2}$/.test(vr)) { len = u[i + 6] | (u[i + 7] << 8); off = i + 8; } else { len = u[i + 4] | (u[i + 5] << 8) | (u[i + 6] << 16) | (u[i + 7] << 24); off = i + 8; }
    if (len > 0 && len < 80 && off + len <= u.length) return String.fromCharCode(...u.slice(off, off + len)).replace(/\0/g, "").trim();
  }
  return "";
}
const amEq = (a, b) => { const x = String(a || "").replace(/\D/g, "").replace(/^0+/, ""), y = String(b || "").replace(/\D/g, "").replace(/^0+/, ""); return !!x && !!y && (x === y || x.endsWith(y) || y.endsWith(x)) && Math.min(x.length, y.length) >= 5; };
async function imgFolderPid(ri, rel) {
  const l = await fsCall({ op: "fslist", ri, rel }, 60000);
  const files = (l.ok ? l.files : []).filter((x) => imgIsCand(x.rel, x.size));
  for (const f of files.slice(0, 3)) {
    const r = await fsCall({ op: "fsread", ri, rel: f.rel, off: 0, len: 65536 }, 30000);
    if (!r.ok) continue;
    const pid = dicomPatientId(b64d(r.data || ""));
    if (pid) return { pid, files };
  }
  return { pid: "", files };
}
JOB_RUNNERS.imgmap = async (job) => {
  const pts = ((job.payload || {}).pts || []).filter((x) => x && x.key && x.name).slice(0, 80);
  if (!pts.length) return { status: "failed", note: "🗺 καμία λίστα ασθενών" };
  const ping = await fsFresh();
  if (!ping.ok || !ping.roots || !ping.roots.length) return { status: "failed", note: "🗺 " + (ping.err || "χωρίς πρόσβαση στον φάκελο της κλινικής") };
  const out = {}; let nSure = 0, nAmb = 0, nAm = 0, i = 0;
  const amOf = await imgAmMap(pts.map((x) => x.key));
  for (const pt of pts) {
    i++; if (i % 5 === 1) imgNote(job.id, "🗺 " + i + "/" + pts.length + " · " + Math.round((i - 1) / pts.length * 100) + "%");
    if (self.efDeadJobs.has(job.id)) break;   // δεύτερη λωρίδα: σταματά ΜΟΝΟ με δικό της όριο/ακύρωση (όχι όταν ακυρωθεί η εργασία της κύριας)
    await new Promise((r) => setTimeout(r, 400));   // ήπια με τον δίσκο δικτύου
    // ⏸ τρέχει επείγουσα δουλειά (παραγγελία/εξιτήριο/…) σε αυτόν τον υπολογιστή → παύση της βαριάς αναζήτησης μέχρι να τελειώσει
    for (let w = 0; jobRunningId && w < 600; w++) await new Promise((r) => setTimeout(r, 500));
    const surname = String(pt.name).trim().split(/\s+/)[0] || "";
    if (imgSkel(surname).replace(/ /g, "").length < 3) continue;
    const f = await fsCall({ op: "fsfind", q: surname }, 30000);
    if (!f.ok) { out[pt.key] = { err: String(f.err || "").slice(0, 80) }; continue; }
    let c = (f.hits || []).filter((h) => h.dir).map((h) => ({ ri: h.ri, rel: h.rel, name: h.name, t: h.t || 0, sc: imgNameScore(h.name, surname) })).filter((x) => x.sc === 3);
    // υποφάκελοι μέσα σε ήδη βρεμένο φάκελο → μόνο ο πάνω
    c.sort((a, b) => a.rel.length - b.rel.length);
    const top = []; for (const x of c) if (!top.some((k) => k.ri === x.ri && (x.rel + "\\").toLowerCase().startsWith((k.rel + "\\").toLowerCase()))) top.push(x);
    // μικρό όνομα (από ΝΠΣ ή 2η λέξη): ξεχωρίζει συνεπώνυμους
    const fn = imgSkel(pt.fname || String(pt.name).trim().split(/\s+/)[1] || "").replace(/ /g, "");
    let pick = top;
    if (top.length > 1 && fn.length >= 2) { const byFn = top.filter((x) => imgSkel(x.name).split(" ").some((w) => w.length >= 2 && (w.startsWith(fn.slice(0, 3)) || fn.startsWith(w)))); if (byFn.length) pick = byFn; }
    // πιο πρόσφατος φάκελος κοντά στην εισαγωγή (αν υπάρχει ημερομηνία)
    const adT = pt.ad ? Date.parse(pt.ad) : 0;
    if (pick.length > 1 && adT) { const near = pick.filter((x) => x.t && x.t >= adT - 45 * 86400000); if (near.length) pick = near; }
    pick.sort((a, b) => b.t - a.t);
    // 🆔 ΑΜ: το PatientID μέσα στα DICOM είναι ο ΑΜ → ο σωστός φάκελος με βεβαιότητα (και απόρριψη συνεπώνυμων)
    const am = amOf[pt.key];
    if (am) {
      let byAm = null; const checked = [];
      for (const x of top.slice(0, 8)) { const r = await imgFolderPid(x.ri, x.rel); checked.push(r.pid ? 1 : 0); if (r.pid && amEq(r.pid, am) && r.files.length) { byAm = { x, files: r.files }; break; } }
      if (!byAm) { const f2 = await fsCall({ op: "fsfind", q: am }, 30000); for (const h of ((f2 && f2.ok && f2.hits) || []).filter((h) => h.dir).slice(0, 4)) { const r = await imgFolderPid(h.ri, h.rel); if (r.files.length && (!r.pid || amEq(r.pid, am))) { byAm = { x: { ri: h.ri, rel: h.rel, t: h.t || 0 }, files: r.files }; break; } } }
      if (byAm) { nSure++; nAm++; out[pt.key] = { ri: byAm.x.ri, rel: byAm.x.rel, n: byAm.files.length, mb: Math.round(byAm.files.reduce((a, x) => a + x.size, 0) / 1048576 * 10) / 10, t: byAm.x.t, sure: true, am: true, alts: 1 }; continue; }
      if (checked.length && checked.every(Boolean)) { out[pt.key] = { none: true, amNo: true }; continue; }   // όλοι οι υποψήφιοι έχουν άλλον ΑΜ
    }
    const best = pick[0];
    if (!best) { out[pt.key] = { none: true }; continue; }
    const l = await fsCall({ op: "fslist", ri: best.ri, rel: best.rel }, 60000);
    const files = (l.ok ? l.files : []).filter((x) => imgIsCand(x.rel, x.size));
    const sure = pick.length === 1 && files.length > 0;
    if (sure) nSure++; else nAmb++;
    out[pt.key] = { ri: best.ri, rel: best.rel, n: files.length, mb: Math.round(files.reduce((a, x) => a + x.size, 0) / 1048576 * 10) / 10, t: best.t, sure, alts: pick.length };
  }
  let enc; try { enc = await fsSealJson({ at: Date.now(), map: out }); } catch (e) { return { status: "failed", note: "🔐 " + e.message }; }
  return { status: "done", note: "🗺 απεικονιστικά: " + nSure + " σίγουρα (" + nAm + " με ΑΜ) · " + nAmb + " με επιλογή · " + (pts.length - nSure - nAmb) + " χωρίς φάκελο", result: { enc, nSure, nAmb, n: pts.length, at: Date.now() } };
};
JOB_KIND.imgmap = "🗺 Απεικονιστικά: ταυτοποίηση φακέλων";
// 2) λήψη ενός φακέλου (ή σειράς): {ri, rel} → κρυπτογραφημένα κομμάτια ~4 MB στο img-enc/<id>/ + κρυπτογραφημένο ευρετήριο
const IMG_MAX_MB = 300;
JOB_RUNNERS.imgget = async (job) => {
  const p = job.payload || {};
  if (p.ri == null || !p.rel) return { status: "failed", note: "λείπει ο φάκελος" };
  imgCleanup();
  let ck; try { ck = await imgClinicKey(); } catch (e) { return { status: "failed", note: "🔐 " + e.message }; }
  imgNote(job.id, "📂 διαβάζω τη λίστα αρχείων… · 0%");
  let l;
  if (p.file) { const st = await fsCall({ op: "fsstat", ri: +p.ri, rel: String(p.rel) }, 60000); l = st.ok ? { ok: true, files: [{ rel: String(p.rel), size: (st.item || {}).size || 0 }] } : st; }
  else l = await fsCall({ op: "fslist", ri: +p.ri, rel: String(p.rel) }, 120000);
  if (!l.ok) return { status: "failed", note: "🩻 " + l.err };
  const files = p.file ? l.files : (l.files || []).filter((x) => imgIsCand(x.rel, x.size));
  const total = files.reduce((a, x) => a + x.size, 0);
  if (!files.length) return { status: "failed", note: "🩻 δεν υπάρχουν αρχεία DICOM σε αυτόν τον φάκελο" };
  if (total > IMG_MAX_MB * 1048576) return { status: "failed", note: `🩻 ${Math.round(total / 1048576)} MB — πολλά για κινητό (όριο ${IMG_MAX_MB}): διάλεξε μία σειρά/υποφάκελο` };
  bgMark("λίστα " + files.length + " αρχεία");
  const CH = 4 * 1048576, PIECE = 655360;
  let buf = new Uint8Array(CH), used = 0, ci = 0, done = 0, lastNote = 0;
  const idx = [];
  // ⚡ ανέβασμα έως 3 κομματιών παράλληλα, όσο συνεχίζει η ανάγνωση από τον δίσκο
  const upP = []; const upQ = async (name, data) => { upP.push(imgUpload(name, data)); if (upP.length >= 3) await upP.shift(); };
  const flush = async () => { if (!used) return; const sealed = await imgSeal(ck.key, buf.subarray(0, used)); await upQ(job.id + "/" + ci + ".bin", sealed); ci++; used = 0; };
  try {
    for (const f of files) {
      if (used && used + Math.min(f.size, CH) > CH) await flush();
      const parts = []; let off = 0;
      while (off < f.size) { const r = await fsCall({ op: "fsread", ri: +p.ri, rel: f.rel, off, len: PIECE }, 60000); if (!r.ok) throw new Error(r.err || "ανάγνωση"); const u = b64d(r.data || ""); if (!u.length) break; parts.push(u); off += u.length; }
      const len = parts.reduce((a, u) => a + u.length, 0);
      if (len > CH) {   // μεγάλο αρχείο: δικό του κομμάτι
        await flush(); const big = new Uint8Array(len); let o = 0; for (const u of parts) { big.set(u, o); o += u.length; }
        idx.push({ n: p.file ? f.rel.split("\\").pop() : f.rel.slice(String(p.rel).length + 1), c: ci, o: 0, l: len }); const sealed = await imgSeal(ck.key, big); await upQ(job.id + "/" + ci + ".bin", sealed); ci++;
      } else {
        if (used + len > CH) await flush();
        idx.push({ n: p.file ? f.rel.split("\\").pop() : f.rel.slice(String(p.rel).length + 1), c: ci, o: used, l: len }); for (const u of parts) { buf.set(u, used); used += u.length; }
      }
      done += f.size;
      if (Date.now() - lastNote > 4000) { lastNote = Date.now(); imgNote(job.id, `🩻 ${Math.round(done / total * 100)}% · ${Math.round(done / 1048576)}/${Math.round(total / 1048576)} MB`); }
    }
    await flush();
    await Promise.all(upP);
  } catch (e) { return { status: "failed", note: "🩻 " + e.message }; }
  bgMark("ανέβηκαν " + ci + " κομμάτια");
  // ευρετήριο (ονόματα αρχείων) κρυπτογραφημένο, στην ίδια μορφή με το pdxCK.encrypt: {e:1, kid, d: base64(iv+ct)}
  const env = { e: 1, kid: ck.kid, d: b64e(await imgSeal(ck.key, new TextEncoder().encode(JSON.stringify({ files: idx, src: String(p.rel).split("\\").slice(-2).join(" / ") })))) };
  return { status: "done", note: `🩻 έτοιμο για το κινητό: ${idx.length} αρχεία · ${Math.round(total / 1048576)} MB (κρυπτογραφημένα)`, result: { idx: env, chunks: ci, mb: Math.round(total / 1048576), at: Date.now() },
    push: p.file || /^📁/.test(job.name || "") ? undefined : ["🩻 Απεικονιστικά έτοιμα", `${job.name}: ${idx.length} εικόνες — ανοίξτε στο Παραδόχαρτο`] };
};
JOB_KIND.imgget = "🩻 Απεικονιστικά: λήψη στο κινητό";
// ===== 📁 Αρχεία κλινικής (σαν την Εξερεύνηση): περιήγηση + αναζήτηση ονόματος. Τα ονόματα/διαδρομές γυρίζουν ΚΡΥΠΤΟΓΡΑΦΗΜΕΝΑ
// με το κλειδί κλινικής (ίδια μορφή με pdxCK.encrypt) — η βάση δεν βλέπει ονόματα ασθενών. Μόνο ανάγνωση.
async function fsSealJson(obj) { const ck = await imgClinicKey(); return { e: 1, kid: ck.kid, d: b64e(await imgSeal(ck.key, new TextEncoder().encode(JSON.stringify(obj)))) }; }
// το βοηθητικό ΜΕΝΕΙ ανοιχτό (η εκκίνηση του PowerShell κοστίζει 5–8″ σε παλιό υπολογιστή)· ξαναξεκινά μόνο αν είναι παλιά
// έκδοση (το αρχείο ανανεώθηκε από το efbot-update) ή αν δεν βρήκε ρίζες
async function fsFresh() {
  const ping = await fsCall({ op: "ping" }, 30000);
  if (ping.ok && ((ping.v || 0) < 10 || !ping.roots || !ping.roots.length)) { try { fsPort && fsPort.disconnect(); } catch (e) {} fsPort = null; return fsCall({ op: "ping" }, 30000); }
  return ping;
}
JOB_RUNNERS.fsls = async (job) => {
  const p = job.payload || {};
  const ping = await fsFresh(); if (!ping.ok) return { status: "failed", note: "📁 " + (ping.err || "το βοηθητικό δεν απαντά") };
  if ((ping.v || 0) < 10) return { status: "failed", note: "📁 το βοηθητικό αρχείων στον υπολογιστή είναι παλιό (v" + (ping.v || "?") + ") — ανανεώνεται μόνο του σε ≤10′" };
  const r = await fsCall(p.ri == null ? { op: "fsls" } : { op: "fsls", ri: +p.ri, rel: String(p.rel || "") }, 90000);
  if (!r.ok) return { status: "failed", note: "📁 " + r.err };
  let enc; try { enc = await fsSealJson({ dirs: r.dirs || [], files: r.files || [], more: !!r.more, roots: p.ri == null ? ping.roots : undefined }); } catch (e) { return { status: "failed", note: "🔐 " + e.message }; }
  return { status: "done", note: `📁 ${(r.dirs || []).length} φάκελοι · ${(r.files || []).length} αρχεία`, result: { enc } };
};
JOB_KIND.fsls = "📁 Αρχεία κλινικής: φάκελος";
JOB_RUNNERS.fsfind = async (job) => {
  const p = job.payload || {};
  const q = String(p.q || "").trim(); if (q.length < 2) return { status: "failed", note: "📁 γράψτε τουλάχιστον 2 γράμματα" };
  const ping = await fsFresh(); if (!ping.ok) return { status: "failed", note: "📁 " + (ping.err || "το βοηθητικό δεν απαντά") };
  if ((ping.v || 0) < 10) return { status: "failed", note: "📁 το βοηθητικό αρχείων στον υπολογιστή είναι παλιό (v" + (ping.v || "?") + ") — ανανεώνεται μόνο του σε ≤10′" };
  imgNote(job.id, "🔎 ψάχνω σε όλους τους φακέλους της κλινικής…");
  const r = await fsCall({ op: "fsfind", q, fresh: !!p.fresh }, 150000);
  if (!r.ok) return { status: "failed", note: "📁 " + r.err };
  let enc; try { enc = await fsSealJson({ hits: r.hits || [], n: r.n || 0, trunc: !!r.trunc, building: !!r.building, folders: r.folders || 0, age: r.age || 0 }); } catch (e) { return { status: "failed", note: "🔐 " + e.message }; }
  return { status: "done", note: `📁 ${(r.hits || []).length} αποτελέσματα (σε ${r.n || 0} φακέλους/έγγραφα${r.building ? ", το ευρετήριο φτιάχνεται ακόμα" : r.trunc ? ", μερικό ευρετήριο" : ""}${r.fast ? "" : " · αργή μέθοδος"})`, result: { enc } };
};
JOB_KIND.fsfind = "📁 Αρχεία κλινικής: αναζήτηση";
// 🔐 8/11: αρχεία κλινικής για τον Claude (π.χ. προγράμματα χειρουργείου → έτοιμα σετ κελιών). Μόνο ανάγνωση.
// payload: { pub:{n,e} (RSA-OAEP-256 μιας χρήσης, το ιδιωτικό ΜΟΝΟ στον Claude), th: sha256(token), ops:[{op:fsls|fslist|fsfind|get,…}] }
// Αποτέλεσμα: result.blob = base64( RSA(κλειδί AES 256) 384B | iv 12B | AES-GCM(JSON) ) — η βάση βλέπει μόνο κρυπτογραφημένο.
JOB_RUNNERS.fsclaude = async (job) => {
  const p = job.payload || {};
  if (!p.pub || !p.pub.n || !/^[0-9a-f]{64}$/.test(String(p.th || ""))) return { status: "failed", note: "🔐 λείπει κλειδί/κωδικός" };
  const ping = await fsFresh(); if (!ping.ok) return { status: "failed", note: "📁 " + (ping.err || "το βοηθητικό δεν απαντά") };
  const MAX = 8 * 1048576; let total = 0;
  const res = [], files = {};
  for (const o of [].concat(p.ops || []).slice(0, 200)) {
    try {
      if (o.op === "getdir") {   // όλα τα αρχεία ενός φακέλου (αναδρομικά) που ταιριάζουν: re (στο rel), ≤ max bytes, εκτός skip (κανονική έκφραση), από τη θέση from
        const l = await fsCall({ op: "fslist", ri: +o.ri, rel: String(o.rel || "") }, 150000); if (!l.ok) throw new Error(l.err || "λίστα");
        const re = new RegExp(o.re || ".", "i"), sk = o.skip ? new RegExp(o.skip, "i") : null;
        const L = (l.files || []).filter((f) => re.test(f.rel) && !(sk && sk.test(f.rel)) && f.size <= (+o.max || 500000)).sort((x, y) => x.rel < y.rel ? -1 : 1).slice(+o.from || 0);
        let i = 0;
        for (const f of L) {
          if (total + f.size > MAX) break;
          const parts = []; let off = 0;
          while (off < f.size) { const r = await fsCall({ op: "fsread", ri: +o.ri, rel: f.rel, off, len: 655360 }, 60000); if (!r.ok) break; const u = b64d(r.data || ""); if (!u.length) break; parts.push(u); off += u.length; }
          const all = new Uint8Array(parts.reduce((a, u) => a + u.length, 0)); let k = 0; for (const u of parts) { all.set(u, k); k += u.length; }
          files[o.ri + "|" + f.rel] = b64e(all); total += all.length; i++;
        }
        res.push({ op: "getdir", q: o, n: L.length, got: i, next: i < L.length ? (+o.from || 0) + i : null });
        continue;
      }
      if (o.op === "get") {
        const parts = []; let off = 0, size = Infinity;
        while (off < size && total < MAX) { const r = await fsCall({ op: "fsread", ri: +o.ri, rel: String(o.rel), off, len: 655360 }, 60000); if (!r.ok) throw new Error(r.err || "ανάγνωση"); size = +r.size || 0; const u = b64d(r.data || ""); if (!u.length) break; parts.push(u); off += u.length; total += u.length; }
        const all = new Uint8Array(parts.reduce((a, u) => a + u.length, 0)); let k = 0; for (const u of parts) { all.set(u, k); k += u.length; }
        files[o.ri + "|" + o.rel] = b64e(all); res.push({ op: "get", ri: o.ri, rel: o.rel, size, got: all.length, cut: all.length < size });
      } else if (/^(fsls|fslist|fsfind|fsdirs)$/.test(o.op)) {
        const r = await fsCall(o, 150000); res.push({ op: o.op, q: o, r });
      } else res.push({ op: o.op, err: "άγνωστη" });
    } catch (e) { res.push({ op: o.op, q: o, err: e.message }); }
    if (total >= MAX) { res.push({ cut: true }); break; }
  }
  const bytes = new TextEncoder().encode(JSON.stringify({ roots: ping.roots, res, files, at: Date.now() }));
  const pub = await crypto.subtle.importKey("jwk", { kty: "RSA", n: p.pub.n, e: p.pub.e || "AQAB", alg: "RSA-OAEP-256", ext: true }, { name: "RSA-OAEP", hash: "SHA-256" }, false, ["encrypt"]);
  const aes = await crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, true, ["encrypt"]);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, aes, bytes));
  const wk = new Uint8Array(await crypto.subtle.encrypt({ name: "RSA-OAEP" }, pub, new Uint8Array(await crypto.subtle.exportKey("raw", aes))));
  const blob = new Uint8Array(wk.length + 12 + ct.length); blob.set(wk, 0); blob.set(iv, wk.length); blob.set(ct, wk.length + 12);
  return { status: "done", note: "🔐 " + res.length + " λειτουργίες · " + Object.keys(files).length + " αρχεία · " + Math.round(blob.length / 1024) + " KB κρυπτογραφημένα", result: { blob: b64e(blob), n: res.length, at: Date.now() } };
};
JOB_KIND.fsclaude = "🔐 Αρχεία κλινικής για τον Claude (κρυπτογραφημένα)";

// ⏱ Χρονομέτρηση ΚΑΘΕ εργασίας: συνολικός χρόνος, σταθερές αναμονές (E.sleep), κέρδος από τις έξυπνες αναμονές (bgSettle)
// και διάρκεια ανά βήμα (bgMark). Γράφεται στο result.time (για ανάλυση) και σύντομα στο note.
function bgTimedWrap(kind) {
  const inner = JOB_RUNNERS[kind]; if (!inner || inner.__timed) return;
  const w = async (job) => {
    const t0 = Date.now(), s0 = E.sleep; let slept = 0, n = 0;
    Object.assign(bgTime, { t0, saved: 0, marks: [] });
    E.sleep = (ms) => { slept += +ms || 0; n++; return s0(ms); };
    let res; try { res = await inner(job); } finally { E.sleep = s0; }
    try {
      const secs = Math.round((Date.now() - t0) / 100) / 10;
      const steps = bgTime.marks.map((m) => m.l + " " + (m.ms / 1000).toFixed(1));
      // συνταγή: χρονομέτρηση των αιτημάτων της καρτέλας του e-prescription (για τη «γρήγορη διαδρομή» με απευθείας αιτήματα)
      const tab = /^(rx|ref$)/.test(kind) ? (await chrome.tabs.query({ url: "https://www.e-prescription.gr/*" }).catch(() => []))[0] || null
        : /^(medbx|cred|fs|img|bx)/.test(kind) ? null : await bgEmrTab().catch(() => null);
      const net = tab && tab.id ? await emrNetSnap(tab.id, t0) : null;
      if (res && typeof res === "object") {
        res.result = Object.assign({}, res.result || {}, { net, secs: Math.round(secs), slept: Math.round(slept / 1000), sleeps: n, time: { ms: Date.now() - t0, slept, saved: bgTime.saved, steps, ver: chrome.runtime.getManifest().version } });
        if (res.note && res.status !== "review" && secs >= 3) res.note += " · ⏱ " + Math.round(secs) + "″ (αναμονές " + Math.round(slept / 1000) + "″" + (bgTime.saved >= 1000 ? ", κερδήθηκαν " + Math.round(bgTime.saved / 1000) + "″" : "") + ")";
      }
    } catch (e) {}
    bgTime.t0 = 0;
    return res;
  };
  w.__timed = true; JOB_RUNNERS[kind] = w;
}
for (const kind of Object.keys(JOB_RUNNERS)) bgTimedWrap(kind);
