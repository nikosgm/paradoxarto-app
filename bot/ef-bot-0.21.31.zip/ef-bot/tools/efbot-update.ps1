﻿# Πρόγραμμα ενημέρωσης του «Βοηθού Ηλεκτρονικού Φακέλου» (ef-bot)
# Κάθε 60 δευτ. ελέγχει αν υπάρχει νέα έκδοση στο https://ef-bot-updates.netlify.app και,
# αν υπάρχει, την αντιγράφει στον φάκελο της επέκτασης. Η επέκταση ξαναφορτώνεται μόνη της.
#
#   efbot-update.bat            -> ξεκινά ΑΟΡΑΤΑ (χωρίς παράθυρο που μπορεί να κλείσει κάποιος) + αυτόματα με τα Windows
#   efbot-update.bat stop       -> σταματά το αόρατο πρόγραμμα ενημέρωσης
#   efbot-update.bat show       -> τρέχει σε ορατό παράθυρο (για έλεγχο)
#   efbot-update.bat install    -> να ξεκινά αυτόματα με τα Windows
#   efbot-update.bat uninstall  -> να μην ξεκινά πια αυτόματα
#   efbot-update.bat once       -> ένας έλεγχος και τέλος
#   efbot-update.bat watchdog-off -> να ΜΗΝ ξανανοίγει το Chrome αν κλείσει (σε αυτόν τον υπολογιστή)
#   efbot-update.bat watchdog-on  -> να ξανανοίγει το Chrome (προεπιλογή)
#
# Φύλακας Chrome: αν κάποιος κλείσει εντελώς το Chrome («Έξοδος»), μέσα σε ~1′ ξανανοίγει ΑΟΡΑΤΑ (χωρίς παράθυρο),
# ώστε το bot να συνεχίζει να παίρνει εντολές από το κινητό. Δουλεύει όσο ο χρήστης είναι συνδεδεμένος στα Windows
# (και με κλειδωμένη οθόνη).
param([string]$Mode = "loop")

$ErrorActionPreference = "Stop"
# νέα φιλοξενία (6/11): GitHub Pages· το Netlify μένει ως εφεδρικό
$Bases   = @("https://paradoxarto.urol.workers.dev/bot", "https://paradoxarto.pages.dev/bot", "https://nikosgm.github.io/paradoxarto-app/bot", "https://ef-bot-updates.netlify.app")
$Base    = $Bases[0]
$ExtDir  = Split-Path -Parent $PSScriptRoot          # ο φάκελος ef-bot (όπου είναι το manifest.json)
$Startup = Join-Path ([Environment]::GetFolderPath("Startup")) "efbot-update.vbs"   # 7/11: .vbs → ΚΑΝΕΝΑ παράθυρο (ούτε στη γραμμή εργασιών· το .bat άνοιγε Terminal)
$StartupOld = Join-Path ([Environment]::GetFolderPath("Startup")) "efbot-update.bat"
$Vbs = Join-Path $PSScriptRoot "efbot-update-hidden.vbs"
$WdOff   = Join-Path $env:LOCALAPPDATA "ef-bot\no-chrome-watchdog"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Log($m) { Write-Host ("[{0:HH:mm:ss}] {1}" -f (Get-Date), $m) }

if (-not (Test-Path (Join-Path $ExtDir "manifest.json"))) {
  Write-Host "Δεν βρέθηκε το manifest.json στο $ExtDir. Το αρχείο πρέπει να είναι στον φάκελο ef-bot\tools."
  Read-Host "Enter για έξοδο"; exit 1
}

# 🧭 6/11: ποιον φάκελο φορτώνει ΠΡΑΓΜΑΤΙΚΑ το Chrome; (Preferences → "path" με manifest «Βοηθός Ηλεκτρονικού Φακέλου»)
# Αν το .bat ξεκίνησε από άλλον φάκελο (π.χ. Λήψεις), αντιγράφει τα αρχεία εκεί και ΠΑΡΑΔΙΔΕΙ στο δικό του πρόγραμμα ενημέρωσης,
# ώστε το βοηθητικό να δηλωθεί για τη σωστή επέκταση (αλλιώς «forbidden»/«not found» και καμία αυτόματη ενημέρωση).
function LoadedExtDirs {
  $out = @{}
  $ud = Join-Path $env:LOCALAPPDATA "Google\Chrome\User Data"
  foreach ($prof in @(Get-ChildItem -LiteralPath $ud -Directory -ErrorAction SilentlyContinue)) {
    foreach ($fn in @("Secure Preferences", "Preferences")) {
      $f = Join-Path $prof.FullName $fn
      if (-not (Test-Path -LiteralPath $f)) { continue }
      try {
        $txt = [IO.File]::ReadAllText($f)
        foreach ($m in [regex]::Matches($txt, '"path":"((?:[^"\\]|\\.){4,260})"')) {
          $pth = $m.Groups[1].Value -replace '\\\\', '\'
          if ($pth -notmatch '^[A-Za-z]:\\') { continue }
          $mf = Join-Path $pth "manifest.json"
          if (-not (Test-Path -LiteralPath $mf)) { continue }
          try { if ((Get-Content -LiteralPath $mf -Raw -Encoding UTF8 | ConvertFrom-Json).name -eq "Βοηθός Ηλεκτρονικού Φακέλου") { $out[(Get-Item -LiteralPath $pth).FullName.TrimEnd('\')] = 1 } } catch {}
        }
      } catch {}
    }
  }
  return @($out.Keys)
}
if ($Mode -notmatch '^(stop|watchdog-off|watchdog-on|uninstall)$') {
  try {
    $me0 = (Get-Item -LiteralPath $ExtDir).FullName.TrimEnd('\')
    $ld = @(LoadedExtDirs)
    if ($ld.Count -ge 1 -and -not ($ld -contains $me0)) {
      $tgt = $ld[0]
      Write-Host "Το Chrome φορτώνει την επέκταση από: $tgt"
      Write-Host "Αντιγραφή αρχείων από $me0 → $tgt ..."
      $mine = [version]((Get-Content (Join-Path $me0 "manifest.json") -Raw -Encoding UTF8 | ConvertFrom-Json).version)
      $theirs = [version]((Get-Content (Join-Path $tgt "manifest.json") -Raw -Encoding UTF8 | ConvertFrom-Json).version)
      if ($mine -ge $theirs) {
        foreach ($f in @(Get-ChildItem -LiteralPath $me0 -Recurse -File | Where-Object { $_.Name -ne "manifest.json" })) {
          $dst = Join-Path $tgt $f.FullName.Substring($me0.Length + 1); New-Item -ItemType Directory -Path (Split-Path -Parent $dst) -Force | Out-Null; Copy-Item -LiteralPath $f.FullName -Destination $dst -Force
        }
        Copy-Item -LiteralPath (Join-Path $me0 "manifest.json") -Destination (Join-Path $tgt "manifest.json") -Force
      }
      $next = Join-Path $tgt "tools\efbot-update.ps1"
      if (Test-Path -LiteralPath $next) {
        Write-Host "Συνέχεια από τον φάκελο της επέκτασης (σωστή δήλωση βοηθητικού)."
        & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $next $Mode
        exit 0
      }
    }
  } catch { Write-Host ("Έλεγχος φακέλου επέκτασης: " + $_.Exception.Message) }
}

# αόρατη εκκίνηση: powershell χωρίς παράθυρο, με τη λειτουργία «hidden» (ο ίδιος βρόχος)
function VbsText($ps) { return ('CreateObject("WScript.Shell").Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""' + $ps + '"" hidden", 0, False') }
function StartHidden {
  # μέσω wscript: το powershell ξεκινά ΧΩΡΙΣ κονσόλα (στα Windows 11 το -WindowStyle Hidden άφηνε παράθυρο Terminal)
  try { Set-Content -LiteralPath $Vbs -Encoding ASCII -Value (VbsText $PSCommandPath); Start-Process -FilePath "wscript.exe" -ArgumentList @("`"$Vbs`"") ; return } catch {}
  Start-Process -FilePath "powershell.exe" -ArgumentList @("-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-File", "`"$PSCommandPath`"", "hidden") -WindowStyle Hidden
}
function InstallStartup {
  try { Remove-Item -LiteralPath (Join-Path $env:LOCALAPPDATA "ef-bot\no-autostart") -ErrorAction SilentlyContinue } catch {}
  # στην Εκκίνηση των Windows: μόνο αόρατο powershell (κανένα παράθυρο cmd)
  $ps = $PSCommandPath
  Set-Content -Path $Startup -Encoding ASCII -Value (VbsText $ps)
  Remove-Item -LiteralPath $StartupOld -ErrorAction SilentlyContinue
}
function StopHidden {
  $script:nStop = 0
  Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -match 'efbot-update\.ps1' -and $_.ProcessId -ne $PID } | ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force; $script:nStop++ } catch {} }
  return [int]$script:nStop
}
if ($Mode -eq "stop") { $n = StopHidden; Write-Host "OK: σταμάτησε ($n)."; Start-Sleep 3; exit 0 }
if ($Mode -eq "loop") {
  # διπλό κλικ: εγκατάσταση στην Εκκίνηση + αόρατη εκτέλεση, και αυτό το παράθυρο κλείνει μόνο του
  try { InstallStartup } catch {}
  StartHidden
  Write-Host "OK: το πρόγραμμα ενημέρωσης τρέχει πλέον ΑΟΡΑΤΑ και θα ξεκινά μόνο του με τα Windows."
  Write-Host "Αυτό το παράθυρο κλείνει σε λίγα δευτερόλεπτα. (Σταμάτημα: efbot-update.bat stop)"
  Start-Sleep 6; exit 0
}
if ($Mode -eq "install") {
  InstallStartup
  Write-Host "OK: θα ξεκινά αυτόματα (αόρατα) με τα Windows."; Start-Sleep 3; exit 0
}
if ($Mode -eq "watchdog-off") {
  New-Item -ItemType Directory -Path (Split-Path -Parent $WdOff) -Force | Out-Null; Set-Content -Path $WdOff -Value "off"
  Write-Host "OK: το Chrome ΔΕΝ θα ξανανοίγει μόνο του σε αυτόν τον υπολογιστή."; Start-Sleep 3; exit 0
}
if ($Mode -eq "watchdog-on") {
  Remove-Item $WdOff -ErrorAction SilentlyContinue
  Write-Host "OK: το Chrome θα ξανανοίγει αόρατα αν κλείσει."; Start-Sleep 3; exit 0
}
if ($Mode -eq "uninstall") {
  Remove-Item $Startup -ErrorAction SilentlyContinue; Remove-Item $StartupOld -ErrorAction SilentlyContinue
  try { New-Item -ItemType Directory -Force -Path (Join-Path $env:LOCALAPPDATA "ef-bot") | Out-Null; Set-Content -LiteralPath (Join-Path $env:LOCALAPPDATA "ef-bot\no-autostart") -Value "1" } catch {}
  Write-Host "OK: δεν θα ξεκινά πια αυτόματα."; Start-Sleep 3; exit 0
}

# Ασφάλεια πριν από οποιαδήποτε διαγραφή: ο φάκελος πρέπει να είναι πράγματι η επέκταση ef-bot
function AssertExtDir {
  $m = Join-Path $ExtDir "manifest.json"
  if (-not (Test-Path -LiteralPath $m)) { throw "Ο φάκελος $ExtDir δεν έχει manifest.json: δεν σβήνω τίποτα." }
  $j = Get-Content -LiteralPath $m -Raw -Encoding UTF8 | ConvertFrom-Json
  if ($j.name -ne "Βοηθός Ηλεκτρονικού Φακέλου") { throw "Ο φάκελος $ExtDir δεν είναι της επέκτασης ef-bot: δεν σβήνω τίποτα." }
  $root = [IO.Path]::GetPathRoot($ExtDir)
  if ($ExtDir.TrimEnd('\') -eq $root.TrimEnd('\') -or $ExtDir -eq $env:USERPROFILE) { throw "Μη ασφαλής φάκελος: $ExtDir" }
}

# Πού είναι το chrome.exe (μητρώο «App Paths», αλλιώς οι συνήθεις φάκελοι)
function ChromeExe {
  foreach ($k in @("HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe", "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe", "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe")) {
    try { $v = (Get-ItemProperty -Path $k -ErrorAction Stop).'(default)'; if ($v -and (Test-Path -LiteralPath $v)) { return $v } } catch {}
  }
  foreach ($p in @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe")) {
    if ($p -and (Test-Path -LiteralPath $p)) { return $p }
  }
  return $null
}
$script:WdLast = [DateTime]::MinValue
function ChromeWatchdog {
  if (Test-Path -LiteralPath $WdOff) { return }
  if (Get-Process -Name chrome -ErrorAction SilentlyContinue) { return }
  if (((Get-Date) - $script:WdLast).TotalSeconds -lt 50) { return }   # όχι πάνω από μία εκκίνηση το λεπτό
  $exe = ChromeExe
  if (-not $exe) { return }
  $script:WdLast = Get-Date
  # --no-startup-window: το Chrome τρέχει χωρίς παράθυρο· το ef-bot (άδεια «background») δουλεύει κανονικά
  # ⚡ χωρίς «φρενάρισμα» των παραθύρων που δεν φαίνονται (το παράθυρο του bot είναι πάντα πίσω από τα άλλα):
  #    αλλιώς το Chrome καθυστερεί τους χρονοδιακόπτες/τη σχεδίαση της σελίδας του ΝΠΣ έως 1″ σε κάθε βήμα
  Start-Process -FilePath $exe -ArgumentList "--no-startup-window --disable-background-timer-throttling" -WindowStyle Hidden
  Log "Το Chrome είχε κλείσει: ξεκίνησε ξανά αόρατα για το ef-bot."
}

# 🔒 Βοηθητικό κρυπτογράφησης κωδικών (Windows DPAPI) για το ef-bot: Chrome native messaging host «gr.efbot.vault».
# Αντιγράφεται έξω από τον φάκελο της επέκτασης (%LOCALAPPDATA%\ef-bot\vault) και δηλώνεται στο μητρώο του χρήστη.
# Επιτρέπεται ΜΟΝΟ στην επέκταση ef-bot αυτού του φακέλου (allowed_origins). Δεν κρατά κανέναν κωδικό.
$VDir = Join-Path $env:LOCALAPPDATA "ef-bot\vault"
$VReg = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\gr.efbot.vault"
function ExtIdFromPath([string]$p) {
  $p = $p.TrimEnd('\'); if ($p -match '^[a-z]:') { $p = $p.Substring(0, 1).ToUpper() + $p.Substring(1) }
  $h = [Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::Unicode.GetBytes($p))
  return -join ($h[0..15] | ForEach-Object { [char](97 + ($_ -shr 4)); [char](97 + ($_ -band 15)) })
}
$script:ExtIdsC = $null; $script:ExtIdsAt = [DateTime]::MinValue
function ExtIds {
  # ελαφρύ: τα αρχεία προτιμήσεων του Chrome (μεγάλα) διαβάζονται το πολύ ανά 10′, όχι κάθε λεπτό
  if ($script:ExtIdsC -and ((Get-Date) - $script:ExtIdsAt).TotalMinutes -lt 10) { return $script:ExtIdsC }
  $script:ExtIdsC = @(ExtIdsRead); $script:ExtIdsAt = Get-Date; return $script:ExtIdsC
}
function ExtIdsRead {
  $ids = @{}
  $me = (Get-Item -LiteralPath $ExtDir).FullName.TrimEnd('\')
  $ids[(ExtIdFromPath $me)] = 1
  $ud = Join-Path $env:LOCALAPPDATA "Google\Chrome\User Data"
  $esc = ($me -replace '\\', '\\')
  foreach ($prof in @(Get-ChildItem -LiteralPath $ud -Directory -ErrorAction SilentlyContinue)) {
    foreach ($fn in @("Secure Preferences", "Preferences")) {
      $f = Join-Path $prof.FullName $fn
      if (-not (Test-Path -LiteralPath $f)) { continue }
      try {
        $txt = [IO.File]::ReadAllText($f)
        $i = 0
        while (($i = $txt.IndexOf('"path":"' + $esc + '"', $i, [StringComparison]::OrdinalIgnoreCase)) -ge 0) {
          $ms = [regex]::Matches($txt.Substring(0, $i), '"([a-p]{32})":\{')
          if ($ms.Count) { $ids[$ms[$ms.Count - 1].Groups[1].Value] = 1 }
          $i++
        }
      } catch {}
    }
  }
  return @($ids.Keys | Sort-Object)
}
$script:VLast = Get-Date
function VaultInstall {
  $srcPs = Join-Path $PSScriptRoot "efbot-vault.ps1"; $srcBat = Join-Path $PSScriptRoot "efbot-vault.bat"
  if (-not (Test-Path -LiteralPath $srcPs) -or -not (Test-Path -LiteralPath $srcBat)) { return }
  New-Item -ItemType Directory -Path $VDir -Force | Out-Null
  $changed = $false
  foreach ($f in @($srcPs, $srcBat)) {
    $dst = Join-Path $VDir (Split-Path -Leaf $f)
    if (-not (Test-Path -LiteralPath $dst) -or (Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $f -Algorithm SHA256).Hash) {
      Copy-Item -LiteralPath $f -Destination $dst -Force; $changed = $true
    }
  }
  $origins = @(ExtIds | ForEach-Object { "chrome-extension://$_/" })
  $man = [ordered]@{ name = "gr.efbot.vault"; description = "ef-bot: κρυπτογράφηση κωδικών με τα Windows (DPAPI)"; path = "efbot-vault.bat"; type = "stdio"; allowed_origins = $origins }
  $json = $man | ConvertTo-Json -Depth 4
  $manPath = Join-Path $VDir "gr.efbot.vault.json"
  $old = if (Test-Path -LiteralPath $manPath) { [IO.File]::ReadAllText($manPath) } else { "" }
  if ($old -ne $json) { [IO.File]::WriteAllText($manPath, $json, (New-Object Text.UTF8Encoding $false)); $changed = $true }
  $cur = $null
  try { $cur = (Get-ItemProperty -Path $VReg -ErrorAction Stop).'(default)' } catch {}
  if ($cur -ne $manPath) { New-Item -Path $VReg -Force | Out-Null; Set-ItemProperty -Path $VReg -Name "(default)" -Value $manPath; $changed = $true }
  try { $bp = Join-Path $PSScriptRoot "efbot-update.bat"; $pf = Join-Path $VDir "updater-path.txt"; $oldp = if (Test-Path -LiteralPath $pf) { [IO.File]::ReadAllText($pf).Trim() } else { "" }; if ($oldp -ne $bp) { [IO.File]::WriteAllText($pf, $bp, (New-Object Text.UTF8Encoding $false)) } } catch {}
  if ($changed) { Log "Κρυπτογράφηση κωδικών: το βοηθητικό εγκαταστάθηκε/ενημερώθηκε ($($origins.Count) αναγνωριστικό/ά επέκτασης)." }
}

# 🩻 Βοηθητικό ανάγνωσης φακέλου απεικονιστικών (Chrome native messaging host «gr.efbot.files»): ΜΟΝΟ ανάγνωση,
# ΜΟΝΟ μέσα στο C:\OUROLOGIKI_KLINIKH (και στις γραμμές του τοπικού roots.txt). Ξεχωριστό από το βοηθητικό κωδικών.
$FDir = Join-Path $env:LOCALAPPDATA "ef-bot\files"
$FReg = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\gr.efbot.files"
function FilesInstall {
  $srcPs = Join-Path $PSScriptRoot "efbot-files.ps1"; $srcBat = Join-Path $PSScriptRoot "efbot-files.bat"
  if (-not (Test-Path -LiteralPath $srcPs) -or -not (Test-Path -LiteralPath $srcBat)) { return }
  New-Item -ItemType Directory -Path $FDir -Force | Out-Null
  $changed = $false
  foreach ($f in @($srcPs, $srcBat)) {
    $dst = Join-Path $FDir (Split-Path -Leaf $f)
    if (-not (Test-Path -LiteralPath $dst) -or (Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $f -Algorithm SHA256).Hash) {
      Copy-Item -LiteralPath $f -Destination $dst -Force; $changed = $true
    }
  }
  $origins = @(ExtIds | ForEach-Object { "chrome-extension://$_/" })
  $man = [ordered]@{ name = "gr.efbot.files"; description = "ef-bot: ανάγνωση φακέλου απεικονιστικών (μόνο ανάγνωση)"; path = "efbot-files.bat"; type = "stdio"; allowed_origins = $origins }
  $json = $man | ConvertTo-Json -Depth 4
  $manPath = Join-Path $FDir "gr.efbot.files.json"
  $old = if (Test-Path -LiteralPath $manPath) { [IO.File]::ReadAllText($manPath) } else { "" }
  if ($old -ne $json) { [IO.File]::WriteAllText($manPath, $json, (New-Object Text.UTF8Encoding $false)); $changed = $true }
  $cur = $null
  try { $cur = (Get-ItemProperty -Path $FReg -ErrorAction Stop).'(default)' } catch {}
  if ($cur -ne $manPath) { New-Item -Path $FReg -Force | Out-Null; Set-ItemProperty -Path $FReg -Name "(default)" -Value $manPath; $changed = $true }
  if ($changed) { Log "Απεικονιστικά: το βοηθητικό ανάγνωσης φακέλου εγκαταστάθηκε/ενημερώθηκε." }
}

function LocalVersion { (Get-Content (Join-Path $ExtDir "manifest.json") -Raw -Encoding UTF8 | ConvertFrom-Json).version }

function CheckOnce {
  $info = $null
  foreach ($b in $Bases) { try { $info = Invoke-RestMethod -Uri ("$b/version.json?t=" + [DateTimeOffset]::Now.ToUnixTimeSeconds()) -UseBasicParsing -TimeoutSec 20; if ($info.version) { $script:Base = $b; break } } catch {} }
  if (-not $info) { throw "καμία διεύθυνση ενημερώσεων δεν απαντά" }
  $local = LocalVersion
  if (-not $info.version -or $info.version -eq $local) { return $false }
  # Μόνο αρχεία από τη δική μας διεύθυνση
  $zipUrl = "$Base/" + ($info.zip -replace '^[/\\]+', '')
  if ($zipUrl -notmatch '^https://(ef-bot-updates\.netlify\.app|nikosgm\.github\.io/paradoxarto-app/bot|paradoxarto\.pages\.dev/bot|paradoxarto\.urol\.workers\.dev/bot)/[A-Za-z0-9._-]+\.zip$') { throw "Μη αποδεκτή διεύθυνση: $zipUrl" }
  Log "Νέα έκδοση $($info.version) (έχετε $local). Λήψη..."
  $tmp = Join-Path $env:TEMP ("efbot-" + [guid]::NewGuid().ToString("N"))
  New-Item -ItemType Directory -Path $tmp | Out-Null
  try {
    $zip = Join-Path $tmp "u.zip"
    Invoke-WebRequest -Uri $zipUrl -OutFile $zip -UseBasicParsing -TimeoutSec 120
    $hash = (Get-FileHash $zip -Algorithm SHA256).Hash.ToLower()
    if ($hash -ne ([string]$info.sha256).ToLower()) { throw "Το αρχείο δεν ταιριάζει (SHA256). Δεν έγινε αλλαγή." }
    Expand-Archive -Path $zip -DestinationPath $tmp -Force
    if (-not (Test-Path (Join-Path $tmp "ef-bot\manifest.json"))) { throw "Το πακέτο δεν έχει ef-bot\manifest.json" }
    # Την πλήρη διαδρομή τη δίνει ο ίδιος ο δίσκος (όχι η σύντομη μορφή NIKOSM~1 του TEMP), ώστε οι σχετικές διαδρομές να βγαίνουν σωστά
    $src = (Get-Item -LiteralPath (Join-Path $tmp "ef-bot")).FullName.TrimEnd('\')
    $files = @(Get-ChildItem -LiteralPath $src -Recurse -File | Where-Object { $_.Name -ne "manifest.json" })
    AssertExtDir
    # 1) Αντικατάσταση όλων των αρχείων της νέας έκδοσης (ΤΕΛΕΥΤΑΙΟ το manifest.json: η επέκταση ανανεώνεται μόλις αλλάξει αυτό)
    foreach ($f in $files) {
      if (-not $f.FullName.StartsWith($src + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "Απρόσμενη διαδρομή: $($f.FullName)" }
      $rel = $f.FullName.Substring($src.Length + 1)
      $dst = Join-Path $ExtDir $rel
      New-Item -ItemType Directory -Path (Split-Path -Parent $dst) -Force | Out-Null
      Copy-Item -LiteralPath $f.FullName -Destination $dst -Force
      # Επαλήθευση: το αρχείο στον φάκελο της επέκτασης είναι πράγματι το νέο
      if ((Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $f.FullName -Algorithm SHA256).Hash) { throw "Δεν αντιγράφηκε σωστά: $rel" }
    }
    Log "Αντιγράφηκαν και ελέγχθηκαν $($files.Count) αρχεία."
    # 2) Καθαρισμός: σβήνουμε ό,τι ΔΕΝ ανήκει στη νέα έκδοση (παλιά/σκόρπια αρχεία). Ό,τι είναι σε χρήση το προσπερνάμε.
    $keep = @{}; foreach ($f in $files) { $keep[$f.FullName.Substring($src.Length + 1).ToLower()] = 1 }; $keep["manifest.json"] = 1
    $extFull = (Get-Item -LiteralPath $ExtDir).FullName.TrimEnd('\')
    $del = 0; $busy = 0
    foreach ($old in @(Get-ChildItem -LiteralPath $extFull -Recurse -File -Force)) {
      $rel = $old.FullName.Substring($extFull.Length + 1).ToLower()
      if ($keep.ContainsKey($rel)) { continue }
      try { Remove-Item -LiteralPath $old.FullName -Force -ErrorAction Stop; $del++ } catch { $busy++ }
    }
    # άδειοι φάκελοι που περίσσεψαν (από τον βαθύτερο προς τα πάνω)
    Get-ChildItem -LiteralPath $extFull -Recurse -Directory -Force | Sort-Object { $_.FullName.Length } -Descending | ForEach-Object {
      if (-not (Get-ChildItem -LiteralPath $_.FullName -Force)) { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue }
    }
    if ($del -or $busy) { Log "Καθαρισμός: σβήστηκαν $del παλιά αρχεία$(if ($busy) { ", $busy σε χρήση (θα σβηστούν την επόμενη φορά)" })." }
    Copy-Item -LiteralPath (Join-Path $src "manifest.json") -Destination (Join-Path $ExtDir "manifest.json") -Force
    Log "Εγκαταστάθηκε η $($info.version). Η επέκταση θα ανανεωθεί μόνη της σε λίγα δευτερόλεπτα."
    if ($info.notes) { Log ("Τι άλλαξε: " + $info.notes) }
    return $true
  } finally { Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue }
}

$Host.UI.RawUI.WindowTitle = "ef-bot: ενημερώσεις"
# Να μην «κρατάμε» τον φάκελο tools (αλλιώς τα Windows δεν αφήνουν να αλλάξει)
Set-Location -LiteralPath $env:TEMP
# Ένα μόνο πρόγραμμα ενημέρωσης: κλείνουμε κάθε άλλο (π.χ. παλιό παράθυρο ή παλιά έκδοση που ξεκίνησε με τα Windows)
try {
  Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" |
    Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -match 'efbot-update\.ps1' } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue; Log "Έκλεισε παλιό πρόγραμμα ενημέρωσης (PID $($_.ProcessId))." }
} catch {}
Log "Φάκελος επέκτασης: $ExtDir (έκδοση $(LocalVersion))"
try { VaultInstall } catch { Log ("Κρυπτογράφηση κωδικών: " + $_.Exception.Message) }
try { FilesInstall } catch { Log ("Απεικονιστικά: " + $_.Exception.Message) }
if ($Mode -eq "once") { try { if (-not (CheckOnce)) { Log "Έχετε την τελευταία έκδοση." } } catch { Log ("Σφάλμα: " + $_.Exception.Message) }; Start-Sleep 5; exit 0 }
# 7/11: αν αυτό το παράθυρο φαίνεται (παλιά εκκίνηση με .bat → Terminal), ξαναξεκινά αόρατα και κλείνει
try { Add-Type -Namespace EfW -Name K -MemberDefinition '[DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow(); [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);' -ErrorAction SilentlyContinue
  $cw = [EfW.K]::GetConsoleWindow(); if ($Mode -eq "hidden" -and -not $env:EFBOT_NORELAUNCH -and ($env:WT_SESSION -or ($cw -ne [IntPtr]::Zero -and [EfW.K]::IsWindowVisible($cw)))) { InstallStartup; $env:EFBOT_NORELAUNCH = "1"; StartHidden; exit 0 } } catch {}
# ένα μόνο αόρατο πρόγραμμα ενημέρωσης: κλείνουν τα παλαιότερα
if ($Mode -eq "hidden") { try { Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -match 'efbot-update\.ps1.*hidden' -and $_.ProcessId -ne $PID } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue } } catch {} }
# 7/11: δεξί κλικ σε φάκελο/CD → «Άνοιγμα με Νίκος CT Viewer» (μόνο για τον χρήστη, HKCU — χωρίς δικαιώματα διαχειριστή)
try {
  $nsrc = Join-Path $PSScriptRoot "nikosct.ps1"
  if (Test-Path -LiteralPath $nsrc) {
    # σταθερός φάκελος (ΔΕΝ σβήνεται όταν ενημερώνεται το ef-bot — πριν: «δεν βρέθηκε nikosct.vbs»)
    $ndir = Join-Path $env:LOCALAPPDATA "ef-bot\nikosct"; New-Item -ItemType Directory -Force -Path $ndir | Out-Null
    $nps = Join-Path $ndir "nikosct.ps1"; Copy-Item -LiteralPath $nsrc -Destination $nps -Force
    $nvbs = Join-Path $ndir "nikosct.vbs"
    # 7/11: πάντα η ΤΕΛΕΥΤΑΙΑ έκδοση του nikosct.ps1 (φάκελος του ef-bot)· αντίγραφο στο %LOCALAPPDATA% μόνο αν λείπει
    $vtxt = 'Set a = WScript.Arguments' + "`r`n" + 'If a.Count = 0 Then WScript.Quit' + "`r`n" + 'd = a(0): If Right(d, 1) = "\" Then d = d & "."' + "`r`n" + 'p = "' + $nsrc + '"' + "`r`n" + 'If Not CreateObject("Scripting.FileSystemObject").FileExists(p) Then p = "' + $nps + '"' + "`r`n" + 'CreateObject("WScript.Shell").Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & p & """ -Dir """ & d & """", 0, False'
    Set-Content -LiteralPath $nvbs -Encoding ASCII -Value $vtxt
    $nico = Join-Path $ndir "nikosct.ico"; try { Copy-Item -LiteralPath (Join-Path $PSScriptRoot "nikosct.ico") -Destination $nico -Force } catch {}
    $ico = (@($nico, "$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1)
    foreach ($k in @("HKCU:\Software\Classes\Directory\shell\NikosCT", "HKCU:\Software\Classes\Drive\shell\NikosCT")) {
      New-Item -Path "$k\command" -Force | Out-Null
      Set-ItemProperty -Path $k -Name "(default)" -Value "Άνοιγμα με Νίκος CT Viewer"
      Set-ItemProperty -Path $k -Name "MUIVerb" -Value "Άνοιγμα με Νίκος CT Viewer"
      if ($ico) { Set-ItemProperty -Path $k -Name "Icon" -Value ('"' + $ico + '",0') }
      Set-ItemProperty -Path "$k\command" -Name "(default)" -Value ('wscript.exe "' + $nvbs + '" "%1"')
    }
  }
} catch { Log ("Δεξί κλικ CT: " + $_.Exception.Message) }
Log "Έλεγχος για ενημερώσεις κάθε 60 δευτ."
# αυτόματη εκκίνηση με τα Windows (αόρατα), εκτός αν κάποιος την αφαίρεσε ρητά (uninstall)
try { $NoAuto = Join-Path $env:LOCALAPPDATA "ef-bot\no-autostart"; if (-not (Test-Path -LiteralPath $NoAuto)) { if (-not (Test-Path -LiteralPath $Startup) -or (Test-Path -LiteralPath $StartupOld) -or ((Get-Content -LiteralPath $Startup -Raw) -notmatch [regex]::Escape($PSCommandPath))) { InstallStartup; Log "Αυτόματη εκκίνηση με τα Windows: ενεργή (αόρατα)." } } } catch {}
if (Test-Path -LiteralPath $WdOff) { Log "Φύλακας Chrome: ανενεργός (efbot-update.bat watchdog-on για ενεργοποίηση)." } else { Log "Φύλακας Chrome: ενεργός — αν κλείσει το Chrome, ξανανοίγει αόρατα." }
# Αν ενημερωθεί το ίδιο το πρόγραμμα, ξαναξεκινά μόνο του με τον νέο κώδικα (αλλιώς θα έτρεχε ο παλιός από τη μνήμη)
$Self = $PSCommandPath
$SelfHash = (Get-FileHash -LiteralPath $Self -Algorithm SHA256).Hash
while ($true) {
  try { [void](CheckOnce) } catch { Log ("Σφάλμα: " + $_.Exception.Message) }
  # βοηθητικό αρχείων: ΑΜΕΣΑ (κάθε κύκλο, σύγκριση SHA256 δύο μικρών αρχείων) — όχι ανά 10′
  try { FilesInstall } catch { Log ("Απεικονιστικά: " + $_.Exception.Message) }
  try { ChromeWatchdog } catch {}
  if (((Get-Date) - $script:VLast).TotalMinutes -ge 10) { $script:VLast = Get-Date; try { VaultInstall } catch { Log ("Κρυπτογράφηση κωδικών: " + $_.Exception.Message) }; try { FilesInstall } catch { Log ("Απεικονιστικά: " + $_.Exception.Message) } }
  try {
    if ((Get-FileHash -LiteralPath $Self -Algorithm SHA256).Hash -ne $SelfHash) {
      Log "Το πρόγραμμα ενημέρωσης ανανεώθηκε. Επανεκκίνηση..."
      StartHidden
      exit 0
    }
  } catch {}
  Start-Sleep -Seconds 60
}
