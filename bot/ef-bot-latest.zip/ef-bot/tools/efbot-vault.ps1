﻿# ef-bot vault helper (Chrome native messaging host "gr.efbot.vault")
# Protects/unprotects a small key with Windows DPAPI (CurrentUser scope). Nothing is stored here.
# Protocol: 4-byte little-endian length + UTF-8 JSON, one request per launch.
$ErrorActionPreference = "Stop"
$stdin  = [Console]::OpenStandardInput()
$stdout = [Console]::OpenStandardOutput()
function ReadN([int]$n) {
  $b = New-Object byte[] $n; $o = 0
  while ($o -lt $n) { $r = $stdin.Read($b, $o, $n - $o); if ($r -le 0) { exit 0 }; $o += $r }
  return ,$b
}
function Reply($obj) {
  $j = [Text.Encoding]::UTF8.GetBytes(($obj | ConvertTo-Json -Compress -Depth 6))
  $stdout.Write([BitConverter]::GetBytes([int]$j.Length), 0, 4)
  $stdout.Write($j, 0, $j.Length)
  $stdout.Flush()
}
try {
  $len = [BitConverter]::ToInt32((ReadN 4), 0)
  if ($len -le 0 -or $len -gt 33554432) { Reply @{ ok = $false; err = "bad length" }; exit 0 }
  $msg = [Text.Encoding]::UTF8.GetString((ReadN $len)) | ConvertFrom-Json
  Add-Type -AssemblyName System.Security
  $ent = [Text.Encoding]::UTF8.GetBytes("ef-bot-vault-v1")
  $scope = [Security.Cryptography.DataProtectionScope]::CurrentUser
  # 7/11: έξτρα έλεγχοι (ΜΟΝΟ ανάγνωση): ουρές εκτυπωτών, Defender, αυτόματη είσοδος Windows, ενημερώσεις
  function SysExtra {
    $x = @{}
    try { $jobs = @(Get-CimInstance Win32_PrintJob -ErrorAction SilentlyContinue)
      $x.pq = @(Get-CimInstance Win32_Printer -ErrorAction SilentlyContinue | Where-Object { $_.Name -notmatch 'pdf|xps|onenote|fax|send to|αποστολή' } | ForEach-Object { $n = $_.Name; $j = @($jobs | Where-Object { ($_.Name -split ',')[0] -eq $n })
        @{ name = $n; def = [bool]$_.Default; off = [bool]$_.WorkOffline; st = [int]$_.PrinterStatus; err = [int]$_.DetectedErrorState; jobs = $j.Count; old = @($j | Where-Object { $_.TimeSubmitted -and ((Get-Date) - $_.TimeSubmitted).TotalMinutes -gt 10 }).Count; jerr = @($j | Where-Object { [string]$_.JobStatus -match 'rror|σφάλ|Paused|Offline|Blocked' }).Count } }) } catch {}
    try { $m = Get-MpComputerStatus -ErrorAction Stop; $x.def = @{ on = [bool]$m.AntivirusEnabled; rt = [bool]$m.RealTimeProtectionEnabled; sigD = [int]$m.AntivirusSignatureAge; scanD = [int]$m.QuickScanAge; thr = @(Get-MpThreatDetection -ErrorAction SilentlyContinue | Where-Object { $_.InitialDetectionTime -gt (Get-Date).AddDays(-7) }).Count } } catch { $x.def = @{ err = "όχι πρόσβαση" } }
    try { $w = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -ErrorAction Stop; $x.autologon = ([string]$w.AutoAdminLogon -eq "1") } catch {}
    try { $x.wuDays = [int]((Get-Date) - (Get-HotFix -ErrorAction Stop | Where-Object { $_.InstalledOn } | Sort-Object InstalledOn -Descending | Select-Object -First 1).InstalledOn).TotalDays } catch {}
    return $x
  }
  switch ([string]$msg.op) {
    "ping"      { Reply @{ ok = $true; v = 1; user = [Environment]::UserName } }
    "protect"   { $d = [Convert]::FromBase64String([string]$msg.data); Reply @{ ok = $true; data = [Convert]::ToBase64String([Security.Cryptography.ProtectedData]::Protect($d, $ent, $scope)) } }
    "unprotect" { $d = [Convert]::FromBase64String([string]$msg.data); Reply @{ ok = $true; data = [Convert]::ToBase64String([Security.Cryptography.ProtectedData]::Unprotect($d, $ent, $scope)) } }
    "update"    {
      # ξαναξεκινά το πρόγραμμα αυτόματων ενημερώσεων του ef-bot, ΜΟΝΟ αν δεν τρέχει ήδη (καμία άλλη εντολή δεν εκτελείται)
      $pf = Join-Path $PSScriptRoot "updater-path.txt"
      if (-not (Test-Path -LiteralPath $pf)) { Reply @{ ok = $false; err = "δεν είναι γνωστός ο φάκελος του ef-bot (τρέξτε μία φορά το efbot-update.bat)" }; break }
      $bat = ([IO.File]::ReadAllText($pf)).Trim()
      if (-not ($bat -match 'efbot-update\.bat$') -or -not (Test-Path -LiteralPath $bat)) { Reply @{ ok = $false; err = "λάθος διαδρομή προγράμματος ενημέρωσης" }; break }
      $run = @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -match 'efbot-update\.ps1' }).Count
      if ($run -gt 0) { Reply @{ ok = $true; already = $true }; break }
      # 7/11: αόρατα (wscript → powershell χωρίς κονσόλα) — τίποτα στη γραμμή εργασιών
      $ps1 = Join-Path (Split-Path -Parent $bat) "efbot-update.ps1"; $cl = "cmd.exe /c start `"ef-bot`" /min `"$bat`""
      if (Test-Path -LiteralPath $ps1) { $vbs = Join-Path (Split-Path -Parent $bat) "efbot-update-hidden.vbs"
        Set-Content -LiteralPath $vbs -Encoding ASCII -Value ('CreateObject("WScript.Shell").Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""' + $ps1 + '"" hidden", 0, False')
        $cl = "wscript.exe `"$vbs`"" }
      $r = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = $cl; CurrentDirectory = $env:TEMP }
      if ($r.ReturnValue -ne 0) { Reply @{ ok = $false; err = "δεν ξεκίνησε (κωδικός $($r.ReturnValue))" }; break }
      Reply @{ ok = $true; started = $true }
    }
    { $_ -eq "hidewin" -or $_ -eq "showwin" } {
      # Κρύβει/δείχνει τα παράθυρα του bot (τίτλος με σήμανση) — ούτε στη γραμμή εργασιών. Μόνο παράθυρα του chrome.exe.
      Add-Type -TypeDefinition @"
using System; using System.Text; using System.Collections.Generic; using System.Runtime.InteropServices;
public static class EfWin {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc f, IntPtr l);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  public static List<long> Find(string m) { var r = new List<long>(); EnumWindows(delegate (IntPtr h, IntPtr l) { var sb = new StringBuilder(512); GetWindowText(h, sb, 512); if (sb.ToString().Contains(m)) r.Add(h.ToInt64()); return true; }, IntPtr.Zero); return r; }
}
"@
      $hs = @()
      if ($msg.h) { $hs = @($msg.h | ForEach-Object { [long]$_ }) }
      elseif (([string]$msg.marker).Length -ge 6) { $hs = @([EfWin]::Find([string]$msg.marker)) }
      $done = @()
      foreach ($h in $hs) {
        $pid0 = [uint32]0; [EfWin]::GetWindowThreadProcessId([IntPtr]$h, [ref]$pid0) | Out-Null
        $pn = (Get-Process -Id $pid0 -ErrorAction SilentlyContinue).ProcessName
        if ($pn -ne "chrome") { continue }
        [EfWin]::ShowWindow([IntPtr]$h, $(if ([string]$msg.op -eq "hidewin") { 0 } else { 6 })) | Out-Null
        $done += $h
      }
      Reply @{ ok = $true; n = $done.Count; h = $done }
    }
    "reboot"    {
      # ♻ Επανεκκίνηση Windows με 2′ προειδοποίηση στην οθόνη (ακυρώνεται με «rebootcancel» ή shutdown /a). Μόνο κατόπιν εντολής από το Κέντρο ελέγχου.
      $sec = [Math]::Max(60, [Math]::Min(600, [int]$msg.sec))
      $o = & shutdown.exe /r /t $sec /c "Παραδόχαρτο: επανεκκίνηση του υπολογιστή σε $([int]($sec/60)) λεπτά για καθαρισμό μνήμης. Σώστε ό,τι έχετε ανοιχτό." 2>&1
      Reply @{ ok = ($LASTEXITCODE -eq 0); sec = $sec; err = [string]$o }
    }
    "rebootcancel" { $o = & shutdown.exe /a 2>&1; Reply @{ ok = ($LASTEXITCODE -eq 0); err = [string]$o } }
    "trim"      {
      # 🧹 «Συμπίεση» μνήμης: EmptyWorkingSet στα προγράμματα ΤΟΥ ΙΔΙΟΥ χρήστη (χωρίς δικαιώματα διαχειριστή, χωρίς κλείσιμο τίποτα).
      # Τα Windows μεταφέρουν τις σελίδες που δεν χρησιμοποιούνται στη λίστα αναμονής· ό,τι χρειαστεί ξαναφορτώνει αυτόματα.
      Add-Type -Namespace EfMem -Name Psapi -MemberDefinition '[DllImport("psapi.dll")] public static extern bool EmptyWorkingSet(IntPtr hProcess);' -ErrorAction SilentlyContinue
      $n = 0; $before = (Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory
      $sid = (Get-Process -Id $PID).SessionId
      foreach ($p in Get-Process -ErrorAction SilentlyContinue) {
        if ($p.SessionId -ne $sid -or $p.Id -eq $PID) { continue }   # μόνο η συνεδρία του χρήστη· ξένες διεργασίες απορρίπτονται από τα Windows (χωρίς διαχειριστή)
        try { if ([EfMem.Psapi]::EmptyWorkingSet($p.Handle)) { $n++ } } catch {}
      }
      Start-Sleep -Milliseconds 800; $after = (Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory
      Reply @{ ok = $true; n = $n; freedMb = [int](($after - $before) / 1024) }
    }
    "printers"  {
      # ΜΟΝΟ ανάγνωση: εκτυπωτές των Windows και αν είναι έτοιμοι
      $pr = @(Get-CimInstance Win32_Printer -ErrorAction SilentlyContinue | ForEach-Object { @{ name = $_.Name; def = [bool]$_.Default; off = [bool]$_.WorkOffline; st = [int]$_.PrinterStatus; err = [int]$_.DetectedErrorState; net = [bool]$_.Network } })
      Reply @{ ok = $true; printers = $pr }
    }
    "a4q" {
      # 🖨 17/11: ΜΟΝΟ ανάγνωση — εκτυπωτές A4 (όχι ετικετών): κατάσταση, θύρα, εργασίες στην ουρά
      $out = @()
      foreach ($p in @(Get-Printer -ErrorAction SilentlyContinue | Where-Object { $_.Name -notmatch '(?i)pdf|xps|onenote|fax' })) {
        $jobs = @(Get-PrintJob -PrinterName $p.Name -ErrorAction SilentlyContinue | Select-Object -First 15 | ForEach-Object { @{ id = [int]$_.Id; st = [string]$_.JobStatus; at = [string]$_.SubmittedTime; pages = [int]$_.TotalPages; size = [int]$_.Size } })
        $wp = $null; try { $wp = Get-CimInstance Win32_Printer -Filter ("Name='" + ($p.Name -replace "'", "''") + "'") -ErrorAction SilentlyContinue } catch {}
        $out += @{ name = [string]$p.Name; st = [string]$p.PrinterStatus; port = [string]$p.PortName; drv = [string]$p.DriverName; type = [string]$p.Type; jobs = $jobs; off = [bool]($wp -and $wp.WorkOffline); net = [bool]($wp -and $wp.Network); label = ([string]$p.Name -match '(?i)zebra|zdesigner|label|ετικ') }
      }
      $def = ""; try { $def = [string](Get-CimInstance Win32_Printer -Filter "Default=TRUE" -ErrorAction SilentlyContinue).Name } catch {}
      Reply @{ ok = $true; printers = $out; def = $def }
    }
    "printq" {
      # 🦓 12/11 (χρήστης: «σε Γωνιακό δεν εκτυπώνει τα barcode»): ΜΟΝΟ ανάγνωση — κατάσταση εκτυπωτών ετικετών + εργασίες στην ουρά (καμία αλλαγή)
      $out = @()
      foreach ($p in @(Get-Printer -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '(?i)zebra|zdesigner|label|ετικ' })) {
        $jobs = @(Get-PrintJob -PrinterName $p.Name -ErrorAction SilentlyContinue | Select-Object -First 15 | ForEach-Object { @{ id = [int]$_.Id; st = [string]$_.JobStatus; doc = ([string]$_.DocumentName -replace '\d{5,}', '#'); at = [string]$_.SubmittedTime; pages = [int]$_.TotalPages; size = [int]$_.Size } })
        $out += @{ name = [string]$p.Name; st = [string]$p.PrinterStatus; port = [string]$p.PortName; drv = [string]$p.DriverName; shared = [bool]$p.Shared; jobs = $jobs }
      }
      Reply @{ ok = $true; printers = $out }
    }
    "display" {
      # 📺 13/11 15:39 (χρήστης: «από HDMI να δείχνω μέσω του bot ό,τι θέλω και να αλλάζω mirror/extend»). Ο κώδικας είναι ΚΕΙΜΕΝΟ (here-string) που
      # τρέχει μέσα σε try: αν έχει λάθος, αποτυγχάνει ΜΟΝΟ αυτή η εντολή — όχι το βοηθητικό (κωδικοί/εκτυπώσεις).
      $dsrc = @'
param($m)
$out = @{ ok = $true }
$mode = [string]$m.mode
if ($mode) {
  $map = @{ clone = "/clone"; extend = "/extend"; internal = "/internal"; external = "/external" }
  if (-not $map.ContainsKey($mode)) { return @{ ok = $false; err = "άγνωστη λειτουργία" } }
  $ds = Join-Path $env:WINDIR "System32\DisplaySwitch.exe"
  Start-Process -FilePath $ds -ArgumentList $map[$mode] -WindowStyle Hidden
  Start-Sleep -Milliseconds 3500
  $out.mode = $mode
}
Add-Type -AssemblyName System.Windows.Forms
$scr = @()
foreach ($s in [System.Windows.Forms.Screen]::AllScreens) {
  $scr += @{ name = [string]$s.DeviceName; primary = [bool]$s.Primary; x = [int]$s.Bounds.X; y = [int]$s.Bounds.Y; w = [int]$s.Bounds.Width; h = [int]$s.Bounds.Height }
}
$out.screens = $scr
return $out
'@
      try { $sb = [ScriptBlock]::Create($dsrc); $res = & $sb $msg; Reply $res } catch { Reply @{ ok = $false; err = "οθόνες: " + [string]$_.Exception.Message } }
    }
    "tvinfo" {
      # 📺 12/11 18:02 (χρήστης: «τηλεόραση με HDMI στον Μεσαίο — άνοιγμα/χειρισμός από τον υπολογιστή, χάσαμε το τηλεχειριστήριο»):
      # ΜΟΝΟ ανάγνωση — οθόνες (EDID: κατασκευαστής/μοντέλο, σύνδεση HDMI;), κάρτες γραφικών, συσκευή CEC (Pulse-Eight USB 2548:1001/1002), cec-client
      $mons = @(); $conn = @{}
      try { foreach ($c in @(Get-CimInstance -Namespace root\wmi -ClassName WmiMonitorConnectionParams -ErrorAction Stop)) { $conn[[string]$c.InstanceName] = [int]$c.VideoOutputTechnology } } catch {}
      $dec = { param($a) if (-not $a) { return "" }; (($a | Where-Object { $_ -gt 0 } | ForEach-Object { [char]$_ }) -join "").Trim() }
      try { foreach ($m in @(Get-CimInstance -Namespace root\wmi -ClassName WmiMonitorID -ErrorAction Stop)) {
          $vt = $conn[[string]$m.InstanceName]
          $mons += @{ maker = (& $dec $m.ManufacturerName); model = (& $dec $m.UserFriendlyName); code = (& $dec $m.ProductCodeID); year = [int]$m.YearOfManufacture; active = [bool]$m.Active; out = $(switch ($vt) { 5 { "HDMI" } 10 { "DisplayPort" } 4 { "DVI" } 0 { "VGA" } 11 { "εσωτερική" } -2147483648 { "εσωτερική" } default { [string]$vt } }) } } } catch { $mons += @{ err = [string]$_.Exception.Message } }
      $gpus = @(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | ForEach-Object { @{ name = [string]$_.Name; drv = [string]$_.DriverVersion } })
      $cec = @(Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue | Where-Object { $_.InstanceId -match '(?i)VID_2548' -or $_.FriendlyName -match '(?i)cec|pulse-?eight' } | ForEach-Object { @{ name = [string]$_.FriendlyName; id = ([string]$_.InstanceId).Substring(0, [Math]::Min(40, ([string]$_.InstanceId).Length)); st = [string]$_.Status } })
      $cc = @("$env:ProgramFiles\Pulse-Eight\USB-CEC Adapter\cec-client.exe", "${env:ProgramFiles(x86)}\Pulse-Eight\USB-CEC Adapter\cec-client.exe") | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
      Reply @{ ok = $true; monitors = $mons; gpus = $gpus; cec = $cec; cecClient = [string]$cc; pc = [string]$env:COMPUTERNAME }
    }
    "tvfind" {
      # 📺 12/11 18:17 (χρήστης: «ο υπολογιστής ενσύρματα, η τηλεόραση Wi-Fi στο ίδιο δίκτυο — να στείλει εντολή από εκεί»): ΜΟΝΟ εντοπισμός
      # (1) SSDP M-SEARCH για LG webOS (2) πίνακας ARP: συσκευές LG (MAC) (3) σύνδεση TCP 3000/3001 μόνο στα IP που βρέθηκαν. Καμία εντολή.
      $found = @{}; $ssdp = @()
      try { $u = New-Object System.Net.Sockets.UdpClient; $u.Client.ReceiveTimeout = 1500; $u.Client.SetSocketOption([System.Net.Sockets.SocketOptionLevel]::Socket, [System.Net.Sockets.SocketOptionName]::ReuseAddress, $true)
        $ep = New-Object System.Net.IPEndPoint ([System.Net.IPAddress]::Parse("239.255.255.250")), 1900
        foreach ($st in @("urn:lge-com:service:webos-second-screen:1", "urn:dial-multiscreen-org:service:dial:1", "ssdp:all")) {
          $q = [Text.Encoding]::ASCII.GetBytes("M-SEARCH * HTTP/1.1`r`nHOST: 239.255.255.250:1900`r`nMAN: `"ssdp:discover`"`r`nMX: 2`r`nST: $st`r`n`r`n"); [void]$u.Send($q, $q.Length, $ep) }
        $t0 = Get-Date
        while (((Get-Date) - $t0).TotalSeconds -lt 4) { try { $rep = New-Object System.Net.IPEndPoint ([System.Net.IPAddress]::Any), 0; $b = $u.Receive([ref]$rep); $tx = [Text.Encoding]::ASCII.GetString($b)
            $ip = [string]$rep.Address; $srv = (([regex]::Match($tx, '(?im)^SERVER:\s*(.+)$')).Groups[1].Value).Trim(); $stv = (([regex]::Match($tx, '(?im)^ST:\s*(.+)$')).Groups[1].Value).Trim()
            if ($tx -match '(?i)webos|lge|LG Electronics' -or $stv -match '(?i)lge') { $found[$ip] = "ssdp: " + $srv }
            if ($ssdp.Count -lt 25) { $ssdp += ($ip + " · " + $srv + " · " + $stv).Substring(0, [Math]::Min(140, ($ip + " · " + $srv + " · " + $stv).Length)) } } catch { } }
        $u.Close() } catch { $ssdp += "✗ " + [string]$_.Exception.Message }
      # LG OUI (μερικά γνωστά): 00:E0:91, A8:23:FE, 64:BC:0C, CC:2D:8C, 58:FD:B1, 38:8C:50, 78:5D:C8, 7C:1C:4E, C8:08:E9, 10:F1:F2, AC:F1:08, 04:4E:AF, 14:C9:13, 2C:FD:A1, 50:55:27, 60:AB:14, 34:FC:EF, B4:B2:91, 88:36:6C, 74:E6:B8
      $oui = '^(00-E0-91|A8-23-FE|64-BC-0C|CC-2D-8C|58-FD-B1|38-8C-50|78-5D-C8|7C-1C-4E|C8-08-E9|10-F1-F2|AC-F1-08|04-4E-AF|14-C9-13|2C-FD-A1|50-55-27|60-AB-14|34-FC-EF|B4-B2-91|88-36-6C|74-E6-B8)'
      $nb = @(Get-NetNeighbor -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.LinkLayerAddress -and $_.State -ne 'Unreachable' })
      foreach ($n in $nb) { if ([string]$n.LinkLayerAddress -match $oui) { if (-not $found[[string]$n.IPAddress]) { $found[[string]$n.IPAddress] = "MAC LG " + [string]$n.LinkLayerAddress } } }
      $my = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notmatch '^(127|169\.254)\.' } | ForEach-Object { [string]$_.IPAddress + "/" + [string]$_.PrefixLength })
      $tv = @(); foreach ($ip in $found.Keys) { $ports = @(); foreach ($pt in 3000, 3001) { try { $c = New-Object System.Net.Sockets.TcpClient; $a = $c.BeginConnect($ip, $pt, $null, $null); if ($a.AsyncWaitHandle.WaitOne(1500) -and $c.Connected) { $ports += $pt }; $c.Close() } catch { } }
        $tv += @{ ip = $ip; how = $found[$ip]; ports = $ports } }
      Reply @{ ok = $true; tv = $tv; ssdp = $ssdp; my = $my; neigh = $nb.Count }
    }
    "printcancel" {
      # 🦓 12/11: ακύρωση ΣΥΓΚΕΚΡΙΜΕΝΩΝ εργασιών (ids) ΜΟΝΟ σε εκτυπωτή ετικετών (zebra/zdesigner) — ποτέ «όλα», ποτέ στους A4
      $name = [string]$msg.printer; $ids = @($msg.ids | ForEach-Object { [int]$_ }) | Where-Object { $_ -gt 0 }
      # 🖨 17/11: και στους A4 (Κέντρο εκτυπώσεων) — ΠΑΝΤΑ μόνο συγκεκριμένες εργασίες (ids), ποτέ «όλα»
      if (-not $name -or -not $ids.Count -or -not (Get-Printer -Name $name -ErrorAction SilentlyContinue)) { Reply @{ ok = $false; err = "χρειάζεται εκτυπωτής και συγκεκριμένες εργασίες" }; break }
      $done = @(); $fail = @()
      foreach ($id in $ids) { try { Remove-PrintJob -PrinterName $name -ID $id -ErrorAction Stop; $done += $id } catch { $fail += @{ id = $id; err = [string]$_.Exception.Message } } }
      Start-Sleep -Milliseconds 800
      $left = @(Get-PrintJob -PrinterName $name -ErrorAction SilentlyContinue | ForEach-Object { @{ id = [int]$_.Id; st = [string]$_.JobStatus } })
      $pst = [string](Get-Printer -Name $name -ErrorAction SilentlyContinue).PrinterStatus
      Reply @{ ok = $true; done = $done; fail = $fail; left = $left; st = $pst }
    }
    "rawprint" {
      # 🦓 11/11 (χρήστης: «δοκιμαστική εκτύπωση σε Zebra»): ωμά δεδομένα (ZPL) κατευθείαν στον εκτυπωτή ετικετών των Windows (winspool, RAW).
      # ΜΟΝΟ σε εκτυπωτή με όνομα Zebra/ZDesigner/label — ποτέ στους A4. Μέγιστο 64 KB.
      $want = [string]$msg.printer; $data = [string]$msg.data
      # 12/11 (χρήστης: «μικρά, εικόνες, emoji»): εικόνα EPL (GW) = δυαδικά → έρχονται ως base64 στο «b64» (όχι UTF-8)
      $bin = $null; if ($msg.b64) { try { $bin = [Convert]::FromBase64String([string]$msg.b64) } catch { $bin = $null } }
      if ($bin) { if ($bin.Length -gt 98304) { Reply @{ ok = $false; err = "πολύ μεγάλη εικόνα" }; break } }
      elseif (-not $data -or $data.Length -gt 65536) { Reply @{ ok = $false; err = "κενά/πολλά δεδομένα" }; break }
      $all = @(Get-CimInstance Win32_Printer -ErrorAction SilentlyContinue)
      $pick = $all | Where-Object { ($want -and $_.Name -eq $want) -or (-not $want -and $_.Name -match '(?i)zebra|zdesigner') } | Select-Object -First 1
      if (-not $pick -or $pick.Name -notmatch '(?i)zebra|zdesigner|label|ετικ') { Reply @{ ok = $false; err = "δεν βρέθηκε εκτυπωτής Zebra"; printers = @($all | ForEach-Object { $_.Name }) }; break }
      Add-Type -TypeDefinition @"
using System; using System.Runtime.InteropServices;
public static class EfRaw {
  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)] public class DOCINFO { public string pDocName; public string pOutputFile; public string pDataType; }
  [DllImport("winspool.drv", CharSet = CharSet.Unicode, SetLastError = true)] static extern bool OpenPrinter(string n, out IntPtr h, IntPtr d);
  [DllImport("winspool.drv", SetLastError = true)] static extern bool ClosePrinter(IntPtr h);
  [DllImport("winspool.drv", CharSet = CharSet.Unicode, SetLastError = true)] static extern int StartDocPrinter(IntPtr h, int lvl, [In] DOCINFO di);
  [DllImport("winspool.drv", SetLastError = true)] static extern bool EndDocPrinter(IntPtr h);
  [DllImport("winspool.drv", SetLastError = true)] static extern bool StartPagePrinter(IntPtr h);
  [DllImport("winspool.drv", SetLastError = true)] static extern bool EndPagePrinter(IntPtr h);
  [DllImport("winspool.drv", SetLastError = true)] static extern bool WritePrinter(IntPtr h, byte[] b, int n, out int w);
  public static int Send(string printer, byte[] bytes, string name) {
    IntPtr h; if (!OpenPrinter(printer, out h, IntPtr.Zero)) return -Marshal.GetLastWin32Error();
    try { DOCINFO di = new DOCINFO(); di.pDocName = name; di.pDataType = "RAW";
      if (StartDocPrinter(h, 1, di) == 0) return -Marshal.GetLastWin32Error();
      try { StartPagePrinter(h); int w; bool ok = WritePrinter(h, bytes, bytes.Length, out w); EndPagePrinter(h); return ok ? w : -Marshal.GetLastWin32Error(); }
      finally { EndDocPrinter(h); } } finally { ClosePrinter(h); } }
}
"@ -ErrorAction SilentlyContinue
      $bytes = if ($bin) { $bin } else { [Text.Encoding]::UTF8.GetBytes($data) }
      $w = [EfRaw]::Send([string]$pick.Name, $bytes, "ef-bot " + [string]$msg.name)
      if ($w -ge 0) { Reply @{ ok = $true; printer = [string]$pick.Name; bytes = $w } } else { Reply @{ ok = $false; err = "winspool σφάλμα " + (-$w); printer = [string]$pick.Name } }
    }
    "sttinstall" {
      # 🎤 8/11 (έγκριση χρήστη «Εγκρίνω whisper σε μεσαίο»): whisper.cpp + large-v3-turbo q5 (ελληνικά) — λήψη στο παρασκήνιο (~600 MB)
      $dir = Join-Path $env:LOCALAPPDATA "efbot-stt"; New-Item -ItemType Directory -Path $dir -Force | Out-Null
      $sc = @'
$ErrorActionPreference = "Stop"; $dir = $args[0]; $stf = Join-Path $dir "status.txt"
function S($t) { Set-Content -LiteralPath $stf -Value ((Get-Date).ToString("s") + " " + $t) -Encoding UTF8 }
try {
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  if (-not (Get-ChildItem -LiteralPath $dir -Recurse -Filter "whisper-cli.exe" -ErrorAction SilentlyContinue)) {
    $zip = Join-Path $dir "whisper.zip"
    # η διεύθυνση από το GitHub API (τελευταία έκδοση με Windows x64 binary)· όχι σταθερή έκδοση (το v1.9.5 έδωσε 404)
    S "αναζήτηση έκδοσης whisper.cpp"; $url = $null; $tried = @()
    foreach ($api in @("https://api.github.com/repos/ggml-org/whisper.cpp/releases?per_page=15")) {
      $wc = New-Object Net.WebClient; $wc.Headers.Add("User-Agent", "efbot"); $rel = $wc.DownloadString($api) | ConvertFrom-Json
      foreach ($r in $rel) { $a = @($r.assets | Where-Object { $_.name -eq "whisper-bin-x64.zip" }); if ($a.Count) { $url = $a[0].browser_download_url; break } ; $tried += $r.tag_name }
    }
    if (-not $url) { throw ("δεν βρέθηκε whisper-bin-x64.zip σε: " + ($tried -join ", ")) }
    S ("λήψη whisper.cpp " + $url); (New-Object Net.WebClient).DownloadFile($url, $zip)
    S "αποσυμπίεση"; Expand-Archive -LiteralPath $zip -DestinationPath (Join-Path $dir "bin") -Force; Remove-Item -LiteralPath $zip -Force
  }
  $m = Join-Path $dir "ggml-large-v3-turbo-q5_0.bin"
  if (-not (Test-Path -LiteralPath $m) -or (Get-Item -LiteralPath $m).Length -ne 574041195) {
    S "λήψη μοντέλου (574 MB)"; $tmp = $m + ".part"; (New-Object Net.WebClient).DownloadFile("https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-large-v3-turbo-q5_0.bin", $tmp)
    if ((Get-Item -LiteralPath $tmp).Length -ne 574041195) { throw "λάθος μέγεθος μοντέλου" }
    Move-Item -LiteralPath $tmp -Destination $m -Force
  }
  S "OK"
} catch { S ("ΣΦΑΛΜΑ " + $_.Exception.Message) }
'@
      $ps = Join-Path $dir "install.ps1"; [IO.File]::WriteAllText($ps, $sc, (New-Object Text.UTF8Encoding $true))
      $cl = 'powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $ps + '" "' + $dir + '"'
      $cr = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = $cl; CurrentDirectory = $dir }
      Reply @{ ok = ($cr.ReturnValue -eq 0); started = $true; err = $(if ($cr.ReturnValue -ne 0) { "κωδικός " + $cr.ReturnValue } else { "" }) }
    }
    "sttstatus" {
      $dir = Join-Path $env:LOCALAPPDATA "efbot-stt"; $stf = Join-Path $dir "status.txt"
      $exe = Get-ChildItem -LiteralPath $dir -Recurse -Filter "whisper-cli.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
      $m = Join-Path $dir "ggml-large-v3-turbo-q5_0.bin"; $mp = $m + ".part"
      Reply @{ ok = $true; status = $(if (Test-Path -LiteralPath $stf) { ([string](Get-Content -LiteralPath $stf -Raw)).Trim() } else { "" }); exe = [bool]$exe; model = $(if (Test-Path -LiteralPath $m) { (Get-Item -LiteralPath $m).Length } else { 0 }); part = $(if (Test-Path -LiteralPath $mp) { (Get-Item -LiteralPath $mp).Length } else { 0 }); cores = [Environment]::ProcessorCount }
    }
    "stt" {
      # 🎤 μεταγραφή: WAV 16 kHz mono → ελληνικό κείμενο. Ο ήχος και τα ενδιάμεσα σβήνονται αμέσως.
      $dir = Join-Path $env:LOCALAPPDATA "efbot-stt"
      $exe = Get-ChildItem -LiteralPath $dir -Recurse -Filter "whisper-cli.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
      $m = Join-Path $dir "ggml-large-v3-turbo-q5_0.bin"
      if (-not $exe -or -not (Test-Path -LiteralPath $m)) { Reply @{ ok = $false; err = "δεν έχει εγκατασταθεί το Whisper σε αυτόν τον υπολογιστή" }; break }
      $id = [Guid]::NewGuid().ToString("N"); $wav = Join-Path $env:TEMP ("efstt-" + $id + ".wav"); $of = Join-Path $env:TEMP ("efstt-" + $id); $ef = $of + ".err"; $sf = $of + ".out"
      try {
        [IO.File]::WriteAllBytes($wav, [Convert]::FromBase64String([string]$msg.b64))
        $th = [Math]::Max(2, [Environment]::ProcessorCount - 1)
        $a = @("-m", ('"' + $m + '"'), "-l", "el", "-t", "$th", "-nt", "-otxt", "-of", ('"' + $of + '"'), "-f", ('"' + $wav + '"'))
        $pr = ([string]$msg.prompt) -replace '["\r\n]', ' '; if ($pr.Length -gt 400) { $pr = $pr.Substring(0, 400) }
        if ($pr) { $a += @("--prompt", ('"' + $pr + '"')) }
        $t0 = Get-Date
        $p = Start-Process -FilePath $exe.FullName -ArgumentList $a -NoNewWindow -Wait -PassThru -RedirectStandardError $ef -RedirectStandardOutput $sf
        $txt = ""; if (Test-Path -LiteralPath ($of + ".txt")) { $txt = [IO.File]::ReadAllText($of + ".txt", [Text.Encoding]::UTF8) }
        $err = ""; if (-not $txt.Trim()) { try { $err = ([IO.File]::ReadAllText($ef)).Trim(); if ($err.Length -gt 300) { $err = $err.Substring($err.Length - 300) } } catch {} }
        Reply @{ ok = [bool]$txt.Trim(); text = $txt.Trim(); secs = [int]((Get-Date) - $t0).TotalSeconds; code = $p.ExitCode; err = $err }
      } catch { Reply @{ ok = $false; err = $_.Exception.Message } }
      finally { foreach ($f in @($wav, ($of + ".txt"), $ef, $sf)) { try { Remove-Item -LiteralPath $f -Force -ErrorAction SilentlyContinue } catch {} } }
    }
    "tcpscan" {
      # 📡 15/11 22:48 (χρήστης: «ξέρουμε IP+όνομα, οι υπολογιστές μας έχουν πρόσβαση — βρες τα αποτελέσματα»): πραγματική σύνδεση TCP (όχι HTTP), ΜΟΝΟ ανάγνωση.
      # Για κάθε θύρα: σύνδεση με μικρό timeout → ανοιχτή/κλειστή με σιγουριά· σε ανοιχτή, διαβάζει έως 200 bytes «banner» αν στείλει κάτι ο server. Τίποτα δεν γράφεται/στέλνεται (εκτός ενός προαιρετικού newline).
      $ip = [string]$msg.ip
      if ($ip -notmatch '^\d{1,3}(\.\d{1,3}){3}$') { Reply @{ ok = $false; err = "λάθος διεύθυνση" }; break }
      $ports = @($msg.ports | ForEach-Object { [int]$_ } | Where-Object { $_ -gt 0 -and $_ -lt 65536 } | Select-Object -Unique -First 80)
      $rows = @()
      foreach ($p in $ports) {
        $row = @{ port = $p; open = $false }
        $c = New-Object Net.Sockets.TcpClient
        try {
          $iar = $c.BeginConnect($ip, $p, $null, $null)
          if ($iar.AsyncWaitHandle.WaitOne(1000) -and $c.Connected) {
            $c.EndConnect($iar); $row.open = $true
            try {
              $ns = $c.GetStream(); $ns.ReadTimeout = 700
              Start-Sleep -Milliseconds 350
              if ($ns.DataAvailable) {
                $buf = New-Object byte[] 200; $n = $ns.Read($buf, 0, 200)
                if ($n -gt 0) { $b = ([Text.Encoding]::ASCII.GetString($buf, 0, $n) -replace '[^\x20-\x7E]', '.').Trim(); if ($b.Length -gt 120) { $b = $b.Substring(0, 120) }; $row.banner = $b }
              }
            } catch {}
          }
        } catch {} finally { try { $c.Close() } catch {} }
        $rows += $row
      }
      Reply @{ ok = $true; ip = $ip; rows = $rows }
    }
    "netname" {
      # 🏷 15/11 22:35 (χρήστης: «μάθε το όνομα από το δίκτυο»): ΜΟΝΟ ανάγνωση — όνομα υπολογιστή/τομέα + συνδεδεμένος χρήστης (NetBIOS) + ανάστροφο DNS. Τίποτα δεν αλλάζει.
      $ip = [string]$msg.ip
      if ($ip -notmatch '^\d{1,3}(\.\d{1,3}){3}$') { Reply @{ ok = $false; err = "λάθος διεύθυνση" }; break }
      $o = @{ ip = $ip }
      try { $o.nbt = (& nbtstat.exe -A $ip 2>&1 | Out-String).Trim() } catch { $o.nbterr = $_.Exception.Message }
      try { $o.dns = @(Resolve-DnsName -Name $ip -ErrorAction Stop | ForEach-Object { [string]$_.NameHost } | Where-Object { $_ }) -join "," } catch {}
      Reply @{ ok = $true; ip = $ip; nbt = [string]$o.nbt; dns = [string]$o.dns; nbterr = [string]$o.nbterr }
    }
    "uqfs" {
      # 🧫 15/11 21:51 (χρήστης: «άνοιξε πρόσβαση στο \\172.16.3.59 από το Παραδόχαρτο»): ΜΟΝΟ ανάγνωση, ΜΟΝΟ κάτω από \\172.16.3.59\ — τίποτα δεν γράφεται/σβήνεται.
      $root = '\\172.16.3.59'; $p = ([string]$msg.path).TrimEnd('\')
      if (-not $p) { $p = $root }
      if ($p -ne $root -and -not $p.StartsWith($root + '\') -or $p -match '\.\.') { Reply @{ ok = $false; err = "μόνο κάτω από $root" }; break }
      try {
        if ($p -eq $root) {
          $o = (& net.exe view $root /all 2>&1) | ForEach-Object { [string]$_ }
          $sh = @($o | Where-Object { $_ -match '^\S.*\s+(Disk|Δίσκος|Print|IPC)' } | ForEach-Object { ($_ -split '\s{2,}')[0].Trim() })
          Reply @{ ok = ($sh.Count -gt 0); shares = $sh; raw = (($o | Select-Object -First 25) -join "`n"); code = $LASTEXITCODE }; break }
        if ($msg.read) {
          $fi = Get-Item -LiteralPath $p -ErrorAction Stop; if ($fi.PSIsContainer) { Reply @{ ok = $false; err = "είναι φάκελος" }; break }
          $max = 4194304; if ($fi.Length -gt $max) { Reply @{ ok = $false; err = "μεγάλο αρχείο"; size = $fi.Length }; break }
          $fs = [IO.File]::Open($p, 'Open', 'Read', 'ReadWrite'); try { $b = New-Object byte[] $fi.Length; [void]$fs.Read($b, 0, $b.Length) } finally { $fs.Close() }
          Reply @{ ok = $true; name = $fi.Name; size = $fi.Length; mt = $fi.LastWriteTime.ToString("o"); b64 = [Convert]::ToBase64String($b) }; break }
        $it = @(Get-ChildItem -LiteralPath $p -Force -ErrorAction Stop | Sort-Object LastWriteTime -Descending | Select-Object -First 400)
        Reply @{ ok = $true; path = $p; items = @($it | ForEach-Object { @{ n = $_.Name; d = [bool]$_.PSIsContainer; s = $(if ($_.PSIsContainer) { 0 } else { [long]$_.Length }); mt = $_.LastWriteTime.ToString("o") } }) }
      } catch { Reply @{ ok = $false; err = $_.Exception.Message } }
    }
    "orsave" {
      # 🗓 Πρόγραμμα χειρουργείου: γράφει το .xlsx στον φάκελο δικτύου — ΜΟΝΟ κάτω από «ΠΡΟΓΡΑΜΜΑ ΧΕΙΡΟΥΡΓΕΙΟΥ» (μήνας\αρχείο)
      $base = '\\pronas\OUROLOGIKH_KLINIKH\ΠΡΟΓΡΑΜΜΑ ΧΕΙΡΟΥΡΓΕΙΟΥ'
      if ($msg.base -and ([string]$msg.base).StartsWith([IO.Path]::GetTempPath())) { $base = [string]$msg.base }   # μόνο για δοκιμές
      $dir = [string]$msg.dir; $name = [string]$msg.name
      if (-not $dir -or -not $name -or $dir -match '[\\/:*?"<>|]|\.\.' -or $name -match '[\\/:*?"<>|]|\.\.' -or $name -notmatch '\.xlsx$') { Reply @{ ok = $false; err = "μη έγκυρο όνομα φακέλου/αρχείου" }; break }
      if (-not (Test-Path -LiteralPath $base)) { Reply @{ ok = $false; err = "δεν βρέθηκε ο φάκελος δικτύου: $base" }; break }
      $full = Join-Path $base $dir
      try { if (-not (Test-Path -LiteralPath $full)) { New-Item -ItemType Directory -Path $full -Force | Out-Null } } catch { Reply @{ ok = $false; err = "δεν δημιουργήθηκε ο φάκελος $dir" }; break }
      $target = Join-Path $full $name
      if ((Test-Path -LiteralPath $target) -and -not $msg.overwrite) {
        $stem = [IO.Path]::GetFileNameWithoutExtension($name); $i = 2
        while (Test-Path -LiteralPath (Join-Path $full ("$stem ($i).xlsx"))) { $i++ }
        $target = Join-Path $full ("$stem ($i).xlsx")
      }
      try {
        $bytes = [Convert]::FromBase64String([string]$msg.b64)
        $tmp = $target + ".part"; [IO.File]::WriteAllBytes($tmp, $bytes)
        if ($msg.dry) { Remove-Item -LiteralPath $tmp -Force; Reply @{ ok = $true; dry = $true; path = $target; name = [IO.Path]::GetFileName($target); size = $bytes.Length }; break }   # δοκιμή: γράφει & σβήνει ΜΟΝΟ το δικό της προσωρινό
        if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Force }
        Move-Item -LiteralPath $tmp -Destination $target -Force
        Reply @{ ok = $true; path = $target; name = [IO.Path]::GetFileName($target); size = $bytes.Length }
      } catch { Reply @{ ok = $false; err = ("εγγραφή: " + $_.Exception.Message) } }
    }
    "printxlsx" {
      # 🖨 16/11 (χρήστης: «η εκτύπωση να είναι ΑΚΡΙΒΩΣ όπως το Excel μας»): ανοίγει το .xlsx στο ίδιο το Excel (κρυφό, μόνο ανάγνωση) και το τυπώνει
      # με τις ρυθμίσεις σελίδας του αρχείου (οριζόντιο, 80%, Print_Area). Ο προεπιλεγμένος εκτυπωτής των Windows ΔΕΝ αλλάζει.
      $skip = 'zebra|zdesigner|label|ετικ|barcode|godex|tsc|datamax|dymo|brother ql|pdf|xps|onenote|fax|send to|αποστολή'
      $all = @(Get-CimInstance Win32_Printer -ErrorAction SilentlyContinue)
      $ready = { param($p) -not $p.WorkOffline -and @(0,3,4,5).Contains([int]$p.PrinterStatus) -or (-not $p.WorkOffline -and [int]$p.PrinterStatus -eq 2) }
      $want = [string]$msg.printer; $pick = $null
      if ($want) { $pick = $all | Where-Object { $_.Name -eq $want } | Select-Object -First 1 }
      if (-not $pick) { $pick = $all | Where-Object { $_.Default -and $_.Name -notmatch $skip -and (& $ready $_) } | Select-Object -First 1 }
      if (-not $pick) { $pick = $all | Where-Object { $_.Name -notmatch $skip -and (& $ready $_) } | Sort-Object @{ e = { [int](-not $_.Network) } } | Select-Object -First 1 }
      if (-not $pick) { Reply @{ ok = $false; err = "δεν βρέθηκε έτοιμος εκτυπωτής A4" }; break }
      $root = Join-Path $env:TEMP "efbot-print"; New-Item -ItemType Directory -Path $root -Force | Out-Null
      Get-ChildItem -LiteralPath $root -Filter "x-*.xlsx" -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt (Get-Date).AddHours(-2) } | Remove-Item -Force -ErrorAction SilentlyContinue
      $f = Join-Path $root ("x-" + [DateTime]::Now.ToString("yyyyMMddHHmmssfff") + ".xlsx")
      try { [IO.File]::WriteAllBytes($f, [Convert]::FromBase64String([string]$msg.b64)) } catch { Reply @{ ok = $false; err = "προσωρινό αρχείο: " + $_.Exception.Message }; break }
      $xl = $null; $wb = $null
      try { $xl = New-Object -ComObject Excel.Application } catch { Remove-Item -LiteralPath $f -Force -ErrorAction SilentlyContinue; Reply @{ ok = $false; noexcel = $true; err = "δεν υπάρχει Excel σε αυτόν τον υπολογιστή" }; break }
      try {
        $xl.Visible = $false; $xl.DisplayAlerts = $false; $xl.ScreenUpdating = $false
        $wb = $xl.Workbooks.Open($f, 0, $true)
        # 🧫 18/11: κουτάκια καλλιέργειας — νέα στενή στήλη αριστερά από την περιοχή εκτύπωσης, ένα κουτί (περίγραμμα + χρώμα) στη γραμμή κάθε ασθενούς
        $marked = $null; $fit = $false
        $mk = @($msg.marks | Where-Object { $_ -and [int]$_.row -gt 0 })
        if ($mk.Count) {
          $ws = $null; if ([string]$msg.sheet) { try { $ws = $wb.Worksheets.Item([string]$msg.sheet) } catch {} }; if (-not $ws) { $ws = $wb.Worksheets.Item(1) }
          $pa = [string]$ws.PageSetup.PrintArea; $rg = $null; try { if ($pa) { $rg = $ws.Range($pa.Split(',')[0]) } } catch {}; if (-not $rg) { $rg = $ws.UsedRange }
          $r1 = $rg.Row; $c1 = $rg.Column; $r2 = $r1 + $rg.Rows.Count - 1; $c2 = $c1 + $rg.Columns.Count - 1
          $pw0 = 1; try { $pw0 = [int]$ws.VPageBreaks.Count + 1 } catch {}
          [void]$ws.Columns.Item($c1).Insert(-4161, 1); $col = $ws.Columns.Item($c1); [void]$col.Clear(); $col.ColumnWidth = 11
          $colr = @{ ok = 0x4C8A1F; pend = 0x006BB2; pos = 0x2828C6; mut = 0x666666 }
          $marked = 0; $rows = @{}; foreach ($m in $mk) { $rows[[int]$m.row] = 1 }
          foreach ($m in $mk) {
            $rr = [int]$m.row; $c = $ws.Cells.Item($rr, $c1)
            # ο ασθενής πιάνει 2 γραμμές (όνομα + επέμβαση από κάτω) → το κουτί πιάνει και τις δύο, για να χωράει σημείωση/«Μύκητες»
            if ($rr + 1 -le $r2 -and -not $rows.ContainsKey($rr + 1)) { $c = $ws.Range($ws.Cells.Item($rr, $c1), $ws.Cells.Item($rr + 1, $c1)); $c.MergeCells = $true }
            $tx = [string]$m.t; if ([string]$m.note) { $tx += "`n" + [string]$m.note }; if ($m.fun) { $tx += "`nΜύκητες" }
            $c.NumberFormat = "@"; $c.Value2 = $tx; $c.WrapText = $true; $c.HorizontalAlignment = -4108; $c.VerticalAlignment = -4108
            $k = [string]$m.cls; $bgr = $colr[$k]; if ($null -eq $bgr) { $bgr = 0 }
            $c.Font.Bold = $true; $c.Font.Size = 9; $c.Font.Name = "Calibri"; $c.Font.Color = $bgr
            foreach ($e in 7, 8, 9, 10) { $b = $c.Borders.Item($e); $b.LineStyle = 1; $b.Weight = -4138; $b.Color = $bgr }
            $marked++
          }
          $ws.PageSetup.PrintArea = $ws.Range($ws.Cells.Item($r1, $c1), $ws.Cells.Item($r2, $c2 + 1)).Address($true, $true)
          # ίδιο πλάτος σελίδων με πριν (αν η νέα στήλη θα το χαλούσε → «προσαρμογή σε N σελίδες πλάτος», ελάχιστα μικρότερο)
          $pw1 = $pw0; try { $pw1 = [int]$ws.VPageBreaks.Count + 1 } catch {}
          if ($pw1 -gt $pw0) { $ws.PageSetup.Zoom = $false; $ws.PageSetup.FitToPagesWide = $pw0; $ws.PageSetup.FitToPagesTall = $false; $fit = $true }
        }
        # το Excel θέλει «<όνομα> on NeXX:» (ελληνικό Excel: «σε NeXX:») — η θύρα NeXX από το μητρώο (HKCU Devices)
        $ne = ""; try { $v = (Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows NT\CurrentVersion\Devices' -ErrorAction Stop).($pick.Name); if ($v) { $ne = ([string]$v).Split(',')[-1] } } catch {}
        $cands = @($pick.Name); if ($ne) { $cands += @("$($pick.Name) on $ne", "$($pick.Name) σε $ne") }
        $done = $false; $last = ""
        foreach ($ap in $cands) { try { $wb.PrintOut([Type]::Missing, [Type]::Missing, 1, $false, $ap); $done = $true; break } catch { $last = $_.Exception.Message } }
        if (-not $done) { Reply @{ ok = $false; err = "το Excel δεν τύπωσε στον «$($pick.Name)»: $last" } } else { $rep = @{ ok = $true; printer = $pick.Name; via = "excel" }; if ($null -ne $marked) { $rep.marked = $marked; $rep.fit = $fit }; Reply $rep }
      } catch { Reply @{ ok = $false; err = "Excel: " + $_.Exception.Message } }
      finally {
        try { if ($wb) { $wb.Close($false) } } catch {}
        try { if ($xl) { $xl.Quit() } } catch {}
        try { if ($wb) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($wb) }; if ($xl) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($xl) } } catch {}
        [GC]::Collect(); [GC]::WaitForPendingFinalizers()
        Start-Sleep -Milliseconds 300; Remove-Item -LiteralPath $f -Force -ErrorAction SilentlyContinue
      }
    }
    "printhtml" {
      # 🖨 Τυπώνει μία σελίδα (HTML από το ef-bot) στον εκτυπωτή A4, χωρίς παράθυρο: ξεχωριστό, προσωρινό προφίλ Chrome με --kiosk-printing
      # και επιλεγμένο εκτυπωτή. Δεν αλλάζει τον προεπιλεγμένο εκτυπωτή των Windows ούτε άλλη ρύθμιση.
      $skip = 'zebra|zdesigner|label|ετικ|barcode|godex|tsc|datamax|dymo|brother ql|pdf|xps|onenote|fax|send to|αποστολή'
      $all = @(Get-CimInstance Win32_Printer -ErrorAction SilentlyContinue)
      $ready = { param($p) -not $p.WorkOffline -and @(0,3,4,5).Contains([int]$p.PrinterStatus) -or (-not $p.WorkOffline -and [int]$p.PrinterStatus -eq 2) }
      $want = [string]$msg.printer; $pick = $null
      if ($want) { $pick = $all | Where-Object { $_.Name -eq $want } | Select-Object -First 1 }
      if (-not $pick) { $pick = $all | Where-Object { $_.Default -and $_.Name -notmatch $skip -and (& $ready $_) } | Select-Object -First 1 }
      if (-not $pick) { $pick = $all | Where-Object { $_.Name -notmatch $skip -and (& $ready $_) } | Sort-Object @{ e = { [int](-not $_.Network) } } | Select-Object -First 1 }
      if (-not $pick) { Reply @{ ok = $false; err = "δεν βρέθηκε έτοιμος εκτυπωτής A4"; printers = @($all | ForEach-Object { $_.Name }) }; break }
      $chrome = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe") | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
      if (-not $chrome) { Reply @{ ok = $false; err = "δεν βρέθηκε το chrome.exe" }; break }
      $root = Join-Path $env:TEMP "efbot-print"; $prof = Join-Path $root "profile"; New-Item -ItemType Directory -Path (Join-Path $prof "Default") -Force | Out-Null
      Get-ChildItem -LiteralPath $root -Filter "p-*.html" -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt (Get-Date).AddHours(-2) } | Remove-Item -Force -ErrorAction SilentlyContinue
      $app = @{ version = 2; recentDestinations = @(@{ id = $pick.Name; origin = "local"; account = "" }); selectedDestinationId = $pick.Name; mediaSize = @{ height_microns = 297000; width_microns = 210000; name = "ISO_A4"; custom_display_name = "A4" }; isHeaderFooterEnabled = $false; isCssBackgroundEnabled = $true; scaling = "100"; scalingType = 0 }
      $pref = @{ printing = @{ print_preview_sticky_settings = @{ appState = ($app | ConvertTo-Json -Compress -Depth 5) } } }
      [IO.File]::WriteAllText((Join-Path $prof "Default\Preferences"), ($pref | ConvertTo-Json -Compress -Depth 6), (New-Object Text.UTF8Encoding $false))
      $f = Join-Path $root ("p-" + [DateTime]::Now.ToString("yyyyMMddHHmmssfff") + ".html")
      $html = [string]$msg.html + '<script>window.addEventListener("load",function(){setTimeout(function(){window.print();setTimeout(function(){window.close()},4000)},600)})</script>'
      [IO.File]::WriteAllText($f, $html, (New-Object Text.UTF8Encoding $false))
      $args2 = @("--user-data-dir=`"$prof`"", "--kiosk-printing", "--no-first-run", "--no-default-browser-check", "--disable-extensions", "--new-window", "--window-position=-2400,-2400", "`"file:///$($f -replace '\\','/')`"")
      # ανεξάρτητη διεργασία (όπως το «update»): δεν κλείνει όταν τελειώσει το βοηθητικό
      $cl = "`"$chrome`" " + ($args2 -join " ")
      # 🖨 18/11 07:17 (χρήστης: «πάτησα εκτύπωση και δεν εκτυπώθηκε» — «ΔΕΝ εμφανίστηκε στην ουρά»): το Chrome --kiosk-printing ΑΓΝΟΟΥΣΕ τον επιλεγμένο
      # εκτυπωτή (sticky settings) → τύπωνε στον προεπιλεγμένο/PDF. Τώρα: για λίγα δευτερόλεπτα ο επιλεγμένος γίνεται προεπιλεγμένος των Windows
      # και ΕΠΑΝΑΦΕΡΕΤΑΙ μόλις μπει η εργασία στην ουρά (ή σε 20″)
      $prevDef = $null; try { $prevDef = ($all | Where-Object { $_.Default } | Select-Object -First 1) } catch {}
      $swapped = $false
      if (-not $prevDef -or $prevDef.Name -ne $pick.Name) { try { $r0 = Invoke-CimMethod -InputObject $pick -MethodName SetDefaultPrinter -ErrorAction Stop; $swapped = ($r0.ReturnValue -eq 0) } catch {} }
      $cr = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = $cl; CurrentDirectory = $root }
      if ($cr.ReturnValue -ne 0) { if ($swapped -and $prevDef) { try { Invoke-CimMethod -InputObject $prevDef -MethodName SetDefaultPrinter | Out-Null } catch {} }; Reply @{ ok = $false; err = "δεν ξεκίνησε η εκτύπωση (κωδικός $($cr.ReturnValue))" }; break }
      # 🖨 17/11 (χρήστης: «δεν βγαίνει χαρτί στον Μεσαίο» ενώ έλεγε «Τυπώθηκε»): έλεγχος ότι η εργασία ΕΜΦΑΝΙΣΤΗΚΕ στην ουρά του εκτυπωτή (έως 15″)
      $seen = $null; $pst = ""; $printed0 = 0
      try { $printed0 = [int](Get-CimInstance Win32_Printer -Filter ("Name='" + ($pick.Name -replace "'", "''") + "'") -ErrorAction SilentlyContinue).JobCountSinceLastReset } catch {}
      for ($k = 0; $k -lt 30 -and -not $seen; $k++) { Start-Sleep -Milliseconds 500
        $seen = @(Get-PrintJob -PrinterName $pick.Name -ErrorAction SilentlyContinue | Where-Object { ([string]$_.DocumentName) -match 'p-\d+|ef-bot|Πρόγραμμα|html' -or $_.SubmittedTime -gt (Get-Date).AddSeconds(-20) } | Select-Object -First 1)[0] }
      # 2η προσπάθεια (μία) αν δεν μπήκε στην ουρά — ο επιλεγμένος είναι ήδη προεπιλεγμένος
      $retry = $false
      if (-not $seen) { $retry = $true; $f2 = Join-Path $root ("p-" + [DateTime]::Now.ToString("yyyyMMddHHmmssfff") + ".html"); [IO.File]::WriteAllText($f2, $html, (New-Object Text.UTF8Encoding $false))
        $u1 = ($f -replace '\\','/'); $u2 = ($f2 -replace '\\','/'); $cl2 = $cl.Replace($u1, $u2); Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = $cl2; CurrentDirectory = $root } | Out-Null
        for ($k = 0; $k -lt 30 -and -not $seen; $k++) { Start-Sleep -Milliseconds 500; $seen = @(Get-PrintJob -PrinterName $pick.Name -ErrorAction SilentlyContinue | Where-Object { $_.SubmittedTime -gt (Get-Date).AddSeconds(-40) }) | Select-Object -First 1 } }
      if ($swapped -and $prevDef) { Start-Sleep -Seconds 2; try { Invoke-CimMethod -InputObject $prevDef -MethodName SetDefaultPrinter | Out-Null } catch {} }
      $q = @(Get-PrintJob -PrinterName $pick.Name -ErrorAction SilentlyContinue | Select-Object -First 8 | ForEach-Object { @{ st = [string]$_.JobStatus; at = [string]$_.SubmittedTime; pages = [int]$_.TotalPages } })
      try { $pst = [string](Get-Printer -Name $pick.Name -ErrorAction SilentlyContinue).PrinterStatus } catch {}
      Reply @{ ok = $true; printer = $pick.Name; queued = [bool]$seen; swapped = $swapped; retry = $retry; jobSt = $(if ($seen) { [string]$seen.JobStatus } else { "" }); pst = $pst; queue = $q; port = [string]$pick.PortName }
    }
    "ctlog" {
      try {
      # ΜΟΝΟ ανάγνωση: τελευταίες γραμμές του «Άνοιγμα με Νίκος CT Viewer» + τι είναι γραμμένο στο δεξί κλικ
      $lf = Join-Path $env:LOCALAPPDATA "ef-bot\nikosct\log.txt"; $t = @(); if (Test-Path -LiteralPath $lf) { $t = @(Get-Content -LiteralPath $lf -Tail 15 -Encoding UTF8) }
      $cmd = ""; try { $cmd = (Get-ItemProperty -Path "HKCU:\Software\Classes\Directory\shell\NikosCT\command" -ErrorAction Stop)."(default)" } catch {}
      $lnk = @(Get-ChildItem -LiteralPath "$env:APPDATA\Microsoft\Windows\Start Menu\Programs" -Recurse -Filter "*.lnk" -ErrorAction SilentlyContinue | Where-Object { $_.BaseName -match 'Νίκος CT|Nikos CT|Αξονικ' } | ForEach-Object { $_.Name })
      # 8/11: εγκατεστημένη έκδοση εφαρμογής + αν τρέχει + τελευταίες γραμμές του προγράμματος ενημέρωσης για το CT Viewer
      $vf = Join-Path $env:LOCALAPPDATA "NikosCTViewer\version.txt"; $ver = ""; if (Test-Path -LiteralPath $vf) { $ver = (Get-Content -LiteralPath $vf -Raw).Trim() }
      $exeOk = Test-Path -LiteralPath (Join-Path $env:LOCALAPPDATA "NikosCTViewer\app\NikosCTViewer.exe")
      $run = [bool](Get-Process -Name "NikosCTViewer" -ErrorAction SilentlyContinue)
      $ul = Join-Path $env:LOCALAPPDATA "ef-bot\update-log.txt"; $up = @(); if (Test-Path -LiteralPath $ul) { $up = @(Get-Content -LiteralPath $ul -Tail 200 -Encoding UTF8 | Where-Object { $_ -match 'CT Viewer' } | Select-Object -Last 8) }
      Reply @{ ok = $true; log = $t; cmd = $cmd; lnk = $lnk; ver = $ver; exe = $exeOk; running = $run; upd = $up }
          } catch { Reply @{ ok = $false; err = ("ctlog: " + $_.Exception.Message) } }
    }
    "ctupdate" {
      # 🩻 8/11: σήμα στο πρόγραμμα ενημέρωσης «έλεγξε ΤΩΡΑ για νέα έκδοση του Νίκος CT Viewer» (μέσα σε ~1′)
      try { $d = Join-Path $env:LOCALAPPDATA "NikosCTViewer"; New-Item -ItemType Directory -Path $d -Force | Out-Null; Set-Content -LiteralPath (Join-Path $d "update-now") -Value (Get-Date).ToString("o") -Encoding ASCII
        $run = [bool](Get-Process -Name "NikosCTViewer" -ErrorAction SilentlyContinue); Reply @{ ok = $true; running = $run } } catch { Reply @{ ok = $false; err = $_.Exception.Message } }
    }
    "ctopen" {
      # 🖥 8/11: άνοιγμα του Νίκος CT Viewer σε αυτόν τον υπολογιστή (τηλεχειρισμός από το κινητό) — μόνο γράμματα/αριθμοί στα ορίσματα
      try {
        $exe = Join-Path $env:LOCALAPPDATA "NikosCTViewer\app\NikosCTViewer.exe"
        if (-not (Test-Path -LiteralPath $exe)) { Reply @{ ok = $false; err = "δεν είναι εγκατεστημένο το Νίκος CT Viewer" }; break }
        $a = @()
        foreach ($k in @("examid", "sur", "fn", "amka")) { $v = ([string]$msg.$k) -replace '[^\p{L}\p{Nd} .\-]', ''; if ($v.Length -gt 60) { $v = $v.Substring(0, 60) }; if ($v) { $a += ('"--evo-' + $k + '=' + $v + '"') } }
        # η σύνδεση Evorad του bot → αρχείο ΜΟΝΟ για τον χρήστη (το διαβάζει και το σβήνει αμέσως η εφαρμογή)
        try { if ($msg.cookies) { $cf = Join-Path $env:LOCALAPPDATA "NikosCTViewer\evo-cookies.json"; ($msg.cookies | ConvertTo-Json -Depth 4 -Compress) | Set-Content -LiteralPath $cf -Encoding UTF8 } } catch {}
        $cl = '"' + $exe + '" ' + ($a -join " ")
        $cr = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = $cl; CurrentDirectory = (Split-Path $exe) }
        if ($cr.ReturnValue -ne 0) { Reply @{ ok = $false; err = "κωδικός " + $cr.ReturnValue }; break }
        # 🔝 9/11 (χρήστης: «να βάζει την αξονική στο προσκήνιο, όχι απλά να ανοίγει παράθυρο»): Alt + ShowWindow + SetForegroundWindow
        $fg = "όχι"
        try {
          Add-Type -Namespace PdxFg -Name W -ErrorAction SilentlyContinue -MemberDefinition '[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h); [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c); [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h); [DllImport("user32.dll")] public static extern void keybd_event(byte k, byte s, uint f, UIntPtr e); [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);'
          for ($i = 0; $i -lt 32 -and $fg -eq "όχι"; $i++) {
            $w = Get-Process -Name "NikosCTViewer" -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 -and $_.MainWindowTitle -notmatch "Αρχείο Ασθενών" } | Select-Object -First 1
            if ($w) { $h = $w.MainWindowHandle
              [PdxFg.W]::keybd_event(0x12, 0, 0, [UIntPtr]::Zero); [PdxFg.W]::keybd_event(0x12, 0, 2, [UIntPtr]::Zero)
              if ([PdxFg.W]::IsIconic($h)) { [void][PdxFg.W]::ShowWindow($h, 9) } else { [void][PdxFg.W]::ShowWindow($h, 5) }
              [void][PdxFg.W]::BringWindowToTop($h); if ([PdxFg.W]::SetForegroundWindow($h)) { $fg = "ναι" } else { $fg = "όχι (Windows)"; break } }
            else { Start-Sleep -Milliseconds 250 }
          }
        } catch { $fg = "σφάλμα" }
        Reply @{ ok = $true; fg = $fg }
      } catch { Reply @{ ok = $false; err = $_.Exception.Message } }
    }
    "ctinstall" {
      # 🩻 8/11: εγκατάσταση/επισκευή Νίκος CT Viewer ΑΠΕΥΘΕΙΑΣ (με αναφορά βημάτων) — ίδια διαδικασία με τον updater
      $st = New-Object System.Collections.ArrayList
      try {
        $db = "https://paradoxarto.urol.workers.dev/desktop"
        $info = Invoke-RestMethod -Uri ("$db/version.json?t=" + [DateTimeOffset]::Now.ToUnixTimeSeconds()) -UseBasicParsing -TimeoutSec 30
        [void]$st.Add("διαθέσιμη " + $info.version)
        $root = Join-Path $env:LOCALAPPDATA "NikosCTViewer"; $app = Join-Path $root "app"; $vf = Join-Path $root "version.txt"; $exe = Join-Path $app "NikosCTViewer.exe"
        $have = ""; if (Test-Path -LiteralPath $vf) { $have = [string](Get-Content -LiteralPath $vf -Raw); $have = $have.Trim() }
        [void]$st.Add("εγκατεστημένη «" + $have + "» · exe " + $(if (Test-Path -LiteralPath $exe) { "ναι" } else { "ΟΧΙ" }))
        $pr = @(Get-Process -Name "NikosCTViewer" -ErrorAction SilentlyContinue)
        if ($pr.Count) {
          if ($msg.force) { $pr | Stop-Process -Force -ErrorAction SilentlyContinue; Start-Sleep -Seconds 2; [void]$st.Add("έκλεισε η ανοιχτή εφαρμογή") }
          else { Reply @{ ok = $false; err = "η εφαρμογή είναι ανοιχτή — κλείσ' την και ξαναδοκίμασε"; steps = @($st) }; break }
        }
        $tmp = Join-Path $env:TEMP ("nctapp-" + [guid]::NewGuid().ToString("N")); New-Item -ItemType Directory -Path $tmp -Force | Out-Null
        try {
          $zip = Join-Path $tmp "app.zip"; $out = [IO.File]::Create($zip); $t0 = Get-Date
          try { foreach ($pt in $info.parts) { $pf = Join-Path $tmp "part"; Invoke-WebRequest -Uri "$db/$pt" -OutFile $pf -UseBasicParsing -TimeoutSec 300; $bb = [IO.File]::ReadAllBytes($pf); $out.Write($bb, 0, $bb.Length) } } finally { $out.Close() }
          [void]$st.Add(("κατέβηκε σε {0:N0}″" -f ((Get-Date) - $t0).TotalSeconds))
          $h = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLower(); if ($h -ne ([string]$info.sha256).ToLower()) { throw "λάθος sha256" }
          $new = Join-Path $tmp "x"; Add-Type -AssemblyName System.IO.Compression.FileSystem; [IO.Compression.ZipFile]::ExtractToDirectory($zip, $new)
          if (-not (Test-Path -LiteralPath (Join-Path $new "NikosCTViewer.exe"))) { $sub = Get-ChildItem -LiteralPath $new -Recurse -Filter "NikosCTViewer.exe" | Select-Object -First 1; if (-not $sub) { throw "δεν υπάρχει exe στο πακέτο" }; $new = $sub.DirectoryName }
          [void]$st.Add("αποσυμπιέστηκε")
          New-Item -ItemType Directory -Path $root -Force | Out-Null
          if (Test-Path -LiteralPath $app) { try { Remove-Item -LiteralPath $app -Recurse -Force -ErrorAction Stop } catch { $old = Join-Path $root ("app-old-" + (Get-Date).Ticks); Rename-Item -LiteralPath $app -NewName (Split-Path $old -Leaf) -ErrorAction Stop; [void]$st.Add("ο παλιός φάκελος κλείδωνε → μετονομάστηκε") } }
          Move-Item -LiteralPath $new -Destination $app
          Set-Content -LiteralPath $vf -Value ([string]$info.version) -Encoding ASCII
          [void]$st.Add("εγκαταστάθηκε " + $info.version)
        } finally { Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue }
        # συντομεύσεις: ΠΑΝΤΑ προς το σωστό exe (και όποια παλιά «Νίκος CT» δείχνει αλλού)
        $ws = New-Object -ComObject WScript.Shell; $fixed = 0
        $dirs = @([Environment]::GetFolderPath("Programs"), [Environment]::GetFolderPath("Desktop"), [Environment]::GetFolderPath("CommonDesktopDirectory"))
        foreach ($d in $dirs) { foreach ($f in @(Get-ChildItem -LiteralPath $d -Filter "*.lnk" -ErrorAction SilentlyContinue | Where-Object { $_.BaseName -match 'Νίκος CT|Nikos ?CT' })) { try { $sc = $ws.CreateShortcut($f.FullName); if ($sc.TargetPath -ne $exe) { $sc.TargetPath = $exe; $sc.WorkingDirectory = $app; $sc.IconLocation = "$exe,0"; $sc.Save(); $fixed++ } } catch {} } }
        foreach ($lp in @((Join-Path ([Environment]::GetFolderPath("Programs")) "Νίκος CT Viewer.lnk"), (Join-Path ([Environment]::GetFolderPath("Desktop")) "Νίκος CT Viewer.lnk"))) { if (-not (Test-Path -LiteralPath $lp)) { $sc = $ws.CreateShortcut($lp); $sc.TargetPath = $exe; $sc.WorkingDirectory = $app; $sc.IconLocation = "$exe,0"; $sc.Save(); $fixed++ } }
        foreach ($k in @("HKCU:\Software\Classes\Directory\shell\NikosCT", "HKCU:\Software\Classes\Drive\shell\NikosCT")) { New-Item -Path "$k\command" -Force | Out-Null; Set-ItemProperty -Path "$k\command" -Name "(default)" -Value ('"' + $exe + '" "%1"') }
        [void]$st.Add("συντομεύσεις διορθώθηκαν: " + $fixed)
        Reply @{ ok = $true; steps = @($st) }
      } catch { Reply @{ ok = $false; err = $_.Exception.Message; steps = @($st) } }
    }
    { @("dbinstall", "dbcall", "dbshortcut", "dbkey") -contains $_ } {
      # 🗂 8/11: «Αρχείο Ασθενών» — σε χωριστό αρχείο (efbot-db.ps1, δίπλα στο efbot-update.bat της επέκτασης)
      $dbs = Join-Path (Split-Path -Parent ([IO.File]::ReadAllText((Join-Path $PSScriptRoot "updater-path.txt")).Trim())) "efbot-db.ps1"
      $r = @(& $dbs -Msg $msg); Reply $r[-1]
    }
    "printclear" {
      # 🖨 Καθαρίζει κολλημένες εκτυπώσεις (μόνο του τρέχοντος χρήστη — οι ξένες θέλουν διαχειριστή και απλώς μετριούνται)
      $want = [string]$msg.printer; $ok = 0; $fail = 0
      foreach ($j in @(Get-CimInstance Win32_PrintJob -ErrorAction SilentlyContinue)) {
        if ($want -and ($j.Name -split ',')[0] -ne $want) { continue }
        try { Remove-CimInstance -InputObject $j -ErrorAction Stop; $ok++ } catch { $fail++ }
      }
      Reply @{ ok = $true; removed = $ok; failed = $fail }
    }
    "mailbm"    {
      # 8/11 ΜΟΝΟ ανάγνωση: bookmarks του Chrome (όλα τα προφίλ) → ΜΟΝΟ διευθύνσεις που μοιάζουν με webmail/Kerio (όνομα + διεύθυνση, τίποτα άλλο)
      $out = New-Object System.Collections.ArrayList
      $ud = Join-Path $env:LOCALAPPDATA "Google\Chrome\User Data"
      foreach ($bf in @(Get-ChildItem -LiteralPath $ud -Directory -ErrorAction SilentlyContinue | ForEach-Object { Join-Path $_.FullName "Bookmarks" } | Where-Object { Test-Path -LiteralPath $_ })) {
        try { $j = Get-Content -LiteralPath $bf -Raw -Encoding UTF8 | ConvertFrom-Json } catch { continue }
        $st = New-Object System.Collections.Stack; foreach ($k in @("bookmark_bar", "other", "synced")) { if ($j.roots.$k) { $st.Push($j.roots.$k) } }
        while ($st.Count -gt 0) { $n = $st.Pop(); if ($n.children) { foreach ($c in $n.children) { $st.Push($c) } }
          if ($n.type -eq "url" -and (([string]$n.url) -match 'kerio|webmail|/mail' -or ([string]$n.name) -match 'kerio|mail|webmail|αλληλογραφ')) { [void]$out.Add(@{ name = ([string]$n.name).Substring(0, [Math]::Min(40, ([string]$n.name).Length)); url = ([string]$n.url -replace '\?.*$', '') }) } }
      }
      Reply @{ ok = $true; items = @($out) }
    }
    "drives"    {
      # 8/11 ΜΟΝΟ ανάγνωση: όλοι οι δίσκοι + οδηγοί CD/DVD + συσκευές USB αποθήκευσης (γιατί «δεν βλέπει το CD»)
      $dv = @(foreach ($d in [IO.DriveInfo]::GetDrives()) { $o = @{ n = $d.Name; t = [string]$d.DriveType; ready = $d.IsReady }; if ($d.IsReady) { $o.label = $d.VolumeLabel; $o.fs = $d.DriveFormat; $o.gb = [math]::Round($d.TotalSize / 1GB, 2) }; $o })
      $cd = @(Get-CimInstance Win32_CDROMDrive -ErrorAction SilentlyContinue | ForEach-Object { @{ drive = $_.Drive; name = $_.Name; media = $_.MediaLoaded; status = $_.Status; type = $_.MediaType; avail = $_.Availability } })
      $ld = @(Get-CimInstance Win32_LogicalDisk -ErrorAction SilentlyContinue | ForEach-Object { @{ id = $_.DeviceID; type = $_.DriveType; vol = $_.VolumeName; size = $_.Size } })
      $pnp = @(Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue | Where-Object { $_.PNPClass -in @('CDROM','DiskDrive') -or $_.Name -match 'DVD|CD-ROM|CDROM|Optical' } | ForEach-Object { @{ name = $_.Name; cls = $_.PNPClass; st = $_.Status; err = $_.ConfigManagerErrorCode } })
      $root = $null; try { $root = @(Get-ChildItem -LiteralPath 'D:\' -ErrorAction Stop | Select-Object -First 8 | ForEach-Object { $_.Name }) } catch { $root = 'err: ' + $_.Exception.Message }
      # 8/11: δίσκοι δικτύου → διαδρομή UNC (για τη νυχτερινή αντιγραφή απεικονιστικών) + προαιρετικός έλεγχος πρόσβασης (μόνο ανάγνωση)
      $net = @(Get-CimInstance Win32_LogicalDisk -Filter "DriveType=4" -ErrorAction SilentlyContinue | ForEach-Object { @{ id = $_.DeviceID; unc = $_.ProviderName; vol = $_.VolumeName; freeGb = [math]::Round($_.FreeSpace / 1GB, 1) } })
      $pr = $null; if ($msg.probe) { $pp = [string]$msg.probe; $pr = @{ path = $pp }; try { $pr.exists = Test-Path -LiteralPath $pp -ErrorAction Stop; if ($pr.exists) { $pr.top = @(Get-ChildItem -LiteralPath $pp -Directory -ErrorAction Stop | Select-Object -First 15 | ForEach-Object { $_.Name }) } } catch { $pr.err = $_.Exception.Message } }
      Reply @{ ok = $true; drives = $dv; cdrom = $cd; logical = $ld; pnp = $pnp; dRoot = $root; net = $net; probe = $pr }
    }
    "fsreset"   {
      # 8/11: κλείνει ΟΛΑ τα βοηθητικά αρχείων (efbot-files.ps1) — στο Παράθυρο είχαν μείνει 82 αδρανή. Το bot ανοίγει νέο όταν χρειαστεί.
      $n = 0; foreach ($q in @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.Name -eq 'powershell.exe' -and ([string]$_.CommandLine) -match 'efbot-files\.ps1' })) { try { Stop-Process -Id $q.ProcessId -Force -ErrorAction Stop; $n++ } catch {} }
      Reply @{ ok = $true; killed = $n }
    }
    "sysinfo"   {
      # ΜΟΝΟ ανάγνωση: φόρτος του υπολογιστή (για διάγνωση «κολλάει»)
      $os = Get-CimInstance Win32_OperatingSystem; $cpu = (Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average
      $P = @(Get-Process -ErrorAction SilentlyContinue)
      $grp = { param($n) $x = @($P | Where-Object { $_.ProcessName -eq $n }); @{ n = $x.Count; mb = [int](($x | Measure-Object WorkingSet64 -Sum).Sum / 1MB); cpu = [int](($x | Measure-Object CPU -Sum).Sum) } }
      $top = @($P | Sort-Object WorkingSet64 -Descending | Select-Object -First 8 | ForEach-Object { @{ p = $_.ProcessName; mb = [int]($_.WorkingSet64 / 1MB); cpu = [int]$_.CPU } })
      $dk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'" -ErrorAction SilentlyContinue
      # 8/11: ΠΟΙΑ powershell τρέχουν (ομαδοποίηση ανά script/εντολή, χωρίς διαδρομές χρήστη) — για τα 85 στο Παράθυρο
      $psk = @{}; foreach ($q in @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.Name -eq 'powershell.exe' })) {
        $c = [string]$q.CommandLine; $k = if (-not $c) { '(άγνωστο)' } elseif ($c -match '([\w\-]+\.ps1)') { $Matches[1] } elseif ($c -match 'PDXCDWATCH') { 'pdx-cd' } elseif ($c -match 'DriveType=5') { 'pdx-cd-old' } else { ($c -replace '^.*?-Command\s*', '').Substring(0, [Math]::Min(40, ($c -replace '^.*?-Command\s*', '').Length)) }
        if ($psk.ContainsKey($k)) { $psk[$k]++ } else { $psk[$k] = 1 } }
      # 8/11: «ανοιχτός» = από το τελευταίο ΑΝΟΙΓΜΑ (εκκίνηση, γρήγορη εκκίνηση, ξύπνημα από αναστολή) — όχι από το LastBootUpTime
      # (με τη «Γρήγορη εκκίνηση» των Windows το κλείσιμο δεν μηδενίζει το LastBootUpTime → έδειχνε 39 ώρες αντί για 30)
      $on = $os.LastBootUpTime
      try { $ev = Get-WinEvent -FilterHashtable @{ LogName = 'System'; Id = @(1, 12, 27, 107); StartTime = (Get-Date).AddDays(-30) } -MaxEvents 40 -ErrorAction Stop | Where-Object { ($_.Id -eq 12 -and $_.ProviderName -eq 'Microsoft-Windows-Kernel-General') -or ($_.Id -eq 27 -and $_.ProviderName -eq 'Microsoft-Windows-Kernel-Boot') -or ($_.Id -eq 1 -and $_.ProviderName -eq 'Microsoft-Windows-Power-Troubleshooter') -or ($_.Id -eq 107 -and $_.ProviderName -eq 'Microsoft-Windows-Kernel-Power') } | Select-Object -First 1; if ($ev -and $ev.TimeCreated -gt $on) { $on = $ev.TimeCreated } } catch {}
      $rb = (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired") -or (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending")
      Reply @{ ok = $true; reboot = [bool]$rb; diskFreeGb = $(if ($dk) { [int]($dk.FreeSpace / 1GB) } else { -1 }); diskGb = $(if ($dk) { [int]($dk.Size / 1GB) } else { 0 }); cpu = [int]$cpu; ramMb = [int]($os.TotalVisibleMemorySize / 1024); freeMb = [int]($os.FreePhysicalMemory / 1024); upH = [int](((Get-Date) - $on).TotalHours); bootH = [int](((Get-Date) - $os.LastBootUpTime).TotalHours); psKinds = $psk; chrome = (& $grp "chrome"); ps = (& $grp "powershell"); top = $top; cores = [Environment]::ProcessorCount; ext = $(if ($msg.ext) { SysExtra } else { $null }) }
    }
    default     { Reply @{ ok = $false; err = "unknown op" } }
  }
} catch {
  try { Reply @{ ok = $false; err = $_.Exception.Message } } catch {}
}
exit 0
