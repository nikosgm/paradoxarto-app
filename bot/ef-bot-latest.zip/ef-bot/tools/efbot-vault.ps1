﻿# ef-bot vault helper (Chrome native messaging host "gr.efbot.vault")
# Protects/unprotects a small key with Windows DPAPI (CurrentUser scope). Nothing is stored here.
# Protocol: 4-byte little-endian length + UTF-8 JSON, one request per launch.
$ErrorActionPreference = "Stop"
$stdin  = [Console]::OpenStandardInput()
$stdout = [Console]::OpenStandardOutput()
function ReadN([int]$n) {
  $b = New-Object byte[] $n; $o = 0
  while ($o -lt $n) { $r = $stdin.Read($b, $o, $n - $o); if ($r -le 0) { exit 0 }; $o += $r }
  return ,$b
}
function Reply($obj) {
  $j = [Text.Encoding]::UTF8.GetBytes(($obj | ConvertTo-Json -Compress -Depth 6))
  $stdout.Write([BitConverter]::GetBytes([int]$j.Length), 0, 4)
  $stdout.Write($j, 0, $j.Length)
  $stdout.Flush()
}
try {
  $len = [BitConverter]::ToInt32((ReadN 4), 0)
  if ($len -le 0 -or $len -gt 33554432) { Reply @{ ok = $false; err = "bad length" }; exit 0 }
  $msg = [Text.Encoding]::UTF8.GetString((ReadN $len)) | ConvertFrom-Json
  Add-Type -AssemblyName System.Security
  $ent = [Text.Encoding]::UTF8.GetBytes("ef-bot-vault-v1")
  $scope = [Security.Cryptography.DataProtectionScope]::CurrentUser
  # 7/11: έξτρα έλεγχοι (ΜΟΝΟ ανάγνωση): ουρές εκτυπωτών, Defender, αυτόματη είσοδος Windows, ενημερώσεις
  function SysExtra {
    $x = @{}
    try { $jobs = @(Get-CimInstance Win32_PrintJob -ErrorAction SilentlyContinue)
      $x.pq = @(Get-CimInstance Win32_Printer -ErrorAction SilentlyContinue | Where-Object { $_.Name -notmatch 'pdf|xps|onenote|fax|send to|αποστολή' } | ForEach-Object { $n = $_.Name; $j = @($jobs | Where-Object { ($_.Name -split ',')[0] -eq $n })
        @{ name = $n; def = [bool]$_.Default; off = [bool]$_.WorkOffline; st = [int]$_.PrinterStatus; err = [int]$_.DetectedErrorState; jobs = $j.Count; old = @($j | Where-Object { $_.TimeSubmitted -and ((Get-Date) - $_.TimeSubmitted).TotalMinutes -gt 10 }).Count; jerr = @($j | Where-Object { [string]$_.JobStatus -match 'rror|σφάλ|Paused|Offline|Blocked' }).Count } }) } catch {}
    try { $m = Get-MpComputerStatus -ErrorAction Stop; $x.def = @{ on = [bool]$m.AntivirusEnabled; rt = [bool]$m.RealTimeProtectionEnabled; sigD = [int]$m.AntivirusSignatureAge; scanD = [int]$m.QuickScanAge; thr = @(Get-MpThreatDetection -ErrorAction SilentlyContinue | Where-Object { $_.InitialDetectionTime -gt (Get-Date).AddDays(-7) }).Count } } catch { $x.def = @{ err = "όχι πρόσβαση" } }
    try { $w = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -ErrorAction Stop; $x.autologon = ([string]$w.AutoAdminLogon -eq "1") } catch {}
    try { $x.wuDays = [int]((Get-Date) - (Get-HotFix -ErrorAction Stop | Where-Object { $_.InstalledOn } | Sort-Object InstalledOn -Descending | Select-Object -First 1).InstalledOn).TotalDays } catch {}
    return $x
  }
  switch ([string]$msg.op) {
    "ping"      { Reply @{ ok = $true; v = 1; user = [Environment]::UserName } }
    "protect"   { $d = [Convert]::FromBase64String([string]$msg.data); Reply @{ ok = $true; data = [Convert]::ToBase64String([Security.Cryptography.ProtectedData]::Protect($d, $ent, $scope)) } }
    "unprotect" { $d = [Convert]::FromBase64String([string]$msg.data); Reply @{ ok = $true; data = [Convert]::ToBase64String([Security.Cryptography.ProtectedData]::Unprotect($d, $ent, $scope)) } }
    "update"    {
      # ξαναξεκινά το πρόγραμμα αυτόματων ενημερώσεων του ef-bot, ΜΟΝΟ αν δεν τρέχει ήδη (καμία άλλη εντολή δεν εκτελείται)
      $pf = Join-Path $PSScriptRoot "updater-path.txt"
      if (-not (Test-Path -LiteralPath $pf)) { Reply @{ ok = $false; err = "δεν είναι γνωστός ο φάκελος του ef-bot (τρέξτε μία φορά το efbot-update.bat)" }; break }
      $bat = ([IO.File]::ReadAllText($pf)).Trim()
      if (-not ($bat -match 'efbot-update\.bat$') -or -not (Test-Path -LiteralPath $bat)) { Reply @{ ok = $false; err = "λάθος διαδρομή προγράμματος ενημέρωσης" }; break }
      $run = @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -match 'efbot-update\.ps1' }).Count
      if ($run -gt 0) { Reply @{ ok = $true; already = $true }; break }
      # 7/11: αόρατα (wscript → powershell χωρίς κονσόλα) — τίποτα στη γραμμή εργασιών
      $ps1 = Join-Path (Split-Path -Parent $bat) "efbot-update.ps1"; $cl = "cmd.exe /c start `"ef-bot`" /min `"$bat`""
      if (Test-Path -LiteralPath $ps1) { $vbs = Join-Path (Split-Path -Parent $bat) "efbot-update-hidden.vbs"
        Set-Content -LiteralPath $vbs -Encoding ASCII -Value ('CreateObject("WScript.Shell").Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""' + $ps1 + '"" hidden", 0, False')
        $cl = "wscript.exe `"$vbs`"" }
      $r = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = $cl; CurrentDirectory = $env:TEMP }
      if ($r.ReturnValue -ne 0) { Reply @{ ok = $false; err = "δεν ξεκίνησε (κωδικός $($r.ReturnValue))" }; break }
      Reply @{ ok = $true; started = $true }
    }
    { $_ -eq "hidewin" -or $_ -eq "showwin" } {
      # Κρύβει/δείχνει τα παράθυρα του bot (τίτλος με σήμανση) — ούτε στη γραμμή εργασιών. Μόνο παράθυρα του chrome.exe.
      Add-Type -TypeDefinition @"
using System; using System.Text; using System.Collections.Generic; using System.Runtime.InteropServices;
public static class EfWin {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc f, IntPtr l);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  public static List<long> Find(string m) { var r = new List<long>(); EnumWindows(delegate (IntPtr h, IntPtr l) { var sb = new StringBuilder(512); GetWindowText(h, sb, 512); if (sb.ToString().Contains(m)) r.Add(h.ToInt64()); return true; }, IntPtr.Zero); return r; }
}
"@
      $hs = @()
      if ($msg.h) { $hs = @($msg.h | ForEach-Object { [long]$_ }) }
      elseif (([string]$msg.marker).Length -ge 6) { $hs = @([EfWin]::Find([string]$msg.marker)) }
      $done = @()
      foreach ($h in $hs) {
        $pid0 = [uint32]0; [EfWin]::GetWindowThreadProcessId([IntPtr]$h, [ref]$pid0) | Out-Null
        $pn = (Get-Process -Id $pid0 -ErrorAction SilentlyContinue).ProcessName
        if ($pn -ne "chrome") { continue }
        [EfWin]::ShowWindow([IntPtr]$h, $(if ([string]$msg.op -eq "hidewin") { 0 } else { 6 })) | Out-Null
        $done += $h
      }
      Reply @{ ok = $true; n = $done.Count; h = $done }
    }
    "reboot"    {
      # ♻ Επανεκκίνηση Windows με 2′ προειδοποίηση στην οθόνη (ακυρώνεται με «rebootcancel» ή shutdown /a). Μόνο κατόπιν εντολής από το Κέντρο ελέγχου.
      $sec = [Math]::Max(60, [Math]::Min(600, [int]$msg.sec))
      $o = & shutdown.exe /r /t $sec /c "Παραδόχαρτο: επανεκκίνηση του υπολογιστή σε $([int]($sec/60)) λεπτά για καθαρισμό μνήμης. Σώστε ό,τι έχετε ανοιχτό." 2>&1
      Reply @{ ok = ($LASTEXITCODE -eq 0); sec = $sec; err = [string]$o }
    }
    "rebootcancel" { $o = & shutdown.exe /a 2>&1; Reply @{ ok = ($LASTEXITCODE -eq 0); err = [string]$o } }
    "trim"      {
      # 🧹 «Συμπίεση» μνήμης: EmptyWorkingSet στα προγράμματα ΤΟΥ ΙΔΙΟΥ χρήστη (χωρίς δικαιώματα διαχειριστή, χωρίς κλείσιμο τίποτα).
      # Τα Windows μεταφέρουν τις σελίδες που δεν χρησιμοποιούνται στη λίστα αναμονής· ό,τι χρειαστεί ξαναφορτώνει αυτόματα.
      Add-Type -Namespace EfMem -Name Psapi -MemberDefinition '[DllImport("psapi.dll")] public static extern bool EmptyWorkingSet(IntPtr hProcess);' -ErrorAction SilentlyContinue
      $n = 0; $before = (Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory
      $sid = (Get-Process -Id $PID).SessionId
      foreach ($p in Get-Process -ErrorAction SilentlyContinue) {
        if ($p.SessionId -ne $sid -or $p.Id -eq $PID) { continue }   # μόνο η συνεδρία του χρήστη· ξένες διεργασίες απορρίπτονται από τα Windows (χωρίς διαχειριστή)
        try { if ([EfMem.Psapi]::EmptyWorkingSet($p.Handle)) { $n++ } } catch {}
      }
      Start-Sleep -Milliseconds 800; $after = (Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory
      Reply @{ ok = $true; n = $n; freedMb = [int](($after - $before) / 1024) }
    }
    "printers"  {
      # ΜΟΝΟ ανάγνωση: εκτυπωτές των Windows και αν είναι έτοιμοι
      $pr = @(Get-CimInstance Win32_Printer -ErrorAction SilentlyContinue | ForEach-Object { @{ name = $_.Name; def = [bool]$_.Default; off = [bool]$_.WorkOffline; st = [int]$_.PrinterStatus; err = [int]$_.DetectedErrorState; net = [bool]$_.Network } })
      Reply @{ ok = $true; printers = $pr }
    }
    "printhtml" {
      # 🖨 Τυπώνει μία σελίδα (HTML από το ef-bot) στον εκτυπωτή A4, χωρίς παράθυρο: ξεχωριστό, προσωρινό προφίλ Chrome με --kiosk-printing
      # και επιλεγμένο εκτυπωτή. Δεν αλλάζει τον προεπιλεγμένο εκτυπωτή των Windows ούτε άλλη ρύθμιση.
      $skip = 'zebra|zdesigner|label|ετικ|barcode|godex|tsc|datamax|dymo|brother ql|pdf|xps|onenote|fax|send to|αποστολή'
      $all = @(Get-CimInstance Win32_Printer -ErrorAction SilentlyContinue)
      $ready = { param($p) -not $p.WorkOffline -and @(0,3,4,5).Contains([int]$p.PrinterStatus) -or (-not $p.WorkOffline -and [int]$p.PrinterStatus -eq 2) }
      $want = [string]$msg.printer; $pick = $null
      if ($want) { $pick = $all | Where-Object { $_.Name -eq $want } | Select-Object -First 1 }
      if (-not $pick) { $pick = $all | Where-Object { $_.Default -and $_.Name -notmatch $skip -and (& $ready $_) } | Select-Object -First 1 }
      if (-not $pick) { $pick = $all | Where-Object { $_.Name -notmatch $skip -and (& $ready $_) } | Sort-Object @{ e = { [int](-not $_.Network) } } | Select-Object -First 1 }
      if (-not $pick) { Reply @{ ok = $false; err = "δεν βρέθηκε έτοιμος εκτυπωτής A4"; printers = @($all | ForEach-Object { $_.Name }) }; break }
      $chrome = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe") | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
      if (-not $chrome) { Reply @{ ok = $false; err = "δεν βρέθηκε το chrome.exe" }; break }
      $root = Join-Path $env:TEMP "efbot-print"; $prof = Join-Path $root "profile"; New-Item -ItemType Directory -Path (Join-Path $prof "Default") -Force | Out-Null
      Get-ChildItem -LiteralPath $root -Filter "p-*.html" -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt (Get-Date).AddHours(-2) } | Remove-Item -Force -ErrorAction SilentlyContinue
      $app = @{ version = 2; recentDestinations = @(@{ id = $pick.Name; origin = "local"; account = "" }); selectedDestinationId = $pick.Name; mediaSize = @{ height_microns = 297000; width_microns = 210000; name = "ISO_A4"; custom_display_name = "A4" }; isHeaderFooterEnabled = $false; isCssBackgroundEnabled = $true; scaling = "100"; scalingType = 0 }
      $pref = @{ printing = @{ print_preview_sticky_settings = @{ appState = ($app | ConvertTo-Json -Compress -Depth 5) } } }
      [IO.File]::WriteAllText((Join-Path $prof "Default\Preferences"), ($pref | ConvertTo-Json -Compress -Depth 6), (New-Object Text.UTF8Encoding $false))
      $f = Join-Path $root ("p-" + [DateTime]::Now.ToString("yyyyMMddHHmmssfff") + ".html")
      $html = [string]$msg.html + '<script>window.addEventListener("load",function(){setTimeout(function(){window.print();setTimeout(function(){window.close()},4000)},600)})</script>'
      [IO.File]::WriteAllText($f, $html, (New-Object Text.UTF8Encoding $false))
      $args2 = @("--user-data-dir=`"$prof`"", "--kiosk-printing", "--no-first-run", "--no-default-browser-check", "--disable-extensions", "--new-window", "--window-position=-2400,-2400", "`"file:///$($f -replace '\\','/')`"")
      # ανεξάρτητη διεργασία (όπως το «update»): δεν κλείνει όταν τελειώσει το βοηθητικό
      $cl = "`"$chrome`" " + ($args2 -join " ")
      $cr = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = $cl; CurrentDirectory = $root }
      if ($cr.ReturnValue -ne 0) { Reply @{ ok = $false; err = "δεν ξεκίνησε η εκτύπωση (κωδικός $($cr.ReturnValue))" }; break }
      Reply @{ ok = $true; printer = $pick.Name }
    }
    "ctlog" {
      try {
      # ΜΟΝΟ ανάγνωση: τελευταίες γραμμές του «Άνοιγμα με Νίκος CT Viewer» + τι είναι γραμμένο στο δεξί κλικ
      $lf = Join-Path $env:LOCALAPPDATA "ef-bot\nikosct\log.txt"; $t = @(); if (Test-Path -LiteralPath $lf) { $t = @(Get-Content -LiteralPath $lf -Tail 15 -Encoding UTF8) }
      $cmd = ""; try { $cmd = (Get-ItemProperty -Path "HKCU:\Software\Classes\Directory\shell\NikosCT\command" -ErrorAction Stop)."(default)" } catch {}
      $lnk = @(Get-ChildItem -LiteralPath "$env:APPDATA\Microsoft\Windows\Start Menu\Programs" -Recurse -Filter "*.lnk" -ErrorAction SilentlyContinue | Where-Object { $_.BaseName -match 'Νίκος CT|Nikos CT|Αξονικ' } | ForEach-Object { $_.Name })
      # 8/11: εγκατεστημένη έκδοση εφαρμογής + αν τρέχει + τελευταίες γραμμές του προγράμματος ενημέρωσης για το CT Viewer
      $vf = Join-Path $env:LOCALAPPDATA "NikosCTViewer\version.txt"; $ver = ""; if (Test-Path -LiteralPath $vf) { $ver = (Get-Content -LiteralPath $vf -Raw).Trim() }
      $exeOk = Test-Path -LiteralPath (Join-Path $env:LOCALAPPDATA "NikosCTViewer\app\NikosCTViewer.exe")
      $run = [bool](Get-Process -Name "NikosCTViewer" -ErrorAction SilentlyContinue)
      $ul = Join-Path $env:LOCALAPPDATA "ef-bot\update-log.txt"; $up = @(); if (Test-Path -LiteralPath $ul) { $up = @(Get-Content -LiteralPath $ul -Tail 200 -Encoding UTF8 | Where-Object { $_ -match 'CT Viewer' } | Select-Object -Last 8) }
      Reply @{ ok = $true; log = $t; cmd = $cmd; lnk = $lnk; ver = $ver; exe = $exeOk; running = $run; upd = $up }
          } catch { Reply @{ ok = $false; err = ("ctlog: " + $_.Exception.Message) } }
    }
    "ctupdate" {
      # 🩻 8/11: σήμα στο πρόγραμμα ενημέρωσης «έλεγξε ΤΩΡΑ για νέα έκδοση του Νίκος CT Viewer» (μέσα σε ~1′)
      try { $d = Join-Path $env:LOCALAPPDATA "NikosCTViewer"; New-Item -ItemType Directory -Path $d -Force | Out-Null; Set-Content -LiteralPath (Join-Path $d "update-now") -Value (Get-Date).ToString("o") -Encoding ASCII
        $run = [bool](Get-Process -Name "NikosCTViewer" -ErrorAction SilentlyContinue); Reply @{ ok = $true; running = $run } } catch { Reply @{ ok = $false; err = $_.Exception.Message } }
    }
    "ctopen" {
      # 🖥 8/11: άνοιγμα του Νίκος CT Viewer σε αυτόν τον υπολογιστή (τηλεχειρισμός από το κινητό) — μόνο γράμματα/αριθμοί στα ορίσματα
      try {
        $exe = Join-Path $env:LOCALAPPDATA "NikosCTViewer\app\NikosCTViewer.exe"
        if (-not (Test-Path -LiteralPath $exe)) { Reply @{ ok = $false; err = "δεν είναι εγκατεστημένο το Νίκος CT Viewer" }; break }
        $a = @()
        foreach ($k in @("examid", "sur", "fn", "amka")) { $v = ([string]$msg.$k) -replace '[^\p{L}\p{Nd} .\-]', ''; if ($v.Length -gt 60) { $v = $v.Substring(0, 60) }; if ($v) { $a += ('"--evo-' + $k + '=' + $v + '"') } }
        # η σύνδεση Evorad του bot → αρχείο ΜΟΝΟ για τον χρήστη (το διαβάζει και το σβήνει αμέσως η εφαρμογή)
        try { if ($msg.cookies) { $cf = Join-Path $env:LOCALAPPDATA "NikosCTViewer\evo-cookies.json"; ($msg.cookies | ConvertTo-Json -Depth 4 -Compress) | Set-Content -LiteralPath $cf -Encoding UTF8 } } catch {}
        $cl = '"' + $exe + '" ' + ($a -join " ")
        $cr = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = $cl; CurrentDirectory = (Split-Path $exe) }
        if ($cr.ReturnValue -ne 0) { Reply @{ ok = $false; err = "κωδικός " + $cr.ReturnValue }; break }
        Reply @{ ok = $true }
      } catch { Reply @{ ok = $false; err = $_.Exception.Message } }
    }
    "ctinstall" {
      # 🩻 8/11: εγκατάσταση/επισκευή Νίκος CT Viewer ΑΠΕΥΘΕΙΑΣ (με αναφορά βημάτων) — ίδια διαδικασία με τον updater
      $st = New-Object System.Collections.ArrayList
      try {
        $db = "https://paradoxarto.urol.workers.dev/desktop"
        $info = Invoke-RestMethod -Uri ("$db/version.json?t=" + [DateTimeOffset]::Now.ToUnixTimeSeconds()) -UseBasicParsing -TimeoutSec 30
        [void]$st.Add("διαθέσιμη " + $info.version)
        $root = Join-Path $env:LOCALAPPDATA "NikosCTViewer"; $app = Join-Path $root "app"; $vf = Join-Path $root "version.txt"; $exe = Join-Path $app "NikosCTViewer.exe"
        $have = ""; if (Test-Path -LiteralPath $vf) { $have = [string](Get-Content -LiteralPath $vf -Raw); $have = $have.Trim() }
        [void]$st.Add("εγκατεστημένη «" + $have + "» · exe " + $(if (Test-Path -LiteralPath $exe) { "ναι" } else { "ΟΧΙ" }))
        $pr = @(Get-Process -Name "NikosCTViewer" -ErrorAction SilentlyContinue)
        if ($pr.Count) {
          if ($msg.force) { $pr | Stop-Process -Force -ErrorAction SilentlyContinue; Start-Sleep -Seconds 2; [void]$st.Add("έκλεισε η ανοιχτή εφαρμογή") }
          else { Reply @{ ok = $false; err = "η εφαρμογή είναι ανοιχτή — κλείσ' την και ξαναδοκίμασε"; steps = @($st) }; break }
        }
        $tmp = Join-Path $env:TEMP ("nctapp-" + [guid]::NewGuid().ToString("N")); New-Item -ItemType Directory -Path $tmp -Force | Out-Null
        try {
          $zip = Join-Path $tmp "app.zip"; $out = [IO.File]::Create($zip); $t0 = Get-Date
          try { foreach ($pt in $info.parts) { $pf = Join-Path $tmp "part"; Invoke-WebRequest -Uri "$db/$pt" -OutFile $pf -UseBasicParsing -TimeoutSec 300; $bb = [IO.File]::ReadAllBytes($pf); $out.Write($bb, 0, $bb.Length) } } finally { $out.Close() }
          [void]$st.Add(("κατέβηκε σε {0:N0}″" -f ((Get-Date) - $t0).TotalSeconds))
          $h = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLower(); if ($h -ne ([string]$info.sha256).ToLower()) { throw "λάθος sha256" }
          $new = Join-Path $tmp "x"; Add-Type -AssemblyName System.IO.Compression.FileSystem; [IO.Compression.ZipFile]::ExtractToDirectory($zip, $new)
          if (-not (Test-Path -LiteralPath (Join-Path $new "NikosCTViewer.exe"))) { $sub = Get-ChildItem -LiteralPath $new -Recurse -Filter "NikosCTViewer.exe" | Select-Object -First 1; if (-not $sub) { throw "δεν υπάρχει exe στο πακέτο" }; $new = $sub.DirectoryName }
          [void]$st.Add("αποσυμπιέστηκε")
          New-Item -ItemType Directory -Path $root -Force | Out-Null
          if (Test-Path -LiteralPath $app) { try { Remove-Item -LiteralPath $app -Recurse -Force -ErrorAction Stop } catch { $old = Join-Path $root ("app-old-" + (Get-Date).Ticks); Rename-Item -LiteralPath $app -NewName (Split-Path $old -Leaf) -ErrorAction Stop; [void]$st.Add("ο παλιός φάκελος κλείδωνε → μετονομάστηκε") } }
          Move-Item -LiteralPath $new -Destination $app
          Set-Content -LiteralPath $vf -Value ([string]$info.version) -Encoding ASCII
          [void]$st.Add("εγκαταστάθηκε " + $info.version)
        } finally { Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue }
        # συντομεύσεις: ΠΑΝΤΑ προς το σωστό exe (και όποια παλιά «Νίκος CT» δείχνει αλλού)
        $ws = New-Object -ComObject WScript.Shell; $fixed = 0
        $dirs = @([Environment]::GetFolderPath("Programs"), [Environment]::GetFolderPath("Desktop"), [Environment]::GetFolderPath("CommonDesktopDirectory"))
        foreach ($d in $dirs) { foreach ($f in @(Get-ChildItem -LiteralPath $d -Filter "*.lnk" -ErrorAction SilentlyContinue | Where-Object { $_.BaseName -match 'Νίκος CT|Nikos ?CT' })) { try { $sc = $ws.CreateShortcut($f.FullName); if ($sc.TargetPath -ne $exe) { $sc.TargetPath = $exe; $sc.WorkingDirectory = $app; $sc.IconLocation = "$exe,0"; $sc.Save(); $fixed++ } } catch {} } }
        foreach ($lp in @((Join-Path ([Environment]::GetFolderPath("Programs")) "Νίκος CT Viewer.lnk"), (Join-Path ([Environment]::GetFolderPath("Desktop")) "Νίκος CT Viewer.lnk"))) { if (-not (Test-Path -LiteralPath $lp)) { $sc = $ws.CreateShortcut($lp); $sc.TargetPath = $exe; $sc.WorkingDirectory = $app; $sc.IconLocation = "$exe,0"; $sc.Save(); $fixed++ } }
        foreach ($k in @("HKCU:\Software\Classes\Directory\shell\NikosCT", "HKCU:\Software\Classes\Drive\shell\NikosCT")) { New-Item -Path "$k\command" -Force | Out-Null; Set-ItemProperty -Path "$k\command" -Name "(default)" -Value ('"' + $exe + '" "%1"') }
        [void]$st.Add("συντομεύσεις διορθώθηκαν: " + $fixed)
        Reply @{ ok = $true; steps = @($st) }
      } catch { Reply @{ ok = $false; err = $_.Exception.Message; steps = @($st) } }
    }
    { @("dbinstall", "dbcall", "dbshortcut") -contains $_ } {
      # 🗂 8/11: «Αρχείο Ασθενών» — σε χωριστό αρχείο (efbot-db.ps1, δίπλα στο efbot-update.bat της επέκτασης)
      $dbs = Join-Path (Split-Path -Parent ([IO.File]::ReadAllText((Join-Path $PSScriptRoot "updater-path.txt")).Trim())) "efbot-db.ps1"
      $r = @(& $dbs -Msg $msg); Reply $r[-1]
    }
    "printclear" {
      # 🖨 Καθαρίζει κολλημένες εκτυπώσεις (μόνο του τρέχοντος χρήστη — οι ξένες θέλουν διαχειριστή και απλώς μετριούνται)
      $want = [string]$msg.printer; $ok = 0; $fail = 0
      foreach ($j in @(Get-CimInstance Win32_PrintJob -ErrorAction SilentlyContinue)) {
        if ($want -and ($j.Name -split ',')[0] -ne $want) { continue }
        try { Remove-CimInstance -InputObject $j -ErrorAction Stop; $ok++ } catch { $fail++ }
      }
      Reply @{ ok = $true; removed = $ok; failed = $fail }
    }
    "sysinfo"   {
      # ΜΟΝΟ ανάγνωση: φόρτος του υπολογιστή (για διάγνωση «κολλάει»)
      $os = Get-CimInstance Win32_OperatingSystem; $cpu = (Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average
      $P = @(Get-Process -ErrorAction SilentlyContinue)
      $grp = { param($n) $x = @($P | Where-Object { $_.ProcessName -eq $n }); @{ n = $x.Count; mb = [int](($x | Measure-Object WorkingSet64 -Sum).Sum / 1MB); cpu = [int](($x | Measure-Object CPU -Sum).Sum) } }
      $top = @($P | Sort-Object WorkingSet64 -Descending | Select-Object -First 8 | ForEach-Object { @{ p = $_.ProcessName; mb = [int]($_.WorkingSet64 / 1MB); cpu = [int]$_.CPU } })
      $dk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'" -ErrorAction SilentlyContinue
      $rb = (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired") -or (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending")
      Reply @{ ok = $true; reboot = [bool]$rb; diskFreeGb = $(if ($dk) { [int]($dk.FreeSpace / 1GB) } else { -1 }); diskGb = $(if ($dk) { [int]($dk.Size / 1GB) } else { 0 }); cpu = [int]$cpu; ramMb = [int]($os.TotalVisibleMemorySize / 1024); freeMb = [int]($os.FreePhysicalMemory / 1024); upH = [int](((Get-Date) - $os.LastBootUpTime).TotalHours); chrome = (& $grp "chrome"); ps = (& $grp "powershell"); top = $top; cores = [Environment]::ProcessorCount; ext = $(if ($msg.ext) { SysExtra } else { $null }) }
    }
    default     { Reply @{ ok = $false; err = "unknown op" } }
  }
} catch {
  try { Reply @{ ok = $false; err = $_.Exception.Message } } catch {}
}
exit 0
