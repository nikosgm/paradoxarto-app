﻿# Νίκος CT Viewer — «Άνοιγμα με…» από το δεξί κλικ σε φάκελο/CD (7/11/2026)
# Μαζεύει τα DICOM του φακέλου σε ΕΝΑ προσωρινό αρχείο .nct (στο %TEMP%) και το ανοίγει με την εγκατεστημένη εφαρμογή.
# Δεν αλλάζει/σβήνει τίποτα στον φάκελο. Τα προσωρινά .nct σβήνονται μετά από 12 ώρες.
param([string]$Dir)
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Windows.Forms
function Msg($t) { [void][System.Windows.Forms.MessageBox]::Show($t, "Νίκος CT Viewer") }
try {
  $Dir = $Dir.TrimEnd('.').TrimEnd('"')
  if (-not (Test-Path -LiteralPath $Dir)) { Msg ("Δεν βρέθηκε ο φάκελος: " + $Dir); exit 1 }
  # η εγκατεστημένη εφαρμογή (συντόμευση του Chrome στο μενού Έναρξη)
  $roots = @("$env:APPDATA\Microsoft\Windows\Start Menu\Programs", "$env:USERPROFILE\Desktop")
  $lnk = $null; foreach ($r in $roots) { if (-not $lnk -and (Test-Path $r)) { $lnk = Get-ChildItem -LiteralPath $r -Recurse -Filter "*.lnk" -ErrorAction SilentlyContinue | Where-Object { $_.BaseName -match 'Νίκος CT|Nikos CT' } | Select-Object -First 1 } }
  if (-not $lnk) { Start-Process "https://paradoxarto.urol.workers.dev/ct?install=1"; Msg "Πρώτα εγκαταστήστε το «Νίκος CT Viewer» (άνοιξε η σελίδα στο Chrome → «💻 Εγκατάσταση»). Μετά ξαναδοκιμάστε το δεξί κλικ."; exit 0 }
  $sc = (New-Object -ComObject WScript.Shell).CreateShortcut($lnk.FullName)
  if ($sc.Arguments -notmatch '--app-id=') { Msg "Η συντόμευση της εφαρμογής δεν είναι του Chrome."; exit 1 }
  $tmp = Join-Path $env:TEMP "nikosct"; New-Item -ItemType Directory -Force -Path $tmp | Out-Null
  Get-ChildItem -LiteralPath $tmp -Filter *.nct -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt (Get-Date).AddHours(-12) } | Remove-Item -Force -ErrorAction SilentlyContinue
  $skip = '\.(jpe?g|png|gif|bmp|txt|html?|xml|pdf|exe|ini|inf|dll|ico|js|css|json|zip|rar|7z|lnk|db|log|mp4|avi|docx?|xlsx?|bat|cmd|sys|cab|msi|url|nct)$'
  $files = @(Get-ChildItem -LiteralPath $Dir -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Length -gt 128 -and $_.Name -notmatch $skip -and $_.Name -notmatch '^(dicomdir|thumbs\.db|desktop\.ini|autorun\.inf)$' })
  if (-not $files.Count) { Msg "Δεν βρέθηκαν εικόνες σε αυτόν τον φάκελο."; exit 0 }
  $base = (Get-Item -LiteralPath $Dir).FullName.TrimEnd('\')
  $name = ((Split-Path $base -Leaf) -replace '[^\w\-]', '_'); if (-not $name) { $name = "CD" }
  $out = Join-Path $tmp ($name + "-" + (Get-Date -Format yyyyMMdd-HHmmss) + ".nct")
  $fs = [IO.File]::Create($out); $bw = New-Object IO.BinaryWriter($fs)
  $bw.Write([byte[]](0x4E,0x43,0x54,0x31)); $bw.Write([int]$files.Count)
  foreach ($f in $files) {
    $rel = $f.FullName.Substring([Math]::Min($f.FullName.Length, $base.Length)).TrimStart('\')
    $nb = [Text.Encoding]::UTF8.GetBytes($rel); $bw.Write([int]$nb.Length); $bw.Write($nb); $bw.Write([long]$f.Length); $bw.Flush()
    $in = [IO.File]::OpenRead($f.FullName); try { $in.CopyTo($fs) } finally { $in.Close() }
  }
  $bw.Flush(); $fs.Close()
  Start-Process -FilePath $sc.TargetPath -ArgumentList ($sc.Arguments + ' "' + $out + '"')
} catch { Msg ("Σφάλμα: " + $_.Exception.Message) }
