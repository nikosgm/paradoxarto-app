// 🗺 10/11 22:45 (χρήστης: «νυχτερινή ΠΛΗΡΗΣ χαρτογράφηση ΝΠΣ, Medilabi, e-prescription, ΑΗΦΥ — κάθε καρτέλα — σε ένα αρχείο αναφοράς»).
// ΜΟΝΟ ΑΝΑΓΝΩΣΗ. Πατά ΜΟΝΟ: στοιχεία μενού πλοήγησης και επικεφαλίδες καρτελών (tabs). ΠΟΤΕ κουμπιά φορμών, ΠΟΤΕ αποθήκευση/καταχώριση/
// υποβολή/οριστικοποίηση/ακύρωση/διαγραφή/εκτύπωση/αποσύνδεση. Καταγράφει ΜΟΝΟ δομή (τίτλοι, ετικέτες/τύποι/ids πεδίων, κείμενα κουμπιών,
// κεφαλίδες πινάκων, καρτέλες) — ΚΑΜΙΑ τιμή πεδίου, ΚΑΝΕΝΑ κελί πίνακα· αριθμοί ≥5 ψηφίων → #. Δική της καρτέλα (κλείνει στο τέλος).
// Φορτώνεται από το background.js (importScripts) — οι συναρτήσεις σελίδας (SM_*) είναι αυτόνομες ώστε να δοκιμάζονται σε ψεύτικες σελίδες.
/* global self */
(function (G) {
  // κείμενα που ΔΕΝ πατιούνται ποτέ (μενού ή καρτέλα)
  const SM_SKIP = "^νέα |^νέο |^\\+ ?νέ|νέα επίσκεψη|νέα συνταγή|νέο παραπεμπτικό|εμβολιασμ|εισαγωγή νέας|θεώρηση|προσθήκη|ολοκλήρωση|τοποθέτηση|επαναπρογραμμ|προγραμματισμ|ελληνικά|αγγλικά|english|γλώσσα|εγχειρίδιο|manual|βοήθεια|help|αποσύνδ|έξοδος|logout|log out|sign ?out|διαγραφ|διαγράψ|ακύρωσ|ακυρώ|εκτύπωσ|εκτυπώ|print|υποβολ|υποβάλ|καταχώρ|οριστικοπ|αποστολ|αποστείλ|send|export|εξαγωγ|λήψη|download|αλλαγή κωδικ|password|κωδικός πρόσβασης|απενεργοπ|κλείδωμα|reset|επαναφορ|import|ανέβασμα|upload";

  // ---------- συναρτήσεις ΣΕΛΙΔΑΣ (τρέχουν μέσα στη σελίδα· αυτόνομες) ----------
  function SM_MENU(skipSrc) {
    const SK = new RegExp(skipSrc, "i");
    const T = (e) => String((e && (e.innerText || e.textContent)) || "").replace(/\s+/g, " ").trim();
    const mk = (s) => String(s || "").replace(/\d{5,}/g, "#").slice(0, 70);
    const SEL = ".ui-menuitem-link, .ui-menubar a, .ui-panelmenu a, .ui-tieredmenu a, .ui-slidemenu a, nav a, [role=menuitem], aside a, header a, .navbar a, ul.nav a, .nav-link, .sidebar a, #menu a, .menu a, .MuiListItem-root a, a.MuiListItemButton-root, .MuiListItemButton-root";
    let els = [...document.querySelectorAll(SEL)];
    if (els.length < 6) els = els.concat([...document.querySelectorAll("a[href]")].filter((a) => { try { const u = new URL(a.href, location.href); return u.origin === location.origin && !/^#?$/.test(a.getAttribute("href") || ""); } catch (e) { return false; } }));
    const seen = new Set(), out = [];
    const pathOf = (e) => { const p = []; let x = e.parentElement;
      while (x && x !== document.body) { if (/^(LI)$/.test(x.tagName) && (x.classList.contains("ui-menu-parent") || x.classList.contains("ui-submenu") || x.querySelector(":scope > ul, :scope > .ui-menu-child, :scope > .ui-submenu-list"))) { const h = x.querySelector(":scope > a, :scope > span, :scope > .ui-menuitem-link, :scope > .ui-submenu-header"); const t = T(h).split(" ")[0] ? T(h) : ""; if (t && h !== e && !h.contains(e)) p.unshift(t); }
        if (x.classList && (x.classList.contains("ui-panelmenu-panel"))) { const h = x.querySelector(".ui-panelmenu-header"); if (h && T(h)) p.unshift(T(h)); }
        x = x.parentElement; }
      return p; };
    for (const e of els) {
      const t = T(e); if (!t || t.length > 70) continue;
      const parent = e.closest("li") && e.closest("li").querySelector(":scope > ul, :scope > .ui-menu-child, :scope > .ui-submenu-list");
      const pp = pathOf(e), key = pp.concat(t).join(" › ");
      if (seen.has(key)) continue; seen.add(key);
      const href = e.getAttribute("href") || "";
      out.push({ key: mk(key), t: mk(t), d: pp.length, leaf: !parent, href: /^(#|javascript:)/i.test(href) ? "" : mk(href.replace(/[?#].*$/, "")), skip: SK.test(t) || SK.test(key) });
    }
    return out.slice(0, 250);
  }
  function SM_CLICK(key) {
    const T = (e) => String((e && (e.innerText || e.textContent)) || "").replace(/\s+/g, " ").trim();
    const mk = (s) => String(s || "").replace(/\d{5,}/g, "#").slice(0, 70);
    const SEL = ".ui-menuitem-link, .ui-menubar a, .ui-panelmenu a, .ui-tieredmenu a, .ui-slidemenu a, nav a, [role=menuitem], aside a, header a, .navbar a, ul.nav a, .nav-link, .sidebar a, #menu a, .menu a, .MuiListItem-root a, a.MuiListItemButton-root, .MuiListItemButton-root, a[href]";
    const pathOf = (e) => { const p = []; let x = e.parentElement;
      while (x && x !== document.body) { if (x.tagName === "LI" && (x.classList.contains("ui-menu-parent") || x.classList.contains("ui-submenu") || x.querySelector(":scope > ul, :scope > .ui-menu-child, :scope > .ui-submenu-list"))) { const h = x.querySelector(":scope > a, :scope > span, :scope > .ui-menuitem-link, :scope > .ui-submenu-header"); const t = T(h); if (t && h !== e && !h.contains(e)) p.unshift(t); }
        if (x.classList && x.classList.contains("ui-panelmenu-panel")) { const h = x.querySelector(".ui-panelmenu-header"); if (h && T(h)) p.unshift(T(h)); }
        x = x.parentElement; } return p; };
    const e = [...document.querySelectorAll(SEL)].find((x) => mk(pathOf(x).concat(T(x)).join(" › ")) === key);
    if (!e) return { err: "δεν βρέθηκε" };
    for (const t of ["pointerdown", "mousedown", "pointerup", "mouseup"]) e.dispatchEvent(new (t.startsWith("pointer") && typeof PointerEvent !== "undefined" ? PointerEvent : MouseEvent)(t, { bubbles: true, cancelable: true }));
    e.click(); return { ok: 1 };
  }
  // 12/11 23:00 «κάθε λεπτομέρεια»: + επιλογές λιστών, υποχρεωτικά, μέγιστο μήκος, ids κουμπιών/πινάκων, δομή παραθύρων, μηνύματα σφάλματος, σελίδα σφάλματος, πλαίσια.
  // hide = λέξεις που κρύβονται παντού (ονοματεπώνυμο ασθενή δοκιμών στη λειτουργία «καρτέλα ασθενή»).
  function SM_SNAP(hide) {
    const T = (e) => String((e && (e.innerText || e.textContent)) || "").replace(/\s+/g, " ").trim();
    const HW = (Array.isArray(hide) ? hide : []).filter((w) => w && String(w).length >= 3);
    const hw = (s) => { let t = String(s || ""); for (const w of HW) t = t.split(w).join("«ασθενής»"); return t; };
    const mk = (s) => hw(s).replace(/\d{5,}/g, "#").replace(/[\w.+-]+@[\w-]+\.[\w.]+/g, "@").slice(0, 90);
    // ελεύθερο κείμενο (παράθυρα/μηνύματα): 2+ λέξεις με ΚΕΦΑΛΑΙΑ που δεν είναι λέξεις του συστήματος = όνομα
    const SYSW = /ΚΛΙΝΙΚ|ΟΥΡΟΛΟΓ|ΗΜΕΡΑΣ|ΤΜΗΜΑ|ΝΟΣΟΚΟΜ|ΓΕΝΙΚ|ΕΨΙΝΕ|ΑΗΦΥ|ΝΠΣ|ΠΡΟΣΟΧΗ|ΧΩΡΙΣ|ΔΕΝ|ΟΧΙ|ΜΟΝΟ|ΑΤΟΜΙΚ|ΕΙΔΙΚ|ΑΝΤΙΒΙΟΤ|ΝΑΡΚΩΤ|ΝΟΣΗΛΕΥ|ΕΞΕΤΑΣ|ΔΙΑΓΝΩΣ|ΠΑΘΗΣΗ|ΣΤΟΙΧΕΙ|ΑΣΘΕΝ|ΑΝΑΖΗΤ|ΠΑΡΑΓΓΕΛ|ΣΥΝΤΑΓ|ΦΑΡΜΑΚ|ΙΑΤΡΙΚ|ΙΣΤΟΡΙΚ|ΠΛΗΡΟΦΟΡ/;
    const nm = (s) => String(s || "").replace(/[Α-ΩΆΈΉΊΌΎΏΪΫ]{3,}(?:[ ,]+[Α-ΩΆΈΉΊΌΎΏΪΫ]{3,}){1,4}/g, (m) => SYSW.test(m) ? m : "«όνομα»");
    const vis = (e) => { if (!e) return false; const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0; };
    const uniq = (a, n) => [...new Set(a.filter(Boolean))].slice(0, n);
    const root = document.body;
    const heads = uniq([...root.querySelectorAll("h1,h2,h3,h4,legend,.ui-panel-title,.ui-dialog-title,.MuiTypography-h4,.MuiTypography-h5,.MuiTypography-h6,.card-title,.page-title")].filter(vis).map((e) => mk(T(e))).filter((t) => t.length <= 90), 40);
    const labEl = (i) => { const id = i.id || ""; let l = id && document.querySelector("label[for='" + CSS.escape(id) + "'], label[for='" + CSS.escape(id + "_input") + "'], label[for='" + CSS.escape(id + "_focus") + "']"); if (l && T(l)) return l; l = i.closest("label"); if (l && T(l)) return l; return null; };
    const lab = (i) => { const le = labEl(i); if (le) return T(le); const al = i.getAttribute("aria-label") || i.getAttribute("placeholder") || ""; if (al) return al;
      const td = i.closest("td"); if (td && td.previousElementSibling && T(td.previousElementSibling)) return T(td.previousElementSibling);
      let c = i.parentElement; for (let k = 0; k < 3 && c; k++, c = c.parentElement) { const L = c.querySelector("label, .ui-outputlabel, .MuiFormLabel-root, .control-label"); if (L && T(L)) return T(L); } return ""; };
    const PERSON = /ιατρ|γιατρ|εντ[εέ]λ|ασθεν|χρήστ|ονοματεπ|θεράπ|doctor|patient|user|υπεύθυν/i;
    const fields = [...root.querySelectorAll("input:not([type=hidden]), select, textarea, [role=combobox], .ui-selectonemenu, .ui-chkbox, .ui-radiobutton, .ql-editor, [contenteditable=true]")].filter((i) => vis(i) && !(i.closest(".ui-helper-hidden-accessible") && i.closest(".ui-selectonemenu, .ui-chkbox, .ui-radiobutton, .ui-selectbooleancheckbox, .ui-selectcheckboxmenu"))).slice(0, 140).map((i) => {
      const raw = lab(i), le = labEl(i), inner = i.matches(".ui-selectonemenu, .ui-chkbox, .ui-radiobutton") ? i.querySelector("select, input") : null, src = inner || i;
      const f = { l: mk(raw).replace(/\s*\*$/, ""), t: (i.tagName.toLowerCase() + (i.type ? ":" + i.type : "") + (i.getAttribute("role") ? "@" + i.getAttribute("role") : "") + (i.classList.contains("ui-selectonemenu") ? "@pfselect" : "") + (i.classList.contains("ui-chkbox") ? "@pfcheck" : "") + (i.classList.contains("ui-radiobutton") ? "@pfradio" : "")),
        id: mk(i.id || i.name || ""), req: !!(src.required || src.getAttribute("aria-required") === "true" || /\*\s*$/.test(raw) || (le && le.querySelector(".ui-outputlabel-rfi, .required, .MuiFormLabel-asterisk")) || i.classList.contains("ui-state-required")), ro: !!(src.readOnly || src.disabled || i.classList.contains("ui-state-disabled")) };
      const sel = i.tagName === "SELECT" ? i : (i.classList.contains("ui-selectonemenu") ? i.querySelector("select") : null);
      // 13/11 (ζωντανή σάρωση #3229: «Γραμμές ανα σελίδα» του patientsTable βγήκε «ονόματα»): πρόσωπα κρίνονται από την ΕΤΙΚΕΤΑ· από το id μόνο doctor/user/physician
      if (sel) { const o = [...sel.options].map((x) => mk(T(x)).slice(0, 50)).filter(Boolean); f.on = o.length; if (!PERSON.test(raw) && !/doctor|physician|user(?!s?table)/i.test(f.id) || /^γραμμές αν[αά] σελίδα$/i.test(raw.trim())) f.opts = o.slice(0, 40); }
      if (src.maxLength > 0 && src.maxLength < 100000) f.max = src.maxLength;
      const ph = src.getAttribute && src.getAttribute("placeholder"); if (ph && ph !== raw) f.ph = mk(ph).slice(0, 40);
      if ((src.type === "radio" || src.type === "checkbox") && src.name) f.grp = mk(src.name).slice(0, 60);
      return f; });
    const BSEL = "button, input[type=submit], input[type=button], a.ui-button, a.btn, [role=button]";
    const bT = (b) => { const t = mk(T(b) || b.value || b.getAttribute("title") || b.getAttribute("aria-label") || ""); return /Α\.?Μ\.?Κ\.?Α|AMKA/i.test(t) || /^[A-Z]{6,}$/.test(t) ? "«όνομα/ασθενής»" : nm(t).replace(/«όνομα»/g, "«όνομα/ασθενής»"); };
    const bEls = [...root.querySelectorAll(BSEL)].filter(vis);
    const buttons = uniq(bEls.map(bT).filter((t) => t && t.length <= 60), 80);
    const bseen = new Set(), btn2 = []; bEls.forEach((b) => { const t = bT(b); if (!t || t.length > 60 || bseen.has(t) || btn2.length >= 80) return; bseen.add(t); const o = { t }; const id = mk(b.id || b.name || "").replace(/j_idt\d+/g, "j"); if (id) o.id = id; if (b.disabled || b.classList.contains("ui-state-disabled") || b.getAttribute("aria-disabled") === "true") o.dis = 1; btn2.push(o); });
    const tables = [...root.querySelectorAll("table")].filter(vis).map((t) => { const h = [...t.querySelectorAll("thead th, thead td")].map((x) => mk(T(x))).filter(Boolean); if (!h.length) return null;
      const dt = t.closest(".ui-datatable"), o = { h: h.slice(0, 25), rows: t.querySelectorAll("tbody tr").length, pager: !!(dt && dt.querySelector(".ui-paginator")) };
      const id = mk((dt && dt.id) || t.id || "").replace(/j_idt\d+/g, "j"); if (id) o.id = id;
      const rp = dt && dt.querySelector(".ui-paginator-rpp-options"); if (rp) o.rpp = [...rp.options].map((x) => x.value).slice(0, 8);
      return o; }).filter(Boolean).slice(0, 15);
    const tabs = uniq([...root.querySelectorAll("[role=tab], .ui-tabs-nav li, .MuiTab-root, .nav-tabs a, .nav-tabs li")].filter(vis).map((e) => mk(T(e))).filter((t) => t && t.length <= 60), 20);
    const dEls = [...document.querySelectorAll("[role=dialog], [role=alertdialog], .ui-dialog, .modal.show, .MuiDialog-root")].filter(vis);
    const dialogs = dEls.map((d) => nm(mk(T(d))).slice(0, 160));
    const dlgs = dEls.slice(0, 4).map((d) => ({ t: nm(mk(T(d.querySelector(".ui-dialog-title, .modal-title, .MuiDialogTitle-root, h1, h2, h3, [id$=_title]")))).slice(0, 80),
      f: uniq([...d.querySelectorAll("input:not([type=hidden]), select, textarea, .ui-selectonemenu")].filter(vis).map((i) => mk(lab(i)).replace(/\s*\*$/, "") || mk(i.id || "")), 30),
      b: uniq([...d.querySelectorAll(BSEL)].filter(vis).map(bT).filter((t) => t && t.length <= 40), 14),
      x: nm(mk((T(d.querySelector(".ui-dialog-content, .modal-body, .MuiDialogContent-root")) || "").slice(0, 400))).slice(0, 200) }));
    const msgs = uniq([...document.querySelectorAll(".ui-messages, .ui-growl-item, .ui-growl, [role=alert], .alert, .validation-summary-errors, .MuiSnackbar-root, .MuiAlert-root")].filter(vis).map((e) => nm(mk(T(e).slice(0, 400))).slice(0, 160)), 6);
    const errs = uniq([...document.querySelectorAll(".ui-messages-error, .ui-messages-fatal, .ui-message-error, .alert-danger, .validation-summary-errors, .field-validation-error, .MuiAlert-standardError, .MuiAlert-filledError, .Mui-error.MuiFormHelperText-root, .error-message, .has-error .help-block")].filter(vis).map((e) => nm(mk(T(e).slice(0, 400))).slice(0, 200)), 6);
    const body = T(root).slice(0, 700), ttl = String(document.title || "");
    const errPage = /(server error|runtime error|unhandled exception|stack ?trace|http status ?[45]\d\d|\b(403|404|500|502|503)\b.{0,20}(error|forbidden|not found|unavailable)|σφάλμα (συστήματος|εφαρμογής|διακομιστή)|η σελίδα δεν βρέθηκε|page not found|access (is )?denied|δεν έχετε (δικαίωμα|πρόσβαση)|service unavailable|bad gateway|viewexpiredexception)/i.test(ttl + " " + (body.length < 650 ? body : heads.join(" ")));
    const frames = uniq([...document.querySelectorAll("iframe[src]")].filter(vis).map((f) => { try { return mk(new URL(f.src, location.href).pathname); } catch (e) { return ""; } }), 6);
    const pw = [...document.querySelectorAll("input[type=password]")].some(vis);
    const out = { path: mk(location.pathname), title: mk(ttl), heads, fields, buttons, tables, tabs, dialogs, msgs, login: pw };
    try { const q = [...new Set([...new URLSearchParams(location.search).keys()])].slice(0, 10); if (q.length) out.q = q; } catch (e) {}
    if (btn2.some((b) => b.id || b.dis)) out.btn2 = btn2; if (dlgs.length) out.dlgs = dlgs; if (errs.length) out.errs = errs; if (errPage) out.errPage = true; if (frames.length) out.frames = frames;
    return out;
  }
  function SM_TAB(i, skipSrc) {
    const SK = new RegExp(skipSrc, "i");
    const T = (e) => String((e && (e.innerText || e.textContent)) || "").replace(/\s+/g, " ").trim();
    const vis = (e) => { if (!e) return false; const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0; };
    const L = [...document.querySelectorAll("[role=tab], .ui-tabs-nav li, .MuiTab-root, .nav-tabs a, .nav-tabs li")].filter(vis);
    const seen = new Set(), U = L.filter((e) => { const t = T(e); if (!t || seen.has(t)) return false; seen.add(t); return true; });
    const e = U[i]; if (!e) return { none: 1 }; if (SK.test(T(e))) return { skip: T(e) };
    const a = e.querySelector("a") || e;
    for (const t of ["mousedown", "mouseup"]) a.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true }));
    a.click(); return { ok: 1, t: T(e).replace(/\d{5,}/g, "#").slice(0, 60) };
  }
  // 10/11 22:55 (1η δοκιμή στο ΝΠΣ: «μενού» = ετικέτες κεφαλίδας «ΑΜΚΑ :»· το πραγματικό μενού είναι ΚΑΡΤΕΛΕΣ με υπο-στοιχεία):
  // ΓΕΝΙΚΑ: ό,τι πατιέται ΓΙΑ ΠΛΟΗΓΗΣΗ — σύνδεσμοι, στοιχεία μενού (και κρυφά), καρτέλες, γραμμές λίστας-μενού. ΠΟΤΕ: κουμπιά, πεδία, γραμμές/κελιά πινάκων
  // (ασθενείς), ετικέτες «…:», κείμενα SM_SKIP. Ταυτότητα = το κείμενο (μοναδικό στη σελίδα).
  function SM_ITEMS(skipSrc) {
    const SK = new RegExp(skipSrc, "i");
    const T = (e) => String((e && (e.innerText || e.textContent)) || "").replace(/\s+/g, " ").trim();
    const vis = (e) => { const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0; };
    const own = (e) => [...e.childNodes].filter((n) => n.nodeType === 3).map((n) => n.textContent).join(" ").replace(/\s+/g, " ").trim();
    const bad = (e) => e.closest("tbody, .ui-datatable-data, table.dataTable, form input, select, textarea, button, [role=button], .ui-button, [role=dialog] .ui-dialog-titlebar") || e.closest("[role=grid] [role=row]");
    const L = [];
    const add = (e, kind) => { if (bad(e)) return; let t = kind === "li" ? own(e) : T(e); if (!t || t.length > 60 || /:\s*$/.test(t) || /^\d+$/.test(t)) return;
      // 14/11 (ΝΠΣ #3408: πατήθηκε η καρτέλα «Όνομα : ΕΠΩΝΥΜΟ ΟΝΟΜΑ» → άνοιξε ασθενής, 58 σελίδες χωρίς λίστα επιτρεπτών): «ετικέτα : τιμή» και ΑΜΚΑ δεν είναι πλοήγηση
      if (/[^\s:]\s*:\s*\S/.test(t) || /Α\.?Μ\.?Κ\.?Α|AMKA|ασθεν/i.test(t) && /[Α-ΩΆΈΉΊΌΎΏΪΫ]{3,}\s+[Α-ΩΆΈΉΊΌΎΏΪΫ]{3,}/.test(t)) return; t = t.replace(/\d{5,}/g, "#");
      if (L.some((x) => x.t === t)) return; L.push({ t, kind, hid: !vis(e), skip: SK.test(t) }); };
    document.querySelectorAll("[role=tab], .ui-tabs-nav li, .MuiTab-root, .nav-tabs a").forEach((e) => vis(e) && add(e, "tab"));
    document.querySelectorAll(".ui-menuitem-link, [role=menuitem], .ui-panelmenu-header a, .ui-submenu-header, .ui-commandlink, nav a, aside a, .navbar a, ul.nav a, .nav-link, .sidebar a, #menu a, .menu a, .MuiListItemButton-root").forEach((e) => add(e, "menu"));
    document.querySelectorAll("a[href]").forEach((e) => { if (!vis(e)) return; const h = e.getAttribute("href") || ""; try { if (/^(mailto:|tel:)/i.test(h) || (/^https?:/i.test(h) && new URL(h).origin !== location.origin)) return; } catch (x) { return; } add(e, "link"); });
    document.querySelectorAll("li").forEach((e) => { if (!vis(e) || e.querySelector("a, button, input") || !own(e)) return; const m = e.closest("ul, ol"); if (!m || !(m.className + " " + (m.getAttribute("role") || "")).match(/menu|nav|tree|list/i)) return; add(e, "li"); });
    return L.slice(0, 200);
  }
  function SM_CLICKTXT(t) {
    const T = (e) => String((e && (e.innerText || e.textContent)) || "").replace(/\s+/g, " ").trim().replace(/\d{5,}/g, "#");
    const own = (e) => [...e.childNodes].filter((n) => n.nodeType === 3).map((n) => n.textContent).join(" ").replace(/\s+/g, " ").trim().replace(/\d{5,}/g, "#");
    const vis = (e) => { const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0; };
    const bad = (e) => e.closest("tbody, .ui-datatable-data, table.dataTable, button, [role=button], .ui-button") || e.closest("[role=grid] [role=row]");
    const C = [...document.querySelectorAll("[role=tab], .ui-tabs-nav li, .MuiTab-root, .nav-tabs a, .ui-menuitem-link, [role=menuitem], .ui-panelmenu-header a, .ui-submenu-header, .ui-commandlink, nav a, aside a, .navbar a, ul.nav a, .nav-link, .sidebar a, #menu a, .menu a, .MuiListItemButton-root, a[href]")].filter((e) => !bad(e) && T(e) === t);
    let e = C.find(vis) || C[0];
    if (!e) e = [...document.querySelectorAll("li")].find((x) => vis(x) && !bad(x) && own(x) === t);
    if (!e) return { err: "δεν βρέθηκε" };
    const a = (e.matches("li") && e.querySelector(":scope > a")) || e;
    for (const k of ["pointerdown", "mousedown", "pointerup", "mouseup"]) a.dispatchEvent(new (k.startsWith("pointer") && typeof PointerEvent !== "undefined" ? PointerEvent : MouseEvent)(k, { bubbles: true, cancelable: true }));
    a.click(); return { ok: 1 };
  }
  // «μη αποθηκευμένα»/«θέλετε να φύγετε» — σταματάμε, δεν πατάμε τίποτα
  function SM_LEAVE() { const b = String(document.body && document.body.innerText || ""); return /δεν έχουν (οριστικοποιηθεί|αποθηκευτεί)|μη αποθηκευμέν|unsaved|θέλετε να (φύγετε|αποχωρήσετε)/i.test(b); }

  // 🌙 12/11 (χρήστης: «σάρωση κάθε κλικ, κάθε εντολή, τι μηνύματα βγαίνουν — όχι διαγνώσεις/ιατρικές πράξεις»):
  // ΑΥΣΤΗΡΗ λίστα απαγόρευσης για ΚΟΥΜΠΙΑ — ό,τι μπορεί να γράψει/στείλει/εκτυπώσει/αλλάξει ΔΕΝ πατιέται ποτέ.
  const SM_BTN_DENY = "εξαγωγ|export|λήψη|download|feedback|εκπαιδευτικ|καταχώρ|υποβολ|υποβάλ|οριστικ|αποθήκ|ενημέρωσ|έκδοσ|εκδ[οό]σ|ακύρ|διαγρ|αφαίρεσ|αποστολ|αποστείλ|στείλ|εκτύπ|εκτυπ|print|save|submit|send|delete|remove|cancel|έγκρισ|εγκρίν|υπογρ|κλείδω|ξεκλείδω|αποσύνδ|logout|έξοδ|ολοκλήρ|επιβεβαί|confirm|^ναι$|^yes$|^ok$|εντάξει|συνέχεια|επόμεν|μεταφορ|μετακίν|εξιτήρ|σφράγ|ανάθεσ|αλλαγ|ενεργοπ|απενεργ|καθαρισ|reset|ανανέωσ|refresh|εισαγωγή|import|upload|ανέβασ|επισύναψ|attach|δημιουργ|create|νέα |νέο |^\\+|προσθήκ|add|διάγνωσ|πράξ|συνταγ|παραπεμπτ|παραγγελ|εντολ|χορήγησ|εκτέλεσ|λήψη|δείγμα|barcode|ετικέτ|κλήσ|εκτίμησ|πρακτικ|πορεία|αίτημα|αίτησ|δήλωσ|εγγραφ|αποδοχ|απόρριψ|reject|accept|approve|κωδικ|password|ρυθμίσ|settings|προφίλ|profile|γλώσσα|language|βοήθεια|help|x$|^×$|^✕$";
  function SM_BTNS(denySrc, allowSrc) {
    const DN0 = new RegExp(denySrc, "i"), AL = allowSrc ? new RegExp(allowSrc, "i") : null, DN = { test: (t) => DN0.test(t) || (AL ? !AL.test(t) : false) };
    const T = (e) => String((e && (e.innerText || e.value || e.getAttribute("title") || e.getAttribute("aria-label") || "")) || "").replace(/\s+/g, " ").trim();
    const vis = (e) => { const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0; };
    const L = [...document.querySelectorAll("button, input[type=button], input[type=submit], a.ui-button, a.btn, [role=button]")].filter((e) => vis(e) && !e.disabled && !e.closest("tbody, [role=grid] [role=row], .ui-datatable-data"));
    const seen = new Set(), out = [];
    // 13/11 (ζωντανή σάρωση e-prescription #3230): κουμπί-ταμπέλα ασθενή («… ΑΜΚΑ: #») και κουμπί λογαριασμού (όνομα γιατρού) — ΠΟΤΕ κλικ, ΠΟΤΕ το όνομα στον χάρτη·
    // διακόπτες «on/off» δεν είναι κουμπιά σελίδας
    const SYSW = /ΚΛΙΝΙΚ|ΟΥΡΟΛΟΓ|ΗΜΕΡΑΣ|ΤΜΗΜΑ|ΝΟΣΟΚΟΜ|ΓΕΝΙΚ|ΕΨΙΝΕ|ΑΗΦΥ|ΝΠΣ|ΠΡΟΣΟΧΗ|ΧΩΡΙΣ|ΔΕΝ|ΟΧΙ|ΜΟΝΟ|ΑΤΟΜΙΚ|ΕΙΔΙΚ|ΑΝΤΙΒΙΟΤ|ΝΑΡΚΩΤ|ΝΟΣΗΛΕΥ|ΕΞΕΤΑΣ|ΔΙΑΓΝΩΣ|ΠΑΘΗΣΗ|ΣΤΟΙΧΕΙ|ΑΣΘΕΝ|ΑΝΑΖΗΤ|ΠΑΡΑΓΓΕΛ|ΣΥΝΤΑΓ|ΦΑΡΜΑΚ|ΙΑΤΡΙΚ|ΙΣΤΟΡΙΚ|ΠΛΗΡΟΦΟΡ|ΕΠΙΣΚΕΨ|ΕΚΤΥΠΩΣ|ΠΡΟΣΘΗΚ|ΑΠΟΘΗΚ|ΚΑΤΑΧΩΡ|ΑΚΥΡΩΣ|ΕΠΙΛΟΓ|ΚΛΕΙΣΙΜΟ|ΝΕΑ|ΝΕΟ/;
    const person = (t) => /Α\.?Μ\.?Κ\.?Α|AMKA/i.test(t) || [...t.matchAll(/[Α-ΩΆΈΉΊΌΎΏΪΫ]{3,}(?:\s+[Α-ΩΆΈΉΊΌΎΏΪΫ]{3,}){1,3}/g)].some((m) => !SYSW.test(m[0])) || /^[A-Z]{6,}$/.test(t);
    // 14/11 00:45 (σάρωση ΝΠΣ #3408): κουμπιά-ΕΙΚΟΝΙΔΙΑ χωρίς κείμενο το PrimeFaces τα γράφει «ui-button» — ίδια ετικέτα για ημερολόγιο ΚΑΙ για κάδο/✎.
    // Πατιούνται ΜΟΝΟ τα κουμπιά ημερολογίου· κάθε άλλο εικονίδιο → ⛔ με το όνομα του εικονιδίου (για τον χάρτη).
    const CAL = ".ui-datepicker-trigger, .ui-calendar button, .p-datepicker-trigger, .p-calendar button";
    L.forEach((e) => { let t = T(e).replace(/\d{5,}/g, "#").slice(0, 60); if (!t || t.length < 2 || /^(on|off)$/i.test(t)) return;
      let icon = false; if (/^ui-button$/i.test(t)) { if (e.matches(CAL) || e.closest(".ui-calendar, .p-calendar")) t = "ui-button (ημερολόγιο)"; else { icon = true; const ic = e.querySelector("[class*=fa-], [class*=pi-], [class*=ui-icon-]"); t = "ui-button (εικονίδιο " + (((ic && ic.className) || "").match(/(?:fa|pi|ui-icon)-[a-z0-9-]+/g) || ["?"]).filter((c) => !/^(fa|pi)-(fw|lg|\dx)$/.test(c)).slice(0, 2).join(" ") + ")"; } }
      const pr = person(t); if (pr) t = "«όνομα/ασθενής»"; if (seen.has(t)) return; seen.add(t); out.push({ t, deny: pr || icon || DN.test(t) }); });
    return out.slice(0, 60);
  }
  function SM_CLICKBTN(t, denySrc, allowSrc) {
    const DN = new RegExp(denySrc, "i"); if (DN.test(t) || (allowSrc && !new RegExp(allowSrc, "i").test(t))) return { err: "απαγορευμένο" };
    const T = (e) => String((e && (e.innerText || e.value || e.getAttribute("title") || e.getAttribute("aria-label") || "")) || "").replace(/\s+/g, " ").trim().replace(/\d{5,}/g, "#").slice(0, 60);
    const vis = (e) => { const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0; };
    if (/^ui-button \(εικονίδιο/.test(t)) return { err: "απαγορευμένο (εικονίδιο χωρίς κείμενο)" };
    const cal = t === "ui-button (ημερολόγιο)", CAL = ".ui-datepicker-trigger, .ui-calendar button, .p-datepicker-trigger, .p-calendar button";
    const e = [...document.querySelectorAll("button, input[type=button], input[type=submit], a.ui-button, a.btn, [role=button]")].find((x) => vis(x) && !x.disabled && (cal ? /^ui-button$/i.test(T(x)) && (x.matches(CAL) || !!x.closest(".ui-calendar, .p-calendar")) : T(x) === t) && !x.closest("tbody, [role=grid] [role=row], .ui-datatable-data"));
    if (!e) return { err: "δεν βρέθηκε" };
    // ⛔ διπλός έλεγχος: ΟΧΙ μέσα σε διάλογο που ήδη έχει πεδία με τιμές (δεν «στέλνουμε» φόρμα)
    for (const k of ["pointerdown", "mousedown", "pointerup", "mouseup"]) e.dispatchEvent(new (k.startsWith("pointer") && typeof PointerEvent !== "undefined" ? PointerEvent : MouseEvent)(k, { bubbles: true, cancelable: true }));
    e.click(); return { ok: 1 };
  }
  // κλείσιμο διαλόγων ΜΟΝΟ με το ✕ του τίτλου / Escape — ποτέ με κουμπί κειμένου
  function SM_CLOSE() {
    const vis = (e) => { const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0; };
    let n = 0; document.querySelectorAll(".ui-dialog-titlebar-close, .ui-dialog .ui-dialog-titlebar-icon, .modal.show .close, .modal.show .btn-close, [role=dialog] button[aria-label=Close], [role=dialog] button[aria-label=close], .MuiDialog-root button[aria-label=close]").forEach((x) => { if (vis(x)) { x.click(); n++; } });
    document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", keyCode: 27, bubbles: true }));
    const left = [...document.querySelectorAll("[role=dialog], .ui-dialog, .modal.show")].filter(vis).length;
    return { closed: n, left };
  }

  // 🎙 12/11 23:00 — ΚΑΤΑΓΡΑΦΕΑΣ της καρτέλας σάρωσης (ΜΟΝΟ στην καρτέλα που ανοίγει η σάρωση, ποτέ στις καρτέλες δουλειάς):
  // κάθε αίτημα (μέθοδος, διαδρομή, ΟΝΟΜΑΤΑ παραμέτρων — ποτέ τιμές, κατάσταση, χρόνος, μέγεθος, τι ενημέρωσε, μηνύματα απάντησης),
  // κάθε παράθυρο alert/confirm/prompt (δεν εμφανίζονται· το confirm απαντά ΠΑΝΤΑ «Άκυρο»), κάθε σφάλμα JavaScript,
  // κάθε μήνυμα που εμφανίζεται και χάνεται (growl/snackbar/toast/επικύρωση). Τίποτα δεν στέλνεται από εδώ — μένει στη σελίδα ώσπου να το πάρει το SM_DRAIN.
  function SM_REC() {
    if (window.__smRec) return { on: 1 };
    const R = window.__smRec = { req: [], al: [], err: [], msg: [], pt: 0, nav: 0 };
    const N = (k) => String(k || "").replace(/j_idt\d+/g, "j").replace(/:\d+(?=[:_]|$)/g, ":#").replace(/\d{5,}/g, "#");
    const P = (u) => { try { const x = new URL(u, location.href); return { p: (x.origin !== location.origin ? x.host : "") + N(x.pathname).slice(0, 120), q: [...new Set([...x.searchParams.keys()])].slice(0, 12) }; } catch (e) { return { p: String(u).slice(0, 80), q: [] }; } };
    const cut = (s, n) => String(s == null ? "" : s).replace(/\s+/g, " ").trim().replace(/\d{5,}/g, "#").slice(0, n || 200);
    const body = (b) => { const o = { k: [], src: "", ev: "" }; try {
        let s = b; if (!s) return o;
        if (typeof s !== "string") { if (s instanceof URLSearchParams) s = s.toString(); else if (typeof FormData !== "undefined" && s instanceof FormData) s = new URLSearchParams([...s.entries()].filter((e) => typeof e[1] === "string")).toString(); else { o.k = ["(" + ((s.constructor && s.constructor.name) || "δυαδικό") + ")"]; return o; } }
        const t = s.trim();
        if (t[0] === "{" || t[0] === "[") { try { const j = JSON.parse(t); o.k = Object.keys((Array.isArray(j) ? j[0] : j) || {}).slice(0, 30); return o; } catch (e) {} }
        for (const kv of s.split("&")) { if (!kv) continue; const i = kv.indexOf("="); let k, v; try { k = decodeURIComponent((i < 0 ? kv : kv.slice(0, i)).replace(/\+/g, " ")); v = i < 0 ? "" : decodeURIComponent(kv.slice(i + 1).replace(/\+/g, " ")); } catch (e) { continue; }
          if (k === "javax.faces.source" || k === "__EVENTTARGET") { if (v) o.src = N(v).slice(0, 80); } else if (/^javax\.faces\.(behavior|partial)\.event$/.test(k)) o.ev = N(v).slice(0, 30);
          if (/^(javax\.faces\.|__VIEWSTATE|__EVENTVALIDATION|__EVENTTARGET|__EVENTARGUMENT|__LASTFOCUS)/.test(k)) continue; const nk = N(k).slice(0, 60); if (o.k.indexOf(nk) < 0) o.k.push(nk); }
        o.k = o.k.slice(0, 40); } catch (e) {} return o; };
    const resp = (txt, ct, st) => { const o = {}, t = String(txt || ""); o.sz = t.length;
      try { if (/partial-response/.test(t.slice(0, 400))) { o.upd = [...new Set([...t.matchAll(/<update id="([^"]+)"/g)].map((m) => N(m[1])))].filter((x) => !/ViewState/.test(x)).slice(0, 10);
          if (/<error>|ui-messages-error|ui-message-error|ui-messages-fatal|validationFailed[^\w]{0,6}true/i.test(t)) o.e = 1;
          const g = [...t.matchAll(/ui-(?:messages|growl)[\w-]*-(?:summary|detail|title)"?>([^<]{1,200})/g)].map((m) => cut(m[1], 160)); if (g.length) o.msg = [...new Set(g)].slice(0, 4);
          const rd = t.match(/<redirect url="([^"]+)"/); if (rd) o.redir = N(rd[1].split("?")[0]).slice(0, 80); }
        else if (/json/i.test(ct || "") && (st >= 400 || t.length < 6000)) { const j = JSON.parse(t), m = [];
          const walk = (x, d) => { if (!x || d > 2 || m.length > 3 || typeof x !== "object") return; for (const k of Object.keys(x).slice(0, 30)) { const v = x[k]; if (typeof v === "string" && /^(message|error|errorMessage|errorsMessage|detail|title|description|msg|reason)$/i.test(k) && v.length < 400) m.push(cut(v, 160)); else if (v && typeof v === "object") walk(v, d + 1); } };
          walk(j, 0); if (m.length && (st >= 400 || /error|σφάλμα|αποτυχ|invalid|δεν /i.test(m.join(" ")))) o.msg = m; }
        else if (st >= 400 && /html/i.test(ct || "")) { const tt = t.match(/<title[^>]*>([^<]{1,120})/i); if (tt) o.msg = [cut(tt[1], 120)]; }
      } catch (e) {} return o; };
    const push = (r) => { if (R.req.length < 60) R.req.push(r); };
    try { const XO = XMLHttpRequest.prototype.open, XS = XMLHttpRequest.prototype.send;
      XMLHttpRequest.prototype.open = function (m, u) { this.__smM = m; this.__smU = u; return XO.apply(this, arguments); };
      XMLHttpRequest.prototype.send = function (b) { const x = this, t0 = Date.now();
        try { x.addEventListener("loadend", () => { try { let txt = ""; try { txt = (x.responseType === "" || x.responseType === "text") ? x.responseText : ""; } catch (e) {}
          const u = P(x.__smU), bb = body(b); push(Object.assign({ m: String(x.__smM || "GET").toUpperCase(), p: u.p, q: u.q, k: bb.k, src: bb.src, ev: bb.ev, st: x.status, ms: Date.now() - t0 }, resp(txt, x.getResponseHeader && x.getResponseHeader("content-type"), x.status))); } catch (e) {} }); } catch (e) {}
        return XS.apply(this, arguments); }; } catch (e) {}
    try { if (window.fetch) { const F = window.fetch; window.fetch = function (i, o) { const t0 = Date.now(), url = typeof i === "string" ? i : (i && i.url) || "", m = String((o && o.method) || (i && i.method) || "GET").toUpperCase(), b = o && o.body;
        return F.apply(this, arguments).then((r) => { try { const u = P(url), bb = body(b), base = { m, p: u.p, q: u.q, k: bb.k, src: bb.src, ev: bb.ev, st: r.status, ms: Date.now() - t0 }, ct = r.headers.get("content-type") || "";
            if (/json|text|html|xml/i.test(ct)) r.clone().text().then((tx) => push(Object.assign(base, resp(tx, ct, r.status)))).catch(() => push(base)); else push(base); } catch (e) {} return r; },
          (e) => { try { const u = P(url); push({ m, p: u.p, q: u.q, k: [], st: 0, ms: Date.now() - t0, e: 1, msg: [cut(e && e.message, 120)] }); } catch (x) {} throw e; }); }; } } catch (e) {}
    window.alert = function (t) { if (R.al.length < 20) R.al.push({ k: "alert", t: cut(t, 300) }); };
    window.confirm = function (t) { if (R.al.length < 20) R.al.push({ k: "confirm→Άκυρο", t: cut(t, 300) }); return false; };
    window.prompt = function (t) { if (R.al.length < 20) R.al.push({ k: "prompt→Άκυρο", t: cut(t, 300) }); return null; };
    window.addEventListener("error", (e) => { try { if (R.err.length < 20) R.err.push(cut((e.message || (e.target && (e.target.src || e.target.href) ? "δεν φορτώθηκε " + P(e.target.src || e.target.href).p : "σφάλμα")) + (e.filename ? " @" + P(e.filename).p.split("/").pop() + ":" + e.lineno : ""), 220)); } catch (x) {} }, true);
    window.addEventListener("unhandledrejection", (e) => { try { if (R.err.length < 20) R.err.push(cut("promise: " + ((e.reason && (e.reason.message || e.reason)) || ""), 220)); } catch (x) {} });
    try { const CE = console.error; console.error = function () { try { const t = [...arguments].map((a) => (a && a.message) || (typeof a === "string" ? a : "")).filter(Boolean).join(" "); if (t && R.err.length < 20) R.err.push(cut("console.error: " + t, 220)); } catch (x) {} return CE.apply(this, arguments); }; } catch (e) {}
    const SEL = ".ui-growl-item, .ui-messages-error, .ui-messages-warn, .ui-messages-info, .ui-messages-fatal, .ui-message-error, .ui-message-warn, [role=alert], [role=alertdialog], .MuiSnackbar-root, .MuiAlert-root, .toast, .Toastify__toast, .swal2-popup, .alert, .validation-summary-errors, .field-validation-error, .error-message, .p-toast-message, .p-message";
    const sev = (e) => { let c = ""; for (let x = e, k = 0; x && k < 3; x = x.parentElement, k++) c += " " + (typeof x.className === "string" ? x.className : ""); return /error|danger|fatal/i.test(c) ? "σφάλμα" : /warn/i.test(c) ? "προειδοποίηση" : /success/i.test(c) ? "επιτυχία" : "ενημέρωση"; };
    const seen = new Set();
    const take = (e) => { try { const t = cut(e.innerText || e.textContent, 240); if (!t || t.length < 3 || seen.has(t)) return; seen.add(t); if (R.msg.length < 30) R.msg.push({ s: sev(e), t }); } catch (x) {} };
    try { new MutationObserver((ml) => { for (const m of ml) { for (const n of m.addedNodes) { if (n.nodeType !== 1) continue; if (n.matches && n.matches(SEL)) take(n); else if (n.querySelectorAll) n.querySelectorAll(SEL).forEach(take); const par = n.parentElement && n.parentElement.closest(SEL); if (par) take(par); }
          if (m.type === "characterData" && m.target.parentElement) { const par = m.target.parentElement.closest(SEL); if (par) take(par); } } }).observe(document, { childList: true, subtree: true, characterData: true }); } catch (e) {}   // «document»: ο καταγραφέας μπαίνει πριν υπάρξει <html>
    return { ok: 1 };
  }
  // παίρνει (και αδειάζει) ό,τι κατέγραψε το SM_REC + ό,τι φορτώθηκε πριν μπει ο καταγραφέας (Performance API: διαδρομή, κατάσταση, χρόνος)
  function SM_DRAIN() {
    const R = window.__smRec; if (!R) return { off: 1 };
    const N = (k) => String(k || "").replace(/j_idt\d+/g, "j").replace(/\d{5,}/g, "#");
    const out = { req: R.req.splice(0), al: R.al.splice(0), js: R.err.splice(0), msg: R.msg.splice(0), perf: [] };   // «js» (όχι «err»: το err σημαίνει αποτυχία ανάγνωσης)
    try { const have = new Set(out.req.map((r) => r.p));
      performance.getEntriesByType("resource").forEach((e) => { if (e.startTime < R.pt || !/xmlhttprequest|fetch|iframe|subdocument|frame/.test(e.initiatorType)) return; let p;
        try { const u = new URL(e.name); p = (u.origin !== location.origin ? u.host : "") + N(u.pathname).slice(0, 120); } catch (x) { return; }
        if (have.has(p)) return; have.add(p); if (out.perf.length < 15) out.perf.push({ p, st: e.responseStatus || 0, ms: Math.round(e.duration) }); });
      if (!R.nav) { const n = performance.getEntriesByType("navigation")[0]; if (n) out.nav = { p: N(location.pathname).slice(0, 120), st: n.responseStatus || 0, ms: Math.round(n.duration || n.domContentLoadedEventEnd || 0), type: n.type }; R.nav = 1; }
      R.pt = performance.now(); } catch (e) {}
    return out;
  }
  // 🧍 ΝΠΣ «καρτέλα ασθενή δοκιμών»: το δεξί μενού του ασθενή (appForm:patientRightMenu) — ΜΟΝΟ τα στοιχεία του (ποτέ γραμμές/κουμπιά).
  // Τα διπλά ονόματα («Φαρμακευτική Αγωγή», «Ιατρικές Πράξεις») ξεχωρίζουν με την ομάδα. Πάτημα με αύξοντα αριθμό.
  function SM_PMENU(skipSrc) {
    const SK = new RegExp(skipSrc, "i"), T = (e) => String((e && (e.innerText || e.textContent)) || "").replace(/\s+/g, " ").trim().replace(/\d{5,}/g, "#");
    const root = document.getElementById("appForm:patientRightMenu") || document.querySelector("[id$='patientRightMenu']"); if (!root) return { err: "δεν βρέθηκε το μενού ασθενή" };
    const L = [...root.querySelectorAll(".ui-menuitem-link")], out = [];
    L.forEach((e, i) => { const t = T(e); if (!t || t.length > 70) return; const pn = e.closest(".ui-panelmenu-panel"), h = pn && pn.querySelector(".ui-panelmenu-header"); const grp = T(h).slice(0, 50);
      out.push({ i, t, grp, key: (grp ? grp + " › " : "") + t, skip: SK.test(t) }); });
    return { items: out.slice(0, 120) };
  }
  function SM_PCLICK(i, t) {
    const T = (e) => String((e && (e.innerText || e.textContent)) || "").replace(/\s+/g, " ").trim().replace(/\d{5,}/g, "#");
    const root = document.getElementById("appForm:patientRightMenu") || document.querySelector("[id$='patientRightMenu']"); if (!root) return { err: "δεν βρέθηκε το μενού ασθενή" };
    const e = [...root.querySelectorAll(".ui-menuitem-link")][i]; if (!e || T(e) !== t) return { err: "το μενού άλλαξε" };
    e.click(); return { ok: 1 };
  }
  // μέσα σε καρτέλα ασθενή ΔΕΝ αρκεί η λίστα απαγόρευσης: πατιούνται ΜΟΝΟ αυτά (φίλτρα/προβολές), τίποτε άλλο.
  const SM_BTN_ALLOW_PT = "^(αναζήτηση|εμφάνιση όλων|εμφάνιση|προβολή όλων|φίλτρα?|καθαρισμός φίλτρων)$";

  G.SM = { SM_SKIP, SM_MENU, SM_CLICK, SM_SNAP, SM_TAB, SM_LEAVE, SM_ITEMS, SM_CLICKTXT, SM_BTN_DENY, SM_BTNS, SM_CLICKBTN, SM_CLOSE, SM_REC, SM_DRAIN, SM_PMENU, SM_PCLICK, SM_BTN_ALLOW_PT };
})(typeof self !== "undefined" ? self : globalThis);
