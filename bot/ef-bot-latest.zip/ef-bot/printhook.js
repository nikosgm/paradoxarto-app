// 🖨 14/11 21:26 (χρήστης: «να εκτυπώνει από όποιον υπολογιστή το προετοίμαζε»): φορτώνεται ΠΡΙΝ από κάθε σελίδα του Medilabi (document_start, MAIN).
// Η σελίδα στέλνει το barcode με SendOrderBarcodesToBarcodePrintSpooler(url) → jQuery GET http://localhost:8000/printorder/<αριθμοί δειγμάτων>.
// • ΠΑΝΤΑ: κρατά τη διεύθυνση (sessionStorage __efPrintUrls) — για «ξανά barcode».
// • ΜΟΝΟ όταν το bot «όπλισε» τη σελίδα (sessionStorage __efRemotePrint = "1", λίγο πριν την «Καταχώρηση» σε υπολογιστή ΑΛΛΟΝ από τον εκτυπωτή):
//   ΔΕΝ τυπώνει τοπικά — το bot στέλνει την ίδια διεύθυνση στον υπολογιστή του εκτυπωτή. Αλλιώς τίποτα δεν αλλάζει.
(function () {
  try {
    if (window.__efPrintHook) return; window.__efPrintHook = 1;
    var isP = function (u) { return /^https?:\/\/(localhost|127\.0\.0\.1):8000\/printorder\//i.test(String(u || "")); };
    var armed = function () { try { return sessionStorage.getItem("__efRemotePrint") === "1"; } catch (e) { return false; } };
    var keep = function (u) { try { var a = JSON.parse(sessionStorage.getItem("__efPrintUrls") || "[]"); a.push({ u: String(u), at: Date.now(), held: armed() }); sessionStorage.setItem("__efPrintUrls", JSON.stringify(a.slice(-10))); } catch (e) {} };
    var O = XMLHttpRequest.prototype.open, S = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function (m, u) { try { this.__efU = u; } catch (e) {} return O.apply(this, arguments); };
    XMLHttpRequest.prototype.send = function () { try { if (isP(this.__efU)) { keep(this.__efU); if (armed()) return; } } catch (e) {} return S.apply(this, arguments); };
    if (window.fetch) { var F = window.fetch; window.fetch = function (u) { try { var s = typeof u === "string" ? u : (u && u.url); if (isP(s)) { keep(s); if (armed()) return Promise.resolve(new Response("OK")); } } catch (e) {} return F.apply(this, arguments); }; }
    var W = window.open; window.open = function (u) { try { if (isP(u)) { keep(u); if (armed()) return null; } } catch (e) {} return W.apply(this, arguments); };
  } catch (e) {}
})();
