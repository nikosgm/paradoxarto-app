// Τρέχει μέσα σε κάθε σελίδα/πλαίσιο (iframe) του φακέλου.
// Κάνει: (α) εκμάθηση στοιχείων με κλικ, (β) εύρεση και εκτέλεση βημάτων.
// ⚡ ΕΛΑΦΡΥ: το script δουλεύει ΜΟΝΟ στις σελίδες του νοσοκομείου/ΗΔΙΚΑ/Παραδόχαρτου (όχι σε YouTube, Gmail, διαφημίσεις…).
// Άλλες διευθύνσεις: μόνο αν τις έχει μάθει ρητά το bot (efbotHosts).
var __efHost = (() => { try { return location.hostname || parent.location.hostname || ""; } catch (e) { return ""; } })();
var __efOk = /(^|\.)(gov\.gr|e-prescription\.gr|idika\.gr|laiko-net\.gr|laiko\.gr|paradoxarto1\.netlify\.app)$/i.test(__efHost) || /^(172\.(1[6-9]|2\d|3[01])\.|10\.|192\.168\.|127\.0\.0\.1$|localhost$)/.test(__efHost);
var __efRun = (fn) => { if (__efOk) return fn(); if (!__efHost) return; try { chrome.storage.local.get(["efbotHosts", "efbotEpLoginHost"]).then((s) => { const L = [...(s.efbotHosts || []), s.efbotEpLoginHost || ""]; if (L.includes(location.host) || L.includes(__efHost)) fn(); }).catch(() => {}); } catch (e) {} };
__efRun(() => {
  // Μετά από αυτόματη ανανέωση της επέκτασης, το παλιό script της σελίδας «πεθαίνει»· το νέο πρέπει να ξαναστήσει τα πάντα
  try { if (window.__efBotLoaded && window.__efBotAlive?.()) return; } catch (e) {}
  window.__efBotLoaded = true;
  window.__efBotAlive = () => { try { return !!chrome.runtime?.id; } catch (e) { return false; } };
  document.querySelectorAll("#__efbot_bar, [data-efbot-menu], [data-efbot-send]").forEach((n) => n.remove());
  // Ζωντανή παραλαβή εργασιών: η σελίδα του Παραδόχαρτου (συνδρομή στη βάση) μας ειδοποιεί με postMessage.
  // Μόνο «ξύπνημα»: το bot ξαναδιαβάζει την ουρά από τη βάση, δεν εμπιστεύεται τίποτα από το μήνυμα.
  if (window === window.top) window.addEventListener("message", (e) => {
    if (e.source !== window || !e.data) return;
    // 📡 ping από άλλο bot / το κινητό: απαντά ΜΟΝΟ αν απαντήσει το ίδιο το bot (service worker) σε 2,5″
    if (e.data.efbotPing === 1 && e.data.n) { const n = String(e.data.n).slice(0, 20); let done = false; const t = setTimeout(() => { done = true; }, 2500);
      try { chrome.runtime.sendMessage({ type: "efPing" }, (r) => { clearTimeout(t); void chrome.runtime.lastError; if (!done && r && r.bot) window.postMessage({ efbotPong: 1, n, r }, location.origin); }); } catch (x) {} }
    if (e.data.efbotJobsWake === 1) { try { chrome.runtime.sendMessage({ type: "jobsNow", id: +e.data.id || 0, st: String(e.data.st || "").slice(0, 20) }); } catch (x) {} }
    // νέος ασθενής στο Παραδόχαρτο → αυτόματες συννοσηρότητες τώρα (όχι στον επόμενο 5λεπτο κύκλο)
    if (e.data.efbotComorbWake === 1) { try { chrome.runtime.sendMessage({ type: "comorbWake" }); } catch (x) {} }
  });

  // Κίνηση ανθρώπου στον φάκελο (μόνο αληθινά κλικ/πλήκτρα, όχι του bot): το bot δεν «δανείζεται» τη σύνδεση όσο κάποιος δουλεύει
  if (/(^|\.)(e-ygeia|ehealthrecord)\.gov\.gr$/.test(location.hostname)) {
    let lastPing = 0;
    const ping = (e) => { if (!e.isTrusted) return; const n = Date.now(); if (n - lastPing < 10000) return; lastPing = n; try { chrome.runtime.sendMessage({ type: "emrInput" }); } catch (x) {} };
    for (const ev of ["pointerdown", "keydown", "wheel", "touchstart"]) window.addEventListener(ev, ping, { capture: true, passive: true });
  }

  // Κανονικοποίηση για ελληνικά: χωρίς τόνους/διαλυτικά, ς→σ, πεζά, ενιαία κενά
  const norm = (s) =>
    (s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/ς/g, "σ").replace(/\s+/g, " ").trim();
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  const isVisible = (el) => {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect();
    if (r.width === 0 && r.height === 0) return false;
    const cs = getComputedStyle(el);
    return cs.visibility !== "hidden" && cs.display !== "none" && cs.opacity !== "0";
  };

  const isEditable = (el) =>
    el &&
    ((el.tagName === "INPUT" &&
      !/^(button|submit|reset|checkbox|radio|image|file|hidden)$/i.test(el.type)) ||
      el.tagName === "TEXTAREA" ||
      el.isContentEditable);

  const ownText = (el) => {
    const t = (el.innerText || el.value || el.getAttribute("title") || "").trim();
    return t.length <= 80 ? t.replace(/\s+/g, " ") : "";
  };

  // Ένα id θεωρείται «σταθερό» αν δεν μοιάζει αυτόματα παραγόμενο
  const goodId = (id) =>
    id && !/\d{3,}|idt\d|^[a-f0-9-]{12,}$|^ext-|^gwt-|^ember\d|^react-/i.test(id);

  function cssPath(el) {
    const parts = [];
    let cur = el;
    while (cur && cur.nodeType === 1 && cur !== document.documentElement) {
      if (goodId(cur.id) && document.querySelectorAll("#" + CSS.escape(cur.id)).length === 1) {
        parts.unshift("#" + CSS.escape(cur.id));
        break;
      }
      let part = cur.tagName.toLowerCase();
      const parent = cur.parentElement;
      if (parent) {
        const same = [...parent.children].filter((c) => c.tagName === cur.tagName);
        if (same.length > 1) part += `:nth-of-type(${same.indexOf(cur) + 1})`;
      }
      parts.unshift(part);
      cur = parent;
    }
    return parts.join(" > ");
  }

  // Αν ο χρήστης κάνει κλικ σε <span> μέσα σε κουμπί, κρατάμε το κουμπί
  function promote(el) {
    const clickable = el.closest(
      "button, a, [role=button], [role=menuitem], [role=tab], [role=option], li, td, tr, label, option"
    );
    if (clickable && !isEditable(el) && el.tagName !== "SELECT") {
      // Μην ανεβαίνουμε σε τεράστια στοιχεία (π.χ. ολόκληρη γραμμή πίνακα με πολύ κείμενο)
      if ((clickable.innerText || "").length <= 200) return clickable;
    }
    return el;
  }

  function describe(el) {
    return {
      css: cssPath(el),
      tag: el.tagName.toLowerCase(),
      cls: [...el.classList].filter((c) => !/active|hover|focus|selected|highlight/i.test(c)).slice(0, 3),
      text: ownText(el),
      name: el.getAttribute("name") || "",
      aria: el.getAttribute("aria-label") || "",
      placeholder: el.getAttribute("placeholder") || "",
      title: el.getAttribute("title") || "",
      editable: !!isEditable(el),
      isSelect: el.tagName === "SELECT",
      framePath: location.pathname,
      host: location.host,
    };
  }

  // Στοιχεία του ίδιου του bot (κουμπί μενού, μπάρα) δεν πρέπει ποτέ να θεωρούνται στοιχεία της εφαρμογής
  const isOwn = (el) => !!el.closest?.("[data-efbot-menu], #__efbot_bar");

  // ---------- Εύρεση στοιχείου ----------
  function locate(t) {
    if (!t) return null;
    // Κρυφό στοιχείο (π.χ. «Ιατρικό Εξιτήριο» σε κλειστό μενού): το βρίσκουμε με CSS + κείμενο, χωρίς να χρειάζεται να φαίνεται
    if (t.hidden) {
      let list = [];
      try { list = [...document.querySelectorAll(t.css)]; } catch (e) {}
      const want = norm(t.text);
      return list.find((e) => !isOwn(e) && (!want || norm(e.textContent) === want)) || null;
    }
    const cands = [];
    const push = (el) => el && isVisible(el) && !isOwn(el) && !cands.includes(el) && cands.push(el);

    if (t.name) document.querySelectorAll(`${t.tag}[name="${CSS.escape(t.name)}"]`).forEach(push);
    if (t.aria) document.querySelectorAll(`${t.tag}[aria-label="${CSS.escape(t.aria)}"]`).forEach(push);
    if (t.placeholder)
      document.querySelectorAll(`${t.tag}[placeholder="${CSS.escape(t.placeholder)}"]`).forEach(push);

    let byCss = null;
    try { byCss = document.querySelector(t.css); } catch (e) {}
    if (byCss && isOwn(byCss)) byCss = null;

    // Αν το στοιχείο έχει κείμενο (κουμπί/σύνδεσμος), το κείμενο είναι πιο αξιόπιστο από τη θέση
    if (t.text && !t.editable) {
      const want = norm(t.text);
      if (byCss && isVisible(byCss) && norm(ownText(byCss)) === want) return byCss;
      const byText = [...document.querySelectorAll(t.tag)].filter(
        (e) => isVisible(e) && !isOwn(e) && norm(ownText(e)) === want
      );
      if (byText.length) return byText[0];
    }
    if (cands.length) return cands[0];
    if (byCss && isVisible(byCss)) return byCss;
    return null;
  }

  // Για ανάγνωση/έλεγχο το κείμενο αλλάζει ανά ασθενή, οπότε δεν ψάχνουμε με βάση το κείμενο
  function locateNoText(t) {
    return locate({ ...t, text: "" });
  }

  // Επιλογή γραμμής από λίστα/αποτελέσματα αναζήτησης με βάση το κείμενο
  let lastAmbiguous = 0;
  function locateChoice(t, value) {
    lastAmbiguous = 0;
    const want = norm(value);
    if (!want) return null;
    const toks = want.split(/[\s,.;]+/).filter((t) => t.length >= 2);
    // Αρχή λέξης: το «ΑΝΑΣΤΑΣΙΟΥ» δεν ταιριάζει μέσα στο «ΠΑΠΑΝΑΣΤΑΣΙΟΥ» (παρά μόνο ως έσχατη λύση)
    const atWord = (s, w) => {
      for (let i = s.indexOf(w); i >= 0; i = s.indexOf(w, i + 1))
        if (i === 0 || !/[\p{L}\p{N}]/u.test(s[i - 1])) return true;
      return false;
    };
    // Κωδικός ICD (π.χ. «E11.9», «N40», «I25.2»): ταίριασμα ΜΟΝΟ με τον ίδιο κωδικό, όχι «περιέχει».
    // Αλλιώς το «E11» θα έπιανε όποια γραμμή E11.x βρισκόταν πιο πάνω. Αν δοθεί κατηγορία 3 χαρακτήρων και
    // δεν υπάρχει στη λίστα ακριβώς, παίρνουμε το «.9» (μη καθορισμένο). Τίποτε άλλο: τότε «δεν βρέθηκε».
    const cm = /^([a-z])\s?(\d\d)(?:[.,]?(\d{1,2}))?$/.exec(want);
    const wc = cm ? cm[1] + cm[2] + (cm[3] || "") : "";
    const codeScore = (e) => {
      const s = norm(e.innerText || e.textContent);
      let best = -1000000;
      for (const m of s.matchAll(/(^|[^\p{L}\p{N}])([a-z])\s?(\d\d)(?:\.?(\d{1,2}))?(?![\p{L}\p{N}])/gu)) {
        const c = m[2] + m[3] + (m[4] || "");
        if (c === wc) best = Math.max(best, 1000 - s.length / 100);
        else if (cm && cm[3] === undefined && c === wc + "9") best = Math.max(best, 600 - s.length / 100);
      }
      return best;
    };
    const textScore = (e) => {
      const s = norm(e.innerText || e.textContent);
      if (s.includes(want)) {
        const w = atWord(s, want) ? 0 : -400;
        return (s === want ? 1000 : s.startsWith(want) ? 500 : 100) + w - s.length / 10;
      }
      // Όνομα με άλλη σειρά λέξεων (π.χ. «Γιώργος Παπαδόπουλος» ↔ «ΠΑΠΑΔΟΠΟΥΛΟΣ ΓΙΩΡΓΟΣ»)
      if (toks.length > 1 && toks.every((t) => s.includes(t))) return (toks.every((t) => atWord(s, t)) ? 50 : -300) - s.length / 10;
      return -1000000;
    };
    const score = cm ? codeScore : textScore;
    const pick = (list) => {
      let best = null, bestS = -1000000;
      for (const e of list) {
        if (!isVisible(e)) continue;
        const s = score(e);
        if (s > bestS) { best = e; bestS = s; }
      }
      return best;
    };
    // Προρυθμισμένος στόχος με «within»: ψάχνουμε ΜΟΝΟ μέσα σε αυτό το κομμάτι της σελίδας
    // (π.χ. αποτελέσματα αναζήτησης γιατρού), ώστε να μην πιάσει ίδιο όνομα σε άλλη λίστα (π.χ. ασθενών)
    if (t && t.within) {
      let root = null;
      try { root = document.querySelector(t.within); } catch (e) {}
      if (!root || !isVisible(root)) return null;
      const sig = t.tag + (t.cls || []).map((c) => "." + CSS.escape(c)).join("");
      let list = [];
      try { list = [...root.querySelectorAll(sig)]; } catch (e) {}
      if (!list.some(isVisible)) list = [...root.querySelectorAll("tr, li, [role=option], td")];
      // «unique» (π.χ. επιλογή ασθενή): αν ταιριάζουν 2+ γραμμές (ίδιο επώνυμο), ΔΕΝ μαντεύουμε
      if (t.unique) {
        const hits = list.filter((e) => isVisible(e) && score(e) > -200);
        if (hits.length > 1 && !hits.some((e) => norm(e.innerText || e.textContent) === want)) { lastAmbiguous = hits.length; return null; }
      }
      return pick(list);
    }
    if (t) {
      const sig = t.tag + t.cls.map((c) => "." + CSS.escape(c)).join("");
      let r = null;
      try { r = pick(document.querySelectorAll(sig)); } catch (e) {}
      if (r) return r;
      r = pick(document.querySelectorAll(t.tag));
      if (r) return r;
    }
    return pick(document.querySelectorAll("li, tr, td, option, [role=option], a, div, span"));
  }

  // ---------- Ενέργειες ----------
  function fire(el, type, extra = {}) {
    const Ctor = /^key/.test(type) ? KeyboardEvent : /^pointer/.test(type) ? PointerEvent : /^mouse|click/.test(type) ? MouseEvent : Event;
    el.dispatchEvent(new Ctor(type, { bubbles: true, cancelable: true, composed: true, view: window, ...extra }));
  }

  function setNativeValue(el, value) {
    const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
    setter.call(el, value);
  }

  function selectOption(sel, value) {
    const want = norm(value);
    const opt =
      [...sel.options].find((o) => norm(o.text) === want) ||
      [...sel.options].find((o) => norm(o.text).includes(want)) ||
      [...sel.options].find((o) => norm(o.value) === want);
    if (!opt) throw new Error(`Δεν βρέθηκε επιλογή «${value}» στη λίστα`);
    sel.value = opt.value;
    fire(sel, "input");
    fire(sel, "change");
  }

  // Γραμμή πίνακα: οι πίνακες PrimeFaces αγνοούν κλικ πάνω στο ίδιο το <tr> (θέλουν κελί <td> ή <span>).
  // Πατάμε το κελί με το κείμενο που ψάχνουμε (π.χ. το όνομα), αλλιώς το πρώτο ορατό κελί χωρίς κουμπιά/checkbox.
  function cellOf(tr, value) {
    const cells = [...tr.children].filter((c) => c.tagName === "TD" && isVisible(c));
    const want = norm(value), toks = want.split(/[\s,.;]+/).filter((x) => x.length >= 2);
    const plain = (c) => !c.querySelector("input, button, a, .ui-chkbox, .ui-radiobutton");
    return cells.find((c) => want && norm(c.innerText).includes(want)) ||
      cells.find((c) => toks.length && toks.every((x) => norm(c.innerText).includes(x))) ||
      cells.find((c) => plain(c) && norm(c.innerText)) || cells[0] || tr;
  }

  async function doClick(el, value) {
    // Λίστα PrimeFaces (selectOneMenu κ.λπ.): ανοίγει ΜΟΝΟ με κλικ στο βελάκι/κείμενο, όχι στο εξωτερικό πλαίσιο
    if (el.matches(".ui-selectonemenu, .ui-selectcheckboxmenu, .ui-autocomplete-multiple-container"))
      el = el.querySelector(".ui-selectonemenu-trigger, .ui-selectcheckboxmenu-trigger, .ui-selectonemenu-label, .ui-selectcheckboxmenu-label") || el;
    el.scrollIntoView({ block: "center", inline: "center" });
    await sleep(50);
    if (el.tagName === "SELECT") {
      if (value) return selectOption(el, value);
    }
    // Checkbox/radio: τσεκάρισμα μόνο αν δεν είναι ήδη τσεκαρισμένο
    const box = el.matches("input[type=checkbox], input[type=radio]") ? el
      : el.tagName === "LABEL" ? (el.control || el.querySelector("input[type=checkbox], input[type=radio]")) : null;
    if (box && box.checked) return;
    if (el.tagName === "OPTION") {
      const sel = el.closest("select");
      if (sel) { sel.value = el.value; fire(sel, "input"); fire(sel, "change"); return; }
    }
    fire(el, "pointerdown"); fire(el, "mousedown");
    el.focus?.();
    fire(el, "pointerup"); fire(el, "mouseup");
    el.click();
  }

  async function doFill(el, value, pressEnter) {
    el.scrollIntoView({ block: "center" });
    el.focus();
    if (el.tagName === "SELECT") return selectOption(el, value);
    if (el.isContentEditable) {
      el.innerText = value;
      fire(el, "input");
    } else {
      setNativeValue(el, "");
      fire(el, "input");
      setNativeValue(el, value);
      fire(el, "input");
      // Μερικά πεδία αναζήτησης ακούνε πλήκτρα για να ξεκινήσουν την αναζήτηση
      const last = value.slice(-1);
      fire(el, "keydown", { key: last }); fire(el, "keyup", { key: last });
      fire(el, "change");
    }
    if (pressEnter) {
      for (const t of ["keydown", "keypress", "keyup"])
        fire(el, t, { key: "Enter", code: "Enter", keyCode: 13, which: 13 });
    } else if (!el.isContentEditable) {
      // Πεδία ημερομηνίας/μάσκας ενημερώνουν την τιμή τους όταν χάσουν την εστίαση
      fire(el, "focusout"); fire(el, "blur");
    }
  }

  // Η εφαρμογή «φορτώνει»; (σελίδα δεν έχει φορτώσει, spinner, γκρι κάλυμμα κλπ)
  const BUSY_SEL = [
    "[aria-busy=true]", "[class*=spinner i]", "[class*=loading i]", "[class*=loader i]",
    "[id*=loading i]", "[class*=blockUI]", ".ui-widget-overlay", "[class*=busy i]", "[class*=progress-circular]",
  ].join(",");
  // Γκρι κάλυμμα πίσω από ανοιχτό παράθυρο (modal). ΔΕΝ σημαίνει «φορτώνει»: μένει όσο είναι ανοιχτή η φόρμα.
  const MASK_SEL = ".ui-dialog-mask, .ui-widget-overlay, .modal-backdrop, [class*=mask i], [class*=backdrop i]";
  const DIALOG_SEL = ".ui-dialog, [role=dialog], [role=alertdialog], .modal.show, .modal.in, dialog[open]";
  const dialogOpen = () => [...document.querySelectorAll(DIALOG_SEL)].some((d) => isVisible(d) && !isOwn(d));
  // Σύντομη περιγραφή στοιχείου για τη διάγνωση (μόνο ετικέτα/κλάσεις, ποτέ κείμενο)
  const tagOf = (el) => el ? el.tagName.toLowerCase() + [...el.classList].slice(0, 3).map((c) => "." + c).join("") : "";

  // Επιστρέφει περιγραφή του στοιχείου που δείχνει «φόρτωση», ή "" αν η σελίδα είναι ήσυχη
  function busyWhat(extraSel) {
    if (document.readyState !== "complete") return "σελίδα-φορτώνει";
    const sel = extraSel ? BUSY_SEL + "," + extraSel : BUSY_SEL;
    let list = [];
    try { list = document.querySelectorAll(sel); } catch (e) { list = document.querySelectorAll(BUSY_SEL); }
    let dlg = null;
    for (const el of list) {
      if (el === box || isOwn(el)) continue;
      const r = el.getBoundingClientRect();
      if (r.width < 12 || r.height < 12 || !isVisible(el)) continue;
      // Πεδία φόρμας ΔΕΝ είναι ένδειξη φόρτωσης. Π.χ. το αριθμητικό πεδίο του PrimeFaces (p:spinner, πεδίο ΗΜΒ/DRG
      // στο Εξιτήριο) έχει κλάση «ui-spinner» και έκανε το bot να περιμένει για πάντα μόλις άνοιγε η φόρμα.
      if (el.matches("input, select, textarea, .ui-spinner, .ui-spinner-button, .ui-inputfield") ||
          (el.querySelector("input:not([type=hidden]), select, textarea") && !el.matches("[aria-busy=true]"))) continue;
      if (el.matches(MASK_SEL) && !el.matches("[class*=blockui i]")) {
        if (dlg === null) dlg = dialogOpen();
        if (dlg) continue; // κάλυμμα πίσω από ανοιχτή φόρμα: όχι φόρτωση
      }
      return tagOf(el);
    }
    return "";
  }
  const isBusy = (extraSel) => !!busyWhat(extraSel);

  // Είναι το στοιχείο ορατό «από πάνω» (όχι κάτω από κάλυμμα); "clear" / "unknown" / περιγραφή καλύμματος
  function coverOf(el) {
    const r = el.getBoundingClientRect();
    const x = r.left + Math.min(r.width / 2, 20), y = r.top + r.height / 2;
    if (x < 0 || y < 0 || x >= innerWidth || y >= innerHeight) return "unknown"; // εκτός οθόνης
    const hit = document.elementFromPoint(x, y);
    if (!hit || hit === el || el.contains(hit) || hit.contains(el) || isOwn(hit) || hit === box) return "clear";
    // Ετικέτα/εικονίδιο του ίδιου πεδίου (π.χ. ημερολόγιο πάνω σε input) δεν είναι κάλυμμα
    const G = "label, .ui-calendar, .ui-inputgroup, .ui-autocomplete, .ui-selectonemenu, .ui-selectcheckboxmenu";
    const hg = hit.closest(G);
    if (hg && hg === el.closest(G)) return "clear";
    // Εικονίδιο/βελάκι μέσα στην ίδια επικεφαλίδα, κουμπί ή γραμμή (π.χ. το ▸ δίπλα στο «Ιατρικές Πράξεις»): δεν είναι κάλυμμα
    const C = "h1, h2, h3, h4, li, button, td, .ui-panelmenu-header, .ui-accordion-header, .ui-button, .ui-chkbox, .ui-menuitem";
    const own = el.closest(C);
    if (own && own.contains(hit)) return "clear";
    return tagOf(hit);
  }

  function findFor(step, value) {
    if (step.type === "choose") return locateChoice(step.target, value);
    if (step.type === "read" || step.type === "check" || step.type === "skipif") return locateNoText(step.target);
    return locate(step.target);
  }

  const readText = (el) =>
    (el.matches("input, textarea, select") ? (el.tagName === "SELECT" ? el.selectedOptions[0]?.text || "" : el.value) : el.innerText || "")
      .replace(/[ \t]+\n/g, "\n").trim();

  async function exec(step, value) {
    const el = findFor(step, value);
    if (!el) return { ok: false, error: "Δεν βρέθηκε το στοιχείο" };
    flash(el);
    if (step.type === "read" && step.asValue) {
      // «Παράλειψη αν ήδη έγινε»: αν δείξατε την ετικέτα αντί για το πεδίο, διαβάζουμε το πεδίο της
      let src = el;
      // Λίστα PrimeFaces (p:selectOneMenu): η τιμή που φαίνεται είναι στο «.ui-selectonemenu-label»,
      // όχι στο κρυφό input «…_focus» στο οποίο δείχνει η ετικέτα
      const som = (el.tagName === "LABEL" && el.control?.closest(".ui-selectonemenu")) || el.closest(".ui-selectonemenu");
      if (som) src = som.querySelector(".ui-selectonemenu-label") || el;
      else if (!el.matches("input, textarea, select")) {
        src = (el.tagName === "LABEL" && el.control) ||
          el.querySelector(".ui-selectonemenu-label, input:not([type=hidden]):not([type=checkbox]):not([type=radio]), textarea, select") ||
          (el.htmlFor && document.getElementById(el.htmlFor)) || el;
      }
      let text = readText(src);
      // «Παρακαλώ επιλέξτε» = κενή λίστα
      if (/^παρακαλω επιλεξτε/.test(norm(text))) text = "";
      return { ok: true, text, tag: tagOf(src), field: src !== el || el.matches("input, textarea, select") };
    }
    if (step.type === "read") {
      // Με φίλτρο γραμμών (π.χ. εργαστηριακά) διαβάζουμε ολόκληρο τον πίνακα/λίστα, όχι μόνο το κελί
      const src = step.filter ? el.closest("table, ul, ol, [role=grid], [role=table]") || el : el;
      return { ok: true, text: readText(src) };
    }
    if (step.type === "check") {
      const got = readText(el);
      const strip = (s) => norm(s).replace(/[\s.\-/]/g, "");
      const toks = norm(value).split(/[\s,.;]+/).filter((t) => t.length >= 2);
      const g = norm(got);
      const same = (strip(got).includes(strip(value)) && strip(value)) || (toks.length > 1 && toks.every((t) => g.includes(t)));
      return same
        ? { ok: true }
        : { ok: false, error: `ΑΣΥΜΦΩΝΙΑ: περίμενα «${value}», βρήκα «${got.slice(0, 60)}». Η εκτέλεση σταμάτησε.` };
    }
    try {
      if (step.type === "fill") await doFill(el, step.target?.upper ? value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase() : value, step.enter);
      else if (el.tagName === "TR" && step.target?.clickSel) {
        // Στοιχείο μέσα στη γραμμή (π.χ. checkbox, κουμπί «Κύρια»). Αν είναι ήδη ενεργό, δεν το ξαναπατάμε (θα ακυρωνόταν).
        const inner = el.querySelector(step.target.clickSel);
        if (!inner) return { ok: false, error: "Δεν βρέθηκε το κουμπί μέσα στη γραμμή" };
        if (step.target.skipIfSel && inner.matches(step.target.skipIfSel)) return { ok: true, already: true };
        await doClick(inner, value);
      }
      else if (el.tagName === "TR") await doClick(cellOf(el, value), value);
      else await doClick(el, value);
      return { ok: true };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  }

  function flash(el) {
    const prev = el.style.outline;
    el.style.outline = "3px solid #f59e0b";
    setTimeout(() => (el.style.outline = prev), 900);
  }

  // ---------- Εκμάθηση (επιλογή στοιχείου με κλικ) ----------
  let picking = null, box = null, hovered = null;

  function ensureBox() {
    if (box) return box;
    box = document.createElement("div");
    Object.assign(box.style, {
      position: "fixed", zIndex: 2147483647, pointerEvents: "none",
      border: "2px solid #2563eb", background: "rgba(37,99,235,.15)", borderRadius: "3px",
      transition: "all 40ms",
    });
    document.documentElement.appendChild(box);
    return box;
  }

  const onMove = (e) => {
    hovered = promote(e.target);
    const r = hovered.getBoundingClientRect();
    Object.assign(ensureBox().style, {
      display: "block", left: r.left + "px", top: r.top + "px", width: r.width + "px", height: r.height + "px",
    });
  };
  const swallow = (e) => { e.preventDefault(); e.stopImmediatePropagation(); };
  const onClick = (e) => {
    swallow(e);
    const el = promote(e.target);
    chrome.runtime.sendMessage({ type: "picked", stepId: picking, desc: describe(el) });
    stopPick();
  };
  const onKey = (e) => { if (e.key === "Escape") { stopPick(); chrome.runtime.sendMessage({ type: "pickCancel" }); } };

  function startPick(stepId) {
    stopPick();
    picking = stepId;
    document.addEventListener("mousemove", onMove, true);
    for (const t of ["mousedown", "mouseup", "pointerdown", "pointerup"]) document.addEventListener(t, swallow, true);
    document.addEventListener("click", onClick, true);
    document.addEventListener("keydown", onKey, true);
  }
  function stopPick() {
    if (picking === null) return;
    picking = null;
    document.removeEventListener("mousemove", onMove, true);
    for (const t of ["mousedown", "mouseup", "pointerdown", "pointerup"]) document.removeEventListener(t, swallow, true);
    document.removeEventListener("click", onClick, true);
    document.removeEventListener("keydown", onKey, true);
    if (box) box.style.display = "none";
  }


  // ---------- Κουμπί του bot μέσα στο μενού της εφαρμογής ----------
  // Ο χρήστης δείχνει ένα στοιχείο του μενού (Ρύθμιση → Γενικές ρυθμίσεις). Βάζουμε ένα αντίγραφό του δίπλα του,
  // ώστε να πάρει αυτόματα τη μορφή της εφαρμογής. Το κλικ ανοίγει μια μικρή λίστα με τις διαδικασίες.
  let menuItem = null, pop = null, menuObs = null, menuTimer = null;
  const msgBg = (m) => { try { chrome.runtime.sendMessage(m).catch(() => {}); } catch (e) {} };
  const launch = (m) => msgBg({ type: "launch", ...m });
  const DEFAULT_LABEL = "🩺 Βοηθός";

  // Αν το στοιχείο που έδειξε ο χρήστης είναι ο σύνδεσμος μέσα σε <li>, δουλεύουμε με ολόκληρο το <li>
  function menuItemOf(el) {
    const li = el.closest("li");
    if (li && li !== el && (li.innerText || "").trim().length <= (el.innerText || "").trim().length + 2) return li;
    return el;
  }

  function buildMenuClone(item, label) {
    const c = item.cloneNode(true);
    const all = [c, ...c.querySelectorAll("*")];
    for (const n of all) {
      n.removeAttribute("id");
      n.removeAttribute("onclick");
      n.removeAttribute("aria-current");
      n.removeAttribute("title");
      for (const k of [...n.classList]) if (/active|selected|current|expanded|open/i.test(k)) n.classList.remove(k);
    }
    c.querySelectorAll("img, svg, i:empty").forEach((n) => n.remove());
    const links = c.tagName === "A" ? [c, ...c.querySelectorAll("a")] : [...c.querySelectorAll("a")];
    links.forEach((a) => { a.setAttribute("href", "#"); a.removeAttribute("target"); });
    const walker = document.createTreeWalker(c, NodeFilter.SHOW_TEXT);
    const texts = [];
    for (let n; (n = walker.nextNode()); ) if (n.nodeValue.trim()) texts.push(n);
    if (texts.length) { texts[0].nodeValue = label; texts.slice(1).forEach((t) => (t.nodeValue = "")); }
    else c.appendChild(document.createTextNode(label));
    c.setAttribute("title", "Βοηθός Φακέλου");
    c.setAttribute("data-efbot-menu", "1");
    c.style.cursor = "pointer";
    return c;
  }

  function closePop() {
    pop?.remove(); pop = null;
    document.removeEventListener("mousedown", outside, true);
    document.removeEventListener("keydown", escClose, true);
  }
  const outside = (e) => { if (pop && !e.composedPath().includes(pop)) closePop(); };
  const escClose = (e) => { if (e.key === "Escape") closePop(); };

  async function openPop() {
    if (pop) return closePop();
    const { efbot } = await chrome.storage.local.get("efbot");
    const wfs = (efbot?.workflows || []).filter((w) => !w.hidden);
    const links = String(efbot?.settings?.linksText || "").split(/\r?\n/).map((l) => {
      const i = l.indexOf(";");
      return i < 0 ? null : { name: l.slice(0, i).trim(), url: l.slice(i + 1).trim() };
    }).filter((l) => l && l.name && /^https?:\/\//i.test(l.url));
    pop = document.createElement("div");
    pop.setAttribute("data-efbot-menu", "pop");
    pop.attachShadow({ mode: "open" });
    pop.shadowRoot.innerHTML = `
      <style>
        .p { position: fixed; z-index: 2147483647; width: 230px; max-height: 70vh; overflow: auto; background: #fff; color: #0f172a;
             border: 1px solid #cbd5e1; border-radius: 10px; box-shadow: 0 8px 24px rgba(0,0,0,.25); padding: 6px;
             font: 13px system-ui, "Segoe UI", sans-serif; }
        button { display: block; width: 100%; text-align: left; border: 0; background: none; padding: 7px 9px; border-radius: 6px; cursor: pointer; font: inherit; color: inherit; }
        button:hover { background: #e0e7ff; }
        .h { font-size: 11px; color: #64748b; padding: 6px 9px 2px; font-weight: 600; }
        hr { border: 0; border-top: 1px solid #e2e8f0; margin: 5px 0; }
      </style>
      <div class="p"></div>`;
    const box = pop.shadowRoot.querySelector(".p");
    const add = (txt, fn, cls) => {
      const b = document.createElement("button");
      b.textContent = txt;
      b.onclick = () => { closePop(); fn(); };
      box.appendChild(b);
    };
    const hdr = (t) => { const d = document.createElement("div"); d.className = "h"; d.textContent = t; box.appendChild(d); };
    hdr("ΔΙΑΔΙΚΑΣΙΕΣ");
    for (const w of wfs) add(w.name, () => launch({ wfId: w.id }));
    box.appendChild(document.createElement("hr"));
    add("👥 Μαζική εκτέλεση για λίστα ασθενών", () => launch({ view: "bulk" }));
    add("🔔 Παρακολούθηση νέων εργαστηριακών", () => launch({ view: "monitor" }));
    if (links.length) {
      box.appendChild(document.createElement("hr"));
      hdr("ΓΡΗΓΟΡΕΣ ΔΙΕΥΘΥΝΣΕΙΣ");
      for (const l of links) add("↗ " + l.name, () => msgBg({ type: "openUrl", url: l.url }));
    }
    document.documentElement.appendChild(pop);
    // Θέση: δεξιά του στοιχείου αν το μενού είναι αριστερά (κάθετο), αλλιώς από κάτω
    const r = menuItem.getBoundingClientRect(), W = 230;
    let left, top;
    if (r.left < 140 && r.right + W + 8 < innerWidth) { left = r.right + 4; top = r.top; }
    else { left = Math.min(Math.max(8, r.left), innerWidth - W - 8); top = r.bottom + 4; }
    const h = box.getBoundingClientRect().height;
    top = Math.max(8, Math.min(top, innerHeight - h - 8));
    box.style.left = left + "px"; box.style.top = top + "px";
    document.addEventListener("mousedown", outside, true);
    document.addEventListener("keydown", escClose, true);
  }

  function unmountMenu() {
    closePop();
    document.querySelectorAll('[data-efbot-menu="1"]').forEach((n) => n.remove());
    menuItem = null;
    menuObs?.disconnect(); menuObs = null;
  }

  async function syncMenu() {
    const { efbot, efbotHosts, efbotMenu } = await chrome.storage.local.get(["efbot", "efbotHosts", "efbotMenu"]);
    const cfg = efbotMenu?.[location.host];
    const on = (efbotHosts || []).includes(location.host) && cfg?.target && cfg.target.framePath === location.pathname;
    if (!on) { unmountMenu(); return; }
    const label = efbot?.settings?.menuLabel || DEFAULT_LABEL;
    if (menuItem?.isConnected) {
      if (menuItem.dataset.label !== label) { menuItem.remove(); menuItem = null; } else return;
    }
    // Αντίγραφα του κουμπιού που έμειναν «νεκρά» (π.χ. η εφαρμογή ξαναέγραψε το HTML του μενού) σβήνονται
    document.querySelectorAll('[data-efbot-menu="1"]').forEach((n) => n.remove());
    const anchor = locate(cfg.target);
    if (!anchor) { watchMenu(); return; }
    const item = menuItemOf(anchor);
    menuItem = buildMenuClone(item, label);
    menuItem.dataset.label = label;
    menuItem.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); openPop(); }, true);
    for (const t of ["mousedown", "mouseup", "pointerdown", "pointerup"]) menuItem.addEventListener(t, (e) => e.stopPropagation());
    item.insertAdjacentElement("afterend", menuItem);
    watchMenu();
  }
  // Οι σύγχρονες εφαρμογές ξαναζωγραφίζουν το μενού· αν χαθεί το κουμπί, το ξαναβάζουμε
  function watchMenu() {
    if (menuObs) return;
    menuObs = new MutationObserver(() => {
      if (menuItem?.isConnected) return;
      clearTimeout(menuTimer);
      menuTimer = setTimeout(syncMenu, 400);
    });
    menuObs.observe(document.documentElement, { childList: true, subtree: true });
  }

  // ---------- Πλωτή εργαλειοθήκη (μόνο στο κύριο παράθυρο) ----------
  // Εμφανίζεται όταν δεν έχει οριστεί κουμπί στο μενού, ή αν το ζητήσει ο χρήστης (Γενικές ρυθμίσεις).
  let bar = null;
  async function renderBar() {
    if (window.top !== window) return;
    const { efbot, efbotHosts, efbotMenu } = await chrome.storage.local.get(["efbot", "efbotHosts", "efbotMenu"]);
    const hasMenu = !!efbotMenu?.[location.host]?.target;
    const show = (efbotHosts || []).includes(location.host) && (!hasMenu || efbot?.settings?.barAlso);
    if (!show) { bar?.remove(); bar = null; return; }
    if (!bar) {
      bar = document.createElement("div");
      bar.id = "__efbot_bar";
      bar.attachShadow({ mode: "open" });
      document.documentElement.appendChild(bar);
    }
    const wfs = (efbot?.workflows || []).filter((w) => !w.hidden);
    const pos = efbot?.settings?.barPos || "bottom-right";
    const sig = pos + "|" + wfs.map((w) => w.id + ":" + w.name).join("|");
    if (bar.dataset.sig === sig) return;
    bar.dataset.sig = sig;
    const [v, h] = pos.split("-");
    bar.shadowRoot.innerHTML = `
      <style>
        .w { position: fixed; ${v}: 14px; ${h}: 14px; z-index: 2147483646; display: flex; gap: 6px; align-items: center;
             font: 600 13px system-ui, "Segoe UI", sans-serif; background: #0f172a; padding: 6px; border-radius: 10px;
             box-shadow: 0 4px 14px rgba(0,0,0,.25); flex-wrap: wrap; max-width: 70vw; }
        button { border: 0; border-radius: 7px; padding: 7px 11px; cursor: pointer; font: inherit; background: #2563eb; color: #fff; }
        button:hover { background: #1d4ed8; }
        .min { background: #334155; padding: 7px 9px; }
        .w.c button:not(.min) { display: none; }
      </style>
      <div class="w ${sessionStorage.__efbotMin ? "c" : ""}">
        <button class="min" title="Βοηθός Φακέλου (απόκρυψη/εμφάνιση)">🩺</button>
        ${wfs.map((w) => `<button data-id="${w.id}"></button>`).join("")}
      </div>`;
    bar.shadowRoot.querySelectorAll("button[data-id]").forEach((b) => {
      b.textContent = wfs.find((w) => w.id === b.dataset.id).name;
      b.onclick = () => launch({ wfId: b.dataset.id });
    });
    bar.shadowRoot.querySelector(".min").onclick = () => {
      const w = bar.shadowRoot.querySelector(".w");
      w.classList.toggle("c");
      if (w.classList.contains("c")) sessionStorage.__efbotMin = "1"; else delete sessionStorage.__efbotMin;
    };
  }
  // Η εκμάθηση ενεργοποιείται μέσω storage, ώστε να πιάνει και πλαίσια/καρτέλες που φόρτωσαν αργότερα
  async function syncPick() {
    const { efbotPicking: p } = await chrome.storage.local.get("efbotPicking");
    if (p && Date.now() - p.ts < 5 * 60000) { if (picking !== p.stepId) startPick(p.stepId); }
    else stopPick();
  }
  syncPick();
  chrome.storage.onChanged.addListener((ch) => { if (ch.efbotPicking) syncPick(); });

  renderBar();
  syncMenu();
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== "local") return;
    if (ch.efbotHosts || ch.efbot || ch.efbotMenu) { renderBar(); syncMenu(); }
  });

  // ---------- Γέφυρα με το Παραδόχαρτο ----------
  // Στο παράθυρο «Εξιτήριο» του Παραδόχαρτου προσθέτουμε κουμπί «Έκδοση στον φάκελο». Με το κλικ στέλνουμε
  // όνομα, κείμενο και θεράποντα στο πάνελ, που ανοίγει τον ασθενή στον φάκελο και συμπληρώνει το εξιτήριο.
  // Τίποτα δεν φεύγει από τον υπολογιστή: το μήνυμα πάει μόνο στην επέκταση.
  const APP_HOSTS = ["paradoxarto.f7dg9j2bzy.workers.dev", "paradoxarto.pages.dev", "nikosgm.github.io", "paradoxarto1.netlify.app"];
  async function paradoxBridge() {
    if (window.top !== window) return;
    const { efbot } = await chrome.storage.local.get("efbot");
    const hosts = [...APP_HOSTS, ...String(efbot?.settings?.appHosts || "").split(/[\s,;]+/).filter(Boolean)];
    if (!hosts.includes(location.host)) return;
    const addBtn = () => {
      const ov = document.getElementById("dischOverlay");
      if (!ov || ov.querySelector("[data-efbot-send]")) return;
      const ta = ov.querySelector("textarea");
      const copyBtn = [...ov.querySelectorAll("button")].find((b) => /^Αντιγραφή/.test(b.textContent.trim()));
      if (!ta || !copyBtn) return;
      const b = document.createElement("button");
      b.setAttribute("data-efbot-send", "1");
      b.className = copyBtn.className;
      b.style.cssText = "flex:1.4;background:#0F7B4A;border-color:#0F7B4A;color:#fff";
      b.textContent = "📤 Έκδοση στον φάκελο";
      b.title = "Ανοίγει τον ασθενή στον ηλεκτρονικό φάκελο και συμπληρώνει το εξιτήριο (χωρίς Αποθήκευση)";
      b.onclick = () => {
        const lines = ta.value.split("\n");
        const head = (lines[0] || "").trim();
        const name = head.includes(" - ") ? head.split(" - ")[0].trim() : "";
        if (!name || /^Ασθενής υπεβλήθη/.test(head)) { b.textContent = "⚠ Λείπει το όνομα του ασθενή"; return; }
        const text = lines.slice(1).join("\n").replace(/^\s+/, "");
        const ther = document.querySelector("#therapistKeypad .key.selected")?.dataset.pick || "";
        // Μετά από ενημέρωση της επέκτασης, το κουμπί μιας ήδη ανοιχτής σελίδας «αποσυνδέεται»: το λέμε καθαρά
        const stale = () => { b.textContent = "⚠ Η επέκταση ανανεώθηκε: πατήστε F5 και ξαναδοκιμάστε"; };
        try { if (!chrome.runtime?.id) return stale(); } catch (e) { return stale(); }
        // Πρέπει να σταλεί αμέσως μέσα στο κλικ (για να ανοίξει το πάνελ)
        // Συννοσηρότητες (ICD-10) που έχουν οριστεί στο Παραδόχαρτο για τον ασθενή: μπαίνουν ως «Επιπλέον διαγνώσεις»
        const extraDx = String(ov.dataset.comorb || "").split(/[\s,;]+/).filter((c) => /^[A-Z]\d\d(\.\d{1,2})?$/.test(c)).slice(0, 40).join("\n");
        try { chrome.runtime.sendMessage({ type: "launch", wfId: "exitirio", app: { name, text, therapist: ther, extraDx } }).catch(stale); }
        catch (e) { return stale(); }
        b.textContent = "✓ Στάλθηκε στον φάκελο" + (extraDx ? ` (+${extraDx.split("\n").length} συννοσηρότητες)` : "");
        setTimeout(() => (b.textContent = "📤 Έκδοση στον φάκελο"), 2500);
      };
      copyBtn.insertAdjacentElement("beforebegin", b);
    };
    new MutationObserver(addBtn).observe(document.body, { childList: true });
    addBtn();
  }
  paradoxBridge();

  // ---------- Radio με ετικέτα (PrimeNG p-radiobutton, κανονικά input[type=radio], role=radio) ----------
  function radioItems() {
    const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    const seen = new Set(), out = [];
    for (const el of document.querySelectorAll(".p-radiobutton, [role=radio], input[type=radio]")) {
      // το κρυφό input του PrimeNG ανήκει στο .p-radiobutton του
      const box = el.matches("input[type=radio]") ? (el.closest(".p-radiobutton, p-radiobutton") || el) : el;
      if (seen.has(box) || isOwn(box)) continue; seen.add(box);
      let clickEl = box.querySelector?.(".p-radiobutton-box") || box;
      const inp = box.matches("input") ? box : box.querySelector("input[type=radio]");
      let lab = "", labEl = null;
      const id = inp?.id;
      if (id) { try { labEl = document.querySelector(`label[for="${CSS.escape(id)}"]`); lab = labEl?.innerText || ""; } catch (e) {} }
      // ορατό το κουτάκι ή, αλλιώς, η ετικέτα του (κλικ στην ετικέτα επιλέγει κι αυτό το radio)
      if (!vis(clickEl)) { if (labEl && vis(labEl)) clickEl = labEl; else continue; }
      if (!lab) lab = box.getAttribute("aria-label") || box.closest("label")?.innerText || "";
      if (!lab) { const host = box.closest("p-radiobutton") || box; let n = host.nextElementSibling; if (n && /^(LABEL|SPAN|DIV)$/.test(n.tagName)) lab = n.innerText || ""; }
      if (!lab) { let p = box.parentElement; for (let i = 0; i < 3 && p && !lab; i++, p = p.parentElement) { const t = (p.innerText || "").trim(); if (t && t.length < 200) lab = t; } }
      const on = !!(inp?.checked || box.getAttribute("aria-checked") === "true" || box.querySelector?.(".p-highlight, .p-radiobutton-checked") || clickEl.matches?.(".p-highlight"));
      out.push({ clickEl, label: lab.replace(/\s+/g, " ").trim(), on });
    }
    return out;
  }
  async function radioPick(want, dry) {
    const items = radioItems();
    if (!items.length) return { present: false };
    const w = norm(want);
    const score = (l) => { const s = norm(l); return !w ? 0 : s === w ? 4 : s.startsWith(w) ? 3 : s.includes(w) ? 2 : (s && w.includes(s)) ? 1 : 0; };
    const best = Math.max(...items.map((x) => score(x.label)));
    const hits = items.filter((x) => best > 0 && score(x.label) === best);
    const labels = items.map((x) => x.label).filter(Boolean).slice(0, 12);
    if (hits.length !== 1) return { present: true, ok: false, labels, ambiguous: hits.length > 1 };
    if (dry) return { present: true, ok: true, labels };
    if (!hits[0].on) await doClick(hits[0].clickEl, "");
    return { present: true, ok: true, already: hits[0].on, labels };
  }

  // ---------- Ατομικός Φάκελος Υγείας (doctor.ehealthrecord.gov.gr) → 🩺 Συννοσηρότητες του Παραδόχαρτου ----------
  // Στη σελίδα των διαγνώσεων: κουμπί που μαζεύει όλους τους κωδικούς ICD-10 της σελίδας (με την περιγραφή της γραμμής)
  // και τους ρίχνει στο ανοιχτό παράθυρο 🩺 του Παραδόχαρτου. Αν δεν είναι ανοιχτό, μένουν στο πρόχειρο για επικόλληση.
  // Τίποτα δεν φεύγει από τον υπολογιστή: το κείμενο πάει μόνο από καρτέλα σε καρτέλα του ίδιου Chrome.
  const EHR_HOSTS = ["doctor.ehealthrecord.gov.gr"];
  function ehrDiagnoses() {
    const btn = document.getElementById("efbot-ehr-dx");
    const re = /(^|[^\p{L}\p{N}])([A-Z])(\d{2})(?:\.(\d{1,2}))?(?![\p{N}\/.])/gu;
    const DATE = /\d{1,2}[\/.-]\d{1,2}[\/.-]\d{2,4}(\s+\d{1,2}:\d{2}(:\d{2})?)?/g;
    const clean = (t) => String(t || "").replace(DATE, " ").replace(/^[\s\-–—:|,;]+|[\s\-–—:|,;]+$/g, "").replace(/\s+/g, " ");
    const isDesc = (t) => t.length >= 3 && /\p{L}{3}/u.test(t) && !/^\d/.test(t);
    const found = new Map();
    for (const raw of document.body.innerText.split(/\n/)) {
      if (!raw.trim() || (btn && raw.includes(btn.innerText))) continue;
      // γραμμή πίνακα: τα κελιά χωρίζονται με tab. Περιγραφή = το υπόλοιπο του κελιού του κωδικού ή το ΕΠΟΜΕΝΟ κελί με κείμενο
      const cells = raw.split("\t").map((c) => c.replace(/\s+/g, " ").trim());
      cells.forEach((cell, ci) => {
        const hits = [...cell.matchAll(re)];
        hits.forEach((m, i) => {
          const code = m[2] + m[3] + (m[4] !== undefined ? "." + m[4] : "");
          const from = m.index + m[0].length, to = i + 1 < hits.length ? hits[i + 1].index : cell.length;
          let d = clean(cell.slice(from, to));
          if (!isDesc(d) && hits.length === 1) { const nx = cells.slice(ci + 1).map(clean).find((c) => c && !re.test(c) && (re.lastIndex = 0, true) && isDesc(c)); re.lastIndex = 0; d = nx || ""; }
          if (!isDesc(d)) d = "";
          if (!found.has(code) || (!found.get(code) && d)) found.set(code, d.slice(0, 90));
        });
      });
    }
    return [...found].map(([c, d]) => c + (d ? " " + d : ""));
  }
  // Όλες οι διαγνώσεις: καρτέλα «Όλες οι διαγνώσεις» και όλες οι σελίδες του πίνακα (PrimeNG paginator)
  async function ehrDiagnosesAll() {
    const tab = [...document.querySelectorAll("[role=tab]")].find((t) => norm(t.innerText) === norm("Όλες οι διαγνώσεις"));
    if (tab && tab.getAttribute("aria-selected") !== "true" && !tab.closest(".p-highlight")) { tab.click(); await waitFor(() => tab.getAttribute("aria-selected") === "true" || tab.closest(".p-highlight"), 4000); await waitFor(() => ehrDiagnoses().length, 3000); }
    const all = new Map();
    for (let page = 0; page < 30; page++) {
      for (const l of ehrDiagnoses()) { const c = l.split(" ")[0]; if (!all.has(c) || (all.get(c) === c && l !== c)) all.set(c, l); }
      const nx = document.querySelector('button.p-paginator-next, button[aria-label="Επόμενη Σελίδα"]');
      if (!nx || nx.disabled || nx.classList.contains("p-disabled")) break;
      const before = (document.querySelector(".p-datatable tbody") || document.body).innerText;
      nx.click();
      await waitFor(() => (document.querySelector(".p-datatable tbody") || document.body).innerText !== before, 5000);
    }
    return [...all.values()];
  }
  // Αναμονή μέχρι να ισχύσει κάτι στη σελίδα. Ελέγχει σε κάθε αλλαγή της σελίδας (MutationObserver), όχι με χρονομετρητή:
  // σε καρτέλα στο παρασκήνιο ο Chrome αραιώνει τους χρονομετρητές (έως 1/λεπτό), τις αλλαγές της σελίδας όχι.
  function waitFor(pred, ms = 8000) {
    return new Promise((res) => {
      let v = null; try { v = pred(); } catch (e) {}
      if (v) return res(v);
      let done = false, to = null;
      const mo = new MutationObserver(() => { let x = null; try { x = pred(); } catch (e) {} if (x) fin(x); });
      const fin = (x) => { if (done) return; done = true; mo.disconnect(); clearTimeout(to); res(x); };
      mo.observe(document.documentElement, { childList: true, subtree: true, attributes: true, characterData: true });
      to = setTimeout(() => { let x = null; try { x = pred(); } catch (e) {} fin(x || null); }, ms);
    });
  }
  // ---- ΑΗΦΥ: εργαστηριακά ----
  // Πίνακας τιμών ενός παραπεμπτικού (στήλες: Ημερομηνία · Εξέταση · Κωδικός εξέτασης · ▲▼ · Αποτέλεσμα · Φυσιολογικές τιμές …)
  // → [ημ/νία ISO, εξέταση, LOINC, τιμή|null, μονάδα, φυσιολογικές, 'H'|'L'|'', κείμενο]
  function parseLabTable(tbl) {
    const ths = [...tbl.querySelectorAll(":scope > thead th")].map((th) => norm(th.innerText));
    const col = (t) => ths.findIndex((x) => x === norm(t));
    const iD = col("Ημερομηνία"), iN = col("Εξέταση"), iC = col("Κωδικός εξέτασης"), iR = col("Αποτέλεσμα εξέτασης"), iRef = col("Φυσιολογικές τιμές");
    if (iD < 0 || iN < 0 || iR < 0) return [];
    const iF = iR > 0 && ths[iR - 1] === "" ? iR - 1 : -1;
    const out = [];
    for (const tr of tbl.querySelectorAll(":scope > tbody > tr")) {
      const td = [...tr.children];
      if (td.length < ths.length) continue; // γραμμές ομάδας («˅ Σίδηρος») / φόρτωσης
      const tx = (i) => (i >= 0 && td[i] ? td[i].innerText.replace(/\s+/g, " ").trim() : "");
      const dm = /(\d{1,2})\/(\d{1,2})\/(\d{4})/.exec(tx(iD));
      if (!dm) continue;
      const iso = dm[3] + "-" + dm[2].padStart(2, "0") + "-" + dm[1].padStart(2, "0");
      const lo = /\((\d{1,7}-\d)\)/.exec(tx(iC));
      const res = tx(iR);
      const m = /^([<>≤≥]=?)?\s*(-?\d+(?:[.,]\d+)?)\s*(.*)$/.exec(res);
      const fl = tx(iF), flag = /▲|↑|\bH\b/.test(fl) ? "H" : /▼|↓|\bL\b/.test(fl) ? "L" : "";
      if (m) out.push([iso, tx(iN), lo ? lo[1] : "", parseFloat(m[2].replace(",", ".")), m[3].trim().slice(0, 24), tx(iRef).slice(0, 40), flag, m[1] ? res.slice(0, 40) : ""]);
      else if (res) out.push([iso, tx(iN), lo ? lo[1] : "", null, "", tx(iRef).slice(0, 40), flag, res.slice(0, 40)]);
    }
    return out;
  }
  // Πρόοδος της τρέχουσας ανάγνωσης: το bot τη ρωτά κάθε λίγα δευτερόλεπτα και στέλνει ό,τι μαζεύτηκε στο Παραδόχαρτο,
  // ώστε τα πρώτα (πιο πρόσφατα) να φαίνονται αμέσως και να μη χάνεται τίποτα αν η ανάγνωση κοπεί.
  let labsProg = null;
  async function ehrLabsAll(maxOrders, skip) {
    const skipSet = new Set(Array.isArray(skip) ? skip : []);
    labsProg = { rows: [], sigs: [], orders: 0, skipped: 0, done: false, t: Date.now() };
    const outer = () => [...document.querySelectorAll("p-table table")].find((t) => [...t.querySelectorAll(":scope > thead th")].some((th) => norm(th.innerText) === norm("Κατηγορία εξετάσεων")));
    const tabEl = () => [...document.querySelectorAll("[role=tab]")].find((t) => norm(t.innerText) === norm("Όλα τα αποτελέσματα"));
    await waitFor(() => tabEl() || outer(), 10000);
    const tab = tabEl();
    if (tab && tab.getAttribute("aria-selected") !== "true" && !tab.closest(".p-highlight")) { tab.click(); await waitFor(() => tabEl()?.getAttribute("aria-selected") === "true" && outer(), 5000); }
    await waitFor(outer, 10000);
    // ο πίνακας εμφανίζεται πρώτα ΑΔΕΙΟΣ και οι γραμμές έρχονται μετά από τον server: περιμένουμε γραμμές ή «δεν υπάρχουν»
    // ΠΡΟΣΟΧΗ: το μήνυμα «δεν υπάρχουν» εμφανίζεται και ΠΡΙΝ φτάσουν τα δεδομένα. Άρα: περιμένουμε γραμμές (έως 20″)
    // και μόνο αν δεν έρθουν, «κανένα παραπεμπτικό» = το μήνυμα είναι ακόμα εκεί και δεν φορτώνει τίποτα.
    const hasRows = () => { const T = outer(); return T && T.querySelector(":scope > tbody > tr.p-selectable-row") ? "rows" : null; };
    let state = await waitFor(hasRows, 20000);
    if (!state) {
      const T = outer();
      const loading = document.querySelector(".p-datatable-loading-overlay, .p-datatable-loading-icon, .pi-spinner, p-progressspinner");
      state = !T ? "notable" : !loading && [...T.querySelectorAll(":scope > tbody > tr")].some((tr) => /Δεν (υπάρχ|βρέθηκ)|δεν υπάρχουν|No records|No data/i.test(tr.innerText)) ? "empty" : "notloaded";
    }
    if (state !== "rows") { labsProg.done = true; return { rows: [], orders: 0, pages: 0, state }; }
    // Ταχύτητα (μετρημένη στον πραγματικό ΑΗΦΥ): 50 γραμμές ανά σελίδα και άνοιγμα των παραπεμπτικών ΜΑΖΙ, σε ομάδες των 10
    // (10 παραπεμπτικά: 0,3–0,4″ αντί για 2,2″ ένα-ένα). Όσα δεν άνοιξαν μέσα στην ομάδα, ξαναδοκιμάζονται ένα-ένα.
    const pageSig = (T) => [...T.querySelectorAll(":scope > tbody > tr.p-selectable-row")].map((r) => r.innerText.replace(/\s+/g, " ").trim()).join("¦");
    try {
      const T = outer(), dd = T?.closest("p-table")?.querySelector(".p-paginator .p-dropdown");
      if (dd && (dd.querySelector(".p-dropdown-label")?.innerText || "").trim() !== "50") {
        const before = pageSig(T);
        dd.click();
        const opt = await waitFor(() => [...document.querySelectorAll(".p-dropdown-items li, [role=option]")].find((o) => o.innerText.trim() === "50"), 3000);
        if (opt) { opt.click(); await waitFor(() => { const T2 = outer(); return T2 && pageSig(T2) && pageSig(T2) !== before; }, 6000); }
        else document.body.click();
      }
    } catch (e) {}
    const detailOf = (r) => {
      const det = r.nextElementSibling;
      const t = det && !det.classList.contains("p-selectable-row") ? det.querySelector("table") : null;
      return t && [...t.querySelectorAll(":scope > tbody > tr")].some((tr) => tr.children.length >= 6 || /Δεν βρέθηκ|No records/i.test(tr.innerText)) ? t : null;
    };
    const opener = (r) => r.querySelector(".pi-chevron-right")?.closest("button");
    const closer = (r) => r.querySelector(".pi-chevron-down")?.closest("button");
    const rows = [], seenPages = new Set();
    let orders = 0, pages = 0;
    for (let page = 0; page < 60; page++) {
      const T = outer(); if (!T) break;
      const sg = pageSig(T);
      if (seenPages.has(sg)) break; // η σελίδα δεν άλλαξε: τέλος
      seenPages.add(sg);
      pages++;
      const list = [...T.querySelectorAll(":scope > tbody > tr.p-selectable-row")].slice(0, Math.max(0, maxOrders - orders));
      // παραπεμπτικά που έχουν ήδη διαβαστεί (ίδια γραμμή = ίδια ημ/νία, κατηγορία και κατάσταση): δεν ξανανοίγουν
      const rowSig = (r) => r.innerText.replace(/\s+/g, " ").trim().slice(0, 160);
      const fresh = list.filter((r) => { if (skipSet.has(rowSig(r))) { labsProg.skipped++; return false; } return true; });
      for (let i = 0; i < fresh.length; i += 10) {
        const batch = fresh.slice(i, i + 10);
        batch.forEach((r) => opener(r)?.click());
        await waitFor(() => batch.every(detailOf), 15000);
        for (const r of batch) {
          let t = detailOf(r);
          if (!t) { if (!closer(r)) opener(r)?.click(); t = await waitFor(() => detailOf(r), 8000); }
          if (t) { const got = parseLabTable(t); rows.push(...got); labsProg.rows.push(...got); labsProg.sigs.push(rowSig(r)); }
        }
        batch.forEach((r) => closer(r)?.click());
        orders += batch.length; labsProg.orders = orders; labsProg.t = Date.now();
      }
      if (orders >= maxOrders) break;
      const nx = T.closest("p-table")?.querySelector(".p-paginator-next");
      if (!nx || nx.disabled || nx.classList.contains("p-disabled")) break;
      const before = pageSig(T);
      nx.click();
      // νέα σελίδα = άλλες γραμμές παραπεμπτικών (όχι απλώς «άλλαξε κάτι»: στο μεταξύ δείχνει «φορτώνει»/«δεν υπάρχουν»)
      await waitFor(() => { const T2 = outer(); if (!T2) return false; const s2 = pageSig(T2); return s2 && s2 !== before; }, 10000);
    }
    labsProg.done = true;
    return { rows, orders, pages, state: "rows", sigs: labsProg.sigs, skipped: labsProg.skipped };
  }
  function ehrBridge() {
    if (!EHR_HOSTS.includes(location.host)) return;
    const show = () => {
      const want = /diagnos/i.test(location.pathname + location.hash);
      let b = document.getElementById("efbot-ehr-dx");
      if (!want) { b?.remove(); return; }
      if (b || !document.body) return;
      b = document.createElement("button");
      b.id = "efbot-ehr-dx";
      b.setAttribute("data-efbot-own", "1");
      b.textContent = "🩺 Διαγνώσεις → Παραδόχαρτο";
      b.title = "Μαζεύει τους κωδικούς ICD-10 της σελίδας και τους στέλνει στο ανοιχτό παράθυρο 🩺 Συννοσηρότητες του Παραδόχαρτου";
      b.style.cssText = "position:fixed;right:18px;bottom:18px;z-index:2147483646;border:0;border-radius:999px;padding:12px 18px;font:700 15px system-ui,sans-serif;background:#0F7B4A;color:#fff;box-shadow:0 6px 18px rgba(0,0,0,.25);cursor:pointer";
      const label = (t, ms) => { b.textContent = t; if (ms) setTimeout(() => (b.textContent = "🩺 Διαγνώσεις → Παραδόχαρτο"), ms); };
      b.onclick = async () => {
        label("⏳ Συλλογή από όλες τις σελίδες…");
        const lines = await ehrDiagnosesAll().catch(() => ehrDiagnoses());
        if (!lines.length) return label("⚠ Δεν βρέθηκαν κωδικοί ICD-10 στη σελίδα", 3500);
        const text = lines.join("\n");
        try { await navigator.clipboard.writeText(text); } catch (e) {}
        let r = null;
        try { r = await chrome.runtime.sendMessage({ type: "comorbPaste", text, n: lines.length }); }
        catch (e) { return label("⚠ Η επέκταση ανανεώθηκε: πατήστε F5", 4000); }
        if (r?.filled) label(`✓ ${lines.length} κωδικοί → 🩺 ${r.name || "Παραδόχαρτο"}`, 4000);
        else label(`📋 ${lines.length} κωδικοί στο πρόχειρο — ανοίξτε 🩺 στο Παραδόχαρτο και «Επικόλληση»`, 6000);
      };
      document.body.appendChild(b);
    };
    show();
    setInterval(show, 1500); // εφαρμογή μιας σελίδας: η διεύθυνση αλλάζει χωρίς φόρτωση
  }
  if (window.top === window) ehrBridge();

  // ---------- Μηνύματα από το πάνελ ----------
  chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
    switch (msg.cmd) {
      case "ping": reply({ ok: true, path: location.pathname }); break;
      // Επιλογή radio με βάση το ΚΕΙΜΕΝΟ της ετικέτας (π.χ. λόγος πρόσβασης στον ΑΗΦΥ). present=false: δεν υπάρχουν radio στη σελίδα
      case "radioPick": radioPick(msg.want, !!msg.dry).then(reply, (e) => reply({ present: true, ok: false, error: e.message })); return true;
      // ΑΗΦΥ: κωδικοί ICD-10 της σελίδας διαγνώσεων (για τις αυτόματες συννοσηρότητες στο παρασκήνιο)
      // ΑΗΦΥ: όλα τα εργαστηριακά (Εργαστηριακές Εξετάσεις → κάθε παραπεμπτικό → πίνακας τιμών)
      case "ehrLabsProg": {
        const P = labsProg; if (!P) { reply({ none: true }); break; }
        const from = +msg.from || 0, sf = +msg.sfrom || 0;
        reply({ rows: P.rows.slice(from), n: P.rows.length, sigs: P.sigs.slice(sf), ns: P.sigs.length, orders: P.orders, done: P.done });
        break;
      }
      case "ehrLabs":
        if (!(window.top === window && EHR_HOSTS.includes(location.host))) { reply({ rows: [] }); break; }
        ehrLabsAll(msg.max || 300, msg.skip).then((r) => reply(r), (e) => reply({ rows: [], err: String(e && e.message || e) }));
        return true;
      case "ehrDx":
        if (!(window.top === window && EHR_HOSTS.includes(location.host))) { reply({ lines: [], text: 0 }); break; }
        ehrDiagnosesAll().then((lines) => reply({ lines, path: location.pathname, text: (document.body?.innerText || "").length }), () => reply({ lines: [], text: 1 }));
        return true;
      // ΑΗΦΥ: κείμενο της κάρτας του ασθενή που δείχνει αυτόν τον ΑΜΚΑ (για έλεγχο ονόματος)
      case "ehrCard": {
        let txt = "";
        const w2 = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
        for (let n; (n = w2.nextNode()); ) {
          const el = n.parentElement;
          if (!el || !el.offsetParent || el.closest("lib-doctor-card-compact, .layout-topbar") || !n.nodeValue.includes(msg.amka)) continue;
          txt = (el.closest(".p-card, lib-patient-card, [class*=patient]") || el.parentElement?.parentElement || el).innerText || "";
          break;
        }
        reply({ text: txt.replace(/\d{6,}/g, " ").slice(0, 400) });
        break;
      }
      // ΑΗΦΥ: ΑΜΚΑ ασθενή στην οθόνη — ΕΞΩ από την κάρτα του ιατρού στην πάνω μπάρα (εκεί είναι ο ΑΜΚΑ του γιατρού)
      case "ehrAmka": {
        const out = new Set();
        const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
        for (let n; (n = w.nextNode()); ) {
          const el = n.parentElement;
          if (!el || !el.offsetParent || el.closest("lib-doctor-card-compact, .layout-topbar, [data-efbot-own]")) continue;
          for (const m of n.nodeValue.matchAll(/(?<!\d)\d{11}(?!\d)/g)) out.add(m[0]);
        }
        reply({ list: [...out], path: location.pathname });
        break;
      }
      case "pickStart": startPick(msg.stepId); reply({ ok: true }); break;
      case "pickStop": stopPick(); reply({ ok: true }); break;
      case "find": {
        // Αν το στοιχείο υπάρχει και δεν καλύπτεται, προχωράμε ακόμα κι αν κάπου γυρίζει spinner.
        // Αν δεν μπορούμε να ξέρουμε (εκτός οθόνης), αποφασίζει η ένδειξη φόρτωσης.
        const bw = msg.busyOff ? "" : busyWhat(msg.busySel);
        const el = document.readyState === "complete" ? findFor(msg.step, msg.value) : null;
        const cov = el && !msg.step.target?.hidden ? coverOf(el) : "";
        const ready = !!el && (msg.step.target?.hidden || cov === "clear" || (cov === "unknown" && !bw));
        reply({ found: ready, seen: !!el, busy: !!bw, busyWhat: bw, coveredBy: cov === "clear" || cov === "unknown" ? "" : cov, ambiguous: lastAmbiguous,
                dialog: dialogOpen(), path: location.pathname });
        break;
      }
      case "busy": reply({ busy: msg.busyOff ? "" : busyWhat(msg.busySel) }); break;
      // Λίστα με σελίδες (PrimeFaces paginator): πόσες γραμμές ταιριάζουν σε αυτή τη σελίδα
      case "choiceCount": {
        const t = msg.step.target;
        let root = null;
        try { root = document.querySelector(t.within); } catch (e) {}
        if (!root) { reply({ ok: false }); break; }
        const sig = t.tag + (t.cls || []).map((c) => "." + CSS.escape(c)).join("");
        const want = norm(msg.value);
        const toks = want.split(/[\s,.;]+/).filter((x) => x.length >= 2);
        const atWord = (s, w) => { for (let i = s.indexOf(w); i >= 0; i = s.indexOf(w, i + 1)) if (i === 0 || !/[\p{L}\p{N}]/u.test(s[i - 1])) return true; return false; };
        let hits = 0;
        for (const e of root.querySelectorAll(sig)) {
          if (!isVisible(e)) continue;
          const s = norm(e.innerText || e.textContent);
          if ((s.includes(want) && atWord(s, want)) || (toks.length > 1 && toks.every((x) => atWord(s, x)))) hits++;
        }
        const cur = root.querySelector(".ui-paginator-current")?.textContent.trim() || "";
        reply({ ok: true, hits, cur });
        break;
      }
      // Αναζήτηση ασθενή: γράφει στο πεδίο (π.χ. Επώνυμο) και πατά «Αναζήτηση». Το πεδίο μπορεί να είναι σε κλειστό πλαίσιο.
      case "searchSet": {
        let inp = null, btn = null;
        try { inp = document.querySelector(msg.field); btn = document.querySelector(msg.button); } catch (e) {}
        if (!inp || !btn) { reply({ ok: false }); break; }
        const before = document.querySelector(msg.within + " .ui-paginator-current")?.textContent || "";
        setNativeValue(inp, msg.value);
        fire(inp, "input"); fire(inp, "change");
        btn.click();
        reply({ ok: true, before });
        break;
      }
      // Κουμπί σελίδας: first / next. Δεν πατιέται αν είναι ανενεργό.
      case "pager": {
        let root = null;
        try { root = document.querySelector(msg.within); } catch (e) {}
        // «page»: κατευθείαν στον αριθμό σελίδας (π.χ. 2), χωρίς να περάσουμε από την πρώτη
        const p = msg.action === "page"
          ? [...(root?.querySelectorAll(".ui-paginator-page") || [])].find((a) => a.textContent.trim() === String(msg.page))
          : root?.querySelector(".ui-paginator-" + msg.action);
        if (p && msg.action === "page" && p.classList.contains("ui-state-active")) { reply({ ok: false, already: true }); break; }
        if (!p) { reply({ ok: false, none: true }); break; }
        if (p.classList.contains("ui-state-disabled") || p.getAttribute("aria-disabled") === "true") { reply({ ok: false, disabled: true }); break; }
        doClick(p).then(() => reply({ ok: true }));
        return true;
      }
      case "exec": exec(msg.step, msg.value).then(reply); return true;
    }
  });
});

// ===== 🔑 «Μάθε τους κωδικούς»: μόνο όταν ο χρήστης το ενεργοποίησε στο πάνελ (15′), τη στιγμή που πατά «Είσοδος» =====
__efRun(function () {
  if (window.__efbotCredLearn) return; window.__efbotCredLearn = true;
  let armed = false, sent = false, auto = [];
  const ask = () => { try { chrome.runtime.sendMessage({ cmd: "credLearnArmed" }, (r) => { void chrome.runtime.lastError; armed = !!(r && r.armed); auto = (r && Array.isArray(r.auto)) ? r.auto : []; }); } catch (e) {} };
  const vis = (e) => { if (!e) return false; const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const hasPw = () => [...document.querySelectorAll("input[type=password]")].some(vis);
  if (hasPw()) ask(); else setTimeout(() => { if (hasPw()) ask(); }, 2500);
  // μόνο αληθινή ενέργεια ανθρώπου (όχι οι αυτόματες συνδέσεις του ίδιου του bot)
  const grab = (ev) => {
    if (sent || (ev && ev.isTrusted === false)) return;
    // Παραδόχαρτο: η σύνδεση εδώ αποθηκεύεται πάντα (μόνο στον υπολογιστή του νοσοκομείου — το αποφασίζει το background)
    if (/^paradoxarto1\.netlify\.app$/.test(location.host)) {
      const pw0 = document.getElementById("lgPw"), u0 = document.getElementById("lgEmail");
      if (pw0 && u0 && vis(pw0) && pw0.value && u0.value.trim()) { sent = true; try { chrome.runtime.sendMessage({ cmd: "pdxCredSave", user: u0.value.trim(), pass: pw0.value }, () => void chrome.runtime.lastError); } catch (e) {} setTimeout(() => { sent = false; }, 5000); }
      return;
    }
    if (!armed && !auto.length) return;
    const pw = [...document.querySelectorAll("input[type=password]")].find((e) => vis(e) && e.value);
    if (!pw) return;
    const form = pw.form || document;
    const fields = [...form.querySelectorAll("input:not([type=hidden]):not([type=password]):not([type=checkbox]):not([type=radio]):not([type=submit]):not([type=button])")].filter(vis);
    const userEl = fields.filter((f) => f.compareDocumentPosition(pw) & Node.DOCUMENT_POSITION_FOLLOWING).pop() || fields[0];
    if (!armed && !auto.includes(String(userEl ? userEl.value : "").trim().toLowerCase())) return;   // «δικοί μου» λογαριασμοί μόνο
    sent = true;
    try { chrome.runtime.sendMessage({ cmd: "credLearnSave", host: location.host, path: location.pathname, user: userEl ? userEl.value : "", pass: pw.value }, () => void chrome.runtime.lastError); } catch (e) {}
    setTimeout(() => { sent = false; }, 5000);
  };
  document.addEventListener("submit", grab, true);
  document.addEventListener("click", (e) => { if (e.target.closest && e.target.closest("button, input[type=submit], input[type=button], [role=button], a")) grab(e); }, true);
  document.addEventListener("keydown", (e) => { if (e.key === "Enter" && e.target && e.target.tagName === "INPUT") grab(e); }, true);
});
