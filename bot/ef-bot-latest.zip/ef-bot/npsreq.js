// 🗺 12/11 18:45 — ΦΑΣΗ 1 «χάρτης αιτημάτων ΝΠΣ» (χρήστης: «να ξέρουμε ακριβώς κάθε αίτημα, κάθε κλικ — μετά ίσως εντολές απευθείας στον server»).
// ΜΟΝΟ ΚΑΤΑΓΡΑΦΗ (καμία αλλαγή, κανένα νέο αίτημα): ό,τι στέλνει ήδη η σελίδα (XHR / fetch / υποβολή φόρμας) → sessionStorage.
// ΧΩΡΙΣ στοιχεία ασθενών: κρατιούνται ονόματα πεδίων (id με αριθμούς γραμμών → #), είδος τιμής (κείμενο/αριθμός/ημ-νία/κενό) και μόνο οι τιμές
// που είναι ονόματα στοιχείων της σελίδας (javax.faces.source/execute/render/event, ζεύγη κουμπιού κλειδί=κλειδί). ViewState: μόνο «υπάρχει».
(() => {
  if (window.__efReqOn) return; window.__efReqOn = 1;
  const KEY = "__efReqLog", MAX = 400;
  // 13/11 07:15 (χρήστης: «ξεκίνα ΟΛΑ τα απευθείας αιτήματα»): ΦΑΣΗ 1 και για e-prescription / ΑΗΦΥ / Medilabi — ίδιοι κανόνες (μόνο δομή, ποτέ τιμές).
  // JSON: ονόματα κλειδιών (έως βάθος 2) + είδος τιμής· απάντηση JSON: μόνο τα ονόματα των κλειδιών της.
  const SYS = /(^|\.)e-ygeia\.gov\.gr$/.test(location.host) ? "nps" : /(^|\.)e-prescription\.gr$/.test(location.host) ? "epres" : /(^|\.)ehealthrecord\.gov\.gr$/.test(location.host) ? "ahfy" : /\/Medilabi/i.test(location.pathname) ? "medilabi" : "";
  if (!SYS) return;
  const NP = (p) => N(p).replace(/\/\d+(?=\/|$)/g, "/#").replace(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f-]{20,}/gi, "#");
  const jkeys = (j, d, pre, out) => { if (!j || typeof j !== "object" || out.keys.length > 100) return; const o = Array.isArray(j) ? (j[0] && typeof j[0] === "object" ? j[0] : null) : j; if (!o) return;
    for (const k of Object.keys(o).slice(0, 60)) { const v = o[k], nk = (pre ? pre + "." : "") + N(k) + (Array.isArray(v) ? "[]" : ""); if (out.vals[nk] !== undefined) continue; out.keys.push(nk);
      out.vals[nk] = v === null ? "null" : typeof v === "object" ? (Array.isArray(v) ? "λίστα(" + v.length + ")" : "αντικείμενο") : typeof v === "boolean" ? String(v) : typeof v === "number" ? "αριθμός" : cls(String(v));
      if (v && typeof v === "object" && d < 2) jkeys(v, d + 1, nk.replace(/\[\]$/, ""), out); } };
  const N = (k) => String(k || "").replace(/j_idt\d+/g, "j").replace(/:\d+(?=[:_]|$)/g, ":#").replace(/\b\d{6,}\b/g, "#");
  const STRUCT = /^javax\.faces\.(source|partial\.(execute|render|event|ajax)|behavior\.event|partial\.resetValues)$|_(first|rows|page|pagination|sortField|sortOrder|filtering|encodeFeature|skipChildren|instantSelection|selection|scrollState|collapsed|activeIndex)$/;
  const cls = (v) => v === "" ? "∅" : /^(true|false|on|off)$/i.test(v) ? v.toLowerCase() : /^\d+$/.test(v) ? "αριθμός" : /^\d{1,2}\/\d{1,2}\/\d{4}( \d{1,2}:\d{2})?$/.test(v) ? "ημ/νία" : /^[\d.,]+$/.test(v) ? "δεκαδικός" : "κείμενο(" + Math.min(v.length, 999) + ")";
  const parse = (body) => {
    const o = { keys: [], vals: {}, vs: 0 };
    let s = body;
    if (!s) return o;
    if (typeof s === "string" && /^\s*[\[{]/.test(s)) { try { jkeys(JSON.parse(s), 0, "", o); o.json = 1; o.keys = o.keys.slice(0, 120); return o; } catch (e) {} }
    if (typeof s !== "string") { try { if (s instanceof URLSearchParams) s = s.toString(); else if (s instanceof FormData) s = new URLSearchParams([...s.entries()].filter((e) => typeof e[1] === "string")).toString(); else return { keys: ["(" + (s.constructor && s.constructor.name) + ")"], vals: {}, vs: 0 }; } catch (e) { return o; } }
    for (const kv of s.split("&")) {
      if (!kv) continue; const i = kv.indexOf("="); let k, v;
      try { k = decodeURIComponent((i < 0 ? kv : kv.slice(0, i)).replace(/\+/g, " ")); v = i < 0 ? "" : decodeURIComponent(kv.slice(i + 1).replace(/\+/g, " ")); } catch (e) { continue; }
      if (k === "javax.faces.ViewState" || /^__(VIEWSTATE|EVENTVALIDATION|VIEWSTATEGENERATOR)$/.test(k)) { o.vs = 1; continue; }
      if (k === "__EVENTTARGET") { o.keys.push(k); o.vals[k] = N(v).slice(0, 120); continue; }
      const nk = N(k); if (o.vals[nk] !== undefined) continue; o.keys.push(nk);
      o.vals[nk] = (STRUCT.test(k) || v === k) ? N(v).slice(0, 240) : cls(v);
    }
    o.keys = o.keys.slice(0, 120); return o;
  };
  const lbl = (id) => { try { const e = id && document.getElementById(id); if (!e) return "";
      const b = e.closest("button, .ui-button, .ui-menuitem-link, input[type=submit], input[type=button], .ui-commandlink, .ui-tabs-header, .ui-paginator-page, .ui-paginator-next, .ui-paginator-prev");
      if (!b) return "<" + e.tagName.toLowerCase() + (e.className ? "." + String(e.className).split(/\s+/).filter((c) => /^ui-/.test(c)).slice(0, 2).join(".") : "") + ">";
      return (b.title || b.value || b.innerText || "").replace(/\s+/g, " ").trim().replace(/\d{5,}/g, "#").slice(0, 50) || "<κουμπί χωρίς κείμενο>"; } catch (e) { return ""; } };
  const push = (r) => { try { const a = JSON.parse(sessionStorage.getItem(KEY) || "[]"); a.push(r); if (a.length > MAX) a.splice(0, a.length - MAX); sessionStorage.setItem(KEY, JSON.stringify(a)); } catch (e) {} };
  const resp = (txt, ct) => { const t = String(txt || ""); const o = { len: t.length, ct: String(ct || "").split(";")[0] };
    if (/partial-response/.test(t)) { o.upd = [...new Set([...t.matchAll(/<update id="([^"]+)"/g)].map((m) => N(m[1])))].slice(0, 25);
      o.err = /<error>|ui-messages-error|ui-message-error|validationFailed[^\w]{0,6}true/i.test(t); const rd = t.match(/<redirect url="([^"]+)"/); if (rd) o.redir = N(rd[1].split("?")[0]);
      const g = [...t.matchAll(/ui-messages-(?:error|warn|info)-summary">([^<]{1,120})/g)].map((m) => m[1].replace(/\d{5,}/g, "#")); if (g.length) o.msg = [...new Set(g)].slice(0, 4); }
    else if (/json/i.test(o.ct) && t.length < 400000) { try { const j = JSON.parse(t), x = { keys: [], vals: {} }; jkeys(j, 1, "", x); o.rk = x.keys.slice(0, 40); if (Array.isArray(j)) o.rn = j.length; } catch (e) {} }
    return o; };
  const rec = (m, url, body, st, ms, txt, ct, how) => { try {
      const u = new URL(url, location.href); if (SYS === "nps" ? !/e-ygeia\.gov\.gr$/.test(u.host) : /\.(js|css|png|jpe?g|gif|svg|woff2?|ico|map)$/i.test(u.pathname)) return;
      const p = parse(body), src = (p.vals["javax.faces.source"] || p.vals["__EVENTTARGET"] || "");
      push({ t: Date.now(), sys: SYS, how, page: NP(location.pathname), m: String(m || "GET").toUpperCase(), path: (u.host !== location.host ? u.host : "") + NP(u.pathname), json: p.json || undefined, q: [...u.searchParams.keys()].slice(0, 10), src, ev: p.vals["javax.faces.behavior.event"] || p.vals["javax.faces.partial.event"] || "", lbl: lbl(src.replace(/:#/g, ":0")), keys: p.keys, vals: p.vals, vs: p.vs, st, ms, ...resp(txt, ct) }); } catch (e) {} };
  // XHR (PrimeFaces ajax)
  const XO = XMLHttpRequest.prototype.open, XS = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, u) { this.__efM = m; this.__efU = u; return XO.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function (b) { const x = this, t0 = Date.now();
    x.addEventListener("loadend", () => { let txt = ""; try { txt = (x.responseType === "" || x.responseType === "text") ? x.responseText : ""; } catch (e) {} rec(x.__efM, x.__efU, b, x.status, Date.now() - t0, txt, x.getResponseHeader && x.getResponseHeader("content-type"), "xhr"); });
    return XS.apply(this, arguments); };
  // fetch
  if (window.fetch) { const F = window.fetch; window.fetch = function (i, o) { const t0 = Date.now(), url = typeof i === "string" ? i : (i && i.url) || "", m = (o && o.method) || (i && i.method) || "GET", b = o && o.body;
      return F.apply(this, arguments).then((r) => { try { const c = r.clone(); c.text().then((tx) => rec(m, url, b, r.status, Date.now() - t0, tx, r.headers.get("content-type"), "fetch")).catch(() => {}); } catch (e) {} return r; }); }; }
  // πλήρης υποβολή φόρμας (αλλαγή σελίδας)
  document.addEventListener("submit", (e) => { try { const f = e.target; const fd = new FormData(f); const s = e.submitter; if (s && s.name) fd.append(s.name, s.value || s.name);
      rec((f.method || "GET").toUpperCase(), f.action || location.href, fd, 0, 0, "", "", "form"); } catch (x) {} }, true);
  // φόρτωση σελίδας (πού βρισκόμαστε)
  push({ t: Date.now(), sys: SYS, how: "page", page: NP(location.pathname), q: [...new URLSearchParams(location.search).keys()].slice(0, 10), title: String(document.title || "").slice(0, 80), ref: N((document.referrer && new URL(document.referrer).pathname) || "") });
})();
