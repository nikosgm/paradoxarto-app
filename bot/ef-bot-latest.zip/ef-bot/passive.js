// 👀 14/11 (χρήστης: «το bot να εκμεταλλεύεται τη χρήση των υπολογιστών από εμάς»): ΑΘΟΡΥΒΗ παρατήρηση.
// Τρέχει ΜΟΝΟ στις καρτέλες των ανθρώπων (ΟΧΙ στο ανώνυμο παράθυρο του bot). ΚΑΝΕΝΑ κλικ, ΚΑΝΕΝΑ αίτημα, καμία αλλαγή στη σελίδα:
// όταν αλλάξει ό,τι βλέπει ο χρήστης (λίστα ασθενών ΝΠΣ, κ.λπ.) στέλνει ΜΟΝΟ ένα σήμα «άλλαξε» στο bot· το bot διαβάζει
// (μόνο ανάγνωση) την ίδια σελίδα και αποφασίζει. Τίποτα δεν αποθηκεύεται εδώ.
(() => {
  if (window.__efPassive) return; window.__efPassive = 1;
  try { if (chrome.extension.inIncognitoContext) return; } catch (e) { return; }
  const T = (e) => (e && (e.innerText || e.textContent) || "").replace(/\s+/g, " ").trim();
  const H = (s) => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0).toString(36); };
  // κάθε «σελίδα που ξέρουμε»: πώς φαίνεται + υπογραφή του περιεχομένου (μόνο για να καταλάβουμε ΑΛΛΑΓΗ)
  const PAGES = [
    { what: "npslist", sig: () => { const t = document.getElementById("appForm:tabview:patientsTable"); if (!t) return null;
        const rows = [...t.querySelectorAll("tbody tr[data-rk]")].map(T).join("|"); if (!rows) return null;
        const tot = ((document.body.innerText || "").match(/Σύνολο\s+ασθενών\s*:\s*(\d+)/) || [])[1] || "";
        return tot + "#" + T(document.querySelector("[id$='dptInput_label']")) + "#" + H(rows); } },
  ];
  const last = {}; let tm = 0;
  const tick = () => { for (const P of PAGES) { let s = null; try { s = P.sig(); } catch (e) {} if (!s || s === last[P.what]) continue; last[P.what] = s;
      try { const pr = chrome.runtime.sendMessage({ type: "efPassive", what: P.what }); if (pr && pr.catch) pr.catch(() => {}); } catch (e) {} } };
  const go = () => { clearTimeout(tm); tm = setTimeout(tick, 2500); };   // περιμένουμε να «ησυχάσει» η σελίδα
  try { new MutationObserver(go).observe(document.documentElement, { childList: true, subtree: true, characterData: true }); } catch (e) {}
  setTimeout(tick, 3000);
})();
