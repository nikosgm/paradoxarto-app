// 🖨 PDF → εικόνες (PNG) στο offscreen, για εκτύπωση χωρίς παράθυρο μέσω του vault «printhtml» (συνταγές/παραπεμπτικά e-prescription).
// Μόνο τοπικά (pdf.js μέσα στην επέκταση)· τίποτα δεν φεύγει από τον υπολογιστή.
import * as pdfjs from "./pdfjs/pdf.min.js";
pdfjs.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL("pdfjs/pdf.worker.min.js");
chrome.runtime.onMessage.addListener((msg, _s, reply) => {
  if (msg?.target !== "efbot-offscreen" || msg.op !== "pdf2png") return;
  (async () => {
    const bin = Uint8Array.from(atob(msg.b64), (c) => c.charCodeAt(0));
    const doc = await pdfjs.getDocument({ data: bin, isEvalSupported: false }).promise;
    const pages = [];
    for (let i = 1; i <= Math.min(doc.numPages, 10); i++) {
      const pg = await doc.getPage(i), vp = pg.getViewport({ scale: 2 });
      const c = document.createElement("canvas"); c.width = Math.ceil(vp.width); c.height = Math.ceil(vp.height);
      await pg.render({ canvasContext: c.getContext("2d"), viewport: vp }).promise;
      pages.push({ src: c.toDataURL("image/png"), w: vp.width / 2, h: vp.height / 2 });
    }
    return { ok: true, pages };
  })().then(reply, (e) => reply({ ok: false, err: String(e && e.message || e) }));
  return true;
});
