// 📧 8/11: αποστολή email από το Kerio Connect της κλινικής (JSON-RPC του webmail), για το «📷 Σάρωση προγράμματος».
// Καθαρός πελάτης: παίρνει fetch απ' έξω (στο bot: το fetch του service worker· στις δοκιμές: ψεύτικος server).
// Ροή: Session.login → (Session.whoAmI) → Folders.get → Contacts.get στους φακέλους επαφών → η ομάδα (λίστα διανομής)
// με το όνομα που δόθηκε → upload συνημμένου → Mails.create {send:true} → Session.logout.
// Ο κωδικός ΔΕΝ περνά από εδώ προς τα έξω· δεν γράφεται σε σημειώσεις/αποτελέσματα.
(function (root) {
  "use strict";
  const nz = (x) => String(x || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().replace(/[^A-ZΑ-Ω0-9@.]+/g, " ").trim();
  const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  function client(base, fetchFn) {
    base = String(base || "").replace(/\/+$/, "");
    let tok = "", n = 0;
    async function call(method, params) {
      const h = { "Content-Type": "application/json-rpc; charset=UTF-8", Accept: "application/json-rpc" };
      if (tok) h["X-Token"] = tok;
      const ctl = typeof AbortController !== "undefined" ? new AbortController() : null, tt = ctl && setTimeout(()=>ctl.abort(), 30000);
      let r; try { r = await fetchFn(base + "/webmail/api/jsonrpc/", { method: "POST", redirect: "error", credentials: "include", headers: h, body: JSON.stringify({ jsonrpc: "2.0", id: ++n, method, params: params || {} }), signal: ctl && ctl.signal }); } finally { if(tt) clearTimeout(tt); }
      let j = null; try { j = await r.json(); } catch (e) {}
      if (!j) throw new Error(method + ": HTTP " + r.status);
      if (j.error) { const e = new Error(method + ": " + (j.error.message || j.error.code || "σφάλμα")); e.code = j.error.code; throw e; }
      return j.result || {};
    }
    async function login(user, pass) {
      const r = await call("Session.login", { userName: user, password: pass, application: { name: "Paradoxarto", vendor: "Urology", version: "1.0" } });
      tok = r.token || ""; if (!tok) throw new Error("Session.login: χωρίς token");
      return true;
    }
    async function upload(bytes, name, type) {
      if (fetchFn.upload) { const j = await fetchFn.upload(base + "/webmail/api/jsonrpc/upload", tok, bytes, name, type || "application/octet-stream");
        if (!j || j.error) throw new Error("upload: " + ((j && j.error && j.error.message) || "σφάλμα")); const f = (j.result && (j.result.file || j.result)) || {}; if (!f.id) throw new Error("upload: χωρίς id"); return f; }
      const fd = new FormData();
      fd.append("newFile.bin", new Blob([bytes], { type: type || "application/octet-stream" }), name);
      const r = await fetchFn(base + "/webmail/api/jsonrpc/upload", { method: "POST", credentials: "include", headers: { "X-Token": tok }, body: fd });
      let j = null; try { j = await r.json(); } catch (e) {}
      if (!j || j.error) throw new Error("upload: " + ((j && j.error && j.error.message) || "HTTP " + r.status));
      const f = (j.result && (j.result.file || j.result)) || {};
      if (!f.id) throw new Error("upload: χωρίς id");
      return f;
    }
    async function logout() { try { await call("Session.logout", {}); } catch (e) {} tok = ""; }
    return { call, login, upload, logout, setToken(t) { tok = String(t || ""); }, get token() { return tok; } };
  }

  // Η σωστή διεύθυνση του webmail: το http://mail συχνά ΑΝΑΚΑΤΕΥΘΥΝΕΙ σε https:// — ένα POST που ακολουθεί ανακατεύθυνση
  // γίνεται GET χωρίς σώμα και το Kerio απαντά «Parse error». Γι' αυτό: πρώτα ένα GET στη σελίδα σύνδεσης και κρατάμε
  // την τελική διεύθυνση (scheme://host[:port]). Επιστρέφει [{base, via}] με τη σειρά που αξίζει να δοκιμαστούν.
  async function resolve(host, fetchFn, ms){
    const out = [], seen = new Set(), add = (b, via)=>{ b = String(b).replace(/\/+$/, ""); if(!seen.has(b)){ seen.add(b); out.push({ base: b, via }); } };
    for(const sch of ["http://", "https://"]){
      try{ const ctl = typeof AbortController !== "undefined" ? new AbortController() : null; const t = ctl && setTimeout(()=>ctl.abort(), ms || 10000);
        const r = await fetchFn(sch + host + "/webmail/login/", { method: "GET", redirect: "follow", credentials: "include", signal: ctl && ctl.signal }); if(t) clearTimeout(t);
        const u = new URL(r.url || (sch + host + "/")); add(u.origin, (r.redirected ? "↪ " : "") + r.status); }
      catch(e){}
    }
    if(!out.length){ add("http://" + host, "?"); add("https://" + host, "?"); }
    return out;
  }

  const Q = (fields) => ({ fields, start: 0, limit: 1000, conditions: [], combining: "And", orderBy: [] });

  // όλοι οι φάκελοι επαφών (προσωπικοί + δημόσιοι)
  async function contactFolders(cli) {
    const out = [];
    for (const m of ["Folders.get", "Folders.getPublic"]) {
      try { const r = await cli.call(m, {}); for (const f of r.list || []) if (f && f.type === "FContact") out.push({ id: f.id, name: f.name || "", pub: m !== "Folders.get", sub: f.subType || "" }); } catch (e) {}
    }
    return out;
  }
  async function mailFolders(cli) { try { const r = await cli.call("Folders.get", {}); return (r.list || []).filter((f) => f && f.type === "FMail"); } catch (e) { return []; } }

  // Μέλη λίστας διανομής: διευθύνσεις μέσα στη λίστα· όσα είναι μόνο αναφορές (refId) ανοίγουν με Contacts.getById.
  async function membersOf(cli, dl) {
    const out = [], refs = [];
    for (const a of dl.emailAddresses || []) {
      if (a && EMAIL.test(String(a.address || "").trim())) out.push({ name: a.name || "", address: String(a.address).trim() });
      else if (a && a.refId) refs.push(a.refId);
    }
    if (refs.length) {
      try {
        const r = await cli.call("Contacts.getById", { ids: refs });
        for (const c of r.result || []) {
          const e = (c.emailAddresses || []).find((x) => x && x.preferred && EMAIL.test(x.address || "")) || (c.emailAddresses || []).find((x) => x && EMAIL.test(x.address || ""));
          if (e) out.push({ name: c.commonName || "", address: e.address.trim() });
        }
      } catch (e) {}
    }
    const seen = new Set(); return out.filter((x) => { const k = x.address.toLowerCase(); if (seen.has(k)) return false; seen.add(k); return true; });
  }

  // Ομάδα με όνομα (χωρίς τόνους/πεζά). Επιστρέφει {group, members, groups (ονόματα όλων των ομάδων), folders}.
  async function findGroup(cli, name) {
    const want = nz(name), folders = await contactFolders(cli), groups = [];
    let hit = null;
    if (folders.length) {
      let r = null; try { r = await cli.call("Contacts.get", { folderIds: folders.map((f) => f.id), query: Q(["id", "folderId", "type", "commonName", "emailAddresses"]) }); } catch (e) {}
      for (const c of (r && r.list) || []) {
        if (!c || c.type !== "ctDistributionList") continue;
        groups.push(c.commonName || "");
        if (!hit && nz(c.commonName) === want) hit = c;
      }
      if (!hit) for (const c of (r && r.list) || []) if (c && c.type === "ctDistributionList" && want && nz(c.commonName).includes(want)) { hit = c; break; }
    }
    return { group: hit ? hit.commonName : "", members: hit ? await membersOf(cli, hit) : [], groups, folders: folders.map((f) => f.name) };
  }

  async function whoAmI(cli) { try { const r = await cli.call("Session.whoAmI", {}); const u = r.userDetails || r; return { name: u.fullName || "", address: u.primaryEmailAddress || u.loginName || "" }; } catch (e) { return null; } }

  // Αποστολή. to: [{name,address}] · att: {bytes, name, type} (προαιρετικό) · dry: σύνδεση+εύρεση ομάδας ΧΩΡΙΣ αποστολή.
  async function send(cli, o) {
    const to = (o.to || []).filter((x) => x && EMAIL.test(x.address || ""));
    if (!to.length) throw new Error("χωρίς παραλήπτες");
    const atts = [];
    if (o.att && o.att.bytes) { const f = await cli.upload(o.att.bytes, o.att.name || "scan.pdf", o.att.type || "application/pdf"); atts.push({ id: f.id, name: o.att.name || f.name || "scan.pdf", contentType: o.att.type || "application/pdf" }); }
    const mf = await mailFolders(cli), drafts = mf.find((f) => f.subType === "FSubDrafts"), me = o.from || (await whoAmI(cli));
    const mail = { subject: String(o.subject || ""), to: to.map((x) => ({ name: x.name || "", address: x.address })), cc: [], bcc: [],
      displayableParts: [{ contentType: "ctTextPlain", content: String(o.text || "") }], attachments: atts, send: true };
    if (drafts) mail.folderId = drafts.id;
    if (me && me.address && EMAIL.test(me.address)) mail.from = { name: me.name || "", address: me.address };
    const r = await cli.call("Mails.create", { mails: [mail] });
    if (r.errors && r.errors.length) throw new Error("Mails.create: " + (r.errors[0].message || JSON.stringify(r.errors[0]).slice(0, 120)));
    return { ok: true, n: to.length, att: atts.length };
  }

  // 📥 10/11 22:50 (χρήστης: «πάρε το ανεβασμένο πρόγραμμα σε PDF από το mail που στέλνουμε στο Kerio»): ΜΟΝΟ ανάγνωση απεσταλμένων.
  // Mails.get στον φάκελο «Απεσταλμένα» (subType FSubSent) — θέμα, ημερομηνία, συνημμένα (όνομα/τύπος/μέγεθος/url). Δεν αλλάζει τίποτα (ούτε «διαβάστηκε»).
  async function sentMails(cli, n) {
    const mf = await mailFolders(cli), sent = mf.find((f) => f.subType === "FSubSentItems" || f.subType === "FSubSent");
    if (!sent) return { err: "δεν βρέθηκε φάκελος Απεσταλμένα (" + mf.map((f) => f.name + ":" + f.subType).slice(0, 8).join(", ") + ")" };
    const r = await cli.call("Mails.get", { folderIds: [sent.id], query: { fields: ["id", "subject", "receiveDate", "sendDate", "attachments", "to", "size"], start: 0, limit: n || 15, orderBy: [{ columnName: "receiveDate", direction: "Desc" }] } });
    return { folder: sent.name, list: (r.list || []).map((m) => ({ id: m.id, subject: m.subject || "", date: m.receiveDate || m.sendDate || "", to: (m.to || []).length,
      att: (m.attachments || []).map((a) => ({ name: a.name || "", type: a.contentType || "", size: a.size || 0, url: a.url || "", id: a.id || "" })) })) };
  }
  // λήψη συνημμένου (url του Kerio, με το X-Token της σύνδεσης)
  async function download(cli, base, fetchFn, url) {
    const u = /^https?:/i.test(url) ? url : String(base || "").replace(/\/+$/, "") + (url.charAt(0) === "/" ? "" : "/") + url;
    const r = await fetchFn(u, { method: "GET", credentials: "include", headers: { "X-Token": cli.token } });
    if (!r.ok) throw new Error("λήψη συνημμένου: HTTP " + r.status);
    return new Uint8Array(await r.arrayBuffer());
  }

  // PDF (μία σελίδα Α4 ανά JPEG, οριζόντια αν η εικόνα είναι πλατύτερη) — για σαρώσεις που ήρθαν ως εικόνες (scanq)
  function jpegSize(u){ for(let i = 2; i < u.length - 9;){ if(u[i] !== 0xFF){ i++; continue; } const m = u[i+1], L = (u[i+2] << 8) | u[i+3];
      if(m >= 0xC0 && m <= 0xCF && m !== 0xC4 && m !== 0xC8 && m !== 0xCC) return { h: (u[i+5] << 8) | u[i+6], w: (u[i+7] << 8) | u[i+8] };
      if(m === 0xD8 || (m >= 0xD0 && m <= 0xD7)){ i += 2; continue; } i += 2 + L; } return null; }
  function pdfFromJpegs(list){
    const te = new TextEncoder(), parts = [], offs = []; let len = 0;
    const put = (x)=>{ const u = typeof x === "string" ? te.encode(x) : x; parts.push(u); len += u.length; };
    const obj = (n, f)=>{ offs[n] = len; put(n + " 0 obj\n"); f(); put("\nendobj\n"); };
    const P = list.map((u)=>({ u, d: jpegSize(u) })).filter((x)=>x.d && x.d.w && x.d.h);
    if(!P.length) throw new Error("χωρίς έγκυρες εικόνες");
    put("%PDF-1.4\n"); put(new Uint8Array([0x25,0xE2,0xE3,0xCF,0xD3,0x0A]));
    const N = P.length, pageNo = (i)=>3 + i*3;
    obj(1, ()=>put("<< /Type /Catalog /Pages 2 0 R >>"));
    obj(2, ()=>put("<< /Type /Pages /Kids [" + P.map((_, i)=>pageNo(i) + " 0 R").join(" ") + "] /Count " + N + " >>"));
    P.forEach((x, i)=>{ const land = x.d.w > x.d.h, W = land ? 841.89 : 595.28, H = land ? 595.28 : 841.89, sc = Math.min(W / x.d.w, H / x.d.h);
      const dw = +(x.d.w*sc).toFixed(2), dh = +(x.d.h*sc).toFixed(2), dx = +((W-dw)/2).toFixed(2), dy = +((H-dh)/2).toFixed(2), n = pageNo(i);
      obj(n, ()=>put("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " + W + " " + H + "] /Resources << /XObject << /Im0 " + (n+1) + " 0 R >> >> /Contents " + (n+2) + " 0 R >>"));
      obj(n+1, ()=>{ put("<< /Type /XObject /Subtype /Image /Width " + x.d.w + " /Height " + x.d.h + " /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length " + x.u.length + " >>\nstream\n"); put(x.u); put("\nendstream"); });
      const cs = "q " + dw + " 0 0 " + dh + " " + dx + " " + dy + " cm /Im0 Do Q"; obj(n+2, ()=>put("<< /Length " + cs.length + " >>\nstream\n" + cs + "\nendstream")); });
    const last = pageNo(N - 1) + 2, xref = len; let x = "xref\n0 " + (last + 1) + "\n0000000000 65535 f \n";
    for(let i = 1; i <= last; i++) x += String(offs[i]).padStart(10, "0") + " 00000 n \n";
    put(x + "trailer\n<< /Size " + (last + 1) + " /Root 1 0 R >>\nstartxref\n" + xref + "\n%%EOF\n");
    const out = new Uint8Array(len); let o = 0; for(const q of parts){ out.set(q, o); o += q.length; } return out;
  }

  const api = { client, resolve, findGroup, membersOf, send, whoAmI, contactFolders, nz, pdfFromJpegs, jpegSize, sentMails, download };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.kMail = api;
})(typeof self !== "undefined" ? self : this);
