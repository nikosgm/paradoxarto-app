// Έγγραφο στο παρασκήνιο (offscreen): εδώ υπάρχει DOMParser για να διαβάσουμε τις σελίδες του Medilabi.
chrome.runtime.onMessage.addListener((msg, _s, reply) => {
  if (msg?.target !== "efbot-offscreen" || msg.op === "rt" || msg.op === "pdf2png") return;
  try {
    const M = self.Medilabi;
    if (msg.op === "waiting") reply({ ok: true, login: M.isLogin(msg.html), list: M.parseWaiting(msg.html) });
    else if (msg.op === "exams") reply({ ok: true, login: M.isLogin(msg.html), groups: M.parseExams(msg.html) });
    else if (msg.op === "results") reply({ ok: true, login: M.isLogin(msg.html), rows: M.parseResults(msg.html, msg.day), all: M.parseAll(msg.html) });
    else if (msg.op === "loginform") reply({ ok: true, form: M.parseLoginForm(msg.html) });
    else reply({ ok: false });
  } catch (e) { reply({ ok: false, error: String(e) }); }
});

// ===== ⚡ Απευθείας ξύπνημα του bot (Supabase Realtime) — ανεξάρτητο από την καρτέλα του Παραδόχαρτου =====
// Το background δίνει ΜΟΝΟ βραχύβιο access token (στη μνήμη· τίποτα στον δίσκο). Κάθε νέα/αλλαγμένη εντολή →
// μήνυμα «jobsNow» στο background (μόνο ξύπνημα: τι θα τρέξει το διαβάζει πάντα από τη βάση).
(function () {
  const RT = { ws: null, url: "", key: "", token: "", ref: 1, hb: null, retry: 0, filtered: true, joined: false, lastMsg: 0, timer: null };
  const send = (o) => { try { if (RT.ws && RT.ws.readyState === 1) RT.ws.send(JSON.stringify(o)); } catch (e) {} };
  const TOPIC = "realtime:efbot-direct";
  function join() {
    const pc = RT.filtered
      ? [{ event: "INSERT", schema: "public", table: "oncall_jobs" }, { event: "UPDATE", schema: "public", table: "oncall_jobs", filter: "status=in.(new,approve,cancelled,dismissed)" }]
      : [{ event: "*", schema: "public", table: "oncall_jobs" }];
    RT.joinRef = String(RT.ref++);
    send({ topic: TOPIC, event: "phx_join", payload: { config: { broadcast: { self: false }, presence: { key: "" }, postgres_changes: pc }, access_token: RT.token }, ref: RT.joinRef, join_ref: RT.joinRef });
  }
  function connect() {
    clearTimeout(RT.timer); clearInterval(RT.hb);
    if (!RT.url || !RT.key || !RT.token) return;
    try { if (RT.ws) { RT.ws.onclose = null; RT.ws.close(); } } catch (e) {}
    RT.joined = false;
    const ws = new WebSocket(RT.url.replace(/^http/, "ws") + "/realtime/v1/websocket?apikey=" + encodeURIComponent(RT.key) + "&vsn=1.0.0");
    RT.ws = ws;
    ws.onopen = () => { RT.retry = 0; join(); RT.hb = setInterval(() => send({ topic: "phoenix", event: "heartbeat", payload: {}, ref: String(RT.ref++) }), 25000); };
    ws.onmessage = (ev) => {
      RT.lastMsg = Date.now();
      let m; try { m = JSON.parse(ev.data); } catch (e) { return; }
      if (m.topic !== TOPIC) return;
      if (m.event === "phx_reply" && m.ref === RT.joinRef) {
        if (m.payload && m.payload.status === "ok") { RT.joined = true; chrome.runtime.sendMessage({ type: "rtState", ok: true, filtered: RT.filtered }).catch(() => {}); }
        else if (RT.filtered) { RT.filtered = false; join(); }   // φίλτρο που δεν υποστηρίζεται: χωρίς φίλτρο
        else chrome.runtime.sendMessage({ type: "rtState", ok: false, err: JSON.stringify(m.payload || {}).slice(0, 200) }).catch(() => {});
        return;
      }
      if (m.event === "postgres_changes") {
        const d = (m.payload && m.payload.data) || {}, rec = d.record || {};
        const st = rec.status || "";
        if (!RT.filtered && d.type === "UPDATE" && !/^(new|approve|cancelled|dismissed)$/.test(st)) return;
        chrome.runtime.sendMessage({ type: "jobsNow", id: rec.id || 0, st, via: "rt" }).catch(() => {});
      }
      if (m.event === "system" && m.payload && m.payload.status === "error") chrome.runtime.sendMessage({ type: "rtState", ok: false, err: String(m.payload.message || "").slice(0, 200) }).catch(() => {});
    };
    ws.onclose = () => {
      clearInterval(RT.hb); RT.joined = false;
      chrome.runtime.sendMessage({ type: "rtState", ok: false, err: "closed" }).catch(() => {});   // 9/11: αμέσως πίσω σε τακτικό έλεγχο της ουράς
      const wait = Math.min(60000, 2000 * Math.pow(2, RT.retry++));
      RT.timer = setTimeout(connect, wait);
    };
    ws.onerror = () => {};
  }
  chrome.runtime.onMessage.addListener((msg, _s, reply) => {
    if (msg?.target !== "efbot-offscreen" || msg.op !== "rt") return;
    const changedConn = msg.url !== RT.url || msg.key !== RT.key;
    const changedTok = msg.token && msg.token !== RT.token;
    RT.url = msg.url; RT.key = msg.key; if (msg.token) RT.token = msg.token;
    if (!RT.ws || RT.ws.readyState > 1 || changedConn) connect();
    else if (changedTok && RT.joined) send({ topic: TOPIC, event: "access_token", payload: { access_token: RT.token }, ref: String(RT.ref++), join_ref: RT.joinRef });
    reply({ ok: true, state: RT.ws ? RT.ws.readyState : -1, joined: RT.joined, filtered: RT.filtered, last: RT.lastMsg });
    return true;
  });
})();
