// 🗺 10/11 22:45 (χρήστης: «νυχτερινή ΠΛΗΡΗΣ χαρτογράφηση ΝΠΣ, Medilabi, e-prescription, ΑΗΦΥ — κάθε καρτέλα — σε ένα αρχείο αναφοράς»).
// ΜΟΝΟ ΑΝΑΓΝΩΣΗ. Πατά ΜΟΝΟ: στοιχεία μενού πλοήγησης και επικεφαλίδες καρτελών (tabs). ΠΟΤΕ κουμπιά φορμών, ΠΟΤΕ αποθήκευση/καταχώριση/
// υποβολή/οριστικοποίηση/ακύρωση/διαγραφή/εκτύπωση/αποσύνδεση. Καταγράφει ΜΟΝΟ δομή (τίτλοι, ετικέτες/τύποι/ids πεδίων, κείμενα κουμπιών,
// κεφαλίδες πινάκων, καρτέλες) — ΚΑΜΙΑ τιμή πεδίου, ΚΑΝΕΝΑ κελί πίνακα· αριθμοί ≥5 ψηφίων → #. Δική της καρτέλα (κλείνει στο τέλος).
// Φορτώνεται από το background.js (importScripts) — οι συναρτήσεις σελίδας (SM_*) είναι αυτόνομες ώστε να δοκιμάζονται σε ψεύτικες σελίδες.
/* global self */
(function (G) {
  // κείμενα που ΔΕΝ πατιούνται ποτέ (μενού ή καρτέλα)
  const SM_SKIP = "^νέα |^νέο |^\\+ ?νέ|νέα επίσκεψη|νέα συνταγή|νέο παραπεμπτικό|εμβολιασμ|εισαγωγή νέας|θεώρηση|προσθήκη|ολοκλήρωση|τοποθέτηση|επαναπρογραμμ|προγραμματισμ|ελληνικά|αγγλικά|english|γλώσσα|εγχειρίδιο|manual|βοήθεια|help|αποσύνδ|έξοδος|logout|log out|sign ?out|διαγραφ|διαγράψ|ακύρωσ|ακυρώ|εκτύπωσ|εκτυπώ|print|υποβολ|υποβάλ|καταχώρ|οριστικοπ|αποστολ|αποστείλ|send|export|εξαγωγ|λήψη|download|αλλαγή κωδικ|password|κωδικός πρόσβασης|απενεργοπ|κλείδωμα|reset|επαναφορ|import|ανέβασμα|upload";

  // ---------- συναρτήσεις ΣΕΛΙΔΑΣ (τρέχουν μέσα στη σελίδα· αυτόνομες) ----------
  function SM_MENU(skipSrc) {
    const SK = new RegExp(skipSrc, "i");
    const T = (e) => String((e && (e.innerText || e.textContent)) || "").replace(/\s+/g, " ").trim();
    const mk = (s) => String(s || "").replace(/\d{5,}/g, "#").slice(0, 70);
    const SEL = ".ui-menuitem-link, .ui-menubar a, .ui-panelmenu a, .ui-tieredmenu a, .ui-slidemenu a, nav a, [role=menuitem], aside a, header a, .navbar a, ul.nav a, .nav-link, .sidebar a, #menu a, .menu a, .MuiListItem-root a, a.MuiListItemButton-root, .MuiListItemButton-root";
    let els = [...document.querySelectorAll(SEL)];
    if (els.length < 6) els = els.concat([...document.querySelectorAll("a[href]")].filter((a) => { try { const u = new URL(a.href, location.href); return u.origin === location.origin && !/^#?$/.test(a.getAttribute("href") || ""); } catch (e) { return false; } }));
    const seen = new Set(), out = [];
    const pathOf = (e) => { const p = []; let x = e.parentElement;
      while (x && x !== document.body) { if (/^(LI)$/.test(x.tagName) && (x.classList.contains("ui-menu-parent") || x.classList.contains("ui-submenu") || x.querySelector(":scope > ul, :scope > .ui-menu-child, :scope > .ui-submenu-list"))) { const h = x.querySelector(":scope > a, :scope > span, :scope > .ui-menuitem-link, :scope > .ui-submenu-header"); const t = T(h).split(" ")[0] ? T(h) : ""; if (t && h !== e && !h.contains(e)) p.unshift(t); }
        if (x.classList && (x.classList.contains("ui-panelmenu-panel"))) { const h = x.querySelector(".ui-panelmenu-header"); if (h && T(h)) p.unshift(T(h)); }
        x = x.parentElement; }
      return p; };
    for (const e of els) {
      const t = T(e); if (!t || t.length > 70) continue;
      const parent = e.closest("li") && e.closest("li").querySelector(":scope > ul, :scope > .ui-menu-child, :scope > .ui-submenu-list");
      const pp = pathOf(e), key = pp.concat(t).join(" › ");
      if (seen.has(key)) continue; seen.add(key);
      const href = e.getAttribute("href") || "";
      out.push({ key: mk(key), t: mk(t), d: pp.length, leaf: !parent, href: /^(#|javascript:)/i.test(href) ? "" : mk(href.replace(/[?#].*$/, "")), skip: SK.test(t) || SK.test(key) });
    }
    return out.slice(0, 250);
  }
  function SM_CLICK(key) {
    const T = (e) => String((e && (e.innerText || e.textContent)) || "").replace(/\s+/g, " ").trim();
    const mk = (s) => String(s || "").replace(/\d{5,}/g, "#").slice(0, 70);
    const SEL = ".ui-menuitem-link, .ui-menubar a, .ui-panelmenu a, .ui-tieredmenu a, .ui-slidemenu a, nav a, [role=menuitem], aside a, header a, .navbar a, ul.nav a, .nav-link, .sidebar a, #menu a, .menu a, .MuiListItem-root a, a.MuiListItemButton-root, .MuiListItemButton-root, a[href]";
    const pathOf = (e) => { const p = []; let x = e.parentElement;
      while (x && x !== document.body) { if (x.tagName === "LI" && (x.classList.contains("ui-menu-parent") || x.classList.contains("ui-submenu") || x.querySelector(":scope > ul, :scope > .ui-menu-child, :scope > .ui-submenu-list"))) { const h = x.querySelector(":scope > a, :scope > span, :scope > .ui-menuitem-link, :scope > .ui-submenu-header"); const t = T(h); if (t && h !== e && !h.contains(e)) p.unshift(t); }
        if (x.classList && x.classList.contains("ui-panelmenu-panel")) { const h = x.querySelector(".ui-panelmenu-header"); if (h && T(h)) p.unshift(T(h)); }
        x = x.parentElement; } return p; };
    const e = [...document.querySelectorAll(SEL)].find((x) => mk(pathOf(x).concat(T(x)).join(" › ")) === key);
    if (!e) return { err: "δεν βρέθηκε" };
    for (const t of ["pointerdown", "mousedown", "pointerup", "mouseup"]) e.dispatchEvent(new (t.startsWith("pointer") && typeof PointerEvent !== "undefined" ? PointerEvent : MouseEvent)(t, { bubbles: true, cancelable: true }));
    e.click(); return { ok: 1 };
  }
  function SM_SNAP() {
    const T = (e) => String((e && (e.innerText || e.textContent)) || "").replace(/\s+/g, " ").trim();
    const mk = (s) => String(s || "").replace(/\d{5,}/g, "#").replace(/[\w.+-]+@[\w-]+\.[\w.]+/g, "@").slice(0, 90);
    const vis = (e) => { if (!e) return false; const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0; };
    const uniq = (a, n) => [...new Set(a.filter(Boolean))].slice(0, n);
    const root = document.body;
    const heads = uniq([...root.querySelectorAll("h1,h2,h3,h4,legend,.ui-panel-title,.ui-dialog-title,.MuiTypography-h4,.MuiTypography-h5,.MuiTypography-h6,.card-title,.page-title")].filter(vis).map((e) => mk(T(e))).filter((t) => t.length <= 90), 40);
    const lab = (i) => { const id = i.id || ""; let l = id && document.querySelector("label[for='" + CSS.escape(id) + "']"); if (l && T(l)) return T(l);
      l = i.closest("label"); if (l && T(l)) return T(l); const al = i.getAttribute("aria-label") || i.getAttribute("placeholder") || ""; if (al) return al;
      const td = i.closest("td"); if (td && td.previousElementSibling && T(td.previousElementSibling)) return T(td.previousElementSibling);
      let c = i.parentElement; for (let k = 0; k < 3 && c; k++, c = c.parentElement) { const L = c.querySelector("label, .ui-outputlabel, .MuiFormLabel-root, .control-label"); if (L && T(L)) return T(L); } return ""; };
    const fields = [...root.querySelectorAll("input:not([type=hidden]), select, textarea, [role=combobox], .ui-selectonemenu, .ui-chkbox, .ql-editor, [contenteditable=true]")].filter(vis).slice(0, 120).map((i) => ({
      l: mk(lab(i)).replace(/\*$/, ""), t: (i.tagName.toLowerCase() + (i.type ? ":" + i.type : "") + (i.getAttribute("role") ? "@" + i.getAttribute("role") : "") + (i.classList.contains("ui-selectonemenu") ? "@pfselect" : "") + (i.classList.contains("ui-chkbox") ? "@pfcheck" : "")),
      id: mk(i.id || i.name || ""), req: !!(i.required || i.getAttribute("aria-required") === "true"), ro: !!(i.readOnly || i.disabled) }));
    const buttons = uniq([...root.querySelectorAll("button, input[type=submit], input[type=button], a.ui-button, a.btn, [role=button]")].filter(vis).map((b) => mk(T(b) || b.value || b.getAttribute("title") || b.getAttribute("aria-label") || "")).filter((t) => t && t.length <= 60), 80);
    const tables = [...root.querySelectorAll("table")].filter(vis).map((t) => { const h = [...t.querySelectorAll("thead th, thead td")].map((x) => mk(T(x))).filter(Boolean);
      return h.length ? { h: h.slice(0, 25), rows: t.querySelectorAll("tbody tr").length, pager: !!(t.closest(".ui-datatable") && t.closest(".ui-datatable").querySelector(".ui-paginator")) } : null; }).filter(Boolean).slice(0, 15);
    const tabs = uniq([...root.querySelectorAll("[role=tab], .ui-tabs-nav li, .MuiTab-root, .nav-tabs a, .nav-tabs li")].filter(vis).map((e) => mk(T(e))).filter((t) => t && t.length <= 60), 20);
    const dialogs = [...document.querySelectorAll("[role=dialog], .ui-dialog, .modal.show")].filter(vis).map((d) => mk(T(d)).slice(0, 160));
    const msgs = uniq([...document.querySelectorAll(".ui-messages, .ui-growl, [role=alert], .alert, .validation-summary-errors")].filter(vis).map((e) => mk(T(e)).slice(0, 160)), 6);
    const pw = [...document.querySelectorAll("input[type=password]")].some(vis);
    return { path: mk(location.pathname), title: mk(document.title), heads, fields, buttons, tables, tabs, dialogs, msgs, login: pw };
  }
  function SM_TAB(i, skipSrc) {
    const SK = new RegExp(skipSrc, "i");
    const T = (e) => String((e && (e.innerText || e.textContent)) || "").replace(/\s+/g, " ").trim();
    const vis = (e) => { if (!e) return false; const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0; };
    const L = [...document.querySelectorAll("[role=tab], .ui-tabs-nav li, .MuiTab-root, .nav-tabs a, .nav-tabs li")].filter(vis);
    const seen = new Set(), U = L.filter((e) => { const t = T(e); if (!t || seen.has(t)) return false; seen.add(t); return true; });
    const e = U[i]; if (!e) return { none: 1 }; if (SK.test(T(e))) return { skip: T(e) };
    const a = e.querySelector("a") || e;
    for (const t of ["mousedown", "mouseup"]) a.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true }));
    a.click(); return { ok: 1, t: T(e).replace(/\d{5,}/g, "#").slice(0, 60) };
  }
  // 10/11 22:55 (1η δοκιμή στο ΝΠΣ: «μενού» = ετικέτες κεφαλίδας «ΑΜΚΑ :»· το πραγματικό μενού είναι ΚΑΡΤΕΛΕΣ με υπο-στοιχεία):
  // ΓΕΝΙΚΑ: ό,τι πατιέται ΓΙΑ ΠΛΟΗΓΗΣΗ — σύνδεσμοι, στοιχεία μενού (και κρυφά), καρτέλες, γραμμές λίστας-μενού. ΠΟΤΕ: κουμπιά, πεδία, γραμμές/κελιά πινάκων
  // (ασθενείς), ετικέτες «…:», κείμενα SM_SKIP. Ταυτότητα = το κείμενο (μοναδικό στη σελίδα).
  function SM_ITEMS(skipSrc) {
    const SK = new RegExp(skipSrc, "i");
    const T = (e) => String((e && (e.innerText || e.textContent)) || "").replace(/\s+/g, " ").trim();
    const vis = (e) => { const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0; };
    const own = (e) => [...e.childNodes].filter((n) => n.nodeType === 3).map((n) => n.textContent).join(" ").replace(/\s+/g, " ").trim();
    const bad = (e) => e.closest("tbody, .ui-datatable-data, table.dataTable, form input, select, textarea, button, [role=button], .ui-button, [role=dialog] .ui-dialog-titlebar") || e.closest("[role=grid] [role=row]");
    const L = [];
    const add = (e, kind) => { if (bad(e)) return; let t = kind === "li" ? own(e) : T(e); if (!t || t.length > 60 || /:\s*$/.test(t) || /^\d+$/.test(t)) return; t = t.replace(/\d{5,}/g, "#");
      if (L.some((x) => x.t === t)) return; L.push({ t, kind, hid: !vis(e), skip: SK.test(t) }); };
    document.querySelectorAll("[role=tab], .ui-tabs-nav li, .MuiTab-root, .nav-tabs a").forEach((e) => vis(e) && add(e, "tab"));
    document.querySelectorAll(".ui-menuitem-link, [role=menuitem], .ui-panelmenu-header a, .ui-submenu-header, .ui-commandlink, nav a, aside a, .navbar a, ul.nav a, .nav-link, .sidebar a, #menu a, .menu a, .MuiListItemButton-root").forEach((e) => add(e, "menu"));
    document.querySelectorAll("a[href]").forEach((e) => { if (!vis(e)) return; const h = e.getAttribute("href") || ""; try { if (/^(mailto:|tel:)/i.test(h) || (/^https?:/i.test(h) && new URL(h).origin !== location.origin)) return; } catch (x) { return; } add(e, "link"); });
    document.querySelectorAll("li").forEach((e) => { if (!vis(e) || e.querySelector("a, button, input") || !own(e)) return; const m = e.closest("ul, ol"); if (!m || !(m.className + " " + (m.getAttribute("role") || "")).match(/menu|nav|tree|list/i)) return; add(e, "li"); });
    return L.slice(0, 200);
  }
  function SM_CLICKTXT(t) {
    const T = (e) => String((e && (e.innerText || e.textContent)) || "").replace(/\s+/g, " ").trim().replace(/\d{5,}/g, "#");
    const own = (e) => [...e.childNodes].filter((n) => n.nodeType === 3).map((n) => n.textContent).join(" ").replace(/\s+/g, " ").trim().replace(/\d{5,}/g, "#");
    const vis = (e) => { const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0; };
    const bad = (e) => e.closest("tbody, .ui-datatable-data, table.dataTable, button, [role=button], .ui-button") || e.closest("[role=grid] [role=row]");
    const C = [...document.querySelectorAll("[role=tab], .ui-tabs-nav li, .MuiTab-root, .nav-tabs a, .ui-menuitem-link, [role=menuitem], .ui-panelmenu-header a, .ui-submenu-header, .ui-commandlink, nav a, aside a, .navbar a, ul.nav a, .nav-link, .sidebar a, #menu a, .menu a, .MuiListItemButton-root, a[href]")].filter((e) => !bad(e) && T(e) === t);
    let e = C.find(vis) || C[0];
    if (!e) e = [...document.querySelectorAll("li")].find((x) => vis(x) && !bad(x) && own(x) === t);
    if (!e) return { err: "δεν βρέθηκε" };
    const a = (e.matches("li") && e.querySelector(":scope > a")) || e;
    for (const k of ["pointerdown", "mousedown", "pointerup", "mouseup"]) a.dispatchEvent(new (k.startsWith("pointer") && typeof PointerEvent !== "undefined" ? PointerEvent : MouseEvent)(k, { bubbles: true, cancelable: true }));
    a.click(); return { ok: 1 };
  }
  // «μη αποθηκευμένα»/«θέλετε να φύγετε» — σταματάμε, δεν πατάμε τίποτα
  function SM_LEAVE() { const b = String(document.body && document.body.innerText || ""); return /δεν έχουν (οριστικοποιηθεί|αποθηκευτεί)|μη αποθηκευμέν|unsaved|θέλετε να (φύγετε|αποχωρήσετε)/i.test(b); }

  G.SM = { SM_SKIP, SM_MENU, SM_CLICK, SM_SNAP, SM_TAB, SM_LEAVE, SM_ITEMS, SM_CLICKTXT };
})(typeof self !== "undefined" ? self : globalThis);
