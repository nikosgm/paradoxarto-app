// ===== 💊 Συνταγογράφηση στο e-prescription (www.e-prescription.gr/epres) =====
// Εντολή «rx» από το Παραδόχαρτο: { icd:[...], meds:[{name,strength,dose,freq,days,line}], mode:"review" }
// Ροή: ΑΜΚΑ (Παραδόχαρτο ή φάκελος) → αναζήτηση ασθενή (έλεγχος ΑΜΚΑ + ονόματος) → επίσκεψη (νέα ή η ήδη ανοιχτή
// του ίδιου ασθενή) → οδηγός «Νέα Συνταγή» → διαγνώσεις → φάρμακα → «Ολοκλήρωση» → σελίδα σύνοψης.
// ΣΤΑΜΑΤΑ στη σύνοψη: ΔΕΝ πατά «Καταχώριση» μόνο του. Η σύνοψη πάει στο κινητό· «Καταχώριση» ΜΟΝΟ όταν την πατήσει ο γιατρός εκεί (approve).
// Σύνδεση: αν ζητά, το bot δοκιμάζει τους αποθηκευμένους λογαριασμούς («Μάθε τους κωδικούς»), έναν-έναν, μία φορά ο καθένας.
// Στο μήνυμα γράφεται σε ποιον λογαριασμό (γιατρό) ετοιμάστηκε η συνταγή.
(function () {
  const EP_HOST = "https://www.e-prescription.gr";
  const EP_HOME = EP_HOST + "/epres/patient";
  const DEF = {
    reason: "Συνταγογράφηση οδηγιών εξιτηρίου",
    disease: "Λοιπές ενδείξεις",
    part: "25%",
    quinoloneNote: "Συνέχιση συνταγής Νοσοκομείου (οδηγίες εξιτηρίου)",
  };
  const ICD_RE = /^[A-Z]\d{2}(\.\d{1,2})?$/;
  // το N39.0 / N30.0 δεν υπάρχουν στη λίστα του e-prescription (1/11/2026): εμφανίζεται μόνο ο «γονικός» κωδικός
  const ICD_FIX = { "N39.0": "N39", "N30.0": "N30" };
  const mask = (s) => String(s || "").replace(/\d{11}/g, "•••");

  // ---------- εκτελείται ΜΕΣΑ στη σελίδα του e-prescription (world MAIN) ----------
  async function EP_PAGE(op, a) {
    a = a || {};
    // ⚡ 6/11: κρυφή καρτέλα → το Chrome στρογγυλεύει κάθε setTimeout στο 1″ (και μετά από 5′ στο 1′). Μηνύματα MessageChannel/MutationObserver
    // δεν περιορίζονται. Η «Καταχώριση» (submit/submit2) μένει ΑΚΡΙΒΩΣ όπως πριν (κανονικοί χρονοδιακόπτες).
    const sleepT = (ms) => new Promise((r) => setTimeout(r, ms));
    const FAST = !/^submit/.test(op);
    const hid = () => FAST && document.visibilityState !== "visible";
    const tick = () => new Promise((r) => { const c = new MessageChannel(); c.port1.onmessage = () => { c.port1.close(); r(); }; c.port2.postMessage(0); });
    const sleep = async (ms) => { if (!hid()) return sleepT(ms); const end = performance.now() + ms; while (performance.now() < end) await tick(); };
    const vis = (e) => { if (!e || !e.isConnected) return false; const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    const txt = (e) => String((e && e.innerText) || "").replace(/\s+/g, " ").trim();
    const up = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().replace(/\s+/g, " ").trim();
    const chk0 = (fn) => { try { return fn() || null; } catch (e) { return null; } };
    const until = async (fn, ms = 10000, step = 200) => {
      let r = chk0(fn); if (r) return r;
      if (!hid()) { const t = Date.now(); while (Date.now() - t < ms) { await sleepT(step); r = chk0(fn); if (r) return r; } return null; }
      return await new Promise((res) => {
        let done = false, lastC = 0, pt = 0, to = 0, mo = null;
        const fin = (v) => { if (done) return; done = true; try { mo && mo.disconnect(); } catch (e) {} clearTimeout(to); clearTimeout(pt); res(v); };
        const test = () => { const now = performance.now(); if (now - lastC < 16) return; lastC = now; const v = chk0(fn); if (v) fin(v); };
        mo = new MutationObserver(test);
        mo.observe(document.documentElement, { subtree: true, childList: true, attributes: true, characterData: true });
        const poll = () => { if (done) return; const v = chk0(fn); if (v) return fin(v); pt = setTimeout(poll, step); };   // όροι χωρίς αλλαγή DOM
        pt = setTimeout(poll, step);
        to = setTimeout(() => fin(chk0(fn)), ms);
      });
    };
    // Radix: θέλει pointerdown/mousedown/pointerup/mouseup/click (επιβεβαιώθηκε 1/11/2026)
    const press = (el) => {
      if (!el) return false;
      try { el.scrollIntoView({ block: "center" }); } catch (e) {}
      const r = el.getBoundingClientRect(), o = { bubbles: true, cancelable: true, clientX: r.x + r.width / 2, clientY: r.y + r.height / 2, button: 0, pointerType: "mouse", isPrimary: true, pointerId: 1 };
      el.dispatchEvent(new PointerEvent("pointerdown", o)); el.dispatchEvent(new MouseEvent("mousedown", o));
      el.dispatchEvent(new PointerEvent("pointerup", o)); el.dispatchEvent(new MouseEvent("mouseup", o));
      el.dispatchEvent(new MouseEvent("click", o));
      return true;
    };
    const setVal = (el, v) => {
      if (!el) return false;
      const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v);
      el.dispatchEvent(new Event("input", { bubbles: true })); el.dispatchEvent(new Event("change", { bubbles: true }));
    };
    const btn = (root, re) => [...(root || document).querySelectorAll("button")].find((b) => vis(b) && re.test(txt(b)));
    const dialogs = () => [...document.querySelectorAll("[role=dialog],[role=alertdialog]")].filter(vis);
    const wizard = () => dialogs().find((d) => /Επιλογή\s*Τύπου/.test(d.innerText) && /Θεραπείες/.test(d.innerText)) || null;
    // οδηγός παραπεμπτικού: «Βασικές Πληροφορίες · Διαγνώσεις · Εξετάσεις» (#577/#579)
    const refWiz = () => dialogs().find((d) => /Βασικές Πληροφορίες/.test(d.innerText) && /Διαγνώσεις/.test(d.innerText) && /Εξετάσεις/.test(d.innerText)) || null;
    const nn = (s) => up(s).replace(/[^A-ZΑ-Ω0-9]+/g, " ").trim();
    const esc = () => document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    const msgs = () => {
      const l = [...document.querySelectorAll("[role=alert],[data-sonner-toast],[class*=toast],[class*=error],[class*=destructive],.text-red-500,.text-red-600")]
        .filter(vis).map(txt).filter((t) => t && t.length < 300);
      return [...new Set(l)].slice(0, 4).join(" · ");
    };
    // 7/11: διάγνωση οδηγού — ποια πεδία είναι κόκκινα/άκυρα, τι γράφουν οι επιλογές, ποιο βήμα
    const wizDiag = () => { try {
      const w = wizard() || refWiz(); if (!w) return { none: true, dlg: dialogs().map((d) => txt(d).slice(0, 200)) };
      const lab = (el) => { const f = el.closest(".MuiFormControl-root,.MuiTextField-root,[class*=FormControl],label,td,div"); const l = f && f.querySelector("label,legend"); return txt(l || f || el).slice(0, 60); };
      const bad = [...w.querySelectorAll("[aria-invalid=true],.Mui-error,[class*=error],[class*=Error]")].filter(vis).map((e) => (lab(e) + " → " + txt(e)).slice(0, 160));
      const combos = [...w.querySelectorAll("[role=combobox]")].filter(vis).map((c) => lab(c) + " = " + txt(c)).slice(0, 30);
      const inputs = [...w.querySelectorAll("input:not([type=hidden]),textarea")].filter((i) => vis(i) || i.type === "radio" || i.type === "checkbox").map((i) => (i.name || i.id || lab(i)) + " = " + (i.type === "checkbox" || i.type === "radio" ? String(i.value || "") + (i.checked ? " ✔" : " ·") : String(i.value || "").slice(0, 40))).slice(0, 40);
      const steps = [...w.querySelectorAll(".MuiStepLabel-root,[class*=StepLabel]")].map((e) => txt(e) + (/Mui-active|Mui-error/.test(e.className) ? " [" + (/Mui-error/.test(e.className) ? "ΣΦΑΛΜΑ" : "τώρα") + "]" : "")).slice(0, 8);
      return { steps, bad: [...new Set(bad)].slice(0, 20), combos, inputs, text: txt(w).slice(0, 1800), alerts: msgs() };
    } catch (e) { return { err: String(e.message || e) }; } };
    const pick = async (combo, test) => {
      if (!combo) return { err: "δεν βρέθηκε το πεδίο" };
      press(combo);
      const opts = await until(() => { const o = [...document.querySelectorAll("[role=option]")].filter(vis); return o.length ? o : null; }, 3000);
      if (!opts) return { err: "δεν άνοιξε η λίστα" };
      const list = opts.map(txt), o = opts.find((x) => test(txt(x), list));
      if (!o) { esc(); await sleep(250); return { err: "δεν υπάρχει στη λίστα", list }; }
      press(o); await until(() => combo.getAttribute("aria-expanded") !== "true" && ![...document.querySelectorAll("[role=option]")].some(vis), 600, 50); await sleep(60);
      if (combo.getAttribute("aria-expanded") === "true") { esc(); await sleep(200); }
      return { ok: true, val: txt(combo), list };
    };
    // ενημερωτικά παράθυρα («Εντάξει», «Ενημερώθηκα»): κρατάμε το κείμενο και τα κλείνουμε
    const ACK = /^(Εντάξει|Ενημερώθηκα|OK)$/i;
    // «Αυτή η σελίδα περιέχει δεδομένα που δεν έχουν οριστικοποιηθεί…»: ΠΟΤΕ «ΟΚ» (θα χανόταν συνταγή σε εξέλιξη)
    const LEAVE = /δεν έχουν οριστικοποιηθεί/;
    // Παράθυρα που ανοίγουν στη ροή (κατά τον χρήστη, 1/11/2026):
    //  • επιλογή ασφάλειας ασθενή → η ΠΡΩΤΗ της λίστας
    //  • αιτιολόγηση / ΚΑΘΕ προειδοποίηση (π.χ. παραπεμπτικά) → όλα τα κουτάκια + «Έλεγχος» στα κενά πεδία κειμένου
    //  • προειδοποιήσεις (π.χ. κινολόνες) → «Εντάξει»/«Ενημερώθηκα»
    // Ποτέ «Καταχώριση» από εδώ, και ποτέ «ΟΚ» στο «δεν έχουν οριστικοποιηθεί». Το κείμενο κάθε παραθύρου κρατιέται.
    // + οδηγός παραπεμπτικού και παράθυρο «Εισαγωγή/Επεξεργασία Εξετάσεων» (έχει «Εισαγωγή»: ΠΟΤΕ από το ack)
    const SKIP = (x) => /Επιλογή\s*Τύπου/.test(x.innerText) && /Θεραπείες/.test(x.innerText) || LEAVE.test(x.innerText) || /Μονάδα Συνταγογράφησης/.test(x.innerText) || x.querySelector("input#keyword")
      || (/Βασικές Πληροφορίες/.test(x.innerText) && /Διαγνώσεις/.test(x.innerText) && /Εξετάσεις/.test(x.innerText)) || /Επεξεργασία Εξετάσεων|Αναζήτηση εξέτασης/.test(x.innerText) || !!x.querySelector("input[placeholder*='Αναζήτηση εξέτασης']");
    // ⚠ ΠΟΤΕ κουμπιά τύπου υποβολής (πριν περιείχε «Υποβολή»/«Αποθήκευση» — έλεγχος 5/11)
    const CONFIRM = /^(Επιλογή|Εντάξει|Ενημερώθηκα|OK|ΟΚ|Συνέχεια|Εισαγωγή)$/i;
    const SUBMITY = /καταχώρ|υποβολ|οριστικοποι|αποθήκευσ/i;
    // συμπλήρωση παραθύρου αιτιολόγησης/προειδοποίησης: όλα τα κουτάκια + «Παράταση προγενέστερης» στις λίστες + «Έλεγχος» στα κενά πεδία
    const fillDlg = async (d) => {
      for (const c of d.querySelectorAll("[role=checkbox]")) if (c.getAttribute("aria-checked") !== "true" && c.getAttribute("data-disabled") == null && !c.disabled) { press(c); await sleep(120); }
      for (const c of d.querySelectorAll("input[type=checkbox]")) if (!c.checked && !c.disabled && !c.closest("[role=checkbox]") && vis(c)) { press(c); await sleep(120); }
      // λίστες αιτιολόγησης (π.χ. «ίδιο φάρμακο ξανά»): «Παράταση προγενέστερης συνταγής» (όπως ο γιατρός, 9/11), αλλιώς η πρώτη
      const PREF = /παράταση\s+προγενέστερης/i;
      for (const cb of d.querySelectorAll("[role=combobox]")) if (vis(cb) && cb.getAttribute("aria-disabled") !== "true" && !/\S/.test(txt(cb).replace(/επιλέξτε|επιλογή|select|\.\.\.|…/gi, ""))) { await pick(cb, (x, list) => list.some((y) => PREF.test(y)) ? PREF.test(x) : x === list[0]); await sleep(150); }
      for (const se of d.querySelectorAll("select")) if (vis(se) && !se.disabled && !se.value) { const o = [...se.options].find((x) => PREF.test(x.text)) || [...se.options].find((x) => x.value); if (o) { se.value = o.value; se.dispatchEvent(new Event("change", { bubbles: true })); } }
      for (const f of d.querySelectorAll("textarea, input[type=text]:not(#keyword)")) if (vis(f) && !f.disabled && !f.readOnly && !f.value.trim() && f.getAttribute("role") !== "combobox" && !f.closest("[role=combobox]")) setVal(f, "Έλεγχος");
    };
    // 📢 10/11 22:35 (χρήστης: «ό,τι μήνυμα σου βγάζει, να πατάς ναι — είναι ενημερωτικά»): job 2447/2448 — «Ενημερώσεις σχετικά με τον ασθενή /
    // COVID-19» άνοιγε ΜΑΖΙ με την «Επιλογή Ασφαλιστικού Φορέα» και έμενε από πάνω (κουμπί μόνο ×) → η επιλογή ασφάλειας δεν περνούσε.
    // Ενημερωτικό = παράθυρο χωρίς πεδία/λίστες/πίνακα· κλείνει με Ναι/Εντάξει/OK/Κλείσιμο/× (ή Escape). ΠΟΤΕ σε κείμενο καταχώρισης/ακύρωσης κ.λπ.
    const DANGER = /καταχώρ|υποβολ|οριστικοποι|αποθήκευσ|ακύρωσ|ακυρώ|διαγραφ|διαγράψ|αφαίρεσ|απόρριψ|δεν έχουν οριστικοποιηθεί/i;
    const INFO = (x) => !SKIP(x) && !DANGER.test(x.innerText || "") && !x.querySelector("input:not([type=hidden]),textarea,select,[role=combobox],[role=radio],[role=checkbox],tbody tr,[role=row]");
    const YES = /^(Ναι|ΝΑΙ|Εντάξει|Ενημερώθηκα|OK|ΟΚ|Κλείσιμο|Close|Συνέχεια)$/i;
    const closeX = (d) => [...d.querySelectorAll("button,[role=button]")].find((b) => vis(b) && (/close|κλείσ/i.test((b.getAttribute("aria-label") || "") + " " + (b.getAttribute("title") || "")) || /^[×✕✖xX]$/.test(txt(b)) || (!txt(b) && b.querySelector("svg"))));
    const infoClose = async (notes) => {
      for (let i = 0; i < 5; i++) {
        const all = dialogs(), d = all.filter(INFO).pop();   // το πάνω-πάνω ενημερωτικό
        if (!d) return;
        const t = txt(d); notes.push("📢 " + t.slice(0, 300));
        const b = btn(d, YES) || closeX(d);
        if (b && !DANGER.test(txt(b))) press(b); else esc();
        await until(() => !d.isConnected || !vis(d) ? "ok" : null, 1500, 60);
        if (d.isConnected && vis(d) && txt(d) === t) { esc(); await sleep(300); if (d.isConnected && vis(d)) return; }
      }
    };
    const ack = async () => {
      const notes = [];
      await infoClose(notes);
      for (let i = 0; i < 6; i++) {
        await infoClose(notes);
        const okB = (x) => btn(x, CONFIRM) || (!DANGER.test(x.innerText || "") ? btn(x, /^(Ναι|ΝΑΙ)$/) : null);
        const d = dialogs().find((x) => !SKIP(x) && okB(x) && !(a.afterFinish && SUBMITY.test(x.innerText)));
        if (!d) break;
        const t = txt(d);
        notes.push(t.slice(0, 400));
        if (/ασφαλ/i.test(t) && (d.querySelector("[role=combobox],[role=radio],[role=option],input[type=radio],tbody tr"))) {
          const cb = d.querySelector("[role=combobox]");
          if (cb) await pick(cb, (x, list) => x === list[0]);
          else {
            const r = d.querySelector("[role=radio],input[type=radio]") || d.querySelector("tbody tr [role=checkbox],tbody tr input[type=checkbox]") || d.querySelector("tbody tr");
            if (r && r.getAttribute("aria-checked") !== "true" && !r.checked) { press(r); await sleep(250); }
          }
        } else {   // κάθε άλλο παράθυρο (αιτιολόγηση, προειδοποιήσεις παραπεμπτικών κ.λπ.): όλα τα κουτάκια + «Έλεγχος» στα κενά πεδία (εντολή χρήστη 9/11)
          await fillDlg(d);
          await sleep(200);
        }
        const b = okB(d);
        if (!b || SUBMITY.test(txt(b))) break;
        press(b); await sleep(500);
        if (vis(d) && txt(d) === t) break;   // δεν έκλεισε (π.χ. υποχρεωτικό πεδίο): σταματάμε εδώ, το κείμενο πάει στο μήνυμα
      }
      return notes;
    };
    const AMKA_RX = /ssrn|amka|αμκα|a\.?m\.?k\.?a|α\.?μ\.?κ\.?α/i;
    const amkaInp = () => {
      const d = document.querySelector("input#ssrn"); if (d && vis(d)) return d;
      const ins = [...document.querySelectorAll("input")].filter((i) => vis(i) && !/^(hidden|checkbox|radio|password|submit|button)$/i.test(i.type));
      const lab = (i) => { const l = (i.id && document.querySelector("label[for='" + CSS.escape(i.id) + "']")) || i.closest("label"); return l ? txt(l) : ""; };
      return ins.find((i) => AMKA_RX.test([i.id, i.name, i.placeholder, i.getAttribute("aria-label"), lab(i)].join(" "))) || (/\/patient/.test(location.pathname) && ins.length === 1 ? ins[0] : null) || d || null;
    };
    const formDiag = () => [...document.querySelectorAll("input,select,[role=combobox]")].filter(vis).slice(0, 10).map((i) => [i.tagName.toLowerCase(), i.type || "", i.id && "#" + i.id, i.name && "n=" + i.name, i.placeholder && "ph=" + i.placeholder.slice(0, 25), i.getAttribute("aria-label") && "al=" + i.getAttribute("aria-label").slice(0, 25)].filter(Boolean).join(" ")).join(" | ") + " · σελίδα " + location.pathname;
    const banner = () => { const b = txt(document.body); const m = b.match(/\(?\s*Α\.?Μ\.?Κ\.?Α\.?\s*:?\s*(\d{11})\s*\)?[\s\S]{0,80}?(?:Ανοιχτή|Ενεργή|Ανοικτή)\s+[Εε]πίσκεψη\s*\(?\s*(\d+)?/);
      if (m) return { amka: m[1], visit: m[2] || "" };
      // νέα μορφή: «Ενεργή/Ανοιχτή επίσκεψη» χωρίς ΑΜΚΑ δίπλα — τότε ο ΑΜΚΑ αλλού στη σελίδα
      const v = b.match(/(?:Ανοιχτή|Ενεργή|Ανοικτή)\s+[Εε]πίσκεψη\s*\(?\s*(\d+)?/), am = b.match(/\b(\d{11})\b/);
      return v && am ? { amka: am[1], visit: v[1] || "" } : null; };
    const goLink = async (path) => {
      if (location.pathname === path) return true;
      const l = [...document.querySelectorAll("a[href]")].find((x) => x.getAttribute("href") === path && vis(x)) || [...document.querySelectorAll("a[href]")].find((x) => x.getAttribute("href") === path);
      if (!l) return false;
      l.click();
      const r = await until(() => location.pathname === path ? "ok" : (dialogs().some((x) => LEAVE.test(x.innerText)) ? "dirty" : null), 6000);
      if (r === "dirty") {
        const d = dialogs().find((x) => LEAVE.test(x.innerText));
        press(btn(d, /^Άκυρο$/)); await sleep(300);
        throw new Error("υπάρχει συνταγή σε εξέλιξη στο e-prescription του υπολογιστή (μη καταχωρισμένη) — καταχωρίστε ή κλείστε την πρώτα · δεν πειράχτηκε");
      }
      return r === "ok";
    };

    try {
      if (op === "state") {
        // «Η συνεδρία σας έχει λήξει…»: δεν έχει πεδίο κωδικού — Ανανέωση → η σελίδα πάει στην είσοδο (μετά: αυτόματη σύνδεση)
        if (/συνεδρία\s+σας\s+έχει\s+λήξει|session\s+(has\s+)?expired/i.test(txt(document.body))) {
          const rb = btn(document, /^Ανανέωση$/); if (rb) press(rb); else location.reload();
          return { path: location.pathname, loading: true, expired: true };
        }
        const pw = [...document.querySelectorAll("input[type=password]")].some(vis);
        const unit = dialogs().some((d) => /Μονάδα Συνταγογράφησης/.test(d.innerText) && btn(d, /^Επιλογή$/));
        const loading = !pw && !unit && document.readyState !== "complete" || (!pw && !unit && !document.querySelector("a[href*='/epres/'],input:not([type=hidden]),button"));
        const dm = document.body ? document.body.innerText.match(/([A-ZΑ-ΩΆ-Ώ][A-ZΑ-ΩΆ-Ώ .'-]{3,60}?)\s*\|\s*Ιατρός/) : null;
        return { path: location.pathname, host: location.host, login: pw || location.host !== "www.e-prescription.gr" || !/^\/epres/.test(location.pathname), unit, loading, banner: banner(), doctor: dm ? dm[1].trim() : "" };
      }
      if (op === "unit") {
        const d = dialogs().find((x) => /Μονάδα Συνταγογράφησης/.test(x.innerText));
        if (!d) return { ok: true };
        // προτίμηση: ΕΞΩΤΕΡΙΚΑ ΙΑΤΡΕΙΑ του νοσοκομείου (ΛΑΪΚΟ / Γ.Ν. …)· αν οριστεί μονάδα στις ρυθμίσεις, εκείνη
        const nzU = (x) => up(String(x || "").normalize("NFD").replace(/[̀-ͯ]/g, ""));
        const sc = (x) => { const u = nzU(x); return (/ΕΞΩΤΕΡΙΚ|ΕΞΩΤ\.?\s*ΙΑΤΡ|Τ\.?\s*Ε\.?\s*Ι\.?/.test(u) ? 4 : 0) + (/ΙΑΤΡΕΙ/.test(u) ? 1 : 0) + (/ΛΑΙΚ/.test(u) ? 3 : 0) + (/ΝΟΣΟΚΟΜ|Γ\.?\s*Ν\.?|ΓΕΝΙΚΟ/.test(u) ? 1 : 0); };
        // a.strict: ΜΟΝΟ η μονάδα που ζητήθηκε (π.χ. για να ολοκληρωθεί ανοιχτή επίσκεψη εκεί) — αλλιώς σφάλμα
        const wds = (x) => nzU(x).replace(/[^A-ZΑ-Ω0-9 ]/g, " ").split(/\s+/).filter((w) => w.length >= 4);
        const sw = (x) => { const w = wds(a.unit); return w.filter((t) => nzU(x).includes(t)).length; };
        const r = await pick(d.querySelector("[role=combobox]"), (t, list) => {
          if (a.strict) { const best = list.reduce((b, x) => sw(x) > sw(b) ? x : b, list[0]); return t === best && wds(a.unit).length > 0 && sw(best) === wds(a.unit).length; }
          if (a.unit && list.some((x) => up(x).includes(up(a.unit)))) return up(t).includes(up(a.unit));
          const best = list.reduce((b, x) => sc(x) > sc(b) ? x : b, list[0]);
          return t === best;
        });
        if (r.err) return { err: "μονάδα συνταγογράφησης: " + r.err + (r.list ? " (" + r.list.join(" | ") + ")" : "") };
        press(btn(d, /^Επιλογή$/));
        const ok = await until(() => !dialogs().some((x) => /Μονάδα Συνταγογράφησης/.test(x.innerText)), 8000);
        return ok ? { ok: true, unit: r.val } : { err: "η μονάδα δεν επιλέχθηκε" };
      }
      if (op === "patient") {
        if (!(await goLink("/epres/patient"))) return { err: "δεν άνοιξε η σελίδα «Ασθενής»" };
        let inp = await until(amkaInp, 8000, 100);
        if (!inp && /κωδικός πρόσβασής σας έχει λήξει/i.test(document.body.innerText || "")) return { err: "ο ΚΩΔΙΚΟΣ του λογαριασμού e-prescription σε αυτόν τον υπολογιστή ΕΧΕΙ ΛΗΞΕΙ — πρέπει να αλλάξει από τον γιατρό στο e-prescription.gr/password (το bot δεν αλλάζει κωδικούς)", pwExpired: true };
        if (!inp) { let d = ""; try { const rt = document.getElementById("root"); d = " [κείμενο " + String(document.body.innerText || "").trim().length + " «" + String(document.body.innerText || "").replace(/\s+/g, " ").replace(/\d{5,}/g, "#").trim().slice(0, 200) + "» · root " + (rt ? rt.innerHTML.length : -1) + " · scripts " + document.scripts.length + (document.documentElement.getAttribute("data-ef-jserr") ? " · JS: " + document.documentElement.getAttribute("data-ef-jserr").slice(0, 160) : "") + " · " + navigator.userAgent.replace(/^.*Chrome\/(\d+).*$/, "Chrome $1") + "]"; } catch (e) {}
          return { err: "δεν βρέθηκε το πεδίο ΑΜΚΑ — βλέπω: " + formDiag() + d }; }
        let form = inp.form || inp.closest("form") || document;
        const clr = btn(form, /^Καθαρισμός$/);
        if (clr) {
          // ο «Καθαρισμός» ξαναφτιάχνει τη φόρμα: το παλιό πεδίο/φόρμα δεν ισχύουν πια (→ «reading 'tagName'» σε null)
          press(clr); await sleep(700);
          inp = await until(amkaInp, 6000, 100);
          if (!inp) { await goLink("/epres/patient"); inp = await until(amkaInp, 8000, 100); }
          if (!inp) return { err: "το πεδίο ΑΜΚΑ δεν ξαναεμφανίστηκε μετά τον «Καθαρισμό»" };
          form = inp.form || inp.closest("form") || document;
        }
        const ty = form.querySelector("[role=combobox]");
        const AMKA = /^[AΑ]\.?[MΜ]\.?[KΚ]\.?[AΑ]\.?$/i;   // γράφεται «AMKA» με λατινικά
        if (ty && !AMKA.test(txt(ty))) {
          const r = await pick(ty, (t) => AMKA.test(t));
          if (r.err) return { err: "τύπος αναζήτησης ΑΜΚΑ: " + r.err };
        }
        inp = amkaInp() || inp;   // μετά την επιλογή τύπου η φόρμα μπορεί να ξαναφτιάχτηκε
        if (!inp || !inp.isConnected) return { err: "χάθηκε το πεδίο ΑΜΚΑ (η σελίδα ξαναφορτώθηκε)" };
        form = inp.form || inp.closest("form") || document;
        // 6/11 (#792): μετά την ολοκλήρωση επίσκεψης η φόρμα ξαναχτίζεται → ο ΑΜΚΑ «χανόταν» («Το πεδίο είναι υποχρεωτικό»).
        // Γράψιμο → έλεγχος ότι κράτησε (ίδιο πεδίο, ίδια τιμή, 400ms μετά) → αλλιώς ξανά, έως 4 φορές· και ξανά αν μετά την αναζήτηση βγει «υποχρεωτικό».
        const fill = async () => { for (let t = 0; t < 4; t++) { inp = amkaInp() || inp; if (!inp || !inp.isConnected) { await sleep(300); continue; }
            inp.focus(); setVal(inp, a.amka); inp.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: "0" })); inp.dispatchEvent(new Event("blur", { bubbles: true }));
            await sleep(400); const i2 = amkaInp(); if (i2 && i2.isConnected && String(i2.value).replace(/\D/g, "") === a.amka) { inp = i2; return true; } }
          return false; };
        if (!(await fill())) return { err: "ο ΑΜΚΑ δεν «κράτησε» στο πεδίο αναζήτησης (η φόρμα ξαναφτιαχνόταν)" };
        form = inp.form || inp.closest("form") || document;
        press(form.querySelector("button[type=submit]"));
        for (let t = 0; t < 2; t++) { await sleep(500); if (!/πεδίο είναι υποχρεωτικό/i.test(msgs() + " " + txt(form))) break;
          if (!(await fill())) break; form = inp.form || inp.closest("form") || document; press(form.querySelector("button[type=submit]")); }
        // κάρτα ασθενή: «Επεξεργασία Ασθενή» υπάρχει πάντα· το «Νέα Επίσκεψη» λείπει όταν υπάρχει ήδη ανοιχτή επίσκεψη
        // κάρτα ασθενή: ΟΧΙ μόνο συγκεκριμένα κουμπιά (#633: ο ασθενής βρέθηκε, το κουμπί είχε άλλο κείμενο) — αρκεί στοιχείο εκτός φόρμας που δείχνει τον ΑΜΚΑ
        const amkaEl = () => { const want = String(a.amka || ""); if (!want) return null;
          return [...document.querySelectorAll("div,span,td,p,li,b,strong")].filter(vis).find((e) => e.children.length < 6 && (e.innerText || "").includes(want) && !e.closest("form") && !e.querySelector("input")) || null; };
        const cardBtn = () => btn(document, /^Επεξεργασία Ασθενή/) || btn(document, /^Νέα Επίσκεψη$/) || btn(document, /Ασφαλιστικ/) || amkaEl();
        await until(() => cardBtn() || dialogs().length || /δεν βρέθηκ|δεν υπάρχει|σφάλμα|μη έγκυρ/i.test(msgs()), 15000);
        const notes = await ack();
        const nb = await until(cardBtn, 3000);
        if (!nb) { const seen = [...document.querySelectorAll("button")].filter(vis).map(txt).filter(Boolean).slice(0, 10).join(" | ");
          return { err: "δεν βρέθηκε ο ασθενής" + (msgs() ? ": " + msgs() : notes.length ? ": " + notes.join(" · ") : "") + " — βλέπω: κουμπιά: " + seen + " · " + formDiag(), notes }; }
        let card = nb; for (let i = 0; i < 10 && card && !(card.innerText || "").includes(a.amka); i++) card = card.parentElement;
        if (!card || !(card.innerText || "").includes(a.amka)) return { err: "η κάρτα ασθενή δεν δείχνει τον ΑΜΚΑ που ζητήθηκε — δεν συνεχίζω" };
        const ct = txt(card);
        return { ok: true, card: ct.slice(0, 700), notes, ayli: /ενεργοποιήσει την άυλη/i.test(ct), self: /δικό σας Α\.?Μ\.?Κ\.?Α/i.test(txt(document.body)) };
      }
      if (op === "visit") {
        // a.noBanner: το απευθείας αίτημα είπε «δεν υπάρχει ενεργή επίσκεψη» → η κεφαλίδα ΔΕΝ μετρά (έπιανε τον ΑΜΚΑ της κάρτας → ψεύτικη «ανοιχτή επίσκεψη», #552/#553)
        const b0 = a.noBanner ? null : banner();
        if (b0 && b0.amka === a.amka) return { ok: true, reuse: true, visit: b0.visit };
        // αναμονή: μετά από ανανέωση της σελίδας η κάρτα ασθενή φορτώνει αργότερα (#587/#589)
        const nb = b0 ? btn(document, /^Νέα Επίσκεψη$/) : await until(() => btn(document, /^Νέα Επίσκεψη$/), 8000);
        if (!nb) return { err: b0 ? "υπάρχει ανοιχτή επίσκεψη άλλου ασθενή στο e-prescription — κλείστε την πρώτα" : "δεν βρέθηκε το «Νέα Επίσκεψη» — βλέπω: σελίδα " + location.pathname + " · κουμπιά: " + [...new Set([...document.querySelectorAll("button")].filter(vis).map(txt).filter((t) => t && t.length < 40))].slice(0, 14).join(" | ") };
        press(nb);
        // μπορεί πρώτα να ζητήσει επιλογή ασφάλειας ασθενή (→ η πρώτη)
        const jf = () => document.querySelector("textarea#justification") || [...document.querySelectorAll("textarea")].find((t) => vis(t) && /αιτιολ|λόγος|justif/i.test([t.id, t.name, t.placeholder, t.getAttribute("aria-label")].join(" ")));
        await until(() => jf() || dialogs().some((x) => !SKIP(x)), 10000, 150);
        const pre = await ack();
        const ta = await until(jf, 6000, 150);
        if (!ta) { const n = pre.concat(await ack()); return { err: "δεν άνοιξε η φόρμα επίσκεψης" + (n.length ? ": " + n.join(" · ") : msgs() ? ": " + msgs() : "") + " — βλέπω: " + formDiag() }; }
        setVal(ta, a.reason); await sleep(250);
        const sub = [...document.querySelectorAll("button[type=submit]")].find((b) => vis(b) && /^Καταχώρ[ιη]ση/.test(txt(b))) || btn(document, /^Καταχώρ[ιη]ση( Επίσκεψης)?$/);
        if (!sub) return { err: "δεν βρέθηκε το «Καταχώριση» της επίσκεψης — βλέπω: " + formDiag() };
        press(sub);
        // a.noBanner: η κεφαλίδα δεν μετρά ως επιτυχία (έπιανε τον ΑΜΚΑ της κάρτας) — μόνο αλλαγή σελίδας ή μήνυμα
        const okNow = () => { if (/\/visits\/active|\/visits\/[0-9]/.test(location.pathname)) return { amka: a.amka, visit: "" }; if (a.noBanner) return null; const b = banner(); return b && b.amka === a.amka ? b : null; };
        let done = await until(() => okNow() || (msgs() || dialogs().some((x) => !SKIP(x)) ? "msg" : null), 15000, 150);
        const notes = await ack();
        if (done === "msg") done = await until(okNow, 4000, 150);
        if (!done && /\/visits\/active|\/visits\/[0-9]/.test(location.pathname)) done = { amka: a.amka, visit: "" };   // η σελίδα πήγε στην ενεργή επίσκεψη
        if (!done) return { err: "η επίσκεψη δεν καταχωρίστηκε" + (notes.length ? ": " + notes.join(" · ") : msgs() ? ": " + msgs() : "") + " — βλέπω: " + formDiag(), notes };
        return { ok: true, visit: done.visit, notes };
      }
      if (op === "rxOpen") {
        // a.fast (μόνο 1η κλήση, επίσκεψη «ήδη ανοιχτή» από το API): «Δεν υπάρχει ενεργή επίσκεψη» σταθερά ≥1.5″ χωρίς οδηγό → stale αμέσως (πριν: ~43″, #559)
        const STALE = { err: "η σελίδα δεν έχει φορτώσει την ενεργή επίσκεψη", stale: true };
        let s0 = 0;
        const stale = () => { if (!a.fast || wizard() || !/Δεν υπάρχει ενεργή επίσκεψη/.test(txt(document.body))) { s0 = 0; return false; } if (!s0) s0 = Date.now(); return Date.now() - s0 >= 1500; };
        const S = (v) => v || (stale() ? "S" : null);
        if (!wizard()) {
          if (location.pathname === "/epres/prescriptions/create") { await goLink("/epres/patient"); await sleep(600); }
          // σύνδεσμος στο μενού· αν δεν φαίνεται (άλλη διάταξη μενού), απευθείας στη διεύθυνση (μόνο πλοήγηση)
          if (!(await goLink("/epres/prescriptions/create"))) {
            if (dialogs().some((x) => LEAVE.test(x.innerText))) return { err: "υπάρχει συνταγή σε εξέλιξη στο e-prescription του υπολογιστή — δεν πειράχτηκε" };
            // μέσα σε ενεργή επίσκεψη: καρτέλα «Συνταγές (N)» της σελίδας επίσκεψης → «Νέα Συνταγή» (μόνο πλοήγηση)
            if (!/\/visits\/active/.test(location.pathname)) await goLink("/epres/visits/active/update");   // «dirty» → σφάλμα (δεν πετιέται συνταγή σε εξέλιξη)
            const tabS = await until(() => S([...document.querySelectorAll("button,[role=tab],a")].find((x) => vis(x) && /^Συνταγές\s*\(\d+\)$/.test(txt(x)))), 6000);
            if (tabS === "S") return STALE;
            if (tabS) { press(tabS); await sleep(700); const nb0 = await until(() => S(btn(document, /^\+?\s*Νέα Συνταγή$/)), 4000); if (nb0 === "S") return STALE; if (nb0) { press(nb0); if ((await until(() => S(wizard()), 8000)) === "S") return STALE; } }
            if (!wizard() && location.pathname !== "/epres/prescriptions/create") { history.pushState({}, "", "/epres/prescriptions/create"); dispatchEvent(new PopStateEvent("popstate")); }
            if ((await until(() => S(location.pathname === "/epres/prescriptions/create" && (wizard() || btn(document, /^\+?\s*Νέα Συνταγή$/))), 6000)) === "S") return STALE;
          }
        }
        // ο οδηγός ανοίγει με το κουμπί «+ Νέα Συνταγή» της σελίδας
        let w = await until(() => S(wizard() || btn(document, /^\+?\s*Νέα Συνταγή$/)), 10000);
        if (w === "S") return STALE;
        if (w && !wizard()) { press(w); w = await until(() => S(wizard()), 8000); if (w === "S") return STALE; }
        const seen = () => " — βλέπω: σελίδα " + location.pathname + " · κουμπιά: " + [...new Set([...document.querySelectorAll("button")].filter(vis).map(txt).filter((t) => t && t.length < 40))].slice(0, 12).join(" | ") + " · " + formDiag();
        // η επίσκεψη άνοιξε σε ΑΛΛΟΝ υπολογιστή: το e-prescription την έχει, η σελίδα εδώ όχι («Δεν υπάρχει ενεργή επίσκεψη») → ανανέωση από τον βρόχο
        if (!w && /Δεν υπάρχει ενεργή επίσκεψη/.test(txt(document.body))) return { err: "η σελίδα δεν έχει φορτώσει την ενεργή επίσκεψη", stale: true };
        if (!w) { const n = await ack(); return { err: "δεν άνοιξε ο οδηγός συνταγής" + (n.length ? ": " + n.join(" · ") : msgs() ? ": " + msgs() : "") + seen() }; }
        // βήματα 1–3 με τις προεπιλογές: Συνταγογράφηση φαρμάκων · 1 επανάληψη · χωρίς ειδικά χαρακτηριστικά
        // 7/11: το «Είδος Συνταγής» είναι πλέον κανονικό radio (input value="regular") — αν μείνει χωρίς επιλογή, στο «Επόμενο»
        // το e-prescription δίνει «Τα στοιχεία της συνταγής δεν είναι έγκυρα» (όλες οι συνταγές απέτυχαν 7/11)
        const regEl = () => { const W = wizard() || w; return W.querySelector("#regular[role=radio]") || W.querySelector('input[type=radio][value="regular"]') || W.querySelector("#regular"); };
        const regOn = () => { const r = regEl(); return !!r && (r.getAttribute("aria-checked") === "true" || r.checked === true || !!(r.closest(".Mui-checked") || (r.parentElement && r.parentElement.classList.contains("Mui-checked")))); };
        for (let i = 0; i < 3 && regEl() && !regOn(); i++) { const r = regEl(); try { r.click(); } catch (e) {} if (!regOn()) press(r.closest("label") || r); await until(regOn, 800, 100); }
        if (!regOn()) { const lb = [...(wizard() || w).querySelectorAll("label")].find((l) => /^Συνταγογράφηση φαρμάκων$/.test(txt(l))); if (lb) { press(lb); await until(regOn, 800, 100); } }
        if (regEl() && !regOn()) return { err: "δεν επιλέχθηκε «Συνταγογράφηση φαρμάκων» (Είδος Συνταγής)" };
        // 🔁 10/11 (οδηγίες γιατρού): επαναλαμβανόμενη → 1ο βήμα «Μήνες» · επόμενο βήμα «Επανάληψη» 30 ή 28 ημέρες. Καταγράφει τι είδε (δοκιμαστικό).
        const rep = a.rep && [2, 3, 6].includes(+a.rep.n) ? { n: +a.rep.n, every: [28, 30].includes(+a.rep.every) ? +a.rep.every : 30 } : null;
        const repLog = rep ? { set: [], steps: [] } : null;
        const clk = (W, re) => [...W.querySelectorAll("button,label,[role=radio],[role=tab],[role=option],[role=button],[role=checkbox]")].filter(vis).find((x) => re.test(txt(x)));
        const look = (W) => ({ t: txt(W).slice(0, 500), clk: [...new Set([...W.querySelectorAll("button,label,[role=radio],[role=tab],[role=checkbox]")].filter(vis).map(txt).filter((x) => x && x.length < 50))].slice(0, 30), combos: [...W.querySelectorAll("[role=combobox]")].filter(vis).map((c) => { const f = c.closest(".MuiFormControl-root,[class*=FormControl]"); const l = f && f.querySelector("label"); return (l ? txt(l) : "") + " = " + txt(c); }).slice(0, 10) });
        const repStep = async () => { const W = wizard(); if (!W || !rep) return; const T = txt(W);
          if (!repLog.set.includes("μήνες") && /Μήνες|μήνες|Μήνας/.test(T)) {
            const b = clk(W, /^Μήνες$/) || clk(W, /^Μην/i); if (b) { press(b); await sleep(300); repLog.set.push("μήνες"); }
            const cb = [...W.querySelectorAll("[role=combobox]")].filter(vis).find((c) => { const f = c.closest(".MuiFormControl-root,[class*=FormControl]"); return /μήν|διάρκ|πλήθος|επαναλ/i.test((f && txt(f)) || ""); });
            if (cb) { const r = await pick(cb, (x) => new RegExp("(^|\\D)" + rep.n + "(\\D|$)").test(x)); if (!r.err) repLog.set.push("μήνες=" + r.val); } }
          const W2 = wizard(); if (W2 && !repLog.set.some((x) => /^επανάληψη/.test(x)) && /Επανάληψ/.test(txt(W2))) {
            const ev = new RegExp("(^|\\D)" + rep.every + "(\\D|$)");
            const b = clk(W2, new RegExp("^(Επανάληψη\\s*(ανά\\s*)?)?" + rep.every + "(\\s*ημ(έρες|\\.)?)?$", "i")); if (b) { press(b); await sleep(300); repLog.set.push("επανάληψη " + rep.every + " (" + txt(b).slice(0, 30) + ")"); }
            else { const cb = [...W2.querySelectorAll("[role=combobox]")].filter(vis).find((c) => { const f = c.closest(".MuiFormControl-root,[class*=FormControl]"); return /επαναλ|διάστημ|ημέρ/i.test((f && txt(f)) || ""); });
              if (cb) { const r = await pick(cb, (x) => ev.test(x)); if (!r.err) repLog.set.push("επανάληψη=" + r.val); } } }
          repLog.steps.push(look(wizard() || W)); };
        await repStep();
        for (let i = 0; i < 4 && !/Επιλέξτε τις διαγνώσεις/.test((wizard() || {}).innerText || ""); i++) { const t0 = (wizard() || {}).innerText || ""; press(btn(wizard(), /^Επόμενο$/)); await until(() => ((wizard() || {}).innerText || "") !== t0, 1500, 100); await sleep(120); if (rep && !/Επιλέξτε τις διαγνώσεις/.test((wizard() || {}).innerText || "")) await repStep(); }
        const repOut = rep ? { repOk: repLog.set.includes("μήνες") || repLog.set.some((x) => /^μήνες=/.test(x)) ? repLog.set.some((x) => /^επανάληψη/.test(x)) : false, repLog } : {};
        return /Επιλέξτε τις διαγνώσεις/.test((wizard() || {}).innerText || "") ? { ok: true, ...repOut } : { err: "ο οδηγός δεν έφτασε στο βήμα «Διαγνώσεις»" + (msgs() ? ": " + msgs() : ""), ...repOut };
      }
      if (op === "icd") {
        const WZ = () => (a.ref ? refWiz() : wizard());   // 8/11: στο παραπεμπτικό ο οδηγός είναι άλλος (refWiz)
        const w = a.ref ? refWiz() : WZ(); if (!w) return { err: a.ref ? "ο οδηγός παραπεμπτικού έκλεισε" : "ο οδηγός συνταγής έκλεισε" };
        const have = () => [...(a.ref ? refWiz() : WZ() || w).querySelectorAll("tbody tr")].some((r) => r.cells.length > 1 && [...r.cells].slice(0, 2).some((c) => { const t = txt(c); return t === a.code || t.startsWith(a.code + " "); }));
        if (have()) return { ok: true, already: true };
        // 8/11 ΡΙΖΑ: ο οδηγός είναι Radix Dialog (onOpenChange → reset + κλείσιμο) και η αναζήτηση ICD MUI Dialog σε ΑΛΛΟ portal.
        // Όταν κλείνει η αναζήτηση, η εστίαση γυρνά «έξω» από τον οδηγό → ο Radix το θεωρεί «κλικ/εστίαση έξω» και τον κλείνει.
        // Λύση: εστίαση στο κουμπί ΜΕΣΑ στον οδηγό πριν ανοίξει η αναζήτηση + μπλοκ των focus/pointer «έξω» όσο κρατά η εισαγωγή.
        const icdB = btn(w, /^Αναζήτηση ICD10$/); try { icdB && icdB.focus(); } catch (e) {}
        const W1 = w, guard = (ev) => { const t = ev.target; if (!t || !t.nodeType) return; if (W1.contains(t)) return; ev.stopImmediatePropagation(); };
        for (const ty of ["focusin", "focusout", "pointerdown", "mousedown"]) window.addEventListener(ty, guard, true);
        const unguard = () => setTimeout(() => { for (const ty of ["focusin", "focusout", "pointerdown", "mousedown"]) window.removeEventListener(ty, guard, true); try { const f = (WZ() || W1).querySelector("button,input"); f && f.focus && f.focus(); } catch (e) {} }, 1200);
        try {
        press(icdB);
        const d = await until(() => dialogs().find((x) => x !== w && x.querySelector("input#keyword") && /Αναζήτηση ICD10/.test(x.innerText)), 5000);
        if (!d) return { err: "δεν άνοιξε η αναζήτηση ICD-10" };
        setVal(d.querySelector("input#keyword"), a.code); await sleep(150);
        press(btn(d, /^Αναζήτηση$/));
        // 10/11 νυχτερινό (eptorture 2098 γύρος 1): «N39 δεν υπάρχει (βρέθηκαν: , , , , )» — 5 γραμμές με ΚΕΝΟ κωδικό = γραμμές φόρτωσης
        // (σκελετός πίνακα) της πρώτης αναζήτησης· μετρούσαν ως «αποτελέσματα» → λάθος «δεν υπάρχει». Τώρα μετρούν ΜΟΝΟ γραμμές με κωδικό
        // και όσο φαίνονται κενές γραμμές η αναμονή συνεχίζεται (δυναμικά, όσο φορτώνει).
        const rows = () => [...d.querySelectorAll("tbody tr")].filter((r) => r.cells.length > 2 && txt(r.cells[1]));
        const blank = () => [...d.querySelectorAll("tbody tr")].some((r) => r.cells.length > 2 && !txt(r.cells[1])) || !!d.querySelector("[class*=Skeleton],[class*=skeleton],[role=progressbar],.MuiCircularProgress-root,.MuiLinearProgress-root");
        const noRes = () => /Δεν (βρέθηκαν|υπάρχουν)/.test(d.innerText || "");
        await until(() => rows().length || noRes(), 2500);
        if (!rows().length && !noRes() && blank()) await until(() => rows().length || noRes() || !blank(), 30000);
        // 9/11 (eptorture 1845): καμία γραμμή και κανένα «Δεν βρέθηκαν» = η αναζήτηση δεν απάντησε ακόμα / το πάτημα χάθηκε → ξανά, μία φορά
        if (!rows().length && !noRes()) { const kw = d.querySelector("input#keyword"); if (kw && kw.value !== a.code) { setVal(kw, a.code); await sleep(150); } press(btn(d, /^Αναζήτηση$/)); await until(() => rows().length || noRes(), 8000); if (!rows().length && !noRes() && blank()) await until(() => rows().length || noRes() || !blank(), 30000); }
        const row = await until(() => rows().find((r) => txt(r.cells[1]) === a.code), 6000);
        if (!row) {
          const seen = rows().map((r) => txt(r.cells[1])).slice(0, 10);
          press(btn(d, /^Ακύρωση$/)); await sleep(300);
          if (!seen.length && !noRes()) return { err: `αναζήτηση ICD-10 «${a.code}»: το e-prescription δεν έδειξε αποτελέσματα (ούτε «Δεν βρέθηκαν») — δοκιμάστε ξανά` };
          return { err: `ο κωδικός ${a.code} δεν υπάρχει στη λίστα ICD-10 του e-prescription` + (seen.length ? ` (βρέθηκαν: ${seen.join(", ")})` : "") };
        }
        const title = txt(row.cells[2]);
        const T = [], tr = (k) => T.push(k + ":" + (WZ() ? "W" : "-") + dialogs().length + (vis(d) ? "d" : ""));   // 7/11: ίχνος (ο οδηγός κλείνει μετά το ICD;)
        tr("row");
        // 7/11: επιβεβαίωση ότι τσεκαρίστηκε και ότι η «Εισαγωγή» πατήθηκε (πριν: ένα πάτημα, χωρίς έλεγχο → «δεν μπήκε»)
        const cb = () => row.querySelector("[role=checkbox]"), on = () => { const c = cb(); return c && (c.getAttribute("aria-checked") === "true" || c.classList.contains("Mui-checked") || !!c.querySelector("input:checked")); };
        for (let i = 0; i < 3 && !on(); i++) { const c0 = cb(), inp = c0 && (c0.querySelector("input[type=checkbox]") || c0); try { inp.click(); } catch (e) { press(c0); } await until(on, 1200, 100); tr("cb" + i + (on() ? "+" : "") + (WZ() ? "W" : "-")); }
        // 8/11: το «Εισαγωγή» του ICD μπορεί να είναι submit ΜΕΣΑ στη φόρμα του οδηγού → υποβάλλει όλο τον οδηγό (κλείνει, «μη έγκυρα στοιχεία»).
        // Μπλοκάρουμε για λίγο την υποβολή ΑΛΛΗΣ φόρμας εκτός του διαλόγου ICD.
        const W0 = WZ() || w;
        // 🔎 8/11: ποιος κώδικας τρέχει στο «Εισαγωγή» (React fiber) — για να βρεθεί γιατί κλείνει ο οδηγός
        let FD = null; try {
          const ins0 = btn(d, /^Εισαγωγή$/), fk = ins0 && Object.keys(ins0).find((k) => k.startsWith("__reactFiber")); let f = fk && ins0[fk]; const L = [];
          for (let i = 0; f && i < 40; i++, f = f.return) { const pr = f.memoizedProps; if (!pr || typeof pr !== "object") continue; const fn = Object.keys(pr).filter((k) => typeof pr[k] === "function" && k !== "children" && !/^on(Mouse|Pointer|Focus|Blur|Key|Touch|Transition|Animation|Context|Drag|Wheel|Scroll|Copy|Paste)/.test(k));
            if (fn.length) L.push({ i, t: typeof f.type === "string" ? f.type : (f.type && (f.type.displayName || f.type.name)) || "?", fn: fn.slice(0, 8), src: fn.slice(0, 6).map((k) => k + "=" + String(pr[k]).replace(/\s+/g, " ").slice(0, 400)), keys: Object.keys(pr).slice(0, 14).join(",") }); }
          FD = L.slice(0, 30);
          // τιμές και σφάλματα της φόρμας του οδηγού (react-hook-form) ΠΡΙΝ το «Εισαγωγή»
          try { let f2 = ins0[fk]; for (let i = 0; f2 && i < 60; i++, f2 = f2.return) { const pr = f2.memoizedProps; if (pr && typeof pr.getValues === "function" && pr.control) {
            const v = pr.getValues(); const er = (pr.control._formState && pr.control._formState.errors) || {};
            FD.push({ form: JSON.stringify(v, (k, x) => (typeof x === "string" && x.length > 60 ? x.slice(0, 60) : x)).replace(/\d{9,}/g, "#").slice(0, 1500), errs: JSON.stringify(Object.keys(er)).slice(0, 300) });
            break; } } } catch (e) { FD.push({ formErr: e.message }); }
        } catch (e) { FD = { err: e.message }; }
        const blockSub = (ev) => { const f = ev.target; if (f && d.contains(f)) return; ev.preventDefault(); ev.stopImmediatePropagation(); T.push("⛔submit"); };
        document.addEventListener("submit", blockSub, true);
        try {
        // 8/11: ΠΡΩΤΑ απευθείας στη φόρμα του οδηγού (react-hook-form setValue) με τα στοιχεία της γραμμής ICD — χωρίς «Εισαγωγή»
        // (που κλείνει όλο τον οδηγό). Μετά κλείνει μόνο η αναζήτηση (onClose του διαλόγου ICD).
        try {
          const fib = (el) => { const k = el && Object.keys(el).find((x) => x.startsWith("__reactFiber")); return k ? el[k] : null; };
          // η εγγραφή ICD (id/code/title) από props ή state (hooks) των στοιχείων React γύρω από τη γραμμή/τον διάλογο
          const isIt = (v) => v && typeof v === "object" && !Array.isArray(v) && (v.code === a.code || v.diagnosisCode === a.code) && (v.id != null || v.diagnosisId != null);
          const seek = (v, dep) => { if (!v || typeof v !== "object" || dep > 3) return null; if (isIt(v)) return v; const vals = Array.isArray(v) ? v.slice(0, 60) : Object.values(v).slice(0, 40); for (const x of vals) { if (x && typeof x === "object" && !(x instanceof Node) && !x.$$typeof) { const r = seek(x, dep + 1); if (r) return r; } } return null; };
          let item = null;
          for (const start of [row, d]) { for (let f = fib(start), i = 0; f && i < 30 && !item; i++, f = f.return) { item = seek(f.memoizedProps, 0); for (let h = f.memoizedState, k = 0; !item && h && k < 30; h = h.next, k++) item = seek(h.memoizedState, 0); } if (item) break; }
          if (item && item.diagnosisCode && !item.code) item = { id: item.diagnosisId, code: item.diagnosisCode, title: item.diagnosisDesc };
          const insB = btn(d, /^Εισαγωγή$/); let oi = null, form = null;
          for (let f = fib(insB), i = 0; f && i < 60; i++, f = f.return) { const pr = f.memoizedProps || {}; if (!oi && pr.formFieldName && typeof pr.mapToFormField === "function" && typeof pr.onClose === "function") oi = pr; if (!form && typeof pr.setValue === "function" && typeof pr.getValues === "function" && pr.control) form = pr; if (oi && form) break; }
          T.push("rhf:" + (item ? "i" : "-") + (oi ? "o" : "-") + (form ? "f" : "-"));
          if (item && oi && form && !a.ref) {   // παραπεμπτικό: το «Εισαγωγή» δουλεύει (έλεγχος 7/11) → μόνο κλικ
            const cur = [].concat(form.getValues(oi.formFieldName) || []), add = oi.mapToFormField([item]);
            // 8/11 ΛΥΣΗ: η τιμή μπαίνει ΚΑΙ στην κύρια φόρμα της συνταγής (ue). Αν ο οδηγός κλείσει, η «Τροποποίηση» τον ξανανοίγει
            // με me.reset(ue.getValues()) → η διάγνωση είναι ήδη μέσα (κώδικας e-prescription: le/«Τροποποίηση»).
            let ueF = null;
            if (!a.ref) try { for (let f = fib(W0), i = 0; f && i < 150 && !ueF; i++, f = f.return) { const forms = []; for (let h = f.memoizedState, k = 0; h && typeof h === "object" && "next" in h && k < 250; h = h.next, k++) { const c = h.memoizedState && h.memoizedState.current; if (c && typeof c === "object" && typeof c.setValue === "function" && typeof c.getValues === "function" && c.control) forms.push(c); }
              if (forms.length >= 2 && forms.some((x) => x.control === form.control)) ueF = forms.find((x) => x.control !== form.control && Array.isArray(x.getValues(oi.formFieldName))) || null; } } catch (e) {}
            if (ueF) { const cu = [].concat(ueF.getValues(oi.formFieldName) || []); if (!cu.some((x) => x && x.diagnosisCode === a.code)) ueF.setValue(oi.formFieldName, cu.concat(add), { shouldDirty: true, shouldValidate: false }); }
            T.push("ue:" + (ueF ? 1 : 0));
            if (!cur.some((x) => x && (x.diagnosisCode === a.code))) form.setValue(oi.formFieldName, cur.concat(add), { shouldDirty: true, shouldValidate: false });
            await sleep(900); tr("sv");
            if (a.keepIcdOpen) { T.push("keep"); return { err: "δοκιμή: έμεινε ανοιχτή η αναζήτηση [" + T.join(" ") + "]", icdDiag: FD }; }
            oi.onClose(); await until(() => !vis(d), 3000); await sleep(400); tr("rhf");
            if (WZ() && await until(have, 3000)) return { ok: true, title, trace: T.join(" "), via: "setValue" };
            // ο πίνακας μπορεί να μη δείχνει τη γραμμή (useFieldArray), αλλά η τιμή της φόρμας την έχει → αρκεί για το «Επόμενο»
            const inForm = [].concat(form.getValues(oi.formFieldName) || []).some((x) => x && x.diagnosisCode === a.code);
            T.push("inForm:" + (inForm ? 1 : 0) + (WZ() ? "W" : "-"));
            if (WZ() && inForm) return { ok: true, title, trace: T.join(" "), via: "setValue(form)" };
          }
        } catch (e) { T.push("rhfErr:" + String(e.message || e).slice(0, 80)); }
        if (!WZ()) { let ueSet = false; try { ueSet = !!window.__efUeDx && [].concat(window.__efUeDx() || []).some((x) => x && x.diagnosisCode === a.code); } catch (e) {}
          return { err: (a.ref ? "ο οδηγός παραπεμπτικού έκλεισε (setValue)" : "ο οδηγός συνταγής έκλεισε (setValue)") + " μετά το " + a.code + " [" + T.join(" ") + "]" + (msgs() ? ": " + msgs() : ""), icdDiag: FD, ueSet: ueSet || T.includes("ue:1") }; }
        for (let i = 0; i < 3 && vis(d); i++) { const ins = btn(d, /^Εισαγωγή$/); if (!ins) break; await until(() => !ins.disabled && ins.getAttribute("aria-disabled") !== "true", 2000, 100); if (i === 0) { tr("btns=" + [...d.querySelectorAll("button")].filter(vis).map(txt).join("/").slice(0, 120)); T.push("form=" + (ins.form ? ((d.contains(ins.form) ? "D" : "") + (W0 && W0.contains(ins.form) ? "W" : "") + (ins.form.contains(d) ? "⊃d" : "")) : "none") + " type=" + ins.type + " dInW=" + (W0 && W0.contains(d) ? 1 : 0)); if (ins.type === "submit" && ins.form && !d.contains(ins.form)) { ins.type = "button"; T.push("→button"); } }
          // 8/11: ΠΡΩΤΑ ο χειριστής React του κουμπιού ΚΑΤΕΥΘΕΙΑΝ (χωρίς πραγματικό συμβάν που «ανεβαίνει» μέσα από το δέντρο React
          // ως τον οδηγό και τον κλείνει)· μόνο αν δεν υπάρχει → κανονικό click
          const rk = Object.keys(ins).find((k) => k.startsWith("__reactProps")), rp = rk && ins[rk];
          if (i === 0 && rp && typeof rp.onClick === "function") {
            const ne = new MouseEvent("click", { bubbles: false }); let stopped = false;
            try { rp.onClick({ type: "click", target: ins, currentTarget: ins, nativeEvent: ne, button: 0, preventDefault() {}, stopPropagation() { stopped = true; }, isPropagationStopped: () => true, isDefaultPrevented: () => false, persist() {} }); T.push("rp"); } catch (e) { T.push("rpErr:" + String(e.message || e).slice(0, 60)); try { ins.click(); } catch (e2) { press(ins); } }
          } else { try { ins.click(); } catch (e) { press(ins); } }
          await until(() => !vis(d), 3000); tr("ins" + i); }
        await sleep(300); tr("end");
        } finally { setTimeout(() => document.removeEventListener("submit", blockSub, true), 1500); }
        if (!WZ()) return { err: "ο οδηγός συνταγής έκλεισε μετά την εισαγωγή του " + a.code + " [" + T.join(" ") + "]" + (msgs() ? ": " + msgs() : ""), icdDiag: FD };
        if (await until(have, 5000)) return { ok: true, title, trace: T.join(" ") };
        if (vis(d)) { press(btn(d, /^Ακύρωση$/)); await sleep(300); }
        return { err: "ο κωδικός " + a.code + " δεν μπήκε στη συνταγή" + (on() ? "" : " (δεν τσεκαρίστηκε)") };
        } finally { unguard(); }
      }
      if (op === "toTher") {
        // 7/11: πώς είναι το βήμα «Διαγνώσεις» ΠΡΙΝ το «Επόμενο» (γραμμές ICD, επιλογές ανά γραμμή) — για τη διάγνωση
        let pre = null; try { const W = wizard(); pre = { d: wizDiag(), rows: [...W.querySelectorAll("tbody tr")].slice(0, 4).map((r) => String(r.outerHTML).replace(/\s+/g, " ").replace(/\d{6,}/g, "#").slice(0, 900)) }; } catch (e) {}
        press(btn(wizard(), /^Επόμενο$/));
        const ok = await until(() => /Προσθέστε θεραπείες/.test((wizard() || {}).innerText || ""), 5000);
        return ok ? { ok: true } : { err: "ο οδηγός δεν πέρασε στις θεραπείες" + (msgs() ? ": " + msgs() : ""), wiz: Object.assign(wizDiag(), { pre }) };
      }
      if (op === "wizDiag") return { ok: true, wiz: wizDiag() };
      // 8/11: ο οδηγός έκλεισε μετά τη διάγνωση → «Τροποποίηση» (ΜΟΝΟ ανοίγει τον οδηγό) → «Επόμενο» ως τις Διαγνώσεις → είναι μέσα ο κωδικός;
      if (op === "reopenDx") {
        if (!wizard()) { const b = [...document.querySelectorAll("button")].find((x) => vis(x) && /^Τροποποίηση$/.test(txt(x))); if (!b) return { err: "δεν βρέθηκε «Τροποποίηση»" }; press(b); if (!(await until(() => wizard(), 6000))) return { err: "δεν ξανάνοιξε ο οδηγός" }; await sleep(500); }
        for (let i = 0; i < 6 && wizard() && !/Επιλέξτε τις διαγνώσεις/.test(txt(wizard())); i++) { const t0 = txt(wizard()); const nx = btn(wizard(), /^Επόμενο$/); if (!nx) break; press(nx); await until(() => !wizard() || txt(wizard()) !== t0, 3000); await sleep(250); }
        if (!wizard()) return { err: "ο οδηγός ξανάκλεισε" + (msgs() ? ": " + msgs() : "") };
        if (!/Επιλέξτε τις διαγνώσεις/.test(txt(wizard()))) return { err: "ο οδηγός δεν έφτασε στις Διαγνώσεις" + (msgs() ? ": " + msgs() : "") };
        const codes = [].concat(a.codes || []);
        const rowsT = [...wizard().querySelectorAll("tbody tr")].map((r) => [...r.cells].slice(0, 2).map(txt).join(" "));
        const miss = codes.filter((c) => !rowsT.some((t) => t === c || t.startsWith(c + " ") || t.includes(" " + c + " ") || t.split(" ").includes(c)));
        return miss.length ? { err: "μετά την «Τροποποίηση» λείπουν: " + miss.join(", "), rows: rowsT.slice(0, 6) } : { ok: true, rows: rowsT.slice(0, 6) };
      }
      // 🔎 8/11 (μόνο δοκιμές): αποσπάσματα από τον κώδικα JS της σελίδας γύρω από δοσμένα μοτίβα — για να βρεθεί τι κλείνει τον οδηγό
      if (op === "srcGrep") {
        const urls = [...new Set([...document.scripts].map((x) => x.src).filter(Boolean).concat(performance.getEntriesByType("resource").map((e) => e.name).filter((u) => /\.m?js(\?|$)/.test(u))))].filter((u) => u.startsWith(location.origin)).slice(0, 60);
        const out = [], seen = new Set();
        for (const u of urls) { let t = ""; try { t = await (await fetch(u, { credentials: "include" })).text(); } catch (e) { continue; }
          for (const pat of a.pats || []) { let i = -1, n = 0; while ((i = t.indexOf(pat, i + 1)) >= 0 && n < (a.max || 3)) { n++; const k = u + "@" + Math.floor(i / 2000); if (seen.has(k)) continue; seen.add(k); out.push({ u: u.replace(location.origin, "").slice(-60), pat, at: i, s: t.slice(Math.max(0, i - (a.before || 1500)), i + (a.after || 800)) }); } } }
        for (const at of a.at || []) { const u = urls.find((x) => x.includes(at.f)); if (!u) continue; try { const t = await (await fetch(u, { credentials: "include" })).text(); out.push({ u: at.f, at: at.p, s: t.slice(Math.max(0, at.p - (at.b || 1200)), at.p + (at.a || 600)) }); } catch (e) {} }
        return { ok: true, urls: urls.map((u) => u.replace(location.origin, "").slice(-60)), out: out.slice(0, a.lim || 12) };
      }
      // 7/11: η σελίδα έδειξε «Τα στοιχεία της συνταγής δεν είναι έγκυρα… Τροποποίηση» → πάτημα «Τροποποίηση» (ξανανοίγει ο οδηγός με τα λάθη σημειωμένα)
      // και καταγραφή των πεδίων με σφάλμα. ΠΟΤΕ «Καταχώριση»/«Προσωρινή Καταχώριση».
      if (op === "modDiag") {
        const b = [...document.querySelectorAll("button")].find((x) => vis(x) && /^Τροποποίηση$/.test(txt(x)));
        if (!b) return { ok: false, wiz: wizDiag() };
        press(b); await until(() => wizard(), 6000); await sleep(800);
        // περιήγηση στα βήματα (μόνο «Επόμενο» — καμία καταχώριση): τι ζητά κάθε βήμα και ποιο δεν περνά
        const walk = [];
        for (let i = 0; i < 5 && wizard(); i++) { const W = wizard(), t0 = txt(W);
          walk.push({ i, text: t0.slice(0, 700), inputs: wizDiag().inputs, err: [...W.querySelectorAll(".Mui-error,.MuiFormHelperText-root,.MuiAlert-message,[role=alert]")].filter(vis).map(txt).filter(Boolean).slice(0, 8) });
          if (/Προσθέστε θεραπείες|Επιλέξτε τις διαγνώσεις/.test(t0) && i > 0) break;
          const nx = btn(W, /^Επόμενο$/); if (!nx) break; press(nx); await until(() => !wizard() || txt(wizard()) !== t0, 3000); await sleep(400); if (!wizard()) { walk.push({ i: i + 1, closed: true, alerts: msgs() }); break; } }
        const w = wizard(); const errTxt = w ? [...w.querySelectorAll(".Mui-error,[class*=error],[class*=Error],.MuiFormHelperText-root,.MuiAlert-message,[role=alert]")].filter(vis).map(txt).filter(Boolean) : [];
        return { ok: true, wiz: wizDiag(), errTxt: [...new Set(errTxt)].slice(0, 15), walk };
      }
      if (op === "med") {
        const therRows = () => { const w = wizard(); return w ? [...w.querySelectorAll("tbody tr")].filter((r) => r.querySelectorAll("[role=combobox]").length >= 5) : []; };
        const before = therRows().length;
        const T0 = Date.now(), tm = {}, mark = (k) => { tm[k] = Date.now() - T0; };   // ⏱ πού πάει ο χρόνος (μόνο μέτρηση)
        press(btn(wizard(), /^Αναζήτηση Φαρμάκου$/));
        const d = await until(() => dialogs().find((x) => x !== wizard() && x.querySelector("input#keyword") && /Αναζήτηση Φαρμάκου/.test(x.innerText)), 5000);
        if (!d) return { err: "δεν άνοιξε η αναζήτηση φαρμάκου" };
        mark("dlg");
        const ty = d.querySelector("[role=combobox]");
        if (ty && !/Εμπορική/.test(txt(ty))) await pick(ty, (t) => /^Εμπορική/.test(t));
        setVal(d.querySelector("input#keyword"), up(a.name)); await sleep(150);
        const nMed = () => ((window.__efEp || {}).log || []).filter((e) => /medicine\/search/.test(e.p || "")).length, nm0 = nMed();
        press(btn(d, /^Αναζήτηση$/));
        // 8/11: αν το «Αναζήτηση» δεν έστειλε αίτημα (π.χ. άλλο παράθυρο από πάνω) → υποβολή της φόρμας του διαλόγου / Enter
        if (!(await until(() => nMed() > nm0, 2500, 150))) { const kw = d.querySelector("input#keyword"), f = kw && kw.closest("form"); try { if (f && f.requestSubmit) f.requestSubmit(); else kw.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, bubbles: true })); } catch (e) {} await until(() => nMed() > nm0, 2500, 150); }
        const medSent = nMed() > nm0, dlgT = dialogs().map((x) => txt(x).slice(0, 40)).join(" / ");
        // όσο φορτώνει, ο πίνακας έχει κενές γραμμές-«σκελετούς»· περιμένουμε γραμμές με όνομα που ταιριάζει
        const rowsNow = () => [...d.querySelectorAll("tbody tr")].filter((r) => r.cells.length > 8 && txt(r.cells[2]));
        await until(() => rowsNow().some((r) => up(txt(r.cells[2])).startsWith(up(a.name))), 10000);
        const all = rowsNow().length ? rowsNow() : null; mark("rows");
        const cancel = async () => { const c = btn(d, /^Ακύρωση$/); if (c) { press(c); await sleep(300); } };
        if (!all) { let dg = ""; try { const rr = [...d.querySelectorAll("tbody tr")].filter(vis); dg = " [γραμμές " + rr.length + ": " + rr.slice(0, 4).map((r) => txt(r).slice(0, 50)).join(" | ") + " · τύπος «" + (ty ? txt(ty).slice(0, 25) : "-") + "» · λέξη «" + ((d.querySelector("input#keyword") || {}).value || "") + "» · αίτημα " + (medSent ? "✓" : "✗") + " · παράθυρα: " + dlgT + " · " + txt(d).replace(/\s+/g, " ").slice(0, 120) + "]"; } catch (e) {}
          await cancel(); return { err: `δεν βρέθηκε φάρμακο «${a.name}» στο e-prescription` + dg }; }
        // επιλογή συσκευασίας: ίδιο όνομα, ίδια περιεκτικότητα, και όσο λιγότερα κουτιά/περίσσευμα γίνεται
        const num = (s) => parseFloat(String(s).replace(",", "."));
        const sNum = num(a.strength), sUnit = (String(a.strength).match(/[a-zA-Zμ]+$/) || [""])[0].toUpperCase().replace("Μ", "M");
        const strOk = (str) => {
          if (isNaN(sNum)) return true;
          const S = up(str).replace(/,/g, ".");
          const nums = [...S.matchAll(/(\d+(?:\.\d+)?)\s*([A-Z]*)/g)].map((m) => ({ n: parseFloat(m[1]), u: m[2] }));
          return nums.some((x) => Math.abs(x.n - sNum) < 1e-9 && (!sUnit || !x.u || x.u.startsWith(sUnit)));
        };
        const packN = (p) => { const S = up(p); const m = S.match(/(?:B|Β)(?:T|Τ)\s*[XΧ]?\s*(\d+)/) || S.match(/(\d+)/); return m ? +m[1] : 0; };
        const cand = all.map((r) => ({ r, name: txt(r.cells[2]), form: txt(r.cells[3]), str: txt(r.cells[4]), pack: txt(r.cells[5]), atc: txt(r.cells[7]), subst: txt(r.cells[8]) }))
          .filter((c) => up(c.name).startsWith(up(a.name)) && strOk(c.str));
        if (!cand.length) {
          const seen = all.slice(0, 6).map((r) => txt(r.cells[2])).join(" · ");
          await cancel();
          return { err: `«${a.name} ${a.strength}»: δεν βρέθηκε αυτή η περιεκτικότητα` + (seen ? ` (υπάρχουν: ${seen})` : "") };
        }
        cand.forEach((c) => { c.n = packN(c.pack) || 1; c.boxes = Math.max(1, Math.ceil((a.need || 1) / c.n)); c.waste = c.boxes * c.n - (a.need || 1); });
        cand.sort((x, y) => x.boxes - y.boxes || x.waste - y.waste || x.n - y.n);
        // ίδια συσκευασία με αυτή που είδε ο γιατρός στο κινητό (τεμάχια/κουτί), αν υπάρχει — αλλιώς η πιο οικονομική
        const ch = (a.perBox && cand.find((c) => c.n === a.perBox)) || cand[0];
        press(ch.r.cells[0].querySelector("button"));
        await until(() => therRows().length > before || dialogs().some((x) => btn(x, ACK)), 8000);
        const notes = await ack();
        if (vis(d)) await cancel();
        mark("added"); const tr0 = await until(() => therRows()[before], 4000);
        if (!tr0) return { err: `«${ch.name}» δεν μπήκε στη συνταγή` + (notes.length ? ": " + notes.join(" · ") : msgs() ? ": " + msgs() : ""), notes };
        const cb = (i) => (therRows()[before] || tr0).querySelectorAll("[role=combobox]")[i];
        const warn = [];
        const set = async (i, test, what) => { const tf = Date.now(); const r = await pick(cb(i), test); tm["f" + i] = Date.now() - tf; if (r.err) warn.push(`${what}: ${r.err}` + (r.list ? ` (${r.list.slice(0, 8).join(" | ")})` : "")); return r; };
        // σειρά: ποσότητα, ασθένεια, % συμμετοχή, ποσό δόσης, συχνότητα, ημέρες (η μονάδα δόσης είναι σταθερή)
        // κουτιά: ό,τι επέλεξε ο γιατρός (a.boxes), αλλιώς από τη συσκευασία· ποτέ λιγότερα χωρίς σημείωση
        let qty = a.boxes > 0 ? a.boxes : ch.boxes;
        const notes0 = [];
        if (a.boxes > 0 && a.boxes < ch.boxes) notes0.push(`${ch.name}: ζητήθηκαν ${a.boxes} κουτιά ενώ για ${a.need || "?"} τεμάχια χρειάζονται ${ch.boxes} (συσκευασία ${ch.pack})`);
        const want = qty;
        // 8/11 ΔΙΟΡΘΩΣΗ: τα πεδία αναγνωρίζονται από το ΠΕΡΙΕΧΟΜΕΝΟ της λίστας τους, όχι από τη θέση (όταν λείπει η «ασθένεια»,
        // π.χ. Algofren με 1 διάγνωση, όλα μετατοπίζονταν: «ποσό δόσης» έπαιρνε «1 φορά την ημέρα»). Κάθε είδος συμπληρώνεται ΜΙΑ φορά.
        const kindOf = (list) => {
          const L = list.map((x) => String(x).trim()).filter(Boolean);
          if (L.some((x) => /%$/.test(x))) return "part";
          if (L.some((x) => /φορ(ά|ές) την ημέρα/i.test(x))) return "freq";
          if (L.some((x) => /^\d+\s*ημέρ/i.test(x))) return "days";
          const nums = L.map((x) => +String(x).replace(",", "."));
          if (L.length && nums.every((x) => !isNaN(x))) return nums.some((x) => x % 1 !== 0) ? "dose" : "qty";
          return "disease";
        };
        const WHAT = { qty: "ποσότητα", disease: "ασθένεια", part: "% συμμετοχή", dose: "ποσό δόσης", freq: "συχνότητα", days: "ημέρες" };
        const TEST = {
          qty: (t, list) => { const nums = list.map((x) => +x).filter((x) => !isNaN(x)); const mx = Math.max(...nums); if (qty > mx) { qty = mx; } return +t === qty; },
          disease: (t, list) => t === a.disease || (list.length === 1),
          part: (t) => t.replace(/\s/g, "") === String(a.part).replace(/\s/g, ""),
          dose: (t) => Math.abs(num(t) - num(a.dose)) < 1e-9,
          freq: (t) => t === (a.freq === 1 ? "1 φορά την ημέρα" : a.freq + " φορές την ημέρα"),
          days: (t) => (t.match(/^(\d+)\s*ημέρ/) || [])[1] === String(a.days),
        };
        const done = {}, nCb = ((therRows()[before] || tr0).querySelectorAll("[role=combobox]") || []).length;
        for (let i = 0; i < nCb && i < 10; i++) {
          const combo = cb(i); if (!combo) break;
          press(combo);
          const opts = await until(() => { const o = [...document.querySelectorAll("[role=option]")].filter(vis); return o.length ? o : null; }, 3000);
          if (!opts) { esc(); await sleep(200); continue; }
          const list = opts.map(txt), k = kindOf(list);
          // ακέραιοι 1..Ν: η ΠΡΩΤΗ τέτοια λίστα = κουτιά· αν ξαναβρεθεί (π.χ. δόση χωρίς δεκαδικά) = ποσό δόσης
          const kind = k === "qty" && done.qty ? "dose" : k;
          if (done[kind] || !TEST[kind]) { esc(); await sleep(200); continue; }
          const o = opts.find((x) => TEST[kind](txt(x), list));
          if (!o) { esc(); await sleep(250); warn.push(`${WHAT[kind]}: δεν υπάρχει στη λίστα (${list.slice(0, 8).join(" | ")})`); done[kind] = "err"; continue; }
          press(o); await until(() => combo.getAttribute("aria-expanded") !== "true" && ![...document.querySelectorAll("[role=option]")].some(vis), 600, 50); await sleep(60);
          if (combo.getAttribute("aria-expanded") === "true") { esc(); await sleep(200); }
          done[kind] = "ok";
        }
        if (qty < want) warn.push(`ποσότητα: ζητήθηκαν ${want} κουτιά αλλά το e-prescription επιτρέπει έως ${qty}`);
        for (const k of ["qty", "part", "dose", "freq", "days"]) if (!done[k]) warn.push(`${WHAT[k]}: δεν βρέθηκε το πεδίο`);
        mark("fields");
        // συσχέτιση με διαγνώσεις: ο πρώτος combobox στις γραμμές λεπτομερειών κάτω από τη θεραπεία
        const dxCombo = () => {
          const tr = therRows()[before]; if (!tr) return null;
          for (let s = tr.nextElementSibling; s && s.querySelectorAll("[role=combobox]").length < 5; s = s.nextElementSibling) {
            const c = s.querySelector("[role=combobox]"); if (c) return c;
          }
          return null;
        };
        if (!dxCombo()) { press(therRows()[before]?.cells[0]?.querySelector("button")); await until(dxCombo, 2000); }
        const dx = await pick(dxCombo(), (t) => /^Επιλογή όλων$/.test(t));
        if (dx.err) warn.push("συσχέτιση με διαγνώσεις: " + dx.err);
        const row = [...(therRows()[before] || tr0).cells].map(txt).filter(Boolean).join(" · ");
        mark("end");
        return { ok: true, chosen: `${ch.name} (${ch.pack})`, atc: ch.atc, subst: ch.subst, boxes: qty, row, warn, notes: notes.concat(notes0), tm };
      }
      if (op === "finish") {
        const w = wizard(); if (!w) return { ok: true, already: true };
        press(btn(w, /^Ολοκλήρωση$/));
        const r = await until(() => !wizard() ? "closed" : (/διορθώστε το σφάλμα/i.test(wizard().innerText) ? "errors" : null), 10000);
        if (r === "closed") { a.afterFinish = true; const notes = await ack(); return { ok: true, notes }; }
        const errs = (wizard()?.innerText || "").split("\n").map((s) => s.trim()).filter((s) => /διορθώστε|υποχρεωτικ/i.test(s));
        return { err: errs.length ? errs.join(" · ") : "ο οδηγός δεν ολοκληρώθηκε" };
      }
      // ✅ «Καταχώριση» — ΜΟΝΟ από JOB_APPROVE.rx (ο γιατρός πάτησε «Καταχώριση» στο κινητό αφού είδε τη σύνοψη)
      if (op === "submit" || op === "submit2") {
        const SUCC = /επιτυχ[ηή]ς καταχ[ωώ]ρ|καταχωρ[ίι]στηκε|καταχωρ[ήη]θηκε|ολοκληρώθηκε η καταχώριση|επιτυχώς/i, NEG = /δεν|ανεπιτυχ|σφάλμα|αποτυχ|λάθος|error/i;
        const nums = (t) => new Set(String(t || "").match(/\b\d{13}\b/g) || []);
        const pre = { nums: nums(txt(document.body)), msgs: new Set(msgs().split(" · ").filter(Boolean)) };
        const look = () => { const d = dialogs()[0]; return d ? { dlg: txt(d).slice(0, 900), btns: [...d.querySelectorAll("button")].filter(vis).map(txt).filter((t) => t && t.length < 40).slice(0, 8) } : null; };
        const p0 = location.pathname;
        if (op === "submit") {
          if (wizard() || refWiz()) return { err: "ο οδηγός " + (wizard() ? "συνταγής" : "παραπεμπτικού") + " είναι ακόμα ανοιχτός", pre: true };
          const d0 = look(); if (d0) return { err: "υπάρχει ανοιχτό παράθυρο στη σελίδα: «" + d0.dlg.slice(0, 200) + "»", pre: true };
          const b = btn(document, /^Καταχώριση$/); if (!b) return { err: "δεν βρέθηκε το κουμπί «Καταχώριση»", pre: true };
          press(b);
        } else {
          const d = dialogs()[0]; if (!d) return { err: "το παράθυρο δεν είναι πια ανοιχτό", pre: true };
          if (txt(d).slice(0, 900) !== a.dlg) return { err: "το παράθυρο άλλαξε", changed: look(), pre: true };
          const b = [...d.querySelectorAll("button")].find((x) => vis(x) && txt(x) === a.btn); if (!b) return { err: "δεν βρέθηκε το κουμπί «" + a.btn + "»", pre: true };
          await fillDlg(d); await sleep(150);   // 9/11: αιτιολόγηση «ίδιο φάρμακο» κ.λπ. → κουτάκι + «Παράταση προγενέστερης συνταγής»
          press(b);
        }
        await until(() => look() || location.pathname !== p0 || !btn(document, /^Καταχώριση$/), 20000, 250);
        await sleep(1200);
        const L = look(), newMsgs = msgs().split(" · ").filter((m) => m && !pre.msgs.has(m)).join(" · ");
        const fresh = ((L && L.dlg) || "") + " " + newMsgs;   // ΜΟΝΟ ό,τι εμφανίστηκε μετά το πάτημα
        const bc = [...nums(fresh)].find((n) => !pre.nums.has(n)) || "";
        const still = !!btn(document, /^Καταχώριση$/) && !wizard();
        return { ok: true, path: location.pathname, moved: location.pathname !== p0, still, dlg: L && L.dlg, btns: L && L.btns, succ: SUCC.test(fresh) && !NEG.test(fresh), neg: NEG.test(fresh), barcode: bc, msg: newMsgs, login: /\/oauth\/|login|pkmsoidc/i.test(location.href) };
      }
      // ===== 📋 Παραπεμπτικό (ΠΟΤΕ «Καταχώριση»/«Προσωρινή Καταχώριση» εδώ) =====
      const refUi = (d) => ({ text: txt(d).slice(0, 1500), b: [...new Set([...d.querySelectorAll("button")].filter(vis).map(txt).filter((t) => t && t.length < 50))].slice(0, 30),
        f: [...d.querySelectorAll("input,textarea,[role=combobox],[role=checkbox],[role=radio]")].filter(vis).slice(0, 30).map((i) => [i.tagName.toLowerCase(), i.getAttribute("role") || i.type || "", i.id && "#" + i.id, i.name && "n=" + i.name, (i.placeholder || "").slice(0, 30), (txt(i) || "").slice(0, 40)].filter(Boolean).join(" ")),
        rows: [...d.querySelectorAll("tbody tr")].filter(vis).slice(0, 15).map((r) => txt(r).slice(0, 160)), msg: msgs() });
      if (op === "refOpen") {
        if (!refWiz()) { const b = await until(() => btn(document, /^\+\s*Νέο\s*Παραπεμπτικό$/), 8000); if (!b) return { err: "δεν βρέθηκε «+ Νέο Παραπεμπτικό»", path: location.pathname }; press(b); }
        const w = await until(refWiz, 8000); return w ? { ok: true, ...refUi(w) } : { err: "δεν άνοιξε ο οδηγός παραπεμπτικού" };
      }
      if (op === "refBasic") {
        const w = refWiz(); if (!w) return { err: "ο οδηγός παραπεμπτικού έκλεισε" };
        const cb = [...w.querySelectorAll("[role=combobox]")].filter(vis).find((c) => /Επιλέξτε κατηγορία/.test(txt(c))) || [...w.querySelectorAll("[role=combobox]")].filter(vis)[1];
        // a.catKey (runner «ref»): χωρίς τόνους/πεζά-κεφαλαία, ΜΟΝΑΔΙΚΗ επιλογή (ακριβής > περιέχει· «…1» ≠ «…10») — αλλιώς σφάλμα με τις υποψήφιες
        const kHit = (x) => { const u = up(x), k = up(a.catKey); const i = u.indexOf(k); return !!k && i >= 0 && !/[0-9]/.test(u.charAt(i + k.length)); };
        const kOne = (list) => { if (a.cat && list.includes(a.cat)) return a.cat; const ex = list.filter((x) => up(x) === up(a.catKey)); if (ex.length === 1) return ex[0]; const h = list.filter(kHit); return h.length === 1 ? h[0] : null; };
        if ((a.cat || a.catRe || a.catKey) && !cb) return { err: "δεν βρέθηκε το πεδίο «Κατηγορία Εξέτασης»", ...refUi(w) };
        if ((a.cat || a.catRe || a.catKey) && cb && txt(cb) !== a.cat && !(a.catKey && up(txt(cb)) === up(a.catKey))) {
          let chosen = "";
          const r = await pick(cb, (t, list) => { const ok = a.catKey ? t === kOne(list) : (a.cat && t === a.cat) || (!!a.catRe && new RegExp(a.catRe, "i").test(t)); if (ok) chosen = t; return ok; });
          if (r.err) { const h = a.catKey ? (r.list || []).filter(kHit) : []; return { err: "κατηγορία «" + (a.cat || a.catKey) + "»: " + (h.length > 1 ? "ασαφής (" + h.join(" | ") + ")" : r.err), list: (r.list || []).slice(0, 45) }; }
          // επαλήθευση: το πεδίο δείχνει ΑΥΤΟ που διαλέχτηκε (χωρίς τόνους)
          await sleep(200);
          if (a.catKey && nn(txt(cb)) !== nn(chosen)) return { err: "η κατηγορία δεν κράτησε την επιλογή («" + chosen + "» → το πεδίο δείχνει «" + txt(cb) + "»)" };
        }
        const j = w.querySelector("textarea#justification"); if (!j) return { err: "δεν βρέθηκε η «Αιτιολογία»" };
        if (a.just) setVal(j, String(a.just).slice(0, 2000));
        if (a.remarks) { const rm = w.querySelector("textarea#remarks"); if (rm) setVal(rm, String(a.remarks).slice(0, 200)); }
        await sleep(300);
        return { ok: true, cat: cb ? txt(cb) : "", ...refUi(w) };
      }
      if (op === "refNext") {
        const w = refWiz(); if (!w) return { err: "ο οδηγός παραπεμπτικού έκλεισε" };
        const t0 = txt(w); const nx = btn(w, /^Επόμενο$/); if (!nx) return { err: "δεν υπάρχει «Επόμενο»", ...refUi(w) };
        press(nx); await until(() => { const x = refWiz(); return !x || txt(x) !== t0; }, 5000); await sleep(600);
        const w2 = refWiz(); if (w2 && txt(w2) === t0) return { err: "ο οδηγός δεν προχώρησε" + (msgs() ? ": " + msgs() : ""), ...refUi(w2) };
        return w2 ? { ok: true, ...refUi(w2), atSubmit: !!btn(w2, /^(Καταχώριση|Προσωρινή Καταχώριση)$/) } : { err: "ο οδηγός έκλεισε" };
      }
      // 🗺 «Εισαγωγή Εξετάσεων»: ΜΟΝΟ άνοιγμα + καταγραφή (+ προαιρετικά αναζήτηση λέξης) και κλείσιμο με «Ακύρωση» — τίποτα δεν προστίθεται
      if (op === "refExamMap") {
        const w = refWiz(); if (!w) return { err: "ο οδηγός παραπεμπτικού έκλεισε" };
        const b = btn(w, /^Εισαγωγή Εξετάσεων$/); if (!b) return { err: "δεν βρέθηκε «Εισαγωγή Εξετάσεων»" };
        press(b);
        const d = await until(() => dialogs().find((x) => x !== w && vis(x)), 6000); if (!d) return { err: "δεν άνοιξε το παράθυρο εξετάσεων" };
        await sleep(800);
        const out = { ok: true, open: refUi(d) };
        if (a.q) { const k = d.querySelector("input#keyword,input[type=search],input[type=text]"); if (k) { setVal(k, a.q); await sleep(200); const s2 = btn(d, /^Αναζήτηση$/); if (s2) press(s2); await sleep(2500); out.search = refUi(d); } else out.search = { err: "χωρίς πεδίο αναζήτησης" }; }
        const c = btn(d, /^(Ακύρωση|Κλείσιμο|Άκυρο)$/); if (c) press(c); else esc(); await sleep(500);
        out.closed = !vis(d);
        return out;
      }
      if (op === "refCancel") {
        // ο οδηγός δεν έχει «Ακύρωση»: κουμπί «✕» (χωρίς κείμενο, sr-only «Close») ή Escape
        const xBtn = (d) => [...d.querySelectorAll("button")].find((b) => vis(b) && (/^(close|κλείσιμο|×|✕)$/i.test(txt(b)) || /close|κλείσ/i.test(b.getAttribute("aria-label") || "") || (!txt(b) && b.querySelector("svg") && b.getBoundingClientRect().top - d.getBoundingClientRect().top < 60)));
        for (let i = 0; i < 4; i++) { const d = dialogs().find((x) => !LEAVE.test(x.innerText)); if (!d) break; const c = btn(d, /^(Ακύρωση|Κλείσιμο|Άκυρο)$/) || xBtn(d); if (c) press(c); else esc(); await sleep(600); }
        return { ok: true, left: dialogs().length, leftText: dialogs().map((d) => txt(d).slice(0, 300) + " [" + [...d.querySelectorAll("button")].filter(vis).map(txt).filter(Boolean).slice(0, 6).join(" | ") + "]") };
      }
      // ===== 📋 runner «ref» (ΠΟΤΕ «Καταχώριση»/«Προσωρινή Καταχώριση»/«Υποβολή» εδώ) =====
      const colIx = (root, re, d) => { const th = [...root.querySelectorAll("thead th")].map(txt); const i = th.findIndex((t) => re.test(t)); return i >= 0 ? i : d; };
      // ενεργή επίσκεψη → FAB «Eνέργειες Επίσκεψης» → «Νέο Παραπεμπτικό» → /epres/referrals/create (μόνο πλοήγηση)
      if (op === "refNav") {
        if (/\/referrals\/create/.test(location.pathname)) return { ok: true, path: location.pathname };
        const fab = await until(() => [...document.querySelectorAll("button,[role=button]")].find((x) => vis(x) && /ν[εέ]ργειες\s+Επίσκεψης/i.test((x.getAttribute("title") || "") + " " + (x.getAttribute("aria-label") || "") + " " + txt(x))), 8000);
        if (!fab) return { err: "δεν βρέθηκε «Ενέργειες Επίσκεψης»", path: location.pathname };
        press(fab);
        const it = await until(() => [...document.querySelectorAll("button,[role=menuitem],a")].find((x) => vis(x) && /^Νέο\s*Παραπεμπτικό$/.test(txt(x))), 5000);
        if (!it) { esc(); return { err: "δεν βρέθηκε «Νέο Παραπεμπτικό» στο μενού" }; }
        press(it);
        const ok = await until(() => /\/referrals\/create/.test(location.pathname) || (dialogs().some((x) => LEAVE.test(x.innerText)) ? "dirty" : null), 8000);
        if (ok === "dirty") { const d = dialogs().find((x) => LEAVE.test(x.innerText)); press(btn(d, /^Άκυρο$/)); return { err: "υπάρχει μη οριστικοποιημένη εργασία στη σελίδα — δεν πειράχτηκε" }; }
        return ok ? { ok: true, path: location.pathname } : { err: "δεν άνοιξε η σελίδα «Νέο Παραπεμπτικό»", path: location.pathname };
      }
      // ➕ εξετάσεις: ΜΙΑ-ΜΙΑ (άνοιγμα παραθύρου → αναζήτηση → ΜΟΝΑΔΙΚΗ αντιστοιχία → τικ + ποσότητα → «Εισαγωγή» → έλεγχος στον πίνακα)
      if (op === "refExams") {
        const W = () => refWiz();
        if (!W()) return { err: "ο οδηγός παραπεμπτικού έκλεισε" };
        const names = [].concat(a.exams || []).map((x) => String(x || "").trim()).filter(Boolean);
        if (!names.length) return { err: "χωρίς εξετάσεις" };
        const qty = String(Math.max(1, Math.min(9, +a.qty || 1)));
        const s3 = () => { const w = W(); if (!w) return []; const i = colIx(w, /^Εξέταση$/, 0); return [...w.querySelectorAll("tbody tr")].filter((r) => vis(r) && r.cells.length > i && txt(r.cells[i]) && !/Δεν υπάρχουν δεδομένα/.test(txt(r))).map((r) => txt(r.cells[i])); };
        const added = [], notes = [];
        for (const name of names) {
          const N = nn(name);
          if (s3().some((x) => nn(x) === N)) { added.push({ want: name, got: name, already: true }); continue; }
          const n0 = s3().length;
          const ib = btn(W(), /^Εισαγωγή Εξετάσεων$/); if (!ib) return { err: "δεν βρέθηκε «Εισαγωγή Εξετάσεων»", added };
          press(ib);
          const dlg = () => dialogs().find((x) => x !== W() && (/Επεξεργασία Εξετάσεων/.test(x.innerText) || x.querySelector("input[placeholder*='Αναζήτηση εξέτασης']")));
          const d = await until(dlg, 6000); if (!d) return { err: "δεν άνοιξε το παράθυρο εξετάσεων", added };
          const cancel = async () => { const c = btn(d, /^(Ακύρωση|Κλείσιμο|Άκυρο)$/); if (c) press(c); else esc(); await sleep(400); };
          const tabAll = [...d.querySelectorAll("[role=tab]")].find((t) => vis(t) && /^Όλες$/.test(txt(t)));
          if (tabAll && tabAll.getAttribute("aria-selected") !== "true" && tabAll.getAttribute("data-state") !== "active") { press(tabAll); await sleep(500); }
          const q = d.querySelector("input[placeholder*='Αναζήτηση εξέτασης']") || [...d.querySelectorAll("input[type=text],input[type=search],input:not([type])")].find(vis);
          if (!q) { await cancel(); return { err: "χωρίς πεδίο «Αναζήτηση εξέτασης»", added }; }
          const iN = colIx(d, /^Εξέταση$/, 1), iK = colIx(d, /Λέξεις/, 2), iT = colIx(d, /^Τύπος$/, 0);
          const rows = () => [...d.querySelectorAll("tbody tr")].filter((r) => vis(r) && r.cells.length > iN && txt(r.cells[iN]));
          const sig = () => rows().map((r) => txt(r.cells[iN])).join("|");
          // 8/11: η λίστα «Όλες» φορτώνει ΜΕΤΑ το άνοιγμα — πρώτα να σταθεροποιηθεί, αλλιώς η «αλλαγή» της λίστας περνιόταν για αποτέλεσμα αναζήτησης
          await until(() => rows().length > 0, 4000, 150); { let p0 = sig(); for (let i = 0; i < 8; i++) { await sleep(250); const p1 = sig(); if (p1 === p0) break; p0 = p1; } }
          const sg0 = sig();
          const toks = nn(name).split(/[\s()\-\/,.]+/).filter((t) => t.length >= 2);
          const related = () => rows().some((r) => { const T = " " + nn(r.innerText || "") + " "; return toks.some((t) => T.includes(t)); });
          setVal(q, name); await sleep(200);
          const sb = btn(d, /^Αναζήτηση$/); if (sb) press(sb); else { const f = q.closest("form"); if (f && f.requestSubmit) f.requestSubmit(); else q.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true })); }
          let chg = await until(() => { const x = sig(); return x && x !== sg0 && related(); }, 6000);
          if (!chg) { const f = q.closest("form"); try { q.focus(); q.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, bubbles: true })); if (f && f.requestSubmit) f.requestSubmit(); } catch (e) {} chg = await until(() => { const x = sig(); return x && x !== sg0 && related(); }, 5000); }
          if (!chg) { const bs = [...d.querySelectorAll("button,[role=button],input[type=submit]")].filter(vis).map((b) => txt(b) || b.value || b.getAttribute("aria-label") || "?").slice(0, 14).join(" | ");
            await cancel(); return { err: "εξέταση «" + name + "»: η αναζήτηση δεν έδωσε σχετικά αποτελέσματα — δεν μπήκε [πεδίο: " + (q.getAttribute("placeholder") || q.name || q.id || "?") + " = «" + q.value + "» · κουμπιά: " + bs + "]", added }; }
          await sleep(400);
          if (!chg) { await cancel(); return { err: "εξέταση «" + name + "»: η αναζήτηση δεν έδωσε νέα αποτελέσματα" + (sg0 ? "" : " (κανένα)") + " — δεν μπήκε", added }; }
          // υπάρχουν κι άλλες σελίδες αποτελεσμάτων;
          const pager = !!([...d.querySelectorAll("button,a,[role=button]")].find((b) => vis(b) && (/^(Περισσότερα|Επόμενη|Επόμενο|›|»|>|>>)$/.test(txt(b)) || /next|επόμεν/i.test(b.getAttribute("aria-label") || "")))
            || d.querySelector("nav[aria-label*=pagination i],[class*=pagination],[class*=pager]") || /Σελίδα\s+\d+\s*(από|\/)\s*\d+/.test(d.innerText || ""));
          const cand = rows().map((r) => ({ r, name: txt(r.cells[iN]), kw: r.cells[iK] ? txt(r.cells[iK]) : "", type: r.cells[iT] ? txt(r.cells[iT]) : "" }));
          const ex = cand.filter((c) => nn(c.name) === N);
          const part = cand.filter((c) => nn(c.name).includes(N) || (" " + nn(c.kw) + " ").includes(" " + N + " "));
          // ακριβές όνομα → δεκτό· μερικό/λέξη-κλειδί ΜΟΝΟ αν είναι η ΜΟΝΑΔΙΚΗ γραμμή αποτελεσμάτων και χωρίς άλλες σελίδες
          const ch = ex.length === 1 ? ex[0] : !ex.length && part.length === 1 && cand.length === 1 && !pager ? part[0] : null;
          if (!ch) {
            const L = (ex.length > 1 ? ex : part.length ? part : cand).slice(0, 12).map((c) => c.name + (c.type ? " [" + c.type + "]" : ""));
            await cancel();
            return { err: "εξέταση «" + name + "»: " + (ex.length > 1 || part.length > 1 ? "ασαφής — υποψήφιες: " : !cand.length ? "δεν βρέθηκε" : "δεν βρέθηκε ακριβές όνομα (στείλτε ξανά με το ακριβές) — βρέθηκαν" + (pager ? " (και άλλες σελίδες)" : "") + ": ") + L.join(" · "), cands: L, added };
          }
          const cb = ch.r.querySelector("[role=checkbox],input[type=checkbox]");
          if (!cb) { await cancel(); return { err: "«" + ch.name + "»: χωρίς κουτάκι επιλογής", added }; }
          // η γραμμή ξαναζωγραφίζεται μετά το τικ (#621): ξαναβρίσκεται από το όνομα και αναμονή έως 2″
          const rowNow = () => rows().find((r) => txt(r.cells[iN]) === ch.name) || ch.r;
          const isOn = () => { const c = rowNow().querySelector("[role=checkbox],input[type=checkbox]"); return !!c && (c.getAttribute("aria-checked") === "true" || c.getAttribute("data-state") === "checked" || !!c.checked); };
          if (!isOn()) { press(cb); if (!(await until(isOn, 2000, 150))) { const c2 = rowNow().querySelector("input[type=checkbox]"); if (c2 && c2 !== cb) { c2.click(); await until(isOn, 1500, 150); } } }
          if (!isOn()) { await cancel(); return { err: "«" + ch.name + "»: δεν επιλέχθηκε", added }; }
          ch.r = rowNow();
          const qi = ch.r.querySelector("input[id^='quantity'],input[type=number]");
          if (qi && !qi.disabled && qi.value !== qty) { setVal(qi, qty); await sleep(200); }
          // ⚠ καμία ΑΛΛΗ επιλεγμένη γραμμή, εκτός από εξετάσεις που είναι ήδη στο παραπεμπτικό (το παράθυρο είναι και «Επεξεργασία»)
          const have = s3().map(nn);
          const other = [...d.querySelectorAll("tbody tr [role=checkbox][aria-checked=true],tbody tr input[type=checkbox]:checked")].filter(vis).map((c) => c.closest("tr")).filter((r) => r && r !== ch.r && !have.includes(r.cells[iN] ? nn(txt(r.cells[iN])) : ""));
          if (other.length) { await cancel(); return { err: "«" + ch.name + "»: είναι επιλεγμένες και άλλες γραμμές (" + other.slice(0, 4).map((r) => txt(r.cells[iN])).join(" · ") + ") — δεν μπήκε", added }; }
          const ins = btn(d, /^Εισαγωγή$/); if (!ins) { await cancel(); return { err: "δεν βρέθηκε «Εισαγωγή»", added }; }
          press(ins);
          await until(() => !vis(d) || dialogs().some((x) => x !== d && x !== W()), 6000);
          if (vis(d)) { const m = msgs() || dialogs().filter((x) => x !== d && x !== W()).map(txt).join(" · ").slice(0, 300); await cancel(); return { err: "«" + ch.name + "»: δεν μπήκε" + (m ? ": " + m : ""), added }; }
          (await ack()).forEach((t) => notes.push(t));
          const okRow = await until(() => s3().length > n0 || s3().some((x) => nn(x) === nn(ch.name)), 5000);   // 8/11: η κενή γραμμή «Δεν υπάρχουν δεδομένα» μετρούσε ως 1
          if (!okRow) return { err: "«" + ch.name + "» δεν εμφανίστηκε στον πίνακα εξετάσεων" + (W() ? " [οδηγός ανοιχτός · γραμμές: " + s3().slice(0, 4).join(" | ") + "]" : " [ο οδηγός έκλεισε με την «Εισαγωγή»]") + (msgs() ? ": " + msgs() : ""), added, notes };
          const nm = s3().find((x) => nn(x) === nn(ch.name) || nn(x).includes(nn(ch.name)) || nn(ch.name).includes(nn(x)));
          added.push({ want: name, got: ch.name, type: ch.type, row: nm || s3()[s3().length - 1] || "", named: !!nm });
        }
        return { ok: true, added, rows: s3(), notes };
      }
      // 🔗 «Αυτόματη συσχέτιση»: διάγνωση (a.icd αν υπάρχει, αλλιώς η 1η) + λόγος (η 1η) · καταγράφει τις επιλογές
      if (op === "refAssoc") {
        const w = refWiz(); if (!w) return { err: "ο οδηγός παραπεμπτικού έκλεισε" };
        const cbs = [...w.querySelectorAll("[role=combobox]")].filter(vis);
        const box = [...w.querySelectorAll("div,section,fieldset")].filter((e) => vis(e) && /Αυτόματη συσχέτιση/.test(e.innerText || "") && e.querySelectorAll("[role=combobox]").length >= 2).sort((x, y) => (x.innerText || "").length - (y.innerText || "").length)[0];
        const inBox = box ? [...box.querySelectorAll("[role=combobox]")].filter(vis) : [];
        const dxC = inBox[0] || cbs.find((c) => /Επιλογή διάγνωσης/.test(txt(c))), rsC = inBox[1] || cbs.find((c) => /Επιλογή λόγου/.test(txt(c)));
        if (!dxC || !rsC) return { err: "δεν βρέθηκε η «Αυτόματη συσχέτιση»", ...refUi(w) };
        // διάγνωση: ΠΟΤΕ «η 1η στην τύχη» — ακριβής κωδικός > μοναδικό πρόθεμα (N40 ↔ N40.0) > σφάλμα
        const code = String(a.icd || "").toUpperCase();
        if (!code) return { err: "συσχέτιση: χωρίς κωδικό ICD" };
        const codesOf = (x) => [...up(x).matchAll(/(?:^|[^A-Z0-9])([A-Z]\d{2}(?:\.\d{1,2})?)(?![0-9])/g)].map((m) => m[1]);
        const dxPick = (list) => { const e = list.filter((x) => codesOf(x).includes(code)); if (e.length === 1) return e[0]; if (e.length) return null;
          const p1 = list.filter((x) => codesOf(x).some((c) => c.startsWith(code + ".") || code.startsWith(c + "."))); return p1.length === 1 ? p1[0] : null; };
        // λόγος: a.reason (κανονική έκφραση ή κείμενο) → αλλιώς η 1η ΜΕ σήμανση reasonAuto
        const rRe = (() => { if (!a.reason) return null; try { return new RegExp(a.reason, "i"); } catch (e) { return null; } })();
        const rsPick = (list) => !a.reason ? list[0] : list.find((x) => (rRe && rRe.test(x)) || up(x).includes(up(a.reason))) || null;
        const dx = await pick(dxC, (t, list) => t === dxPick(list));
        if (dx.err) return { err: "συσχέτιση διάγνωσης: ο κωδικός " + code + " δεν βρέθηκε ούτε ως πρόθεμα μοναδικά στις επιλογές" + (dx.list ? " (" + dx.list.slice(0, 10).join(" | ") + ")" : ""), dxList: dx.list };
        await sleep(400);
        const rs = await pick(rsC, (t, list) => t === rsPick(list));
        if (rs.err) return { err: "λόγος παραπομπής" + (a.reason ? " «" + a.reason + "» δεν βρέθηκε" : ": " + rs.err) + (rs.list ? " (" + rs.list.slice(0, 12).join(" | ") + ")" : ""), dxList: dx.list, reasonList: rs.list };
        const reasonAuto = !a.reason;
        await sleep(600);
        // ανά γραμμή: ό,τι έμεινε «Επιλογή…» → ίδιοι κανόνες (διάγνωση: κωδικός/πρόθεμα, αλλιώς σφάλμα· λόγος: a.reason ή 1η = auto) — όλα καταγράφονται
        const iD = colIx(w, /^Διάγνωση/, 1), iR = colIx(w, /^Λόγος/, 2);
        const tr = () => [...w.querySelectorAll("tbody tr")].filter((r) => vis(r) && r.cells.length > Math.max(iD, iR));
        const empty = (c) => { const x = c && c.querySelector("[role=combobox]"); const t = txt(x || c); return !t || /^Επιλογή|^Επιλέξτε|^-+$/.test(t); };
        const perRow = [];
        for (const r of tr()) for (const i of [iD, iR]) if (empty(r.cells[i])) { const c = r.cells[i].querySelector("[role=combobox]"); if (!c) continue; const isD = i === iD; const p = await pick(c, (t, list) => t === (isD ? dxPick(list) : rsPick(list))); perRow.push({ row: txt(r.cells[0]).slice(0, 60), col: isD ? "διάγνωση" : "λόγος", auto: !isD && reasonAuto, ...(p.err ? { err: p.err } : { val: p.val }) }); }
        const rows = tr().map((r) => ({ exam: txt(r.cells[0]).slice(0, 100), dx: txt(r.cells[iD]).slice(0, 120), reason: txt(r.cells[iR]).slice(0, 120) }));
        const unset = tr().filter((r) => empty(r.cells[iD]) || empty(r.cells[iR])).map((r) => txt(r.cells[0]).slice(0, 60));
        const rowErr = perRow.filter((x) => x.err);
        if (rowErr.length) return { err: "συσχέτιση ανά εξέταση: " + rowErr.map((x) => x.row + " (" + x.col + ")").join(" · "), perRow, dxList: (dx.list || []).slice(0, 20), reasonList: (rs.list || []).slice(0, 30) };
        return { ok: true, dx: dx.val, reason: rs.val, reasonAuto, dxList: (dx.list || []).slice(0, 20), reasonList: (rs.list || []).slice(0, 30), perRow, rows, unset };
      }
      // «Ολοκλήρωση» του οδηγού παραπεμπτικού (όπως finish) — ΠΟΤΕ «Καταχώριση»
      if (op === "refFinish") {
        const w = refWiz(); if (!w) return { ok: true, already: true };
        const ob = btn(w, /^Ολοκλήρωση$/); if (!ob) return { err: "δεν υπάρχει «Ολοκλήρωση» στον οδηγό", ...refUi(w) };
        // σφάλματα = ΝΕΕΣ γραμμές τύπου «υποχρεωτικό/διορθώστε…» μετά το πάτημα (όχι σταθερές ετικέτες του οδηγού)
        const ERR = /διορθώστε|υποχρεωτικ|απαιτείται|πρέπει να|δεν έχει συμπληρωθεί|μη έγκυρ|σφάλμα/i;
        const lines = (d) => (d?.innerText || "").split("\n").map((s) => s.trim()).filter((s) => s && s.length < 300 && ERR.test(s));
        const base = new Set(lines(w)), m0 = msgs();
        press(ob);
        const fresh = () => lines(refWiz()).filter((s) => !base.has(s));
        const r = await until(() => !refWiz() ? "closed" : (fresh().length || (msgs() && msgs() !== m0) ? "errors" : null), 10000);
        if (r === "closed") { a.afterFinish = true; const notes = await ack(); return { ok: true, notes, path: location.pathname }; }
        await sleep(400); if (!refWiz()) { a.afterFinish = true; const notes = await ack(); return { ok: true, notes, path: location.pathname }; }
        const errs = [...new Set(fresh().concat(msgs() && msgs() !== m0 ? [msgs()] : []))].slice(0, 8);
        return { err: "ο οδηγός δεν ολοκληρώθηκε" + (errs.length ? ": " + errs.join(" · ") : " (χωρίς μήνυμα)"), errs, ...refUi(refWiz()) };
      }
      // 🧾 σύνοψη σελίδας παραπεμπτικού (μόνο ανάγνωση) + υπογραφή (hash) για τον έλεγχο «άλλαξε κάτι;»
      if (op === "refSummary") {
        const root = document.querySelector("main") || document.body, t = root.innerText || "";
        const i0 = ["Βασικές Πληροφορίες", "Κατηγορία", "Διαγνώσεις", "Εξετάσεις"].map((k) => t.indexOf(k)).filter((i) => i >= 0).sort((x, y) => x - y)[0] ?? 0;
        const hasSubmit = !!btn(document, /^Καταχώριση$/) && !refWiz() && !wizard();
        const vals = [...root.querySelectorAll("textarea,input:not([type=hidden]):not([type=checkbox]):not([type=radio])")].filter(vis).map((e) => (e.id || e.name || "") + "=" + e.value).join("|");
        const raw = t.slice(i0, i0 + 12000).replace(/\b\d{1,2}:\d{2}(:\d{2})?\b/g, "#").replace(/\s+/g, " ").trim() + "##" + vals;
        let full = ""; try { full = [...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw)))].map((x) => x.toString(16).padStart(2, "0")).join(""); } catch (e) {}
        if (!/\/referrals\//.test(location.pathname) || !t.trim()) full = "";
        return { ok: true, text: t.slice(i0, i0 + 6000).replace(/[ \t]+/g, " ").replace(/\n\s*\n+/g, "\n").trim().slice(0, 6000), full, hasSubmit, path: location.pathname };
      }
      if (op === "dialogs") {
        return { ok: true, list: dialogs().filter((x) => !(/Επιλογή\s*Τύπου/.test(x.innerText) && /Θεραπείες/.test(x.innerText))).map((x) => txt(x).slice(0, 300)) };
      }
      if (op === "remarks") {
        const ta = document.querySelector("textarea#remarks");
        if (!ta) return { err: "δεν βρέθηκε το «Σχόλια Συνταγής»" };
        const cur = ta.value.trim();
        if (!cur.includes(a.text)) setVal(ta, (cur ? cur + " · " : "") + a.text);
        return { ok: true };
      }
      if (op === "summary") {
        const t = document.body.innerText, i = t.indexOf("Θεραπείες/Φάρμακα"), j = t.indexOf("Σχόλια Συνταγής", i);
        const part = i >= 0 ? t.slice(i, j > i ? j : i + 2500) : "";
        const hasSubmit = !!btn(document, /^Καταχώριση$/);
        // υπογραφή για τον έλεγχο «άλλαξε κάτι;»: όλο το κείμενο από «Θεραπείες/Φάρμακα» και μετά + τιμές πεδίων (σχόλια κ.λπ.)
        const vals = [...document.querySelectorAll("textarea,input:not([type=hidden]):not([type=checkbox]):not([type=radio])")].filter(vis).map((e) => (e.id || e.name || "") + "=" + e.value).join("|");
        // πάνω από τα φάρμακα: ασθενής + διαγνώσεις (ICD). Στο hash μπαίνουν οι ΚΩΔΙΚΟΙ ICD (σταθεροί), στο κινητό το κείμενο
        const hdr = i > 0 ? t.slice(Math.max(0, i - 1500), i) : "";
        const icdH = [...new Set((hdr.match(/\b[A-Z]\d{2}(?:\.\d{1,4})?\b/g) || []))].sort().join(",");
        const raw = "ICD:" + icdH + "##" + (i >= 0 ? t.slice(i, i + 12000) : "").replace(/\b\d{1,2}:\d{2}(:\d{2})?\b/g, "#").replace(/\s+/g, " ").trim() + "##" + vals;   // χωρίς ώρες/χρονόμετρα (αλλιώς «άλλαξε» συνέχεια)
        let full = ""; try { full = [...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw)))].map((x) => x.toString(16).padStart(2, "0")).join(""); } catch (e) {}   // μόνο hash (όχι κείμενο με ΑΜΚΑ στη βάση)
        if (i < 0) full = "";
        const shown = i >= 0 ? t.slice(i, i + 6000) : "";   // ο γιατρός βλέπει ΚΑΙ τα σχόλια συνταγής (όχι μόνο ως το «Σχόλια Συνταγής»)
        const hdrT = hdr.replace(/\b(\d{9})(\d{2})\b/g, "·········$2").replace(/[ \t]+/g, " ").replace(/\n\s*\n+/g, "\n").trim().slice(-1200);
        return { ok: true, hdr: hdrT, icdPage: icdH, text: shown.replace(/[ \t]+/g, " ").replace(/\n\s*\n+/g, "\n").trim().slice(0, 6000) + ((document.querySelector("textarea#remarks") || {}).value ? "\nΣχόλια συνταγής (πεδίο): " + document.querySelector("textarea#remarks").value.trim().slice(0, 500) : ""), part: part.slice(0, 2500), full, hasSubmit, path: location.pathname };
      }
      // 🗺 χαρτογράφηση (ΜΟΝΟ ανάγνωση, χωρίς ασθενή): σύνδεσμοι μενού και δομή σελίδας/οδηγού — καμία καταχώριση
      // ⚠ «Υπάρχει ανοιχτή επίσκεψη με μονάδα X. Ολοκληρώστε…»: ποια μονάδα (και κλείνει το μήνυμα με «Εντάξει»)
      if (op === "otherunit") {
        const RX = /ανοιχτ[ήη] επίσκεψη με μονάδα/i;
        const d = dialogs().find((x) => RX.test(txt(x)));
        const t = d ? txt(d) : ((txt(document.body).match(/Υπάρχει ανοιχτ[ήη] επίσκεψη με μονάδα[^.]*\./) || [])[0] || "");
        if (!t) return { ok: true, none: true };
        const m = t.match(/με μονάδα\s+(.+?)\s*\.(\s|$)/i);
        if (d) { const b = btn(d, /^Εντάξει$/); if (b) { press(b); await sleep(300); } }
        return { ok: true, unit: m ? m[1].trim() : "", text: t.slice(0, 300) };
      }
      // 🚪 Αποσύνδεση (μενού λογαριασμού: το κουμπί με το email) — ΜΟΝΟ στο παράθυρο του bot
      if (op === "logout") {
        // μενού λογαριασμού: παλιά το κουμπί με το email· τώρα «ΟΝΟΜΑ | Ιατρός» + κυκλάκι με αρχικά πάνω δεξιά (11/2026)
        const top = (x) => { const r = x.getBoundingClientRect(); return r.top < 90 && r.left > window.innerWidth * 0.5; };
        const cands = [...document.querySelectorAll("button, [role=button], a")].filter((b) => vis(b));
        const acc = cands.find((b) => /@/.test(txt(b)))
          || cands.find((b) => top(b) && /Ιατρ/i.test(txt(b)))
          || cands.find((b) => top(b) && (b.getAttribute("aria-haspopup") || /avatar|user|account|profile/i.test(String(b.className || "") + " " + (b.getAttribute("aria-label") || ""))))
          || cands.filter((b) => top(b) && /^[Α-ΩA-Z]{2}$/.test(txt(b).trim())).pop();
        // το στοιχείο «Αποσύνδεση»: μπορεί να είναι button/a/li/menuitem και να έχει εικονίδιο-κείμενο (π.χ. «logout Αποσύνδεση»)
        const LO = /(^|\s)(Αποσύνδεση|Έξοδος|Logout|Log out|Sign out)$/i;
        const findLo = () => { const els = [...document.querySelectorAll("button, a, li, [role=menuitem], [mat-menu-item], .dropdown-item, .p-menuitem-link, div, span")].filter((x) => vis(x) && txt(x).length <= 40 && LO.test(txt(x)));
          const el = els.sort((x, y) => txt(x).length - txt(y).length)[0]; return el ? (el.closest("button, a, [role=menuitem], li") || el) : null; };
        // ήδη ανοιχτό μενού; αλλιώς δοκιμάζει με τη σειρά τα πιθανά κουμπιά λογαριασμού
        let lo = findLo(); const tried = [];
        const SAFEB = (b) => !/Καταχ|Υποβολ|Αποθήκ|Ολοκλήρ|Διαγραφ|Ακύρωσ|Νέα|Έκδοσ|Εκτύπ/i.test(txt(b));
        const order = [acc, ...cands.filter((b) => top(b) && b !== acc)].filter((b) => b && SAFEB(b)).slice(0, 6);
        if (!lo && !order.length) return { err: "δεν βρέθηκε το μενού λογαριασμού" };
        for (const b of order) { if (lo) break; press(b); tried.push(txt(b).replace(/[^\sΑ-Ωα-ωA-Za-z|]/g, "").split(/\s+/).map((w) => w.length > 2 && /^[Α-ΩA-Z]/.test(w) && !/Ιατρ/.test(w) ? w[0] + "." : w).join(" ").slice(0, 30) || "(εικονίδιο)"); lo = await until(findLo, 1800); if (!lo) { esc(); await sleep(250); } }
        if (!lo) { const menu = [...document.querySelectorAll("[role=menu], .p-menu, .mat-menu-panel, .dropdown-menu, .p-tieredmenu, .p-overlaypanel")].filter(vis).map((m) => txt(m).slice(0, 120));
          esc(); return { err: "δεν βρέθηκε «Αποσύνδεση» (δοκιμάστηκαν: " + tried.join(" / ") + (menu.length ? " · μενού: " + menu.join(" | ") : "") + ")" }; }
        press(lo); await sleep(600);
        const cd = dialogs().find((x) => /αποσύνδεσ/i.test(txt(x)));
        if (cd) { const b = btn(cd, /^(Ναι|Αποσύνδεση|Επιβεβαίωση|OK|ΟΚ)$/); if (b) press(b); }
        return { ok: true };
      }
      // ✅ Ολοκλήρωση της ανοιχτής επίσκεψης (απόφαση χρήστη 3/11/2026: αυτόματα, χωρίς έγκριση).
      // ΠΟΤΕ «Ακύρωση». Όχι αν είναι του ίδιου ασθενή (a.keep). Αν υπάρχει μη οριστικοποιημένη συνταγή → σφάλμα (goLink).
      if (op === "closevisit") {
        if (!(await goLink("/epres/visits/active/update"))) return { err: "δεν άνοιξε η «Ενεργή Επίσκεψη»" };
        const OB = () => [...document.querySelectorAll("button")].find((b) => vis(b) && /^Ολοκλήρωση$/.test(txt(b)) && !b.closest("[role=dialog],[role=alertdialog]"));
        await until(() => OB() || /δεν υπάρχει (ενεργή|ανοιχτή)/i.test(txt(document.body)), 8000);
        for (const d of dialogs()) if (/ανοιχτ[ήη] επίσκεψη με μονάδα/i.test(txt(d))) { const b = btn(d, /^Εντάξει$/); if (b) { press(b); await sleep(300); } }
        const body = txt(document.querySelector("main") || document.body);
        const am = (body.match(/AMKA:\s*(\d{11})/i) || [])[1] || "";
        if (a.keep && am === a.keep) return { ok: true, keep: true };
        const nRx = +((body.match(/Συνταγές\s*\((\d+)\)/) || [])[1] || 0), nRef = +((body.match(/Παραπεμπτικά\s*\((\d+)\)/) || [])[1] || 0);
        const unit = (body.match(/Ιατρός\s+(.+?)\s+Επίσκεψη\s+Ενεργή/) || [])[1] || "";
        const UNITD = () => dialogs().some((x) => /Μονάδα Συνταγογράφησης/.test(txt(x)));
        if (UNITD()) return { needUnit: true };   // 6/11 (#790): πρώτα επιλογή μονάδας, μετά ολοκλήρωση
        const ob = OB();
        if (!ob) return /Ενεργή Επίσκεψη/.test(body) && am ? { err: "δεν βρέθηκε «Ολοκλήρωση» στην ενεργή επίσκεψη" } : { ok: true, none: true };
        press(ob);
        const OKB = /^(Ναι|Ολοκλήρωση|Επιβεβαίωση|OK|ΟΚ|Εντάξει)$/;
        // το παράθυρο ολοκλήρωσης (COMPLETE_MODAL) μπορεί να ζητά αιτιολόγηση εξαιρέσεων (κουτάκι + κείμενο) ή «όριο επισκέψεων».
        // ΚΑΤΑΓΡΑΦΗ ό,τι ζητά· αν ζητά κάτι πέρα από απλή επιβεβαίωση → ΔΕΝ συμπληρώνεται μόνο του, κλείνει και επιστρέφει τι είδε.
        const cd0 = await until(() => dialogs().find((x) => !/ανοιχτ[ήη] επίσκεψη με μονάδα/i.test(txt(x)) && !/Μονάδα Συνταγογράφησης/.test(txt(x))), 5000);
        // 11/11 20:39 (χρήστης: «πατάω κλείσιμο επίσκεψης και λέει υπάρχει συνταγή σε εξέλιξη — δεν πειράζει, να την κλείνει· σε ειδοποίηση πάτα ναι»):
        // ενημερωτικό/προειδοποιητικό παράθυρο (π.χ. «συνταγή σε εξέλιξη») ΠΡΙΝ από την επιβεβαίωση → «Ναι»/«Συνέχεια» και μετά κανονικά
        let cd = cd0;
        for (let k = 0; k < 3 && cd && /εξέλιξη|σε εκκρεμότητα|δεν έχει ολοκληρωθεί|προσοχή/i.test(txt(cd)) && !/Είστε σίγουρ/i.test(txt(cd)); k++) {
          const yb = btn(cd, /^(Ναι|ΝΑΙ|Συνέχεια|Εντάξει|OK|ΟΚ|Κλείσιμο επίσκεψης|Ολοκλήρωση)$/); if (!yb) break;
          window.__efVcNotes = (window.__efVcNotes || []).concat(txt(cd).slice(0, 200)); press(yb); await sleep(700);
          cd = await until(() => dialogs().find((x) => !/ανοιχτ[ήη] επίσκεψη με μονάδα/i.test(txt(x)) && !/Μονάδα Συνταγογράφησης/.test(txt(x))), 4000);
        }
        if (!cd && UNITD()) return { needUnit: true, pressed: true };
        let ctext = "", cdiag = null;
        if (cd) {
          await sleep(600);
          ctext = txt(cd).slice(0, 300);
          cdiag = { text: txt(cd).slice(0, 1500), btns: [...cd.querySelectorAll("button")].filter(vis).map(txt).filter((t) => t && t.length < 50).slice(0, 14),
            checks: [...cd.querySelectorAll("[role=checkbox],input[type=checkbox],[role=switch]")].filter(vis).map((c) => ({ lab: txt(c.closest("label") || c.parentElement || c).slice(0, 140), on: c.getAttribute("aria-checked") || String(!!c.checked) })).slice(0, 10),
            inputs: [...cd.querySelectorAll("textarea,input:not([type=checkbox]):not([type=hidden]),[role=combobox],[role=radio]")].filter(vis).map((i) => (i.tagName.toLowerCase() + ":" + (i.getAttribute("role") || i.type || "") + ":" + (i.id || i.name || "") + ":" + (i.placeholder || txt(i)).slice(0, 40))).slice(0, 12) };
          // πραγματικό παράθυρο (#569): «Είστε σίγουροι ότι θέλετε να κλείσετε την επίσκεψη;» + κουτάκι «Υπολογίζεται στο Οριο
          // Επισκέψεων» (μένει όπως το έχει το e-prescription) + «Ολοκλήρωση και Προβολή» / «Ολοκλήρωση και Νέα Επίσκεψη»
          const okB = btn(cd, /^Ολοκλήρωση και Προβολή$/) || btn(cd, OKB);
          cdiag.checks = cdiag.checks.filter((c) => !/Υπολογίζεται στο Ορ[ιί]ο Επισκέψεων/i.test(c.lab));
          const cancel = () => { const c = btn(cd, /^(Άκυρο|Ακύρωση|Όχι|Κλείσιμο)$/); if (c) press(c); else esc(); };
          if (LEAVE.test(ctext) || /ακύρωσ/i.test(ctext) && !/ολοκλήρωσ/i.test(ctext)) { cancel(); return { err: "μήνυμα που δεν είναι επιβεβαίωση ολοκλήρωσης: «" + ctext + "» — δεν πατήθηκε", diag: cdiag }; }
          // 13/11 14:34 (χρήστης, ΚΥΡΙΑΚΟΥ: «εδώ να πατάς ναι σε όλα, ό,τι στοιχεία και να ζητάει»): κουτάκια + «Έλεγχος» στα κενά πεδία (fillDlg)
          // και μετά «Ολοκλήρωση». Το κουτάκι «Υπολογίζεται στο Όριο Επισκέψεων» μένει όπως το έχει το e-prescription (αφορά το όριο του γιατρού).
          if (okB && (cdiag.checks.length || cdiag.inputs.length)) {
            const LIM = /Υπολογίζεται στο Ορ[ιί]ο Επισκέψεων/i, limBox = () => [...cd.querySelectorAll("[role=checkbox],input[type=checkbox],[role=switch]")].find((c) => LIM.test(txt(c.closest("label") || c.parentElement || c)));
            const st0 = (c) => c ? (c.getAttribute("aria-checked") || String(!!c.checked)) : null, l0 = st0(limBox());
            await fillDlg(cd); await sleep(250);
            const lb = limBox(); if (lb && l0 !== null && st0(lb) !== l0) { press(lb); await sleep(150); }
            window.__efVcNotes = (window.__efVcNotes || []).concat("☑ συμπληρώθηκε: " + cdiag.checks.map((c) => c.lab).join(" | ").slice(0, 160) + (cdiag.inputs.length ? " · «Έλεγχος» σε " + cdiag.inputs.length + " πεδία" : ""));
            cdiag.checks = []; cdiag.inputs = [];
          }
          if (!okB || cdiag.checks.length || cdiag.inputs.length) { cancel(); await sleep(300); return { err: "το παράθυρο ολοκλήρωσης ζητά στοιχεία («" + ctext.slice(0, 160) + "» · κουμπιά: " + cdiag.btns.join(" | ") + " · κουτάκια " + cdiag.checks.length + " · πεδία " + cdiag.inputs.length + ") — δεν συμπληρώθηκε τίποτα", diag: cdiag }; }
          press(okB);
        }
        const gone = await until(() => !OB() || /ολοκληρώθηκε/i.test(msgs()), 10000);
        const notes = await ack();
        return gone ? { ok: true, amka: am, rx: nRx, ref: nRef, unit, confirm: ctext, msg: msgs(), notes } : { err: "η επίσκεψη δεν φαίνεται να ολοκληρώθηκε" + (msgs() ? ": " + msgs() : "") + (cd ? " · παράθυρο: «" + ctext.slice(0, 160) + "»" : " · δεν άνοιξε παράθυρο επιβεβαίωσης"), confirm: ctext, diag: cdiag };
      }
      if (op === "map") {
        const L = (re) => [...document.querySelectorAll("a[href]")].filter(vis).map((x) => ({ t: txt(x).slice(0, 50), h: x.getAttribute("href") })).filter((x) => x.t && (!re || re.test(x.t + " " + x.h)));
        const ui = (root) => ({
          h: [...root.querySelectorAll("h1,h2,h3,h4,legend,[role=tab]")].filter(vis).map(txt).filter(Boolean).slice(0, 25),
          b: [...new Set([...root.querySelectorAll("button")].filter(vis).map(txt).filter((t) => t && t.length < 50))].slice(0, 40),
          f: [...root.querySelectorAll("input,select,textarea,[role=combobox],[role=radio],[role=checkbox]")].filter(vis).slice(0, 40).map((i) => [i.tagName.toLowerCase(), i.getAttribute("role") || i.type || "", i.id && "#" + i.id, i.name && "n=" + i.name, i.placeholder && "ph=" + i.placeholder.slice(0, 30), (i.getAttribute("aria-label") || "").slice(0, 30), (i.closest("label") ? txt(i.closest("label")).slice(0, 40) : "")].filter(Boolean).join(" ")),
          lab: [...new Set([...root.querySelectorAll("label")].filter(vis).map(txt).filter((t) => t && t.length < 60))].slice(0, 40) });
        if (a.step === "links") return { ok: true, path: location.pathname, links: L(), ...ui(document) };
        if (a.step === "go") { let ok = await goLink(a.href); if (!ok && a.direct && /^\/epres\//.test(a.href)) { location.assign(a.href); return { ok: true, nav: true }; } await sleep(900); return { ok, path: location.pathname, ...ui(document), text: txt(document.querySelector("main") || document.body).slice(0, 2000), dlg: dialogs().map((d) => ({ text: txt(d).slice(0, 500), ...ui(d) })) }; }
        if (a.step === "press") {
          const RE = new RegExp(a.re);
          const b = a.title ? await until(() => [...document.querySelectorAll("button,[role=button]")].find((x) => vis(x) && RE.test(x.getAttribute("title") || x.getAttribute("aria-label") || "")), a.wait || 6000) : a.any ? await until(() => [...document.querySelectorAll("button,[role=tab],a")].find((x) => vis(x) && RE.test(txt(x))), a.wait || 6000) : (a.wait ? await until(() => btn(document, RE), a.wait) : btn(document, RE));
          if (!b) return { err: "δεν βρέθηκε κουμπί " + a.re, path: location.pathname, text: txt(document.querySelector("main") || document.body).slice(0, 600), ...ui(document) };
          press(b); await sleep(1200);
          const out = { ok: true, path: location.pathname, ...ui(document), text: txt(document.querySelector("main") || document.body).slice(0, 2500), dlg: dialogs().map((d) => ({ text: txt(d).slice(0, 1500), ...ui(d) })), msg: msgs() };
          // βήματα οδηγού: «Επόμενο» μόνο αν δεν ζητά τίποτα υποχρεωτικό· ΠΟΤΕ Καταχώριση/Υποβολή
          const steps = [];
          // κάθε βήμα: επιλογές των λιστών (ονόματα κατηγοριών)· κενή λίστα → η 1η επιλογή ΜΟΝΟ για να προχωρήσει ο οδηγός· ΠΟΤΕ Καταχώριση/Υποβολή
          const lists = async (d) => { const o = []; for (const cb of [...d.querySelectorAll("[role=combobox]")].filter(vis).slice(0, 6)) {
              const lab = (cb.id && d.querySelector("label[for='" + CSS.escape(cb.id) + "']")) || cb.closest("div")?.querySelector("label");
              press(cb); const op = await until(() => { const x = [...document.querySelectorAll("[role=option]")].filter(vis); return x.length ? x : null; }, 2500);
              const opts = op ? op.map(txt).slice(0, 40) : []; const cur = txt(cb);
              const want = a.pick && op ? op.find((o) => new RegExp(a.pick, "i").test(txt(o))) : null;   // χαρτογράφηση: συγκεκριμένη επιλογή (π.χ. κατηγορία)
              if (op && a.fill && (!cur || /Επιλέξτε|Επιλογή/.test(cur)) && (want || !/Επιλέξτε κατηγορία/.test(cur) || !a.pick)) { press(want || op[0]); await sleep(400); } else { esc(); await sleep(200); }
              o.push({ label: lab ? txt(lab).slice(0, 50) : "", cur: cur.slice(0, 50), opts, picked: op && a.fill && (!cur || /Επιλέξτε|Επιλογή/.test(cur)) ? opts[0] : undefined }); }
            return o; };
          if (dialogs()[0]) out.lists0 = await lists(dialogs()[0]);
          for (let i = 0; i < 4; i++) { const d = dialogs()[0]; if (!d) break; if (btn(d, /^(Καταχώριση|Υποβολή|Αποθήκευση)$/)) { out.reachedSubmit = true; break; }
            // χαρτογράφηση: δοκιμαστική αιτιολογία ΜΟΝΟ για να προχωρήσει ο οδηγός (ποτέ καταχώριση — στο τέλος «Ακύρωση»)
            if (a.just) { const j = d.querySelector("textarea#justification"); if (j && !j.value) { setVal(j, a.just); await sleep(200); } }
            const nx = btn(d, /^Επόμενο$/); if (!nx) break; press(nx); await sleep(900); const d2 = dialogs()[0]; if (!d2) break;
            const st0 = { text: txt(d2).slice(0, 900), ...ui(d2), msg: msgs() }; st0.lists = await lists(d2); steps.push(st0); }
          out.steps = steps;
          // κλείσιμο χωρίς αποθήκευση
          for (let i = 0; i < 3; i++) { const d = dialogs().find((x) => !LEAVE.test(x.innerText)); if (!d) break; const c = btn(d, /^(Ακύρωση|Κλείσιμο|Άκυρο|Close)$/); if (c) press(c); else esc(); await sleep(400); }
          return out;
        }
        return { err: "άγνωστο βήμα" };
      }
      return { err: "άγνωστη ενέργεια " + op };
    } catch (e) {
      return { err: op + ": " + (e && e.message || e) };
    }
  }

  // ---------- background ----------
  async function epCookieLogout(tabId) {
    const t = await chrome.tabs.get(tabId).catch(() => null);
    if (!t || !t.incognito) return { err: "όχι ανώνυμο παράθυρο του bot — δεν σβήνεται τίποτα" };
    try { await chrome.scripting.executeScript({ target: { tabId }, func: () => { try { sessionStorage.clear(); localStorage.clear(); } catch (e) {} } }); } catch (e) {}
    const stores = await chrome.cookies.getAllCookieStores().catch(() => []);
    const st = stores.find((x) => (x.tabIds || []).includes(tabId)); if (!st) return { err: "δεν βρέθηκε η αποθήκη cookies" };
    const cs = (await chrome.cookies.getAll({ storeId: st.id }).catch(() => [])).filter((c) => /(^|\.)e-prescription\.gr$/i.test(String(c.domain).replace(/^\./, "")));
    let n = 0; for (const c of cs) { const url = (c.secure ? "https://" : "http://") + String(c.domain).replace(/^\./, "") + (c.path || "/"); if (await chrome.cookies.remove({ url, name: c.name, storeId: st.id }).catch(() => null)) n++; }
    await chrome.tabs.update(tabId, { url: EP_HOME }).catch(() => {});
    return { ok: true, n };
  }
  async function epTab() {
    // η καρτέλα του bot (μπορεί να βρίσκεται προσωρινά στη σελίδα σύνδεσης, σε άλλη διεύθυνση)
    const { efbotEpTab: keep } = await chrome.storage.session.get("efbotEpTab");
    let t = keep ? await chrome.tabs.get(keep).catch(() => null) : null;
    const inc = typeof self.botIncogOn === "function" ? await self.botIncogOn() : false;
    if (t && !!t.incognito !== inc) t = null;
    if (!t) t = (await chrome.tabs.query({ url: EP_HOST + "/*" }).catch(() => [])).find((x) => !!x.incognito === inc);
    if (!t && inc) { t = await self.botSiteTab(EP_HOST, EP_HOME); if (!t) return { err: "δεν άνοιξε το e-prescription σε ανώνυμο παράθυρο" }; }
    if (!t) {
      const wins = (await chrome.windows.getAll({ windowTypes: ["normal"] }).catch(() => [])).filter((w) => !w.incognito);
      if (wins.length) t = await chrome.tabs.create({ windowId: wins[0].id, url: EP_HOME, active: false }).catch(() => null);
      else { const w = await chrome.windows.create({ url: EP_HOME, focused: false, state: "minimized" }).catch(() => null); t = w?.tabs?.[0] || null; }
      if (!t) return { err: "δεν άνοιξε το e-prescription" };
    }
    await chrome.storage.session.set({ efbotEpTab: t.id });
    if (typeof self.tabWake === "function") { const w = await self.tabWake(t.id); if (w) t = w; }
    for (let i = 0; i < 80; i++) { const x = await chrome.tabs.get(t.id).catch(() => null); if (!x) return { err: "η καρτέλα του e-prescription έκλεισε" }; if (x.status === "complete") break; await new Promise((r) => setTimeout(r, 250)); }
    return t;
  }
  // Η σελίδα μπορεί να ανακατευθύνεται (π.χ. στη σελίδα εισόδου /oauth/…): τότε το executeScript αποτυγχάνει προσωρινά
  // («Cannot access contents of the page», «Frame … was removed»). Ξαναδοκιμάζουμε για ~15″ αντί να σταματήσουμε.
  const TRANSIENT = /Cannot access contents|Frame with ID|was removed|No frame|error page|showing error|not.*loaded|No tab with id/i;
  async function pageRaw(tabId, op, a) {
    let last = "";
    // «state» ρωτιέται σε βρόχο: εδώ μόνο ~3″ (πριν 15″ × 40 επαναλήψεις = έως 10′ «άνοιγμα e-prescription», #544/#552)
    // ενέργειες που ΑΛΛΑΖΟΥΝ κάτι: μία προσπάθεια (αλλιώς μια επανάληψη μπορεί να βάλει διπλή επίσκεψη/φάρμακο — έλεγχος 5/11)
    const MUT = /^(visit|icd|reopenDx|med|finish|closevisit|remarks|unit|logout|submit|submit2|refOpen|refBasic|refNext|refCancel|refExamMap|refNav|refExams|refAssoc|refFinish)$/;
    const maxTry = op === "state" ? 6 : MUT.test(op) ? 1 : 30;
    // όριο χρόνου ΑΝΑ κλήση (πριν: μία κλήση σε σελίδα που φόρτωνε μπορούσε να κρατήσει λεπτά)
    const lim = op === "state" ? 8000 : /^(med|rxOpen|patient|visit|map|refExams)$/.test(op) ? 120000 : 60000;
    for (let i = 0; i < maxTry; i++) {
      try {
        const [r] = await Promise.race([chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", func: EP_PAGE, args: [op, a || {}], injectImmediately: op === "state" }),
          new Promise((_, rej) => setTimeout(() => rej(new Error("η σελίδα δεν απάντησε σε " + Math.round(lim / 1000) + "″ (" + op + ")")), lim))]);
        if (r?.result) return r.result;
        last = "χωρίς απάντηση από τη σελίδα";
      } catch (e) {
        last = e.message;
        if (!TRANSIENT.test(last)) break;
      }
      await new Promise((res) => setTimeout(res, 500));
    }
    // η καρτέλα στη σελίδα εισόδου: το λέμε ως «ζητά σύνδεση», όχι ως τεχνικό σφάλμα
    if (op === "state") {
      const t = await chrome.tabs.get(tabId).catch(() => null);
      if (t && /\/oauth\/|openid-connect|pkmsoidc|login/i.test(t.url || "")) return { login: true, path: "", loading: false, url: t.url };
    }
    if (/Cannot access contents/i.test(last) && typeof self.siteAccessWhy === "function") { const t = await chrome.tabs.get(tabId).catch(() => null); const why = t ? await self.siteAccessWhy(t.url) : ""; if (why) return { err: op + ":" + why }; }
    return { err: op + ": " + last };
  }
  const page = (...a) => pageRaw(...a);
  // 🔑 8/11: «ο κωδικός πρόσβασής σας έχει λήξει» στη σελίδα «Ασθενής» → επόμενος αποθηκευμένος λογαριασμός (έως 3), μετά ξανά «Ασθενής»
  async function patientPage(tab, H, amka, mk) {
    let pt = await page(tab.id, "patient", { amka });
    // 🔁 10/11 νυχτερινό (eptorture 2094 γύρος 1): «e-prescription: συνδεδεμένο» αλλά η σελίδα ΔΕΝ είχε σύνδεσμο «Ασθενής»
    // (παλιά καρτέλα/ληγμένη συνεδρία χωρίς κλειδί σελίδας) → αποτυχία σε 0″, ενώ ο επόμενος γύρος (νέα σύνδεση) πέρασε.
    // Τώρα: ΜΙΑ φορά απευθείας μετάβαση στο /epres/patient → (σύνδεση / μονάδα αν ζητηθεί) → ξανά «Ασθενής». Καμία καταχώριση.
    if (pt && pt.err && /δεν άνοιξε η σελίδα «Ασθενής»/.test(pt.err)) {
      const where = await chrome.tabs.get(tab.id).then((t) => { try { const u = new URL(t.url); return u.host + u.pathname.replace(/\d{3,}/g, "#"); } catch (e) { return "?"; } }).catch(() => "?");
      if (mk) mk("χωρίς σύνδεσμο «Ασθενής» (" + where + ") → απευθείας /epres/patient");
      await chrome.tabs.update(tab.id, { url: "https://www.e-prescription.gr/epres/patient" }).catch(() => {});
      let st = null; const t2 = Date.now();
      for (let i = 0; i < 80 && Date.now() - t2 < 30000; i++) { await H.sleep(400); st = await page(tab.id, "state"); if (!st.err && (st.login || st.unit || !st.loading)) break; }
      if (st && st.login && H.epresAutoLogin) {
        const lg = await H.epresAutoLogin(tab.id, "");
        if (mk) mk("σύνδεση e-prescription " + (lg.ok ? "✓" : "✗ " + String(lg.err || "").slice(0, 80)));
        if (!lg.ok) return { err: "δεν άνοιξε η σελίδα «Ασθενής» (" + where + ") και η νέα σύνδεση απέτυχε: " + String(lg.err || "") };
        for (let i = 0; i < 40; i++) { st = await page(tab.id, "state"); if (st.err || st.unit || !st.loading) break; await H.sleep(250); }
      }
      if (st && st.unit) await page(tab.id, "unit", { unit: "" });
      pt = await page(tab.id, "patient", { amka });
      if (pt && pt.err && /δεν άνοιξε η σελίδα «Ασθενής»/.test(pt.err)) pt.err += " (ήταν: " + where + ", και μετά από απευθείας μετάβαση)";
    }
    for (let k = 0; k < 3 && pt && pt.err && /ΕΧΕΙ ΛΗΞΕΙ/.test(pt.err) && H.epExpiredSwitch; k++) {
      const sw = await H.epExpiredSwitch(tab.id);
      if (mk) mk("ληγμένος κωδικός" + (sw.was ? " (" + sw.was + ")" : "") + " → " + (sw.ok ? "λογαριασμός " + sw.who : "✗ " + sw.err));
      if (!sw.ok) { pt.err += " · άλλος λογαριασμός: " + sw.err; break; }
      for (let i = 0; i < 40; i++) { const st = await page(tab.id, "state"); if (st && st.unit) { await page(tab.id, "unit", { unit: "" }); break; } if (!st || st.err || !st.loading) break; await H.sleep(250); }
      pt = await page(tab.id, "patient", { amka });
      if (pt && !pt.err) pt.switched = sw.who;
    }
    return pt;
  }
  // ολοκλήρωση επίσκεψης· αν πρώτα ζητηθεί «Μονάδα Συνταγογράφησης» → επιλογή μονάδας και ξανά (έως 2 φορές)
  async function epCloseVisit(tabId, pg, a, unit, strict) {
    let c = null;
    for (let i = 0; i < 3; i++) {
      c = await pg(tabId, "closevisit", a);
      if (!c || !c.needUnit) return c;
      const u = await pg(tabId, "unit", { unit: unit || "", strict: !!(strict && unit) });
      if (u && u.err) return { err: u.err };
    }
    return { err: "ζητά συνέχεια «Μονάδα Συνταγογράφησης»" };
  }
  const nz = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().replace(/[^A-ZΑ-Ω0-9 ]/g, " ").split(/\s+/).filter((t) => t.length >= 3);

  // 🔌 ποιος είναι συνδεδεμένος — ΑΠΕΥΘΕΙΑΣ (generate/me), με τις κεφαλίδες που στέλνει η ίδια η εφαρμογή (epres-hook).
  // Επιστρέφει ΜΟΝΟ το id χρήστη του e-prescription (όχι ονόματα/ΑΜΚΑ). {skip} αν η σελίδα δεν έχει κάνει ακόμα αίτημα.
  // ⏱ απευθείας κλήσεις (me/active): όριο 8″ — παγωμένη σελίδα δεν κρατά πια την εργασία/έγκριση για πάντα
  const ex8 = (o) => Promise.race([chrome.scripting.executeScript(o), new Promise((r) => setTimeout(() => r([{ result: { err: "χωρίς απάντηση σε 8″" } }]), 8000))]);
  async function epMe(tabId, tries = 1) {
    for (let i = 0; i < tries; i++) {
      const [r] = await ex8({ target: { tabId }, world: "MAIN", func: async () => {
        const S = window.__efEp; if (!S || !S.h || !S.h["x-authorization"]) return { skip: true };
        const h = { accept: "application/json" }; for (const [k, v] of Object.entries(S.h)) h[k] = v; try { h["x-request-id"] = crypto.randomUUID(); } catch (e) {}
        try { const r = await fetch("/epres/api/auth/v1/token/secure/generate/me", { credentials: "include", headers: h }); const j = await r.json().catch(() => null);
          return r.status === 200 && j && j.id != null ? { ok: true, id: String(j.id) } : { err: "me HTTP " + r.status }; } catch (e) { return { err: String(e.message || e) }; }
      } }).catch((e) => [{ result: { err: e.message } }]);
      const o = (r && r.result) || { err: "χωρίς απάντηση" };
      if (o.ok || i === tries - 1) return o;
      await new Promise((res) => setTimeout(res, 1000));
    }
    return { skip: true };
  }
  // 🔌 ενεργή επίσκεψη — ΑΠΕΥΘΕΙΑΣ (visit/v1/active). {none} = «Δεν βρέθηκε ενεργή επίσκεψη» · {ok, id, amka} · {skip}/{err}
  // ⚡ 6/11: απευθείας έλεγχος ασθενή (ΜΟΝΟ ανάγνωση) πριν τη φόρμα «Ασθενής»: ο τύπος (patientType) μαθαίνεται από τα αιτήματα της
  // ίδιας της σελίδας. 200 με ίδιο ΑΜΚΑ → εντάξει · ρητό «δεν βρέθηκε» → τέλος με καθαρό λόγο · οτιδήποτε άλλο → η φόρμα όπως πριν.
  async function epPatientApi(tabId, amka) {
    const [r] = await ex8({ target: { tabId }, world: "MAIN", args: [String(amka || "")], func: async (amka) => {
      const S = window.__efEp; if (!S || !S.h || !S.h["x-authorization"] || !S.h["x-sender-unit-id"]) return { skip: "χωρίς κλειδί σελίδας" };
      const seen = performance.getEntriesByType("resource").map((e) => e.name).filter((u) => /\/epres\/api\/doctor\/patient\/v1\/[^/?]+\?[^#]*patientType=/.test(u));
      const pt = seen.length ? new URL(seen[seen.length - 1]).searchParams.get("patientType") : "";
      if (!pt) return { skip: "άγνωστος τύπος ασθενή" };
      const h = { accept: "application/json" }; for (const [k, v] of Object.entries(S.h)) h[k] = v;
      try { h["x-request-id"] = crypto.randomUUID(); } catch (e) {}
      try { const r = await fetch("/epres/api/doctor/patient/v1/" + encodeURIComponent(amka) + "?patientType=" + encodeURIComponent(pt), { credentials: "include", headers: h });
        const j = await r.json().catch(() => null);
        if (r.status === 200 && j && typeof j === "object") { const am = String(j.ssrn || j.amka || j.socialSecurityNumber || ""); return am === amka ? { ok: true } : am ? { mismatch: true } : { skip: "χωρίς ΑΜΚΑ στην απάντηση" }; }
        if ((r.status === 404 || r.status === 400) && j && /δεν\s+βρέθηκ|not\s+found|δεν υπάρχει/i.test(String(j.message || j.error || ""))) return { notFound: String(j.message || "").slice(0, 160) };
        return { skip: "HTTP " + r.status };
      } catch (e) { return { skip: String(e.message || e) }; }
    } }).catch((e) => [{ result: { skip: e.message } }]);
    return (r && r.result) || { skip: "χωρίς απάντηση" };
  }
  async function epActive(tabId) {
    const [r] = await ex8({ target: { tabId }, world: "MAIN", func: async () => {
      const S = window.__efEp; if (!S || !S.h || !S.h["x-authorization"] || !S.h["x-sender-unit-id"]) return { skip: true };
      const h = { accept: "application/json" }; for (const [k, v] of Object.entries(S.h)) h[k] = v;
      h["x-sender-transaction-code"] = "Doctor:Retrieve Active Visit"; try { h["x-request-id"] = crypto.randomUUID(); } catch (e) {}
      try { const r = await fetch("/epres/api/doctor/visit/v1/active", { credentials: "include", headers: h }); const j = await r.json().catch(() => null);
        if (r.status === 400 && j && /Δεν βρέθηκε ενεργή επίσκεψη/i.test(String(j.message || ""))) return { none: true };
        if (r.status === 200 && j && j.id != null) { const pv = j.patientVisit || {}; return { ok: true, id: String(j.id), amka: String(pv.ssrn || pv.amka || "") }; }
        // 200 χωρίς επίσκεψη (κενό σώμα / {}) = καμία ενεργή επίσκεψη (#581)· οτιδήποτε άλλο → σφάλμα ΜΕ τα ονόματα πεδίων
        // 200 με ΚΕΝΟ σώμα ΔΕΝ σημαίνει «καμία επίσκεψη» (#587: υπήρχε ανοιχτή) → ασάφεια (μάλλον παλιό κλειδί)
        if (r.status === 200 && (j == null || (typeof j === "object" && !Array.isArray(j) && !Object.keys(j).length))) return { err: "active HTTP 200 κενό" };
        return { err: "active HTTP " + r.status + (j && typeof j === "object" ? " πεδία: " + Object.keys(j).slice(0, 12).join(",") : "") }; } catch (e) { return { err: String(e.message || e) }; }
    } }).catch((e) => [{ result: { err: e.message } }]);
    return (r && r.result) || { err: "χωρίς απάντηση" };
  }
  // ⚡ ΠΡΟΕΛΕΓΧΟΣ με απευθείας αιτήματα (ΜΟΝΟ ανάγνωση, πριν ανοίξει επίσκεψη): υπάρχει κάθε φάρμακο/ICD στο e-prescription;
  // Ίδια αιτήματα με την εφαρμογή (κωδικοί συναλλαγής «Search medicine»/«Search ICD10», παράμετροι από τη #559/#563).
  // Σταματά τη συνταγή ΜΟΝΟ όταν η απάντηση είναι σαφώς άδεια· άγνωστη μορφή απάντησης → απλή καταγραφή.
  async function epPreflight(tabId, meds, icds, age) {
    const [r] = await chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", args: [meds.map((m) => ({ name: m.name, strength: m.strength })), icds, age], func: async (meds, icds, age) => {
      const S = window.__efEp; if (!S || !S.h || !S.h["x-authorization"] || !S.h["x-sender-unit-id"]) return { skip: true };
      const up = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().replace(/\s+/g, " ").trim();
      const get = async (path, tc) => { const h = { accept: "application/json" }; for (const [k, v] of Object.entries(S.h)) h[k] = v; h["x-sender-transaction-code"] = tc; try { h["x-request-id"] = crypto.randomUUID(); } catch (e) {}
        const t0 = performance.now(); try { const r = await fetch(path, { credentials: "include", headers: h }); const j = await r.json().catch(() => null); return { st: r.status, j, ms: Math.round(performance.now() - t0) }; } catch (e) { return { st: 0, err: String(e.message || e) }; } };
      const arr = (j) => Array.isArray(j) ? j : j && typeof j === "object" ? (["content", "items", "data", "results", "list", "medicines", "icd10s"].map((k) => j[k]).find(Array.isArray) || null) : null;
      const keys = (o) => o && typeof o === "object" ? Object.keys(o).slice(0, 25) : [];
      const out = { meds: [], icds: [] };
      for (const m of meds) {
        const q = new URLSearchParams({ patientAge: String(age || 50), mode: "Commercial", page: "1", pageSize: "20", limitedByProtocol: "true", keyword: up(m.name), dhpcMode: "2" });
        const x = await get("/epres/api/masterdata/v1/medicine/search?" + q, "Search medicine"), a = arr(x.j);
        const txt = a ? a.map((it) => up(JSON.stringify(it))) : [];
        const sN = String(m.strength || "").replace(/[^0-9.,]/g, "").replace(",", ".");
        out.meds.push({ name: m.name, st: x.st, ms: x.ms, n: a ? a.length : null, keys: keys(a && a[0] || x.j), strOk: sN ? txt.some((t) => t.includes(sN)) : null, sample: a && a[0] ? JSON.stringify(a[0]).slice(0, 400) : "" });
      }
      for (const c of icds) {
        const q = new URLSearchParams({ limitedByProtocol: "true", isConsumable: "false", patientAge: String(age || 50), page: "1", pageSize: "20", codeOrTitle: c });
        const x = await get("/epres/api/masterdata/v1/icd10/search?" + q, "Search ICD10"), a = arr(x.j);
        out.icds.push({ code: c, st: x.st, ms: x.ms, n: a ? a.length : null, hit: a ? a.some((it) => new RegExp("\"" + c.replace(".", "\\.") + "\"").test(JSON.stringify(it))) : null, keys: keys(a && a[0] || x.j) });
      }
      return out;
    } }).catch((e) => [{ result: { err: e.message } }]);
    return (r && r.result) || { err: "χωρίς απάντηση" };
  }
  // ενεργή επίσκεψη ΣΤΗΝ ΑΡΧΗ μιας εργασίας: αν το κλειδί σύνδεσης που κράτησε το bot είναι παλιό (απάντηση {operation}, #582)
  // → ανανέωση της σελίδας (η εφαρμογή ξαναστέλνει αιτήματα με νέο κλειδί) και ξανά. ΜΟΝΟ πριν από οποιοδήποτε βήμα.
  async function epActiveFresh(tabId, H) {
    let a = await epActive(tabId);
    if (a.err && /operation|κενό|HTTP 401|HTTP 403/.test(a.err) || a.skip) {
      await chrome.tabs.update(tabId, { url: "https://www.e-prescription.gr/epres/patient" }).catch(() => {});
      for (let i = 0; i < 30; i++) { await H.sleep(500); const s2 = await pageRaw(tabId, "state"); if (!s2.err && !s2.loading) break; }
      await H.sleep(1500);
      a = await epActive(tabId); a.refreshed = true;
    }
    return a;
  }
  // λογαριασμός (username) → id χρήστη e-prescription: μαθαίνεται ΜΟΝΟ όταν μπαίνει το ίδιο το bot με αυτόν (σίγουρο)
  async function epIdsGet() { try { return (await chrome.storage.local.get("efbotEpIds")).efbotEpIds || {}; } catch (e) { return {}; } }
  async function epIdLearn(tabId, user) {
    if (!user) return;
    const me = await epMe(tabId, 8);
    if (!me.ok) return;
    const ids = await epIdsGet(); ids[String(user).toLowerCase()] = me.id;
    await chrome.storage.local.set({ efbotEpIds: ids }).catch(() => {});
  }

  // Έλεγχος γραμμών φαρμάκων (ίδιο σχήμα με το Παραδόχαρτο)
  function cleanMeds(list) {
    const out = [], bad = [];
    for (const m of Array.isArray(list) ? list : []) {
      const name = String(m?.name || "").trim(), strength = String(m?.strength || "").trim();
      const dose = String(m?.dose || "1").replace(",", "."), freq = +m?.freq, days = +m?.days;
      if (!/^[A-Za-z][A-Za-z0-9\- ]{1,40}$/.test(name) || !(freq >= 1 && freq <= 4) || !(days >= 1 && days <= 30) || !(+dose > 0)) { bad.push(m?.line || name || "?"); continue; }
      // 💊 νέα πεδία από το Παραδόχαρτο (προαιρετικά): % συμμετοχής (25%/0%), κουτιά (όπως τα είδε ο γιατρός), τεμάχια/κουτί
      const part = /^(0|10|25)%$/.test(String(m?.part || "").replace(/\s/g, "")) ? String(m.part).replace(/\s/g, "") : "";
      const boxes = Number.isInteger(+m?.boxes) && +m.boxes >= 1 && +m.boxes <= 20 ? +m.boxes : 0;
      const perBox = Number.isInteger(+m?.perBox) && +m.perBox >= 1 && +m.perBox <= 1000 ? +m.perBox : 0;
      out.push({ name, strength, dose, freq, days, line: m.line || "", need: Math.ceil(+dose * freq * days), part, boxes, perBox });
    }
    return { out, bad };
  }

  // ✅ Ανοιχτές επισκέψεις: (1) σε ΑΛΛΗ μονάδα → αποσύνδεση, είσοδος σε εκείνη, Ολοκλήρωση, αποσύνδεση, είσοδος στη δική μας·
  // (2) στη δική μας, άλλου ασθενή → Ολοκλήρωση. Μόνο στο παράθυρο του bot (ανώνυμο όταν botIncog). Ειδοποίηση για κάθε μία.
  async function freeVisits(tab, H, opt) {
    const page = async (...x) => { if (H && H.alive) H.alive(); const r = await pageRaw(...x); if (H && H.alive) H.alive(); return r; };
    const done = [];
    const relogin = async (unit, strict) => {
      const cr0 = await epCookieLogout(tab.id); if (!cr0.ok) { const lo = await page(tab.id, "logout"); if (lo.err) return { err: lo.err + " · " + cr0.err }; }
      let st = null;
      for (let i = 0; i < 60; i++) { await H.sleep(500); st = await page(tab.id, "state"); if (st.login || st.unit) break; }
      if (st?.login) {
        // ΜΟΝΟ ο ίδιος λογαριασμός (έλεγχος 5/11): αλλιώς μπορούσε να μπει άλλος και η συνταγή να συνεχίσει με αυτόν
        const lg = H.epresAutoLogin ? await H.epresAutoLogin(tab.id, opt.doctor || "", opt.epUser ? { only: opt.epUser } : undefined) : { ok: false, err: "ζητά σύνδεση" };
        if (!lg.ok) return { err: lg.err };
        for (let i = 0; i < 40; i++) { st = await page(tab.id, "state"); if (st.err || st.unit || !st.loading) break; await H.sleep(250); }
      }
      if (st?.unit) {
        const u = await page(tab.id, "unit", { unit, strict });
        if (u.err) { if (strict) await page(tab.id, "unit", { unit: opt.unit || "" }); return u; }
        return { ok: true, unit: u.unit };
      }
      return strict ? { err: "δεν ζητήθηκε επιλογή μονάδας μετά τη σύνδεση" } : { ok: true };
    };
    const ou = await page(tab.id, "otherunit");
    if (ou && ou.unit) {
      let r = await relogin(ou.unit, true);
      if (r.err) return { err: "μονάδα «" + ou.unit + "»: " + r.err, done };
      const c = await epCloseVisit(tab.id, page, {}, ou.unit, true);
      if (c.err) { await relogin(opt.unit || "", false); return { err: "ολοκλήρωση επίσκεψης στη μονάδα «" + ou.unit + "»: " + c.err, done }; }
      if (!c.none) done.push({ unit: c.unit || ou.unit, amka: c.amka, rx: c.rx, ref: c.ref });
      r = await relogin(opt.unit || "", false);
      if (r.err) return { err: "επιστροφή στη μονάδα μας: " + r.err, done };
    }
    if (opt.current) {
      const st = await page(tab.id, "state");
      // απόφαση χρήστη 5/11: ΟΛΕΣ οι ανοιχτές επισκέψεις άλλων ασθενών ολοκληρώνονται — εντοπισμός ΚΑΙ με απευθείας αίτημα
      // (η κεφαλίδα δεν φαίνεται πάντα, #591)
      const av = await epActiveFresh(tab.id, H);   // με ανανέωση αν το κλειδί είναι παλιό (#617: έμενε ανοιχτή η ··31)
      const otherApi = av.ok && av.amka && av.amka !== opt.keep;
      if (otherApi || (st && st.banner && st.banner.amka && st.banner.amka !== opt.keep)) {
        const c = await epCloseVisit(tab.id, page, { keep: opt.keep }, opt.unit || "", false);
        if (c.err) return { err: "ολοκλήρωση ανοιχτής επίσκεψης: " + c.err, done };
        if (otherApi) { let a2 = await epActive(tab.id); for (let i = 0; i < 6 && a2.ok && a2.amka === av.amka; i++) { await H.sleep(1000); a2 = await epActive(tab.id); } if (a2.ok && a2.amka === av.amka) return { err: "η ανοιχτή επίσκεψη του ··" + av.amka.slice(-2) + " δεν έκλεισε", done }; }
        if (!c.keep && !c.none) done.push({ unit: c.unit || "δική μας μονάδα", amka: c.amka, rx: c.rx, ref: c.ref });
      }
    }
    for (const d of done) { try { if (typeof labsPushPhone === "function") labsPushPhone("✅ Ολοκληρώθηκε ανοιχτή επίσκεψη", "e-prescription · " + d.unit + " · ΑΜΚΑ ··" + String(d.amka || "").slice(-2) + " · συνταγές " + (d.rx || 0) + ", παραπεμπτικά " + (d.ref || 0)).catch(() => {}); } catch (e) {} }
    return { ok: true, done };
  }
  // 🗑 προηγούμενη συνταγή/παραπεμπτικό του bot που ΔΕΝ εγκρίθηκε (ακύρωση/«Αλλαγή» από το κινητό, ή έληξε): μένει μισό στη σελίδα και
  // μπλοκάρει το νέο. Απορρίπτεται ΜΟΝΟ αν η σελίδα δείχνει ΑΚΡΙΒΩΣ τη σύνοψη που έφτιαξε το bot (άγγιγμα από γιατρό → μένει).
  const OPEN_KEYS = [["efbotRxOpen", "summary", "συνταγής"], ["efbotRefOpen", "refSummary", "παραπεμπτικού"]];
  async function dropOpen(tab, st, job, H, page, mk) {
    for (const [key, op, lab] of OPEN_KEYS) {
      const { [key]: ro } = await chrome.storage.local.get(key);
      if (!ro || ro.jobId === job.id) continue;
      if (ro.tabId === tab.id && !st.login) {
        const sm0 = await page(tab.id, op);
        if (sm0 && sm0.ok && sm0.full && sm0.full === ro.sig) {
          mk("απόρριψη προηγούμενης μη καταχωρισμένης " + lab);
          await chrome.tabs.update(tab.id, { url: "https://www.e-prescription.gr/epres/patient" }).catch(() => {});
          for (let i = 0; i < 40; i++) { await H.sleep(500); st = await page(tab.id, "state"); if (!st.err && !st.loading) break; }
        }
      }
      await chrome.storage.local.remove(key);
    }
    return st;
  }
  const fvNote = (fv) => fv && fv.done && fv.done.length ? " · ✅ ολοκληρώθηκαν ανοιχτές επισκέψεις: " + fv.done.map((d) => d.unit + " (··" + String(d.amka || "").slice(-2) + ")").join(", ") : "";
  async function run(job, H) {
    const p = job.payload || {};
    const t0 = Date.now();
    // 🪦 η εντολή σταμάτησε (όριο χρόνου/ακύρωση): κάθε επόμενο βήμα ΣΤΑΜΑΤΑ (πριν συνέχιζε στο παρασκήνιο — έλεγχος 5/11)
    const alive = () => { if (self.efDeadJobs && self.efDeadJobs.has(job.id)) throw new Error("η εντολή σταμάτησε (όριο χρόνου ή ακύρωση) — δεν συνεχίζει"); };
    const page = async (...a) => { alive(); const r = await pageRaw(...a); alive(); return r; };
    H = { ...H, alive };
    // ⏳ πρόοδος στη σημείωση της εντολής (φαίνεται στο Παραδόχαρτο): αν κολλήσει, ξέρουμε σε ποιο βήμα
    const mk = (l) => { try { if (typeof bgMark === "function") bgMark(l); } catch (e) {} try { if (typeof imgNote === "function" && job.id) imgNote(job.id, "⏳ " + l + " · " + Math.round((Date.now() - t0) / 1000) + "″"); } catch (e) {} };
    const { out: meds, bad } = cleanMeds(p.meds);
    if (bad.length) return { status: "failed", note: "δεν κατάλαβα τις γραμμές: " + bad.join(" · ") };
    if (!meds.length) return { status: "failed", note: "η εντολή δεν έχει φάρμακα (στείλτε ξανά από το 💊 του Παραδόχαρτου)" };
    let icds = (Array.isArray(p.icd) ? p.icd : [p.icd || "N39"]).map((c) => String(c || "").trim().toUpperCase()).map((c) => ICD_FIX[c] || c).filter((c) => ICD_RE.test(c));
    icds = [...new Set(icds)];
    if (!icds.length) return { status: "failed", note: "χωρίς έγκυρη διάγνωση ICD-10" };
    const { efbot } = await chrome.storage.local.get("efbot");
    const S = { ...DEF, ...(efbot?.settings?.epres || {}) };

    // 1) ΑΜΚΑ: από το Παραδόχαρτο, αλλιώς από τον φάκελο (με έλεγχο ονόματος)
    const am = /^\d{11}$/.test(String(p.amka || "")) ? { r: String(p.amka) } : job.room ? await H.pdxCall("pdxComorbAmka", [job.room, job.name]) : null;
    let amka = /^\d{11}$/.test(String(am?.r || "")) ? String(am.r) : "";
    if (!amka && !job.room) return { status: "failed", note: "χωρίς έγκυρο ΑΜΚΑ" };
    if (!amka) {
      const tab = await H.bgEmrTab();
      if (!tab || tab.err) return { status: "failed", note: (tab?.err || "δεν άνοιξε ο φάκελος") + " — ή γράψτε τον ΑΜΚΑ στο 🩺 του ασθενή" };
      const a = await H.comorbAmka({ name: job.name, amka: "" }, tab);
      if (a.err) return { status: "failed", note: mask(a.err) };
      amka = a.amka;
    }

    // 2) e-prescription: συνδεδεμένο; μονάδα
    mk("άνοιγμα e-prescription");
    const tab = await epTab();
    if (tab.err) return { status: "failed", note: tab.err };
    let st = null;
    const tS = Date.now();
    for (let i = 0; i < 40 && Date.now() - tS < 30000; i++) { st = await page(tab.id, "state"); if (st.err || st.login || st.unit || !st.loading) break; await H.sleep(250); }
    // η σελίδα δεν απαντά (ανακατεύθυνση/σφάλμα): ΜΙΑ ανανέωση και ξανά (≤30″)· αλλιώς σταματά λέγοντας πού ήταν
    // (ΟΧΙ «ζητά σύνδεση» στα τυφλά: αν ήταν συνδεδεμένος άλλος λογαριασμός, θα παρακαμπτόταν ο έλεγχος λογαριασμού)
    if (st?.err) {
      const whereOf = async () => { const tb = await chrome.tabs.get(tab.id).catch(() => null); try { const u = new URL(tb.url); return u.host + u.pathname.replace(/\d{3,}/g, "#"); } catch (e) { return "?"; } };
      mk("η σελίδα δεν απαντά (" + (await whereOf()) + ") → ανανέωση");
      await chrome.tabs.update(tab.id, { url: "https://www.e-prescription.gr/epres/patient" }).catch(() => {});
      const t2 = Date.now(); st = null;
      for (let i = 0; i < 60 && Date.now() - t2 < 30000; i++) { await H.sleep(500); st = await page(tab.id, "state"); if (!st.err && (st.login || st.unit || !st.loading)) break; }
      if (!st || st.err) return { status: "failed", note: "e-prescription: η σελίδα δεν απαντά και μετά από ανανέωση (" + (await whereOf()) + ") — δεν έγινε τίποτα" };
    }
    mk("e-prescription: " + (st.login ? "ζητά σύνδεση" : st.unit ? "επιλογή μονάδας" : "συνδεδεμένο"));
    // 🗑 προηγούμενη συνταγή/παραπεμπτικό του bot που ΔΕΝ εγκρίθηκε → dropOpen (κοινό με το παραπεμπτικό)
    st = await dropOpen(tab, st, job, H, page, mk);
    let who = "", preferMiss = "";
    const therapist = String(p.therapist || "").trim();
    // 👤 λογαριασμός που διάλεξε ο γιατρός στο Παραδόχαρτο: ΜΟΝΟ αυτός (αλλιώς αποσύνδεση του τωρινού και είσοδος με αυτόν)
    const epUser = String(p.epUser || "").trim();
    if (epUser) {
      if (H.epresHasUser && !(await H.epresHasUser(epUser))) return { status: "failed", note: "🔑 ο λογαριασμός " + epUser + " δεν έχει μάθει σε αυτόν τον υπολογιστή" };
      if (!st?.login) {
        const last = H.epresLastWho ? await H.epresLastWho() : "";
        const sur = String(st?.doctor || "").trim().split(/\s+/).sort((a, b) => b.length - a.length);
        // ⚡ ακριβής έλεγχος: id του συνδεδεμένου (generate/me) ↔ id που έμαθε το bot για αυτόν τον λογαριασμό
        const known = (await epIdsGet())[epUser.toLowerCase()], me = known ? await epMe(tab.id, 3) : { skip: true };
        const same = me.ok ? me.id === known : last ? last === epUser.toLowerCase() : !!(H.epresNameScore && sur.some((w) => H.epresNameScore(epUser, w) > 0));
        if (me.ok) mk("λογαριασμός " + (same ? "σωστός" : "άλλος") + " (απευθείας)");
        if (!same) {
          mk("αλλαγή λογαριασμού → " + epUser);
          // ⚡ ΠΡΩΤΑ καθαρισμός σύνδεσης στο ΑΝΩΝΥΜΟ παράθυρο του bot (≈1″· το κουμπί της σελίδας κολλούσε 60″, #624), μετά η σελίδα
          let lo; { const cr = await epCookieLogout(tab.id); if (cr.ok) { mk("αποσύνδεση με καθαρισμό σύνδεσης (" + cr.n + ")"); lo = { ok: true }; } else { lo = await page(tab.id, "logout"); if (lo.err) lo.err += " · " + cr.err; } }
          if (lo.err) return { status: "failed", note: "e-prescription: αλλαγή λογαριασμού — " + lo.err };
          for (let i = 0; i < 60; i++) { await H.sleep(500); st = await page(tab.id, "state"); if (st.login || st.err) break;
            // αν η σύνδεση ζει σε άλλο host (SSO) και ξαναμπαίνει ο παλιός: μετά από ~6″ και το κουμπί αποσύνδεσης της σελίδας
            if (i === 12 && !st.loading) { mk("ο καθαρισμός δεν αρκεί — αποσύνδεση από τη σελίδα"); const lo2 = await page(tab.id, "logout"); if (lo2.err) mk("αποσύνδεση σελίδας: " + lo2.err); } }
          if (!st?.login) return { status: "failed", note: "e-prescription: δεν βγήκε ο προηγούμενος λογαριασμός" };
        } else who = epUser;
      }
    }
    if (st?.login) {
      // σύνδεση με τους αποθηκευμένους λογαριασμούς· πρώτος δοκιμάζεται ο θεράπων του εξιτηρίου (ή ΜΟΝΟ ο επιλεγμένος)
      mk("σύνδεση " + (epUser || "e-prescription") + "…");
      const lg = H.epresAutoLogin ? await H.epresAutoLogin(tab.id, therapist, epUser ? { only: epUser } : undefined) : { ok: false, err: "το e-prescription ζητά σύνδεση" };
      if (!lg.ok) return { status: "failed", note: epUser ? "🔑 e-prescription: δεν μπήκε ο " + epUser + " — " + String(lg.err || "").replace(/^🔑\s*e-prescription:\s*/, "") : lg.err };
      if (epUser && lg.who && String(lg.who).toLowerCase() !== epUser.toLowerCase()) return { status: "failed", note: "e-prescription: μπήκε άλλος λογαριασμός (" + lg.who + ") — ΔΕΝ ετοιμάστηκε συνταγή" };
      who = lg.who || "";
      if (lg.who) epIdLearn(tab.id, lg.who).catch(() => {});   // την επόμενη φορά: ακριβής έλεγχος λογαριασμού
      if (therapist && !epUser && lg.preferMatched === false) preferMiss = therapist;
      for (let i = 0; i < 40; i++) { st = await page(tab.id, "state"); if (st.err || st.unit || !st.loading) break; await H.sleep(250); }
      if (st?.err || st?.login) return { status: "failed", note: "το e-prescription ζητά σύνδεση και μετά την είσοδο" };
    }
    mk(who ? "σύνδεση e-prescription" : "e-prescription έτοιμο");
    const doctor = who || st?.doctor || "";
    // ήταν ήδη συνδεδεμένος κάποιος (δεν έκανε σύνδεση το bot): σύγκριση ελληνικού ονόματος γιατρού ↔ θεράποντα
    if (therapist && !who && !epUser && st?.doctor) {
      const nz2 = (x) => String(x || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^α-ω]/g, "");
      const d2 = nz2(st.doctor), th2 = nz2(therapist);
      if (th2.length >= 3 && !d2.includes(th2) && !d2.includes(th2.slice(0, Math.max(4, th2.length - 2)))) preferMiss = therapist;
    }
    if (st?.unit) { const u = await page(tab.id, "unit", { unit: S.unit || "" }); if (u.err) return { status: "failed", note: u.err }; }
    mk("έλεγχος ανοιχτών επισκέψεων");
    const fv = await freeVisits(tab, H, { keep: (H.epPendingSame && !(await H.epPendingSame(amka, job.id))) ? "" : amka, current: true, unit: S.unit || "", doctor, epUser: epUser || who || (await (H.epresLastWho ? H.epresLastWho() : "")) || "" });
    if (fv.err) return { status: "failed", note: "e-prescription: " + mask(fv.err) + fvNote(fv) };
    if (fv.done.length) mk("ολοκλήρωση ανοιχτών επισκέψεων");
    // ο λογαριασμός μετά τις ανοιχτές επισκέψεις: ίδιος με πριν (αν ξέρουμε το id του)
    if (fv.done.length && (epUser || who)) { const k = (await epIdsGet())[(epUser || who).toLowerCase()]; if (k) { const m2 = await epMe(tab.id, 5); if (m2.ok && m2.id !== k) return { status: "failed", note: "e-prescription: μετά το κλείσιμο ανοιχτών επισκέψεων μπήκε άλλος λογαριασμός — ΔΕΝ ετοιμάστηκε συνταγή" + fvNote(fv) }; } }

    // μήνυμα της σελίδας (ανοιχτά παράθυρα) για τις αποτυχίες
    const pmsg = async (r) => {
      const dl = await page(tab.id, "dialogs");
      const extra = [...(r.notes || []), ...((dl && dl.list) || [])].filter(Boolean).slice(-2).map((t) => mask(t).slice(0, 220));
      return extra.length ? ` · μήνυμα e-prescription: «${extra.join(" · ")}»` : "";
    };
    // ⚡ προέλεγχος φαρμάκων/ICD με απευθείας αιτήματα — ΠΡΙΝ ανοίξει επίσκεψη (αλλιώς έμενε μισή συνταγή)
    let pre = null;
    { const age = (() => { const d = +amka.slice(0, 2), m = +amka.slice(2, 4), y = +amka.slice(4, 6); if (!(d && m)) return 50; const now = new Date(), Y = (y > now.getFullYear() % 100 ? 1900 : 2000) + y; return now.getFullYear() - Y; })();
      pre = await epPreflight(tab.id, meds, icds, age).catch((e) => ({ err: e.message })); mk("προέλεγχος φαρμάκων/ICD (απευθείας)");
      if (pre && !pre.err && !pre.skip) {
        const noMed = (pre.meds || []).filter((x) => x.st === 200 && x.n === 0).map((x) => x.name);
        const noIcd = (pre.icds || []).filter((x) => x.st === 200 && x.n === 0).map((x) => x.code);
        if (noMed.length || noIcd.length) return { status: "failed", noRetry: true, note: "⚠ δεν βρέθηκαν στο e-prescription: " + [...noMed.map((n) => "φάρμακο «" + n + "»"), ...noIcd.map((c) => "ICD " + c)].join(" · ") + " — ΔΕΝ άνοιξε επίσκεψη· διορθώστε και ξαναστείλτε", result: { pre } };
      } }
    // 3) ασθενής: ΑΜΚΑ + όνομα πρέπει να ταιριάζουν
    { const pa = await epPatientApi(tab.id, amka); if (pa.notFound) return { status: "failed", noRetry: true, note: "e-prescription: ο ΑΜΚΑ δεν βρέθηκε («" + pa.notFound + "») — ελέγξτε τον ΑΜΚΑ" }; if (pa.mismatch) return { status: "failed", note: "e-prescription: η απάντηση είχε άλλον ΑΜΚΑ — δεν έγινε τίποτα" }; mk(pa.ok ? "ασθενής (απευθείας ✓)" : "ασθενής: απευθείας έλεγχος παραλείφθηκε (" + pa.skip + ")"); }
    const pt = await patientPage(tab, H, amka, typeof mk === "function" ? mk : null); mk("ασθενής");
    if (pt.err) { let who = ""; if (pt.pwExpired) { try { const { efbotEpWho: w } = await chrome.storage.session.get("efbotEpWho"); if (w && w.user) who = " (λογαριασμός: " + w.user + ")"; } catch (e) {} }
      return { status: "failed", note: "e-prescription: " + mask(pt.err) + who + (await pmsg(pt)) }; }
    if (!String(pt.card || "").includes(amka)) return { status: "failed", note: "ο ασθενής που άνοιξε δεν έχει τον ίδιο ΑΜΚΑ — δεν έγινε τίποτα" };
    const want = nz(job.name), card = new Set(nz(pt.card));
    if (want.length && !want.some((w) => card.has(w))) return { status: "failed", note: "ο ΑΜΚΑ ανήκει σε άλλο όνομα στο e-prescription — ελέγξτε τον ΑΜΚΑ (δεν έγινε τίποτα)" };

    // 4) επίσκεψη
    // ⚡ ενεργή επίσκεψη απευθείας: ίδιος ασθενής → συνέχεια χωρίς να διαβαστεί η οθόνη· αλλιώς ο δρόμος της οθόνης όπως πριν
    const actv = async () => { let x = { skip: true }; for (let i = 0; i < 4; i++) { x = await epActive(tab.id); if (x.ok || x.none) return x; await H.sleep(1000); } return x; };
    const av = await actv();
    let vs;
    if (av.ok && av.amka && av.amka !== amka) return { status: "failed", note: "υπάρχει ανοιχτή επίσκεψη ΑΛΛΟΥ ασθενή στο e-prescription — δεν έγινε τίποτα (ολοκληρώστε την πρώτα)" };
    if (av.ok && av.amka === amka) { vs = { ok: true, reuse: true, visit: av.id }; mk("επίσκεψη (ήδη ανοιχτή, απευθείας)"); }
    else { vs = await page(tab.id, "visit", { amka, reason: S.reason, noBanner: !!av.none }); mk(av.none ? "νέα επίσκεψη" : "επίσκεψη"); }
    // διπλός έλεγχος (έλεγχος 5/11): η ενεργή επίσκεψη ΠΡΕΠΕΙ να επιβεβαιωθεί απευθείας ότι είναι αυτού του ΑΜΚΑ
    const a2u = async (a2) => { if (a2.ok || a2.none) return a2; const st2 = await page(tab.id, "state"); if (!(st2 && st2.unit)) return a2; const u2 = await page(tab.id, "unit", { unit: S.unit || "" }); mk("μονάδα (στον έλεγχο επίσκεψης)"); if (u2.err) return a2; await H.sleep(1200); return actv(); };   // 7/11: «Μονάδα Συνταγογράφησης» στη μέση → επιλογή και ξανά
    if (!vs.err) { let a2 = await a2u(await actv());
      // νέα επίσκεψη: το e-prescription μπορεί να αργήσει λίγο να τη δείξει — έως ~12″
      if (!vs.reuse && a2.none) { for (let i = 0; i < 8 && a2.none; i++) { await H.sleep(1500); a2 = await epActive(tab.id); } }
      // 🌙 12/11 (eptorture 2942 γ.1, αμέσως μετά την επαναφόρτωση καρτέλας + «Νέες Ενημερώσεις Προς Επαγγελματίες Υγείας»): ήδη ανοιχτή επίσκεψη,
      // αλλά ο 2ος απευθείας έλεγχος δεν απάντησε (κλειδιά/μονάδα δεν είχαν φορτώσει) → αποτυχία σε 4″. Όπως στο παραπεμπτικό: δυναμική αναμονή
      // όσο η απάντηση είναι ΑΣΑΦΗΣ (skip/σφάλμα) — ΠΟΤΕ συνέχεια χωρίς επιβεβαίωση ίδιου ΑΜΚΑ.
      if (vs.reuse && !a2.ok && !a2.none) { for (let i = 0; i < 8 && !a2.ok && !a2.none; i++) { await H.sleep(1500); a2 = await a2u(await epActive(tab.id)); } }
      if (a2.ok && a2.amka && a2.amka !== amka) vs = { err: "η ενεργή επίσκεψη δεν είναι του ίδιου ΑΜΚΑ — σταμάτησε" };
      else if (vs.reuse && !(a2.ok && a2.amka === amka)) vs = { err: "δεν επιβεβαιώθηκε ότι η ανοιχτή επίσκεψη είναι αυτού του ασθενή — σταμάτησε [" + (a2.none ? "καμία ενεργή" : a2.skip ? "χωρίς κλειδιά σελίδας" : String(a2.err || "?").slice(0, 60)) + "]" };
      else if (!vs.reuse && a2.none) vs = { err: "η επίσκεψη δεν καταχωρίστηκε (το e-prescription λέει «δεν υπάρχει ενεργή επίσκεψη»)" }; }
    if (vs.err) return { status: "failed", note: "επίσκεψη: " + mask(vs.err) + (await pmsg(vs)) };

    // 5) οδηγός συνταγής
    const fail = async (where, r) => { let wz = r.wiz; if (!wz) { const d = await page(tab.id, "wizDiag").catch(() => null); wz = d && d.wiz; }
      if (r.icdDiag) wz = Object.assign({}, wz || {}, { icdDiag: r.icdDiag });
      // 7/11: τι απάντησε το API του e-prescription (κείμενο σφάλματος) + τι δείχνει η σελίδα
      try { const [x] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: "MAIN", func: () => { const S = window.__efEp || {}; return { errs: (S.errs || []).filter((e) => Date.now() - e.at < 120000), last: (S.log || []).slice(-25).map((e) => (e.m || "") + " " + (e.p || "") + " " + (e.st || "")), page: String((document.querySelector("main") || document.body).innerText || "").replace(/\d{6,}/g, "#").slice(0, 1500), dlg: [...document.querySelectorAll("[role=dialog],[role=alertdialog]")].map((d) => String(d.innerText || "").replace(/\d{6,}/g, "#").slice(0, 600)) }; } }); if (x && x.result) wz = Object.assign({}, wz || {}, { api: x.result }); } catch (e) {}
      if (/Τροποποίηση/.test((wz && wz.api && wz.api.page) || "")) { const md = await page(tab.id, "modDiag").catch(() => null); if (md) wz = Object.assign({}, wz, { mod: md }); }
      const me = wz && wz.mod && ((wz.mod.errTxt || []).length ? wz.mod.errTxt : (wz.mod.wiz && wz.mod.wiz.bad) || []);
      const bd2 = me && me.length ? " · ⚠ οδηγός: " + mask(me.slice(0, 6).join(" | ")).slice(0, 500) : "";
      const ae = wz && wz.api && wz.api.errs && wz.api.errs.length ? " · API: " + mask(wz.api.errs.map((e) => e.st + " " + e.t.slice(0, 200)).join(" | ")).slice(0, 500) : "";
      const bd = wz && wz.bad && wz.bad.length ? " · ⚠ πεδία: " + mask(wz.bad.slice(0, 4).join(" | ")) : "";
      return { status: "failed", note: `${where}: ${mask(r.err)}` + bd + bd2 + ae + (await pmsg(r)) + ` — η συνταγή ΔΕΝ καταχωρίστηκε (η επίσκεψη ${vs.reuse ? "ήταν ήδη ανοιχτή" : "άνοιξε"})`, result: { wiz: wz || null, icdTr: (pre && pre.icdTr) || undefined } }; };
    const repA = p.repeat && typeof p.repeat === "object" ? p.repeat : null;
    let r = await page(tab.id, "rxOpen", { fast: !!vs.reuse, rep: repA }); mk("νέα συνταγή");
    if (r.stale) {   // ΜΙΑ ανανέωση της σελίδας ώστε να φορτώσει την επίσκεψη που άνοιξε αλλού, και ξανά
      mk("ανανέωση σελίδας (η επίσκεψη άνοιξε σε άλλον υπολογιστή)");
      await chrome.tabs.update(tab.id, { url: "https://www.e-prescription.gr/epres/patient" }).catch(() => {});
      for (let i = 0; i < 40; i++) { await H.sleep(500); const s2 = await page(tab.id, "state"); if (!s2.err && !s2.loading) break; }
      const a3 = await epActive(tab.id); if (!(a3.ok && a3.amka === amka)) return { status: "failed", note: "μετά την ανανέωση η ενεργή επίσκεψη δεν είναι αυτού του ασθενή — σταμάτησε" };
      r = await page(tab.id, "rxOpen", { rep: repA }); mk("νέα συνταγή (2η)");
    }
    // 🌙 12/11 (eptorture 2944 γ.3, μετά από αποσύνδεση + νέα σύνδεση, ήδη ανοιχτή επίσκεψη): «Τα στοιχεία της συνταγής δεν είναι έγκυρα» ΠΡΙΝ τις Διαγνώσεις
    // (ο οδηγός άνοιξε πριν η σελίδα φορτώσει την επίσκεψη/μονάδα). ΜΙΑ καθαρή επανάληψη: φόρτωση σελίδας ασθενή (ο μισός οδηγός πετιέται — τίποτα δεν καταχωρίστηκε)
    // → ξανά επιβεβαίωση ίδιου ΑΜΚΑ → ξανά οδηγός. Η διάγνωση της 1ης αποτυχίας μένει στο αποτέλεσμα.
    let firstBad = null;
    if (r.err && /δεν είναι έγκυρα/.test(String(r.err))) {
      firstBad = String(r.err).slice(0, 300); mk("«δεν είναι έγκυρα» στον οδηγό → καθαρή επανάληψη");
      await chrome.tabs.update(tab.id, { url: "https://www.e-prescription.gr/epres/patient" }).catch(() => {});
      for (let i = 0; i < 40; i++) { await H.sleep(500); const s2 = await page(tab.id, "state"); if (!s2.err && !s2.loading) break; }
      let a4 = await epActive(tab.id); for (let i = 0; i < 8 && !a4.ok && !a4.none; i++) { await H.sleep(1500); a4 = await a2u(await epActive(tab.id)); }
      if (!(a4.ok && a4.amka === amka)) return { status: "failed", note: "συνταγή: «δεν είναι έγκυρα» και μετά την επαναφόρτωση η ενεργή επίσκεψη δεν επιβεβαιώθηκε — σταμάτησε (ΔΕΝ καταχωρίστηκε) · 1η: " + mask(firstBad) };
      await H.sleep(2500);
      r = await page(tab.id, "rxOpen", { rep: repA }); mk("νέα συνταγή (μετά την επαναφόρτωση)");
      if (r.err) r.err = String(r.err) + " · (2η προσπάθεια· 1η: " + firstBad.slice(0, 120) + ")";
    }
    const repRes = { ok: !!r.repOk, log: r.repLog || null };
    if (r.err) return await fail("συνταγή", r);
    if (p.test && p.srcGrep) { const g = await page(tab.id, "srcGrep", p.srcGrep).catch((e) => ({ err: e.message })); return { status: "failed", note: "🔎 srcGrep (δοκιμή) — η συνταγή ΔΕΝ καταχωρίστηκε", result: { grep: g } }; }
    const icdTr = []; let wizRe = false;
    for (const code of icds) { r = await page(tab.id, "icd", { code }); if (r.err && !/δεν υπάρχει στη λίστα|έκλεισε/.test(r.err)) { mk("ICD " + code + ": 2η προσπάθεια (" + String(r.err).slice(0, 160) + ")"); await H.sleep(800); r = await page(tab.id, "icd", { code }); } if (r.err && r.ueSet) { const ro = await page(tab.id, "reopenDx", { codes: icds.slice(0, icds.indexOf(code) + 1) }); mk("ICD " + code + ": «Τροποποίηση» " + (ro.err ? "✗" : "✓")); if (!ro.err) r = { ok: true, via: "ue+Τροποποίηση", trace: r.err.slice(0, 200) }; else r = { ...r, err: r.err + " · " + ro.err }; }
      // 🌙 12/11 (eptorture 3110 γ.3, μετά από αποσύνδεση + ήδη ανοιχτή επίσκεψη): ο οδηγός έφτασε στις «Διαγνώσεις» και ΕΚΛΕΙΣΕ (η σελίδα ξαναφόρτωσε
      // την επίσκεψη) → ΜΙΑ καθαρή επανάληψη: σελίδα ασθενή → επιβεβαίωση ίδιου ΑΜΚΑ → νέος οδηγός → ξανά οι διαγνώσεις που είχαν ήδη μπει + αυτή. Τίποτα δεν είχε καταχωριστεί.
      if (r.err && /οδηγός συνταγής έκλεισε/.test(String(r.err)) && !wizRe) { wizRe = true;
        try { mk("ο οδηγός έκλεισε στις «Διαγνώσεις» → καθαρή επανάληψη"); const firstErr = String(r.err).slice(0, 160);
          await chrome.tabs.update(tab.id, { url: "https://www.e-prescription.gr/epres/patient" }).catch(() => {});
          for (let i = 0; i < 40; i++) { await H.sleep(500); const s2 = await page(tab.id, "state"); if (!s2.err && !s2.loading) break; }
          let a5 = await epActive(tab.id); for (let i = 0; i < 8 && !a5.ok && !a5.none; i++) { await H.sleep(1500); a5 = await a2u(await epActive(tab.id)); }
          if (!(a5.ok && a5.amka === amka)) return { status: "failed", note: "διάγνωση: ο οδηγός έκλεισε και μετά την επαναφόρτωση η ενεργή επίσκεψη δεν επιβεβαιώθηκε — σταμάτησε (η συνταγή ΔΕΝ καταχωρίστηκε)" };
          await H.sleep(2500);   // 3111 γ.1: χωρίς αναμονή ο νέος οδηγός άνοιγε πριν φορτώσει η επίσκεψη → «δεν είναι έγκυρα»
          r = await page(tab.id, "rxOpen", { rep: repA }); mk("νέα συνταγή (μετά το κλείσιμο του οδηγού)");
          if (!r.err) for (const c0 of icdTr.map((x) => x.code).concat([code])) { r = await page(tab.id, "icd", { code: c0 }); if (r.err) break; }
          if (r.err) r.err = String(r.err) + " · (2η προσπάθεια· 1η: " + firstErr + ")";
        } catch (e) { r = { err: String(r && r.err || e.message || e) }; } }
      if (r.err) return await fail("διάγνωση", r); icdTr.push({ code, already: !!r.already, via: r.via || "", trace: String(r.trace || "").slice(0, 300), d: p.test ? r.icdDiag || null : null }); mk("ICD " + code + (r.already ? " (ήδη)" : r.via ? " (" + r.via + ")" : "")); }
    if (p.test) pre = Object.assign({}, pre || {}, { icdTr });
    r = await page(tab.id, "toTher"); mk("θεραπείες");
    if (r.err) return await fail("συνταγή", r);
    const done = [], warn = [], notes = [], medT = [];
    for (const m of meds) {
      r = await page(tab.id, "med", { ...m, disease: S.disease, part: m.part || S.part }); mk("φάρμακο " + String(m.name).slice(0, 18));
      if (r.err) return await fail(m.name, r);
      done.push(`${r.chosen} ×${r.boxes}`); if (r.tm) medT.push(r.tm);
      (r.warn || []).forEach((w) => warn.push(`${m.name}: ${w}`));
      (r.notes || []).forEach((n) => notes.push(n));
    }
    if (warn.length) return { status: "failed", noRetry: true, note: "⚠ η συνταγή έμεινε ανοιχτή στον υπολογιστή για συμπλήρωση: " + warn.join(" · ") };
    r = await page(tab.id, "finish"); mk("ολοκλήρωση");
    if (r.err) return await fail("ολοκλήρωση", r);
    (r.notes || []).forEach((n) => notes.push(n));
    if (notes.some((n) => /κινολόν/i.test(n))) await page(tab.id, "remarks", { text: S.quinoloneNote });
    const sm = await page(tab.id, "summary");
    // 🔁 επαναλαμβανόμενη συνταγή (payload.repeat = {n:2|3|6, every:28|30}): ο οδηγός τη συμπληρώνει στα πρώτα βήματα (rxOpen)· εδώ μόνο το κείμενο
    const rp = p.repeat && typeof p.repeat === "object" ? p.repeat : null;
    const repTxt = rp && [2, 3, 6].includes(+rp.n) ? ({ 2: "δίμηνη", 3: "τρίμηνη", 6: "εξάμηνη" })[+rp.n] + ([28, 30].includes(+rp.every) ? " · ανά " + (+rp.every) + " ημέρες" : "") : "";
    const secs = Math.round((Date.now() - t0) / 1000);
    const head = `${done.join(", ")} · ICD ${icds.join(", ")}` + fvNote(fv) + (doctor ? ` · λογαριασμός: ${doctor}` : "") + (preferMiss ? ` · ⚠ ΟΧΙ ο θεράπων (${preferMiss}) — έλεγξε το όνομα πριν την καταχώριση` : "") + (vs.reuse ? " · ήδη ανοιχτή επίσκεψη" : " · νέα επίσκεψη") + ` · ${secs}″` + (repTxt ? (repRes.ok ? ` · 🔁 επανάληψη «${repTxt}» συμπληρώθηκε (${(repRes.log.set || []).join(", ")}) — ελέγξτε τη στη σύνοψη` : ` · ⚠ επανάληψη «${repTxt}»: το bot ΔΕΝ βρήκε τα πεδία (${((repRes.log && repRes.log.set) || []).join(", ") || "τίποτα"}) — συμπληρώστε τη στον υπολογιστή πριν την καταχώριση`) : "");
    // 📱 ο γιατρός ελέγχει στο κινητό και πατά «Καταχώριση» εκεί (εντολή χρήστη 5/11) — ΠΟΤΕ αυτόματα
    const meId = (await epMe(tab.id, 2)).id || "";
    const canPhone = !!(sm && sm.ok && sm.hasSubmit && sm.text && sm.full && meId);
    if (canPhone) await chrome.storage.local.set({ efbotRxOpen: { jobId: job.id, tabId: tab.id, sig: sm.full, at: Date.now() } });
    return {
      status: canPhone ? "review" : "done",
      note: (canPhone ? "💊 για έλεγχο στο κινητό (ΟΧΙ καταχωρισμένη): " : "💊 έτοιμη για έλεγχο στον υπολογιστή (ΟΧΙ καταχωρισμένη · δεν βρέθηκε η σύνοψη για το κινητό): ") + head,
      result: { summary: mask(sm?.text || ""), pgHdr: mask(sm?.hdr || ""), icdPage: sm?.icdPage || "", sig: sm?.full || "", notes: notes.map(mask).slice(0, 6), medT, pre, at: Date.now(), tabId: tab.id, amka, meId, path: sm?.path || "", meds: done, icds, doctor, preferMiss, filledAt: Date.now(), repeatManual: repTxt && !repRes.ok ? repTxt : "", repeat: repTxt ? { txt: repTxt, ok: repRes.ok, log: repRes.log } : undefined },
      push: canPhone ? ["💊 Συνταγή για έλεγχο", `${job.name}: ${done.join(", ")} — ανοίξτε το Παραδόχαρτο και πατήστε «Καταχώριση»`] : ["💊 Συνταγή έτοιμη για έλεγχο", `${job.name}: στο e-prescription του υπολογιστή — ελέγξτε και πατήστε «Καταχώριση»`],
    };
  }

  // ===== 📋 ΠΑΡΑΠΕΜΠΤΙΚΟ (εντολή «ref»): ίδια ροή με τη συνταγή ως την επίσκεψη → «Νέο Παραπεμπτικό» → Βασικές → ICD → Εξετάσεις →
  // Αυτόματη συσχέτιση → «Ολοκλήρωση» → σύνοψη. ΣΤΑΜΑΤΑ πριν την «Καταχώριση»: πατιέται ΜΟΝΟ από το κινητό (approve kind ref).
  // payload: { amka?, cat, just, icd:[...], exams:[ονόματα ή {name}], remarks?, epUser? }
  async function refRun(job, H) {
    const p = job.payload || {};
    const t0 = Date.now();
    const alive = () => { if (self.efDeadJobs && self.efDeadJobs.has(job.id)) throw new Error("η εντολή σταμάτησε (όριο χρόνου ή ακύρωση) — δεν συνεχίζει"); };
    const page = async (...a) => { alive(); const r = await pageRaw(...a); alive(); return r; };
    H = { ...H, alive };
    const mk = (l) => { try { if (typeof bgMark === "function") bgMark(l); } catch (e) {} try { if (typeof imgNote === "function" && job.id) imgNote(job.id, "⏳ " + l + " · " + Math.round((Date.now() - t0) / 1000) + "″"); } catch (e) {} };
    // έλεγχος εντολής
    const exams = [...new Set((Array.isArray(p.exams) ? p.exams : []).map((x) => String((x && typeof x === "object" ? x.name : x) || "").replace(/\s+/g, " ").trim()).filter(Boolean))];
    if (!exams.length) return { status: "failed", note: "το παραπεμπτικό δεν έχει εξετάσεις" };
    // 9/11: τα ΕΠΙΣΗΜΑ ονόματα είναι μακριά («Γενική εξέταση αίματος (αιμοσφαιρίνη - …)» = 136) → όριο 250 (ήταν 120 και απέρριπτε τη γενική αίματος)
    { const long = exams.find((x) => x.length > 250); if (long) return { status: "failed", noRetry: true, note: "πολύ μεγάλη γραμμή εξέτασης (>250 χαρακτήρες): «" + long.slice(0, 60) + "…» — γράψτε το όνομα της εξέτασης" }; }
    // όριο χρόνου εργασίας JOB_LIMIT_S.ref = 420″ ≈ 90″ + 25″ × 12 εξετάσεις
    if (exams.length > 12) return { status: "failed", noRetry: true, note: "έως 12 εξετάσεις ανά παραπεμπτικό (στάλθηκαν " + exams.length + ")" };
    const cat = String(p.cat || "").replace(/\s+/g, " ").trim();
    if (!cat) return { status: "failed", note: "χωρίς «Κατηγορία Εξέτασης» (στείλτε από το 📋 Παραπεμπτικό του ασθενή)" };
    const just = String(p.just || "").trim().slice(0, 2000);
    if (!just) return { status: "failed", note: "χωρίς αιτιολογία παραπεμπτικού" };
    const remarks = String(p.remarks || "").trim().slice(0, 200);
    let icds = (Array.isArray(p.icd) ? p.icd : [p.icd]).map((c) => String(c || "").trim().toUpperCase()).map((c) => ICD_FIX[c] || c).filter((c) => ICD_RE.test(c));
    icds = [...new Set(icds)];
    if (!icds.length) return { status: "failed", note: "χωρίς έγκυρη διάγνωση ICD-10" };
    const { efbot } = await chrome.storage.local.get("efbot");
    const S = { ...DEF, ...(efbot?.settings?.epres || {}) };
    // 1) ΑΜΚΑ
    const am = /^\d{11}$/.test(String(p.amka || "")) ? { r: String(p.amka) } : job.room ? await H.pdxCall("pdxComorbAmka", [job.room, job.name]) : null;
    let amka = /^\d{11}$/.test(String(am?.r || "")) ? String(am.r) : "";
    if (!amka && !job.room) return { status: "failed", note: "χωρίς έγκυρο ΑΜΚΑ" };
    if (!amka) {
      const etab = await H.bgEmrTab();
      if (!etab || etab.err) return { status: "failed", note: (etab?.err || "δεν άνοιξε ο φάκελος") + " — ή γράψτε τον ΑΜΚΑ στο 🩺 του ασθενή" };
      const a = await H.comorbAmka({ name: job.name, amka: "" }, etab);
      if (a.err) return { status: "failed", note: mask(a.err) };
      amka = a.amka;
    }
    // 2) e-prescription: σύνδεση / λογαριασμός / μονάδα (όπως run)
    mk("άνοιγμα e-prescription");
    const tab = await epTab();
    if (tab.err) return { status: "failed", note: tab.err };
    let st = null;
    const tS = Date.now();
    for (let i = 0; i < 40 && Date.now() - tS < 30000; i++) { st = await page(tab.id, "state"); if (st.err || st.login || st.unit || !st.loading) break; await H.sleep(250); }
    if (st?.err) {
      await chrome.tabs.update(tab.id, { url: EP_HOME }).catch(() => {});
      const t2 = Date.now(); st = null;
      for (let i = 0; i < 60 && Date.now() - t2 < 30000; i++) { await H.sleep(500); st = await page(tab.id, "state"); if (!st.err && (st.login || st.unit || !st.loading)) break; }
      if (!st || st.err) return { status: "failed", note: "e-prescription: η σελίδα δεν απαντά και μετά από ανανέωση — δεν έγινε τίποτα" };
    }
    st = await dropOpen(tab, st, job, H, page, mk);
    let who = "";
    const epUser = String(p.epUser || "").trim();
    if (epUser) {
      if (H.epresHasUser && !(await H.epresHasUser(epUser))) return { status: "failed", note: "🔑 ο λογαριασμός " + epUser + " δεν έχει μάθει σε αυτόν τον υπολογιστή" };
      if (!st?.login) {
        const last = H.epresLastWho ? await H.epresLastWho() : "";
        const sur = String(st?.doctor || "").trim().split(/\s+/).sort((a, b) => b.length - a.length);
        const known = (await epIdsGet())[epUser.toLowerCase()], me = known ? await epMe(tab.id, 3) : { skip: true };
        const same = me.ok ? me.id === known : last ? last === epUser.toLowerCase() : !!(H.epresNameScore && sur.some((w) => H.epresNameScore(epUser, w) > 0));
        if (!same) {
          mk("αλλαγή λογαριασμού → " + epUser);
          let lo = await page(tab.id, "logout");
          if (lo.err) { const cr = await epCookieLogout(tab.id); if (cr.ok) lo = { ok: true }; else lo.err += " · " + cr.err; }
          if (lo.err) return { status: "failed", note: "e-prescription: αλλαγή λογαριασμού — " + lo.err };
          for (let i = 0; i < 60; i++) { await H.sleep(500); st = await page(tab.id, "state"); if (st.login || st.err) break; }
          if (!st?.login) return { status: "failed", note: "e-prescription: δεν βγήκε ο προηγούμενος λογαριασμός" };
        } else who = epUser;
      }
    }
    if (st?.login) {
      mk("σύνδεση " + (epUser || "e-prescription") + "…");
      const lg = H.epresAutoLogin ? await H.epresAutoLogin(tab.id, "", epUser ? { only: epUser } : undefined) : { ok: false, err: "το e-prescription ζητά σύνδεση" };
      if (!lg.ok) return { status: "failed", note: epUser ? "🔑 e-prescription: δεν μπήκε ο " + epUser + " — " + String(lg.err || "").replace(/^🔑\s*e-prescription:\s*/, "") : lg.err };
      if (epUser && lg.who && String(lg.who).toLowerCase() !== epUser.toLowerCase()) return { status: "failed", note: "e-prescription: μπήκε άλλος λογαριασμός (" + lg.who + ") — ΔΕΝ ετοιμάστηκε παραπεμπτικό" };
      who = lg.who || "";
      if (lg.who) epIdLearn(tab.id, lg.who).catch(() => {});
      for (let i = 0; i < 40; i++) { st = await page(tab.id, "state"); if (st.err || st.unit || !st.loading) break; await H.sleep(250); }
      if (st?.err || st?.login) return { status: "failed", note: "το e-prescription ζητά σύνδεση και μετά την είσοδο" };
    }
    const doctor = who || st?.doctor || "";
    if (st?.unit) { const u = await page(tab.id, "unit", { unit: S.unit || "" }); if (u.err) return { status: "failed", note: u.err }; }
    mk("έλεγχος ανοιχτών επισκέψεων");
    const fv = await freeVisits(tab, H, { keep: (H.epPendingSame && !(await H.epPendingSame(amka, job.id))) ? "" : amka, current: true, unit: S.unit || "", doctor, epUser: epUser || who || (await (H.epresLastWho ? H.epresLastWho() : "")) || "" });
    if (fv.err) return { status: "failed", note: "e-prescription: " + mask(fv.err) + fvNote(fv) };
    if (fv.done.length && (epUser || who)) { const k = (await epIdsGet())[(epUser || who).toLowerCase()]; if (k) { const m2 = await epMe(tab.id, 5); if (m2.ok && m2.id !== k) return { status: "failed", note: "e-prescription: μετά το κλείσιμο ανοιχτών επισκέψεων μπήκε άλλος λογαριασμός — ΔΕΝ ετοιμάστηκε παραπεμπτικό" + fvNote(fv) }; } }
    const pmsg = async (r) => { const dl = await page(tab.id, "dialogs"); const extra = [...(r.notes || []), ...((dl && dl.list) || [])].filter(Boolean).slice(-2).map((t) => mask(t).slice(0, 220)); return extra.length ? ` · μήνυμα e-prescription: «${extra.join(" · ")}»` : ""; };
    // ⚡ προέλεγχος ICD (απευθείας, ΠΡΙΝ την επίσκεψη)
    { const age = (() => { const d = +amka.slice(0, 2), m = +amka.slice(2, 4), y = +amka.slice(4, 6); if (!(d && m)) return 50; const now = new Date(), Y = (y > now.getFullYear() % 100 ? 1900 : 2000) + y; return now.getFullYear() - Y; })();
      const pre = await epPreflight(tab.id, [], icds, age).catch((e) => ({ err: e.message })); mk("προέλεγχος ICD (απευθείας)");
      const noIcd = pre && !pre.err && !pre.skip ? (pre.icds || []).filter((x) => x.st === 200 && x.n === 0).map((x) => x.code) : [];
      if (noIcd.length) return { status: "failed", noRetry: true, note: "⚠ δεν βρέθηκαν στο e-prescription: " + noIcd.map((c) => "ICD " + c).join(" · ") + " — ΔΕΝ άνοιξε επίσκεψη" }; }
    // 3) ασθενής
    { const pa = await epPatientApi(tab.id, amka); if (pa.notFound) return { status: "failed", noRetry: true, note: "e-prescription: ο ΑΜΚΑ δεν βρέθηκε («" + pa.notFound + "») — ελέγξτε τον ΑΜΚΑ" }; if (pa.mismatch) return { status: "failed", note: "e-prescription: η απάντηση είχε άλλον ΑΜΚΑ — δεν έγινε τίποτα" }; mk(pa.ok ? "ασθενής (απευθείας ✓)" : "ασθενής: απευθείας έλεγχος παραλείφθηκε (" + pa.skip + ")"); }
    const pt = await patientPage(tab, H, amka, typeof mk === "function" ? mk : null); mk("ασθενής");
    if (pt.err) { let who = ""; if (pt.pwExpired) { try { const { efbotEpWho: w } = await chrome.storage.session.get("efbotEpWho"); if (w && w.user) who = " (λογαριασμός: " + w.user + ")"; } catch (e) {} }
      return { status: "failed", note: "e-prescription: " + mask(pt.err) + who + (await pmsg(pt)) }; }
    if (!String(pt.card || "").includes(amka)) return { status: "failed", note: "ο ασθενής που άνοιξε δεν έχει τον ίδιο ΑΜΚΑ — δεν έγινε τίποτα" };
    const want = nz(job.name), card = new Set(nz(pt.card));
    if (want.length && !want.some((w) => card.has(w))) return { status: "failed", note: "ο ΑΜΚΑ ανήκει σε άλλο όνομα στο e-prescription — ελέγξτε τον ΑΜΚΑ (δεν έγινε τίποτα)" };
    // 4) επίσκεψη (ίδιου ΑΜΚΑ: επαναχρησιμοποίηση) — επιβεβαίωση ΑΠΕΥΘΕΙΑΣ
    const actv = async () => { let x = { skip: true }; for (let i = 0; i < 4; i++) { x = await epActive(tab.id); if (x.ok || x.none) return x; await H.sleep(1000); } return x; };
    const av = await actv();
    if (av.ok && av.amka && av.amka !== amka) return { status: "failed", note: "υπάρχει ανοιχτή επίσκεψη ΑΛΛΟΥ ασθενή στο e-prescription — δεν έγινε τίποτα" };
    let vs = (av.ok && av.amka === amka) ? { ok: true, reuse: true, visit: av.id } : await page(tab.id, "visit", { amka, reason: S.reason, noBanner: !!av.none });
    mk(vs.reuse ? "επίσκεψη (ήδη ανοιχτή)" : "νέα επίσκεψη");
    const a2u = async (a2) => { if (a2.ok || a2.none) return a2; const st2 = await page(tab.id, "state"); if (!(st2 && st2.unit)) return a2; const u2 = await page(tab.id, "unit", { unit: S.unit || "" }); mk("μονάδα (στον έλεγχο επίσκεψης)"); if (u2.err) return a2; await H.sleep(1200); return actv(); };   // 7/11: «Μονάδα Συνταγογράφησης» στη μέση → επιλογή και ξανά
    if (!vs.err) { let a2 = await a2u(await actv()); for (let i = 0; i < 8 && !(a2.ok && a2.amka === amka); i++) { await H.sleep(1500); a2 = await a2u(await epActive(tab.id)); }
      if (!(a2.ok && a2.amka === amka)) vs = { err: "δεν επιβεβαιώθηκε ότι η ενεργή επίσκεψη είναι αυτού του ασθενή — σταμάτησε" }; }
    if (vs.err) return { status: "failed", note: "επίσκεψη: " + mask(vs.err) + (await pmsg(vs)) };
    // 5) «Νέο Παραπεμπτικό»: ΠΛΗΡΗΣ φόρτωση (η σελίδα να έχει την επίσκεψη, #565)· αλλιώς ενεργή επίσκεψη → «Ενέργειες Επίσκεψης»
    const vNote = ` — το παραπεμπτικό ΔΕΝ καταχωρίστηκε (η επίσκεψη ${vs.reuse ? "ήταν ήδη ανοιχτή" : "άνοιξε"})`;
    const load = async (url) => { await chrome.tabs.update(tab.id, { url }).catch(() => {}); for (let i = 0; i < 30; i++) { await H.sleep(500); const s2 = await page(tab.id, "state"); if (!s2.err && !s2.loading) break; } await H.sleep(1500); };
    // μετά από φόρτωση το «αυτί» θέλει λίγο για τα κλειδιά ({skip}) → έως ~6″
    const sameAmka = async () => { for (let i = 0; i < 6; i++) { const x = await epActive(tab.id); if (x.ok) return x.amka === amka; if (x.none) return false; await H.sleep(1000); } return false; };
    // ο οδηγός ανοιχτός → κλείσιμο (χωρίς καταχώριση) και σφάλμα
    let wizOpen = false, finishing = false;
    const fail = async (where, r) => { const c = await page(tab.id, "refCancel"); wizOpen = false; return { status: "failed", noRetry: !!(r.cands || /ασαφής|δεν βρέθηκε|δεν υπάρχει στη λίστα/.test(r.err || "")), note: `${where}: ${mask(r.err)}` + (await pmsg(r)) + vNote + (c && c.ok && !c.left ? " · ο οδηγός έκλεισε" : ""), result: { step: where, r: JSON.parse(JSON.stringify(r || {}, (k, v) => typeof v === "string" ? mask(v).slice(0, 1500) : v)) } }; };
    mk("νέο παραπεμπτικό");
    await load(EP_HOST + "/epres/referrals/create");
    if (!(await sameAmka())) return { status: "failed", note: "η ενεργή επίσκεψη δεν επιβεβαιώθηκε για αυτόν τον ΑΜΚΑ — σταμάτησε" + vNote };
    let r, catGot = "", assoc = null;
    const added = [], notes = [];
    // 🧹 φάση οδηγού: σε ΟΠΟΙΟΔΗΠΟΤΕ σφάλμα/διακοπή → «refCancel» (κλείσιμο χωρίς καταχώριση)· ΟΧΙ μετά από επιτυχή «Ολοκλήρωση»
    try {
    r = await page(tab.id, "refOpen");
    if (r.err) {
      mk("νέο παραπεμπτικό από την επίσκεψη");
      await load(EP_HOST + "/epres/visits/active/update");
      if (!(await sameAmka())) return { status: "failed", note: "η ενεργή επίσκεψη δεν επιβεβαιώθηκε για αυτόν τον ΑΜΚΑ — σταμάτησε" + vNote };
      const nv = await page(tab.id, "refNav"); if (nv.err) return { status: "failed", note: "παραπεμπτικό: " + mask(nv.err) + vNote };
      await H.sleep(1500);
      r = await page(tab.id, "refOpen");
      if (r.err) return { status: "failed", note: "παραπεμπτικό: " + mask(r.err) + vNote };
    }
    wizOpen = true;
    if (!(await sameAmka())) return await fail("παραπεμπτικό", { err: "η ενεργή επίσκεψη άλλαξε" });
    r = await page(tab.id, "refBasic", { cat, catKey: cat, just, remarks }); mk("βασικές πληροφορίες");
    if (r.err) return await fail("κατηγορία/αιτιολογία", r);
    catGot = String(r.cat || "").trim();   // ό,τι ΔΕΙΧΝΕΙ το πεδίο (όχι ό,τι ζητήθηκε)
    if (!catGot || /^Επιλέξτε/.test(catGot)) return await fail("κατηγορία", { err: "το πεδίο κατηγορίας δεν δείχνει επιλογή" });
    r = await page(tab.id, "refNext");
    if (r.err) return await fail("βήμα «Διαγνώσεις»", r);
    if (!(r.b || []).some((b) => /Αναζήτηση ICD10/.test(b))) return await fail("βήμα «Διαγνώσεις»", { err: "ο οδηγός δεν έφτασε στις διαγνώσεις" });
    for (const code of icds) { r = await page(tab.id, "icd", { code, ref: true }); if (r.err && !/δεν υπάρχει στη λίστα|έκλεισε/.test(r.err)) { mk("ICD " + code + ": 2η προσπάθεια (" + String(r.err).slice(0, 160) + ")"); await H.sleep(800); r = await page(tab.id, "icd", { code, ref: true }); } if (r.err) return await fail("διάγνωση", r); mk("ICD " + code); }
    r = await page(tab.id, "refNext");
    if (r.err) return await fail("βήμα «Εξετάσεις»", r);
    if (!(r.b || []).some((b) => /Εισαγωγή Εξετάσεων/.test(b))) return await fail("βήμα «Εξετάσεις»", { err: "ο οδηγός δεν έφτασε στις εξετάσεις" });
    for (const ex of exams) {   // μία κλήση ανά εξέταση (όριο χρόνου ανά κλήση)
      r = await page(tab.id, "refExams", { exams: [ex], qty: 1 }); mk("εξέταση " + ex.slice(0, 18));
      if (r.err) return await fail("εξέταση «" + ex + "»", r);
      (r.added || []).forEach((x) => added.push(x)); (r.notes || []).forEach((n) => notes.push(n));
    }
    assoc = await page(tab.id, "refAssoc", { icd: icds[0], reason: String(p.reason || "").trim().slice(0, 200) }); mk("συσχέτιση");
    if (assoc.err) return await fail("συσχέτιση", assoc);
    finishing = true;
    r = await page(tab.id, "refFinish"); mk("ολοκλήρωση");
    if (r.err) { finishing = false; return await fail("ολοκλήρωση", r); }
    wizOpen = false;
    (r.notes || []).forEach((n) => notes.push(n));
    } finally {
      if (wizOpen && !finishing) await pageRaw(tab.id, "refCancel").catch(() => {});
    }
    const sm = await page(tab.id, "refSummary");
    const secs = Math.round((Date.now() - t0) / 1000);
    const exT = added.map((x) => x.got + (x.got !== x.want ? " (← " + x.want + ")" : "")).join(", ");
    const head = `${exT} · ICD ${icds.join(", ")} · ${catGot}` + fvNote(fv) + (doctor ? ` · λογαριασμός: ${doctor}` : "") + (vs.reuse ? " · ήδη ανοιχτή επίσκεψη" : " · νέα επίσκεψη") + ` · ${secs}″`;
    // 📱 «Καταχώριση» ΜΟΝΟ από το κινητό (approve kind ref) — ΠΟΤΕ αυτόματα
    const meId = (await epMe(tab.id, 2)).id || "";
    const canPhone = !!(sm && sm.ok && sm.hasSubmit && sm.text && sm.full && meId);
    if (canPhone) await chrome.storage.local.set({ efbotRefOpen: { jobId: job.id, tabId: tab.id, sig: sm.full, at: Date.now() } });
    return {
      status: canPhone ? "review" : "done",
      note: (canPhone ? "📋 για έλεγχο στο κινητό (ΟΧΙ καταχωρισμένο): " : "📋 έτοιμο για έλεγχο στον υπολογιστή (ΟΧΙ καταχωρισμένο · δεν βρέθηκε η σύνοψη για το κινητό): ") + head,
      result: { kind: "ref", summary: mask(sm?.text || ""), pgHdr: mask(sm?.hdr || ""), icdPage: sm?.icdPage || "", sig: sm?.full || "", notes: notes.map(mask).slice(0, 6), at: Date.now(), tabId: tab.id, amka, meId, path: sm?.path || "", cat: catGot, catAsked: cat, exams: added, icds, doctor,
        assoc: { dx: mask(assoc.dx || ""), reason: assoc.reason || "", reasonAuto: !!assoc.reasonAuto, dxList: (assoc.dxList || []).map(mask), reasonList: assoc.reasonList || [], perRow: (assoc.perRow || []).map((x) => ({ ...x, val: mask(x.val || "") })), unset: assoc.unset || [], rows: (assoc.rows || []).map((x) => ({ exam: x.exam, dx: mask(x.dx), reason: x.reason })) }, filledAt: Date.now() },
      push: canPhone ? ["📋 Παραπεμπτικό για έλεγχο", `${job.name}: ${exT} — ανοίξτε το Παραδόχαρτο και πατήστε «Καταχώριση»`] : ["📋 Παραπεμπτικό έτοιμο για έλεγχο", `${job.name}: στο e-prescription του υπολογιστή — ελέγξτε και πατήστε «Καταχώριση»`],
    };
  }

  // ✅ Έγκριση από το κινητό: ΜΟΝΟ αφού ο γιατρός είδε τη σύνοψη. Έλεγχοι πριν την «Καταχώριση»: ίδια καρτέλα, ίδιος
  // λογαριασμός, ενεργή επίσκεψη του ΙΔΙΟΥ ΑΜΚΑ, η σύνοψη στη σελίδα ΙΔΙΑ με αυτή που είδε. Άγνωστο παράθυρο → 2η έγκριση.
  // kind "ref": ίδιοι έλεγχοι για το παραπεμπτικό (σύνοψη refSummary, κλειδί efbotRefOpen, ίδια σελίδα)
  async function approve(job, kind) {
    const isRef = kind === "ref";
    const K = isRef ? { op: "refSummary", key: "efbotRefOpen", gen: "του παραπεμπτικού", nom: "το παραπεμπτικό", acc: "το παραπεμπτικό", list: "στα Παραπεμπτικά της επίσκεψης", Cap: "Παραπεμπτικό" }
      : { op: "summary", key: "efbotRxOpen", gen: "της συνταγής", nom: "η συνταγή", acc: "τη συνταγή", list: "στις Συνταγές της επίσκεψης", Cap: "Συνταγή" };
    const r = (job.payload || {}).result || {};
    const keep = (x) => ({ ...r, ...x });
    if (!r.tabId || !r.amka) return { status: "failed", note: "λείπουν στοιχεία " + K.gen + " — καταχωρίστε από τον υπολογιστή" };
    const t = await chrome.tabs.get(r.tabId).catch(() => null);
    if (!t || !/e-prescription\.gr/.test(t.url || "")) return { status: "failed", note: "η καρτέλα του e-prescription έκλεισε — " + K.nom + " ΔΕΝ καταχωρίστηκε" };
    if (!r.meId) return { status: "failed", note: "δεν είναι γνωστός ο λογαριασμός " + K.gen + " — καταχωρίστε από τον υπολογιστή" };
    { const me = await epMe(r.tabId, 3); if (!me.ok || me.id !== r.meId) return { status: "failed", note: "άλλαξε ο λογαριασμός στο e-prescription — ΔΕΝ καταχωρίστηκε" }; }
    const av = await epActive(r.tabId);
    if (!(av.ok && av.amka === r.amka)) return { status: "failed", note: "η ενεργή επίσκεψη δεν είναι πια αυτού του ασθενή — ΔΕΝ καταχωρίστηκε" };
    let x;
    if (r.stage === "dlg") {
      if (!r.dlg || !r.dlgBtn) return { status: "approved", note: "⚠ το μήνυμα του e-prescription δεν έχει κουμπί συνέχειας — ΔΕΝ ξέρουμε αν καταχωρίστηκε· ελέγξτε στον υπολογιστή ΠΡΙΝ ξαναστείλετε", result: keep({ stage: "unsure" }) };
      if (self.efDeadJobs && self.efDeadJobs.has(job.id)) return { status: "failed", note: "⏱ η έγκριση έληξε πριν το πάτημα — ΔΕΝ πατήθηκε «Καταχώριση»" }; // ⛔ έληξε η έγκριση (2′) → ΚΑΝΕΝΑ πάτημα
      x = await pageRaw(r.tabId, "submit2", { dlg: r.dlg, btn: r.dlgBtn });
      if (x.changed) return { status: "review", note: "⚠ το μήνυμα του e-prescription άλλαξε — δείτε το ξανά", result: keep({ stage: "dlg", dlg: x.changed.dlg, dlgBtn: (x.changed.btns || []).find((b) => !/^(Άκυρο|Ακύρωση|Κλείσιμο|Όχι)$/i.test(b)) || "", dlgBtns: x.changed.btns }) };
    } else {
      const sm = await pageRaw(r.tabId, K.op);
      if (!sm || !sm.ok || !sm.hasSubmit) return { status: "failed", note: "η σελίδα δεν δείχνει πια " + K.acc + " με «Καταχώριση» — ελέγξτε στον υπολογιστή" };
      if (isRef && (!r.path || sm.path !== r.path)) return { status: "failed", note: "η σελίδα του παραπεμπτικού άλλαξε (" + String(sm.path || "?").replace(/\d{3,}/g, "#") + ") — ΔΕΝ καταχωρίστηκε· ελέγξτε στον υπολογιστή" };
      if (!r.sig || sm.full !== r.sig) return { status: "review", note: "⚠ " + K.nom + " στη σελίδα άλλαξε — δείτε τη νέα σύνοψη πριν την καταχώριση", result: keep({ summary: mask(sm.text), pgHdr: mask(sm.hdr || ""), icdPage: sm.icdPage || "", sig: sm.full, at: Date.now(), ...(isRef ? { exams: [], assoc: null, changed: true } : {}) }) };
      if (self.efDeadJobs && self.efDeadJobs.has(job.id)) return { status: "failed", note: "⏱ η έγκριση έληξε πριν το πάτημα — ΔΕΝ πατήθηκε «Καταχώριση»" }; 
      x = await pageRaw(r.tabId, "submit");
    }
    // σφάλμα ΠΡΙΝ το πάτημα → τίποτα δεν έγινε· οποιοδήποτε άλλο σφάλμα (η σελίδα δεν απάντησε κ.λπ.) → ΙΣΩΣ καταχωρίστηκε
    if (x.err && x.pre) return { status: "failed", note: "καταχώριση: " + mask(x.err) + " — ΔΕΝ πατήθηκε τίποτα· ελέγξτε στον υπολογιστή" };
    if (x.err) { await chrome.storage.local.remove(K.key); return { status: "approved", note: "⚠ πατήθηκε «Καταχώριση» αλλά η σελίδα δεν απάντησε (" + mask(x.err).slice(0, 80) + ") — ΔΕΝ ξέρουμε αν καταχωρίστηκε· ελέγξτε " + K.list + " ΠΡΙΝ ξαναστείλετε", result: keep({ stage: "unsure" }) }; }
    const okSig = (x.succ || (x.barcode && !x.neg)) && !x.login;
    const done = okSig && !x.still;
    // μήνυμα επιτυχίας αλλά η σελίδα δείχνει ακόμα «Καταχώριση» από κάτω: ΠΟΤΕ «δεν καταχωρίστηκε»/2η έγκριση (→ διπλή συνταγή)
    if (okSig && !done) { await chrome.storage.local.remove(K.key); return { status: "approved", note: "✅ πιθανώς καταχωρίστηκε (μήνυμα επιτυχίας" + (x.barcode ? " · barcode " + x.barcode : "") + ") — επιβεβαιώστε " + K.list + " ΠΡΙΝ ξαναστείλετε" + (x.dlg ? " · «" + mask(x.dlg).slice(0, 140) + "»" : ""), result: keep({ stage: "unsure", barcode: x.barcode }) }; }
    if (done || !x.dlg) await chrome.storage.local.remove(K.key);
    if (x.login) return { status: "approved", note: "⚠ μετά την «Καταχώριση» το e-prescription ζήτησε σύνδεση — ΔΕΝ ξέρουμε αν καταχωρίστηκε· ελέγξτε " + K.list + " ΠΡΙΝ ξαναστείλετε", result: keep({ stage: "unsure" }) };
    if (done) return { status: "approved", note: "✅ καταχωρίστηκε" + (x.barcode ? " · barcode " + x.barcode : "") + (x.dlg ? " · «" + mask(x.dlg).slice(0, 160) + "»" : ""), result: keep({ stage: "done", barcode: x.barcode, after: { path: x.path, dlg: mask(x.dlg || ""), msg: mask(x.msg || "") } }), push: ["✅ " + K.Cap + " καταχωρίστηκε", (job.name || "") + (x.barcode ? " · " + x.barcode : "")] };
    if (x.dlg && !done) {   // άγνωστο μήνυμα μετά την «Καταχώριση» → ο γιατρός το βλέπει στο κινητό (2η έγκριση) — τίποτα δεν πατιέται μόνο του
      const go = (x.btns || []).find((b) => !/^(Άκυρο|Ακύρωση|Κλείσιμο|Όχι|Πίσω)$/i.test(b)) || "";
      return { status: "review", note: "⚠ το e-prescription ρωτά: «" + mask(x.dlg).slice(0, 200) + "»", result: keep({ stage: "dlg", dlg: x.dlg, dlgBtn: go, dlgBtns: x.btns }), push: ["⚠ " + K.Cap + ": ερώτηση e-prescription", (job.name || "") + " · " + mask(x.dlg).slice(0, 90)] };
    }
    return { status: "approved", note: "⚠ πατήθηκε «Καταχώριση», αλλά η καταχώριση ΔΕΝ επιβεβαιώνεται" + (x.msg ? " · «" + mask(x.msg).slice(0, 160) + "»" : "") + " — ελέγξτε στο e-prescription", result: keep({ stage: "unsure", after: { path: x.path, msg: mask(x.msg || "") } }) };
  }

  // 🔎 ΑΜΚΑ → όνομα (γενικό μενού συνταγογράφησης). ΜΟΝΟ αναζήτηση ασθενή: δεν ανοίγει επίσκεψη, δεν γράφει τίποτα.
  async function lookup(job, H) {
    const amka = String((job.payload || {}).amka || "");
    if (!/^\d{11}$/.test(amka)) return { status: "failed", note: "ο ΑΜΚΑ θέλει 11 ψηφία" };
    const lc = await loginCheck(H);
    if (!lc.ok) return { status: "failed", note: "e-prescription: " + lc.err };
    const { efbot } = await chrome.storage.local.get("efbot");
    const S = { ...DEF, ...(efbot?.settings?.epres || {}) };
    const fv = await freeVisits(await epTab(), H, { keep: amka, current: false, unit: S.unit || "", doctor: lc.doctor || "" });
    if (fv.err) return { status: "failed", note: "e-prescription: " + mask(fv.err) + fvNote(fv) };
    const pt = await page((await epTab()).id, "patient", { amka });
    if (pt.err) return { status: "failed", note: "e-prescription: " + mask(pt.err) + fvNote(fv) };
    if (!String(pt.card || "").includes(amka)) return { status: "failed", note: "δεν βρέθηκε ασθενής με αυτόν τον ΑΜΚΑ" };
    // όνομα: τα κεφαλαία ελληνικά/λατινικά πριν από τον ΑΜΚΑ ή τις ετικέτες της κάρτας
    const card = String(pt.card).replace(/\s+/g, " ");
    const m = card.match(/([Α-ΩΆ-ΏA-Z][Α-ΩΆ-ΏA-Z'\-]+(?:\s+[Α-ΩΆ-ΏA-Z][Α-ΩΆ-ΏA-Z'\-]+){1,3})/);
    const name = m ? m[1].trim() : "";
    return { status: "done", note: "🔎 " + (name || "βρέθηκε ασθενής") + (pt.ayli ? " · έχει άυλη" : " · χωρίς άυλη") + fvNote(fv), result: { name, card: mask(card).slice(0, 400), ayli: !!pt.ayli, doctor: lc.doctor || "" } };
  }

  // 🔑 Έλεγχος σύνδεσης (για την εντολή «Έλεγχος συνδέσεων»): ανοίγει/βρίσκει την καρτέλα, και αν ζητά σύνδεση
  // δοκιμάζει τους αποθηκευμένους λογαριασμούς. Δεν αγγίζει ασθενή ούτε συνταγή.
  async function loginCheck(H) {
    const tab = await epTab();
    if (tab.err) return { ok: false, err: tab.err };
    let st = null;
    for (let i = 0; i < 40; i++) { st = await page(tab.id, "state"); if (st.err || st.login || st.unit || !st.loading) break; await H.sleep(250); }
    if (st?.err) return { ok: false, err: st.err };
    let who = "", how = "ήταν ήδη συνδεδεμένο";
    if (st?.login) {
      const lg = H.epresAutoLogin ? await H.epresAutoLogin(tab.id, "") : { ok: false, err: "ζητά σύνδεση" };
      if (!lg.ok) return { ok: false, err: lg.err };
      who = lg.who || ""; how = "μπήκε με αποθηκευμένο λογαριασμό" + (who ? " (" + who + ")" : "");
      if (lg.who) await epIdLearn(tab.id, lg.who).catch(() => {});
      for (let i = 0; i < 40; i++) { st = await page(tab.id, "state"); if (st.err || st.unit || !st.loading) break; await H.sleep(250); }
    }
    if (st?.login) return { ok: false, err: "ζητά ακόμα σύνδεση" };
    if (st?.unit) { const u = await page(tab.id, "unit", {}); if (u.err) return { ok: false, err: u.err }; }
    return { ok: true, how, doctor: st?.doctor || who };
  }

  // 🗺 χαρτογράφηση σελίδας παραπεμπτικών (μόνο ανάγνωση) — για να μάθει το bot τη ροή πριν τη γράψει
  async function map(job, H) {
    const lc = await loginCheck(H);
    if (!lc.ok) return { status: "failed", note: "e-prescription: " + lc.err };
    const id = (await epTab()).id, out = {};
    out.home = await page(id, "map", { step: "links" });
    // 🔎 μία συγκεκριμένη σελίδα (payload.href) — ΜΟΝΟ ανάγνωση: κουμπιά, πεδία, κείμενο, διάλογοι
    if ((job.payload || {}).href) {
      const href = job.payload.href;
      let r = await page(id, "map", { step: "go", href, direct: true });
      if (r && r.nav) { await H.sleep(2500); r = await page(id, "map", { step: "go", href }); }
      return { status: "done", note: "🔎 " + href + ": " + (r && r.err ? "✗ " + r.err : "σελίδα " + (r && r.path) + " · κουμπιά: " + ((r && r.b) || []).join(" | ") + ((r && r.dlg && r.dlg.length) ? " · διάλογος: " + r.dlg.map((d) => d.text).join(" / ").slice(0, 300) : "")), result: { home: out.home, page: r } };
    }
    const refs = ((out.home && out.home.links) || []).filter((x) => /παραπεμπ|referr|εξετ|exam/i.test(x.t + " " + x.h)).slice(0, 4);
    out.pages = [];
    for (const l of refs) { if (!/^\//.test(l.h)) continue; out.pages.push({ link: l, r: await page(id, "map", { step: "go", href: l.h }) }); }
    const newBtn = (job.payload || {}).press || "^\\+?\\s*Νέο\\s*Παραπεμπτικό$";
    // ΠΡΩΤΑ στη σελίδα «Νέο Παραπεμπτικό» (πριν πατούσε το κουμπί σε άλλη σελίδα → δεν το έβρισκε)
    if (out.pages.length) { await page(id, "map", { step: "go", href: "/epres/referrals/create" }); await H.sleep(1500); out.wizard = await page(id, "map", { step: "press", re: newBtn }); }
    await page(id, "map", { step: "go", href: "/epres/patient" }).catch(() => null);
    const n = refs.length;
    return { status: "done", note: "🗺 e-prescription: " + ((out.home && out.home.links) || []).length + " σύνδεσμοι · παραπεμπτικά: " + (n ? refs.map((x) => x.t).join(", ") : "δεν βρέθηκε σύνδεσμος"), result: out };
  }
  // 🗺 φόρμα ΠΑΡΑΠΕΜΠΤΙΚΟΥ μέσα σε επίσκεψη (μόνο ανάγνωση): ασθενής → επίσκεψη → «Νέο Παραπεμπτικό» → καταγραφή → «Ακύρωση».
  // ΠΟΤΕ Καταχώριση/Υποβολή. Η επίσκεψη μένει ανοιχτή (την κλείνει ο γιατρός).
  async function refmap(job, H) {
    const p = job.payload || {}, amka = String(p.amka || "").replace(/\D/g, "");
    if (!/^\d{11}$/.test(amka)) return { status: "failed", note: "χρειάζεται ΑΜΚΑ" };
    const { efbot } = await chrome.storage.local.get("efbot");
    const S = { ...DEF, ...(efbot?.settings?.epres || {}) };
    const lc = await loginCheck(H); if (!lc.ok) return { status: "failed", note: "e-prescription: " + lc.err };
    const tab = await epTab(); if (tab.err) return { status: "failed", note: tab.err };
    const note = (t) => { try { if (typeof imgNote === "function") imgNote(job.id, "⏳ " + t); } catch (e) {} };
    // ανοιχτές επισκέψεις άλλων ασθενών: ολοκληρώνονται όπως στη συνταγή (απόφαση χρήστη 3/11)
    note("έλεγχος ανοιχτών επισκέψεων");
    const fv = await freeVisits(tab, H, { keep: amka, current: true, unit: S.unit || "", doctor: lc.doctor || "" });
    if (fv.err) return { status: "failed", note: "e-prescription: " + mask(fv.err) + fvNote(fv) };
    // 🛡 ενεργή επίσκεψη ΑΛΛΟΥ ασθενή → ΣΤΟΠ (#566: η χαρτογράφηση μπήκε στην επίσκεψη του ΜΑΥΡΟΥΔΗ αντί του ΔΟΥΚΑ)
    const a0 = await epActiveFresh(tab.id, H);
    if (a0.ok && a0.amka && a0.amka !== amka) return { status: "failed", note: "υπάρχει ανοιχτή επίσκεψη ΑΛΛΟΥ ασθενή (ΑΜΚΑ ··" + a0.amka.slice(-2) + ") — δεν έγινε τίποτα" };
    if (!a0.ok && !a0.none) return { status: "failed", note: "δεν επιβεβαιώθηκε η ενεργή επίσκεψη (" + (a0.err || "χωρίς απάντηση") + ") — δεν έγινε τίποτα" };
    note("ασθενής");
    const pt = await patientPage(tab, H, amka, typeof mk === "function" ? mk : null); if (pt.err) return { status: "failed", note: "ασθενής: " + mask(pt.err) };
    if (!String(pt.card || "").includes(amka)) return { status: "failed", note: "άνοιξε άλλος ασθενής — σταμάτησα" };
    note("επίσκεψη");
    // ήδη ανοιχτή επίσκεψη ΙΔΙΟΥ ΑΜΚΑ (API) → χρήση της (η σελίδα κρύβει το «Νέα Επίσκεψη», #590) — όπως στη συνταγή
    const vs = (a0.ok && a0.amka === amka) ? { ok: true, reuse: true, visit: a0.id } : await page(tab.id, "visit", { amka, reason: S.reason, noBanner: !!a0.none }); if (vs.err) return { status: "failed", note: "επίσκεψη: " + mask(vs.err) };
    let a1 = await epActive(tab.id); for (let i = 0; i < 8 && !(a1.ok && a1.amka === amka); i++) { await H.sleep(1500); a1 = await epActive(tab.id); }
    if (!(a1.ok && a1.amka === amka)) return { status: "failed", note: "η ενεργή επίσκεψη δεν επιβεβαιώθηκε για αυτόν τον ΑΜΚΑ — σταμάτησα" };
    note("φόρμα παραπεμπτικού");
    const out = { visit: { reuse: !!vs.reuse } };
    out.visitPage = await page(tab.id, "map", { step: "links" });
    // η επίσκεψη επιβεβαιώθηκε (API) → ΠΛΗΡΗΣ φόρτωση της «Νέο Παραπεμπτικό» ώστε η σελίδα να έχει την επίσκεψη (#565: κενή σελίδα)
    note("ενεργή επίσκεψη → «Ενέργειες Επίσκεψης» → «Νέο Παραπεμπτικό»");
    await chrome.tabs.update(tab.id, { url: "https://www.e-prescription.gr/epres/visits/active/update" }).catch(() => {});
    for (let i = 0; i < 30; i++) { await H.sleep(500); const s2 = await page(tab.id, "state"); if (!s2.err && !s2.loading) break; }
    await H.sleep(2000);
    out.create = await page(tab.id, "map", { step: "links" });
    // ξανά: ΙΔΙΟΣ ασθενής πριν πατηθεί οτιδήποτε
    const a2 = await epActive(tab.id); if (!(a2.ok && a2.amka === amka)) return { status: "failed", note: "η ενεργή επίσκεψη άλλαξε — σταμάτησα", result: out };
    // «Νέο Παραπεμπτικό» είναι μέσα στο κουμπί-εικονίδιο «Eνέργειες Επίσκεψης» κάτω δεξιά (κώδικας εφαρμογής, #568)
    out.fab = await page(tab.id, "map", { step: "press", title: true, wait: 8000, re: "ν[εέ]ργειες\\s+Επίσκεψης", fill: false });
    // «Νέο Παραπεμπτικό» του μενού → σελίδα /referrals/create· εκεί το «+ Νέο Παραπεμπτικό» ανοίγει τον οδηγό (#570)
    out.nav = await page(tab.id, "map", { step: "press", wait: 8000, re: "^Νέο\\s*Παραπεμπτικό$", fill: false }); await H.sleep(2500);
    const a3 = await epActive(tab.id); if (!(a3.ok && a3.amka === amka)) return { status: "failed", note: "η ενεργή επίσκεψη άλλαξε — σταμάτησα", result: out };
    if (p.icd) {   // 📋 δομημένος δρόμος (σκελετός runner «ref»): Βασικές → ICD → Εξετάσεις (μόνο χάρτης) → Ακύρωση
      out.open = await page(tab.id, "refOpen");
      if (!out.open.err) out.basic = await page(tab.id, "refBasic", { cat: p.cat || "", catRe: p.pick || "", just: p.just || "" });
      if (out.basic && !out.basic.err) out.n1 = await page(tab.id, "refNext");
      if (out.n1 && !out.n1.err) for (const code of [].concat(p.icd)) { const r = await page(tab.id, "icd", { code, ref: true }); (out.icd = out.icd || []).push({ code, ...r }); if (r.err) break; }
      if (out.icd && !out.icd.some((x) => x.err)) out.n2 = await page(tab.id, "refNext");
      if (out.n2 && !out.n2.err) out.exam = await page(tab.id, "refExamMap", { q: p.q || "PSA" });
      out.cancel = await page(tab.id, "refCancel");
      const st = [out.open, out.basic, out.n1, ...(out.icd || []), out.n2].filter(Boolean), bad = st.find((x) => x.err);
      return { status: "done", note: "🗺 παραπεμπτικό (δομημένο): " + (bad ? "✗ " + bad.err : "✓ έφτασε στις «Εξετάσεις»") + " · κατηγορία: " + ((out.basic || {}).cat || "—") + " · " + (out.n2 ? "βήμα 3: " + String(out.n2.text || "").slice(0, 300) : "") + " · κλείσιμο χωρίς καταχώριση", result: out };
    }
    out.form = await page(tab.id, "map", { step: "press", wait: 8000, re: p.press || "^\\+\\s*Νέο\\s*Παραπεμπτικό$", fill: p.fill !== false, pick: p.pick || "", just: p.just || "" });
    await H.sleep(1500);
    out.after = await page(tab.id, "map", { step: "links" });
    const f = out.form || {}, nF = (f.f || []).length + ((f.dlg || [])[0] ? ((f.dlg[0].f || []).length) : 0);
    return { status: "done", note: "🗺 παραπεμπτικό: " + (f.err ? "✗ " + f.err : "σελίδα " + (f.path || "") + " · πεδία " + nF + " · κουμπιά: " + (f.b || []).slice(0, 14).join(" | ") + ((f.dlg && f.dlg.length) ? " · διάλογος: " + String(f.dlg[0].text || "").slice(0, 160) : "")) + " · βήματα οδηγού: " + (1 + ((f.steps || []).length)) + (f.reachedSubmit ? " (έφτασε ως την «Καταχώριση» — ΔΕΝ πατήθηκε)" : "") + " · λίστες: " + [...(f.lists0 || []), ...((f.steps || []).flatMap((x) => x.lists || []))].map((l) => (l.label || "?") + "×" + l.opts.length).join(", ") + " · η επίσκεψη έμεινε ανοιχτή (" + (vs.reuse ? "υπήρχε" : "νέα") + ")" + fvNote(fv), result: out };
  }
  // 🔌 ΒΗΜΑ 1 «απευθείας αιτήματα» (ΜΟΝΟ ανάγνωση): μπορεί το bot να καλέσει το API του e-prescription μέσα στη σύνδεση της καρτέλας;
  // Καμία τιμή κουπονιού/δεδομένων δεν φεύγει: μόνο κωδικός απάντησης, χρόνος, ονόματα πεδίων.
  async function apiprobe(job, H) {
    const lc = await loginCheck(H); if (!lc.ok) return { status: "failed", note: "e-prescription: " + lc.err };
    const tab = await epTab(); if (tab.err) return { status: "failed", note: tab.err };
    // το «αυτί» φορτώνει με τη σελίδα: αν η καρτέλα ήταν ανοιχτή από πριν, μία ανανέωση (μένει συνδεδεμένο) και αναμονή για τις πρώτες κλήσεις της
    const hookN = async () => { const [x] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: "MAIN", func: () => (window.__efEp ? window.__efEp.n : -1) }).catch(() => [{ result: -1 }]); return x ? x.result : -1; };
    if ((await hookN()) <= 0) { await chrome.tabs.reload(tab.id).catch(() => {}); for (let i = 0; i < 40; i++) { await H.sleep(500); if ((await hookN()) > 0) break; } }
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: "MAIN", func: async () => {
      const out = { tokKeys: [], tok: false, calls: [] };
      const JWT = /^eyJ[\w-]+\.[\w-]+\.[\w-]+$/;
      let tok = "", claims = [];
      // 1) ό,τι είδε το «αυτί» (epres-hook.js) από τις κλήσεις της ίδιας της εφαρμογής
      const EP = window.__efEp || null; out.hook = !!EP; out.hookN = EP ? EP.n : 0;
      if (EP && EP.h["x-authorization"]) { tok = EP.h["x-authorization"].replace(/^Bearer\s+/i, ""); out.tokKeys.push("hook"); }
      const scanVal = (k, v) => { try { if (JWT.test(v)) { out.tokKeys.push(k); if (!tok) tok = v; return; } const o = JSON.parse(v); const walk = (x, d) => { if (!x || d > 3 || typeof x !== "object") return; for (const [kk, vv] of Object.entries(x)) { if (typeof vv === "string" && JWT.test(vv) && /access/i.test(kk)) { out.tokKeys.push(k + "." + kk); if (!tok) tok = vv; } else walk(vv, d + 1); } }; walk(o, 0); } catch (e) {} };
      for (const S of [sessionStorage, localStorage]) for (let i = 0; i < S.length; i++) { const k = S.key(i); scanVal(k.slice(0, 40), S.getItem(k) || ""); }
      out.tok = !!tok;
      try { if (tok) claims = Object.keys(JSON.parse(atob(tok.split(".")[1].replace(/-/g, "+").replace(/_/g, "/")))); } catch (e) {}
      out.claims = claims.slice(0, 30);
      const call = async (path, tx) => { const t0 = performance.now(); try {
        const H0 = (window.__efEp && window.__efEp.h) || {};
        const hd = { "Accept": "application/json", "x-Authorization": "Bearer " + tok, "x-sender-code": H0["x-sender-code"] || "EPRESAPP", "x-webapp-version": H0["x-webapp-version"] || "1.0.30", "x-request-id": crypto.randomUUID(), "x-sender-transaction-code": tx };
        if (H0["x-sender-req-type"]) hd["x-sender-req-type"] = H0["x-sender-req-type"]; if (H0["x-sender-req-id"]) hd["x-sender-req-id"] = H0["x-sender-req-id"];
        const res = await (window.__efEpFetch || fetch)("/epres/api" + path, { credentials: "include", headers: hd });
        let keys = []; try { const j = await res.clone().json(); keys = Array.isArray(j) ? ["[" + j.length + "]"].concat(Object.keys(j[0] || {}).slice(0, 12)) : Object.keys(j || {}).slice(0, 15); } catch (e) {}
        return { path, status: res.status, ms: Math.round(performance.now() - t0), keys }; } catch (e) { return { path, err: String(e.message || e).slice(0, 120), ms: Math.round(performance.now() - t0) }; } };
      if (tok) { out.calls.push(await call("/doctor/visit/v1/active", "Doctor:Retrieve Active Visit")); out.calls.push(await call("/doctor/v1/units?isActive=true&sortBy=healthCareUnit.description&sortOrder=ASC", "Doctor:Retrieve Doctor Units")); }
      return out;
    } }).catch((e) => [{ result: { err: e.message } }]);
    const o = (r && r.result) || {};
    if (o.err) return { status: "failed", note: "🔌 " + o.err };
    const c = (o.calls || []).map((x) => x.path.split("?")[0].replace(/^\/doctor\//, "") + " → " + (x.err ? "✗ " + x.err : x.status + " σε " + x.ms + "ms")).join(" · ");
    return { status: o.tok && (o.calls || []).every((x) => x.status === 200 || x.status === 204) ? "done" : "failed", note: "🔌 API e-prescription: " + (o.tok ? "βρέθηκε σύνδεση (" + o.tokKeys.length + ") · " + c : "δεν βρέθηκε σύνδεση στη σελίδα"), result: o };
  }
  const refApprove = (job) => approve(job, "ref");
  // 👤 9/11→10/11: σύνδεση στο e-prescription ΩΣ συγκεκριμένος λογαριασμός (π.χ. ο γιατρός που έγραψε τη συνταγή, για ακύρωση).
  // Ίδια λογική με τη συνταγή: έλεγχος id (generate/me) ↔ id που έμαθε το bot· αλλιώς αποσύνδεση και είσοδος ΜΟΝΟ με αυτόν.
  async function asUser(epUser, H) {
    epUser = String(epUser || "").trim(); if (!epUser) return { err: "χωρίς λογαριασμό" };
    if (H.epresHasUser && !(await H.epresHasUser(epUser))) return { err: "ο λογαριασμός " + epUser + " δεν έχει μάθει σε αυτόν τον υπολογιστή" };
    const tab = await epTab(); if (tab.err) return { err: tab.err };
    let st = null; const t0 = Date.now();
    for (let i = 0; i < 60 && Date.now() - t0 < 30000; i++) { st = await page(tab.id, "state"); if (st.err || st.login || st.unit || !st.loading) break; await H.sleep(250); }
    if (!st || st.err) return { err: "η σελίδα του e-prescription δεν απαντά" };
    if (!st.login) {
      const known = (await epIdsGet())[epUser.toLowerCase()], me = await epMe(tab.id, 3);
      if (known && me.ok && me.id === known) return { tab, who: epUser, same: true, id: me.id };
      let lo; { const cr = await epCookieLogout(tab.id); if (cr.ok) lo = { ok: true }; else { lo = await page(tab.id, "logout"); if (lo.err) lo.err += " · " + cr.err; } }
      if (lo.err) return { err: "αλλαγή λογαριασμού — " + lo.err };
      for (let i = 0; i < 60; i++) { await H.sleep(500); st = await page(tab.id, "state"); if (st.login || st.err) break; if (i === 12 && !st.loading) await page(tab.id, "logout"); }
      if (!st || !st.login) return { err: "δεν βγήκε ο προηγούμενος λογαριασμός" };
    }
    const lg = H.epresAutoLogin ? await H.epresAutoLogin(tab.id, "", { only: epUser }) : { ok: false, err: "ζητά σύνδεση" };
    if (!lg.ok) return { err: "δεν μπήκε ο " + epUser + " — " + String(lg.err || "").replace(/^🔑\s*e-prescription:\s*/, "") };
    if (lg.who && String(lg.who).toLowerCase() !== epUser.toLowerCase()) return { err: "μπήκε άλλος λογαριασμός (" + lg.who + ")" };
    await epIdLearn(tab.id, epUser);
    const me = await epMe(tab.id, 8);
    return { tab, who: epUser, id: me.ok ? me.id : "" };
  }
  // ✅ 10/11 (χρήστης): «Ολοκλήρωση επίσκεψης» από το κινητό μετά τη συνταγή/το παραπεμπτικό — ΜΟΝΟ αν η ενεργή επίσκεψη είναι αυτού του ασθενή
  async function visitClose(job, H) {
    const p = job.payload || {}, amka = String(p.amka || "").replace(/\D/g, "");
    if (!/^\d{11}$/.test(amka)) return { status: "failed", note: "χρειάζεται ΑΜΚΑ" };
    const tab = await epTab(); if (tab.err) return { status: "failed", note: tab.err };
    const av = await epActive(tab.id);
    if (av.none) return { status: "done", note: "✅ δεν υπάρχει ανοιχτή επίσκεψη (ήδη κλειστή)" };
    if (!av.ok) return { status: "failed", note: "δεν διαβάστηκε η ενεργή επίσκεψη" + (av.err ? ": " + mask(av.err) : av.skip ? " (η καρτέλα e-prescription δεν είναι συνδεδεμένη)" : "") };
    if (!av.amka) return { status: "done", note: "✅ δεν υπάρχει ανοιχτή επίσκεψη (ήδη κλειστή)" };
    if (av.amka !== amka) return { status: "failed", note: "η ανοιχτή επίσκεψη είναι άλλου ασθενή (··" + av.amka.slice(-2) + ") — δεν πειράχτηκε" };
    const page = async (...x) => pageRaw(...x);
    const c = await epCloseVisit(tab.id, page, {}, "", false);
    if (c && c.err) return { status: "failed", note: "ολοκλήρωση επίσκεψης: " + mask(c.err) };
    return { status: "done", note: "✅ ολοκληρώθηκε η επίσκεψη (··" + amka.slice(-2) + ")" + (c && (c.rx || c.ref) ? " · συνταγές " + (c.rx || 0) + " · παραπεμπτικά " + (c.ref || 0) : ""), push: ["✅ Ολοκληρώθηκε η επίσκεψη", (job.name || "") + " · e-prescription"] };
  }
  self.EFEpres = { run, visitClose, asUser, epMe, epIdsGet, approve, refRun, refApprove, lookup, loginCheck, map, refmap, apiprobe, epTab, EP_PAGE, cleanMeds, ICD_FIX, DEF };
})();
