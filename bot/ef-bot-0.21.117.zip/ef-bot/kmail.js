// 📧 8/11: αποστολή email από το Kerio Connect της κλινικής (JSON-RPC του webmail), για το «📷 Σάρωση προγράμματος».
// Καθαρός πελάτης: παίρνει fetch απ' έξω (στο bot: το fetch του service worker· στις δοκιμές: ψεύτικος server).
// Ροή: Session.login → (Session.whoAmI) → Folders.get → Contacts.get στους φακέλους επαφών → η ομάδα (λίστα διανομής)
// με το όνομα που δόθηκε → upload συνημμένου → Mails.create {send:true} → Session.logout.
// Ο κωδικός ΔΕΝ περνά από εδώ προς τα έξω· δεν γράφεται σε σημειώσεις/αποτελέσματα.
(function (root) {
  "use strict";
  const nz = (x) => String(x || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().replace(/[^A-ZΑ-Ω0-9@.]+/g, " ").trim();
  const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  function client(base, fetchFn) {
    base = String(base || "").replace(/\/+$/, "");
    let tok = "", n = 0;
    async function call(method, params) {
      const h = { "Content-Type": "application/json-rpc; charset=UTF-8", Accept: "application/json-rpc" };
      if (tok) h["X-Token"] = tok;
      const r = await fetchFn(base + "/webmail/api/jsonrpc/", { method: "POST", credentials: "include", headers: h, body: JSON.stringify({ jsonrpc: "2.0", id: ++n, method, params: params || {} }) });
      let j = null; try { j = await r.json(); } catch (e) {}
      if (!j) throw new Error(method + ": HTTP " + r.status);
      if (j.error) { const e = new Error(method + ": " + (j.error.message || j.error.code || "σφάλμα")); e.code = j.error.code; throw e; }
      return j.result || {};
    }
    async function login(user, pass) {
      const r = await call("Session.login", { userName: user, password: pass, application: { name: "Paradoxarto", vendor: "Urology", version: "1.0" } });
      tok = r.token || ""; if (!tok) throw new Error("Session.login: χωρίς token");
      return true;
    }
    async function upload(bytes, name, type) {
      const fd = new FormData();
      fd.append("newFile.bin", new Blob([bytes], { type: type || "application/octet-stream" }), name);
      const r = await fetchFn(base + "/webmail/api/jsonrpc/upload", { method: "POST", credentials: "include", headers: { "X-Token": tok }, body: fd });
      let j = null; try { j = await r.json(); } catch (e) {}
      if (!j || j.error) throw new Error("upload: " + ((j && j.error && j.error.message) || "HTTP " + r.status));
      const f = (j.result && (j.result.file || j.result)) || {};
      if (!f.id) throw new Error("upload: χωρίς id");
      return f;
    }
    async function logout() { try { await call("Session.logout", {}); } catch (e) {} tok = ""; }
    return { call, login, upload, logout, get token() { return tok; } };
  }

  const Q = (fields) => ({ fields, start: 0, limit: 1000, conditions: [], combining: "And", orderBy: [] });

  // όλοι οι φάκελοι επαφών (προσωπικοί + δημόσιοι)
  async function contactFolders(cli) {
    const out = [];
    for (const m of ["Folders.get", "Folders.getPublic"]) {
      try { const r = await cli.call(m, {}); for (const f of r.list || []) if (f && f.type === "FContact") out.push({ id: f.id, name: f.name || "", pub: m !== "Folders.get", sub: f.subType || "" }); } catch (e) {}
    }
    return out;
  }
  async function mailFolders(cli) { try { const r = await cli.call("Folders.get", {}); return (r.list || []).filter((f) => f && f.type === "FMail"); } catch (e) { return []; } }

  // Μέλη λίστας διανομής: διευθύνσεις μέσα στη λίστα· όσα είναι μόνο αναφορές (refId) ανοίγουν με Contacts.getById.
  async function membersOf(cli, dl) {
    const out = [], refs = [];
    for (const a of dl.emailAddresses || []) {
      if (a && EMAIL.test(String(a.address || "").trim())) out.push({ name: a.name || "", address: String(a.address).trim() });
      else if (a && a.refId) refs.push(a.refId);
    }
    if (refs.length) {
      try {
        const r = await cli.call("Contacts.getById", { ids: refs });
        for (const c of r.result || []) {
          const e = (c.emailAddresses || []).find((x) => x && x.preferred && EMAIL.test(x.address || "")) || (c.emailAddresses || []).find((x) => x && EMAIL.test(x.address || ""));
          if (e) out.push({ name: c.commonName || "", address: e.address.trim() });
        }
      } catch (e) {}
    }
    const seen = new Set(); return out.filter((x) => { const k = x.address.toLowerCase(); if (seen.has(k)) return false; seen.add(k); return true; });
  }

  // Ομάδα με όνομα (χωρίς τόνους/πεζά). Επιστρέφει {group, members, groups (ονόματα όλων των ομάδων), folders}.
  async function findGroup(cli, name) {
    const want = nz(name), folders = await contactFolders(cli), groups = [];
    let hit = null;
    if (folders.length) {
      let r = null; try { r = await cli.call("Contacts.get", { folderIds: folders.map((f) => f.id), query: Q(["id", "folderId", "type", "commonName", "emailAddresses"]) }); } catch (e) {}
      for (const c of (r && r.list) || []) {
        if (!c || c.type !== "ctDistributionList") continue;
        groups.push(c.commonName || "");
        if (!hit && nz(c.commonName) === want) hit = c;
      }
      if (!hit) for (const c of (r && r.list) || []) if (c && c.type === "ctDistributionList" && want && nz(c.commonName).includes(want)) { hit = c; break; }
    }
    return { group: hit ? hit.commonName : "", members: hit ? await membersOf(cli, hit) : [], groups, folders: folders.map((f) => f.name) };
  }

  async function whoAmI(cli) { try { const r = await cli.call("Session.whoAmI", {}); const u = r.userDetails || r; return { name: u.fullName || "", address: u.primaryEmailAddress || u.loginName || "" }; } catch (e) { return null; } }

  // Αποστολή. to: [{name,address}] · att: {bytes, name, type} (προαιρετικό) · dry: σύνδεση+εύρεση ομάδας ΧΩΡΙΣ αποστολή.
  async function send(cli, o) {
    const to = (o.to || []).filter((x) => x && EMAIL.test(x.address || ""));
    if (!to.length) throw new Error("χωρίς παραλήπτες");
    const atts = [];
    if (o.att && o.att.bytes) { const f = await cli.upload(o.att.bytes, o.att.name || "scan.pdf", o.att.type || "application/pdf"); atts.push({ id: f.id, name: o.att.name || f.name || "scan.pdf", contentType: o.att.type || "application/pdf" }); }
    const mf = await mailFolders(cli), drafts = mf.find((f) => f.subType === "FSubDrafts"), me = o.from || (await whoAmI(cli));
    const mail = { subject: String(o.subject || ""), to: to.map((x) => ({ name: x.name || "", address: x.address })), cc: [], bcc: [],
      displayableParts: [{ contentType: "ctTextPlain", content: String(o.text || "") }], attachments: atts, send: true };
    if (drafts) mail.folderId = drafts.id;
    if (me && me.address && EMAIL.test(me.address)) mail.from = { name: me.name || "", address: me.address };
    const r = await cli.call("Mails.create", { mails: [mail] });
    if (r.errors && r.errors.length) throw new Error("Mails.create: " + (r.errors[0].message || JSON.stringify(r.errors[0]).slice(0, 120)));
    return { ok: true, n: to.length, att: atts.length };
  }

  const api = { client, findGroup, membersOf, send, whoAmI, contactFolders, nz };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.kMail = api;
})(typeof self !== "undefined" ? self : this);
