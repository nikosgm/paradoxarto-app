// Λογική του πλευρικού πάνελ: ρύθμιση βημάτων, εκμάθηση, εκτέλεση, μαζική εκτέλεση, παρακολούθηση.
// Η εκτέλεση των βημάτων βρίσκεται στο engine.js (κοινή με το background).
const $ = (id) => document.getElementById(id);
const E = EFEngine;
const sleep = E.sleep;
const VERSION = 13;
const TYPES = {
  click: "Κλικ / επιλογή", fill: "Συμπλήρωση", choose: "Επιλογή από λίστα",
  read: "Ανάγνωση κειμένου", check: "Έλεγχος ασθενή", copy: "Αντιγραφή στο πρόχειρο",
  skipif: "Παράλειψη αν ήδη έγινε", goto: "Μετάβαση σε διεύθυνση", tab: "Μετάβαση σε καρτέλα", manual: "Χειροκίνητο", wait: "Αναμονή (ms)",
};
const NO_TARGET = ["wait", "copy", "tab", "goto"];

let state = { workflows: [], current: null, values: {} };
let aborted = false, manualResolve = null, pickingIdx = null;
let ctx = null; // τρέχουσα συνεδρία εκτέλεσης (βλ. makeCtx)

// ---------- Αποθήκευση ----------
async function load() {
  const s = (await chrome.storage.local.get("efbot")).efbot;
  state = s || { workflows: structuredClone(DEFAULT_WORKFLOWS), current: DEFAULT_WORKFLOWS[0].id, values: {}, ver: VERSION };
  if (!state.workflows.length) state.workflows = structuredClone(DEFAULT_WORKFLOWS);
  if ((state.ver || 1) < VERSION) await migrate();
  if (E.patchWorkflows(state)) await save();
  if (!wf()) state.current = state.workflows[0].id;
}
// Αναβάθμιση από την 0.1: προσθέτουμε τις νέες διαδικασίες. Όσα έχει ήδη «μάθει» ο χρήστης στις
// υπάρχουσες εργαστηριακές διαδικασίες (ίδια ονομασία βήματος) περνούν αυτόματα και στις νέες.
async function migrate() {
  const have = new Set(state.workflows.map((w) => w.id));
  const taught = new Map();
  for (const w of state.workflows) for (const s of w.steps) if (s.target && !taught.has(s.label)) taught.set(s.label, s.target);
  for (const d of DEFAULT_WORKFLOWS) {
    if (!d.since || d.since <= (state.ver || 1) || have.has(d.id)) continue;
    const c = structuredClone(d);
    for (const s of c.steps) if (!NO_TARGET.includes(s.type) && taught.has(s.label)) s.target = structuredClone(taught.get(s.label));
    state.workflows.push(c);
  }
  // 0.3: νέα βήματα στο Εξιτήριο (σημαδεμένα since: 3). Μπαίνουν πριν από το επόμενο γνωστό βήμα, χωρίς να πειράξουν όσα έχετε μάθει.
  const ex = state.workflows.find((w) => w.id === "exitirio");
  const dEx = DEFAULT_WORKFLOWS.find((w) => w.id === "exitirio");
  if (ex && dEx) {
    let anchor = ex.steps.length;
    for (const st of [...dEx.steps].reverse()) {
      const at = ex.steps.findIndex((x) => x.label === st.label);
      if (at >= 0) { anchor = at; continue; }
      if (st.type === "skipif" || st.since === 3) { ex.steps.splice(anchor, 0, structuredClone(st)); }
    }
    // Το πεδίο «Ημ/νία - ώρα Εξόδου» θέλει ημερομηνία και ώρα
    for (const st of ex.steps)
      if (st.label === "Ώρα: τώρα") {
        if (st.value === "{ώρα}") st.value = "{ημερομηνία} {ώρα}";
        if (st.fillValue === "{ώρα}") st.fillValue = "{ημερομηνία} {ώρα}";
      }
  }
  // 0.2.2 (ver 4): έτοιμα βήματα για το πραγματικό σύστημα (apps.e-ygeia.gov.gr), χωρίς 🎯.
  // Το Εξιτήριο αντικαθίσταται (η φόρμα είναι διαφορετική από ό,τι υποθέταμε). Το «Άνοιγμα ασθενή» μόνο αν δεν έχει μάθει τίποτα.
  if ((state.ver || 1) < 10) {
    for (const d of DEFAULT_WORKFLOWS.filter((x) => x.preset)) {
      const i = state.workflows.findIndex((w) => w.id === d.id);
      const fresh = structuredClone(d);
      if (i < 0) { state.workflows.push(fresh); continue; }
      const old = state.workflows[i];
      // Αντικαθιστούμε αν: Εξιτήριο από παλιά έκδοση (<4), ή τα βήματα είναι τα δικά μας έτοιμα, ή δεν έχει μάθει τίποτα
      const ours = old.steps.every((x) => !x.target || x.target.preset);
      if ((d.id === "exitirio" && (state.ver || 1) < 4) || ours) {
        state.workflows[i] = { ...fresh, name: old.name, collected: old.collected, oldSteps: old.oldSteps || old.steps };
      }
    }
  }
  state.ver = VERSION;
  await save();
}
const save = () => chrome.storage.local.set({ efbot: state });
// Το πάνελ κρατά αντίγραφο των ρυθμίσεων στη μνήμη. Αν τις αλλάξει κάποιος άλλος (το bot στο παρασκήνιο, ή πάνελ σε άλλο
// παράθυρο), το αντίγραφο ανανεώνεται αμέσως· αλλιώς η επόμενη «αποθήκευση» αυτού του πάνελ έγραφε από πάνω τις παλιές τιμές
// (γι' αυτό «χανόταν» π.χ. το «δικό του παράθυρο»).
chrome.storage.onChanged.addListener((ch, area) => {
  if (area !== "local" || !ch.efbot || !ch.efbot.newValue) return;
  const nv = ch.efbot.newValue;
  if (JSON.stringify(nv) === JSON.stringify(state)) return;
  const cur = state && state.current;
  state = nv;
  if (cur && (state.workflows || []).some((w) => w.id === cur)) state.current = cur;
  try { emrPassRender(); } catch (e) {}
});
const settings = () => {
  const st = (state.settings ||= { timeout: 30, delay: 0, busySel: "", busyOff: false, barPos: "bottom-right" });
  // Από 0.2.1 το bot περιμένει μόνο του να φύγει η «φόρτωση» μετά από κάθε κλικ· η σταθερή παύση μικραίνει
  if (!st.delayFix) { if (st.delay === 800) st.delay = 300; st.delayFix = 1; }
  // 0.5.5: το bot περιμένει μόνο του τη φόρτωση μετά από κάθε κλικ· η σταθερή παύση δεν χρειάζεται
  if (st.delayFix < 2) { if (st.delay === 300) st.delay = 0; st.delayFix = 2; }
  st.openerId ||= "anoigma";
  return st;
};
const wf = () => state.workflows.find((w) => w.id === state.current);
const curVals = (w) => (state.values[w.id] ||= { ...(w.defaults || {}) });

// ---------- Μεταβλητές ----------
// Το πεδίο «ασθενής» το γεμίζει η μαζική εκτέλεση· εμφανίζεται μόνο στις βοηθητικές διαδικασίες (για δοκιμή)
const shownVars = (w) => E.varsOf(w).filter((k) => k !== E.BULKVAR || w.hidden);
const missingVars = (w) =>
  shownVars(w).filter((x) => !(w.optionalVars || []).includes(x) && !(state.values[w.id] || {})[x]);
const pretty = (k) => k.replace(/_/g, " ").replace(/^./, (c) => c.toUpperCase());
const untaught = (w) =>
  w.steps.filter((s) => !s.disabled && !s.target && !["manual", "skipif", ...NO_TARGET].includes(s.type)).length;

// ---------- Καρτέλα στόχου ----------
async function targetTab() {
  let tabs = (await chrome.tabs.query({ active: true, lastFocusedWindow: true, windowType: "normal" })).filter(E.isWeb);
  if (!tabs.length) tabs = (await chrome.tabs.query({ active: true, windowType: "normal" })).filter(E.isWeb);
  if (!tabs.length) throw new Error("Δεν βρέθηκε ανοιχτή καρτέλα της εφαρμογής");
  return tabs[0];
}
async function copyText(text) {
  try { await navigator.clipboard.writeText(text); return; } catch (e) {}
  const ta = document.createElement("textarea");
  ta.value = text; document.body.appendChild(ta); ta.select();
  document.execCommand("copy"); ta.remove();
}

// ---------- Συνεδρία εκτέλεσης ----------
function log(text, cls = "", boxId = "log") {
  const d = document.createElement("div");
  d.className = cls; d.textContent = text;
  const box = $(boxId);
  box.appendChild(d);
  d.scrollIntoView({ block: "nearest" });
  return d;
}

function makeCtx(tabId, w, boxId = "log") {
  const c = {
    tabId, homeTabId: tabId, vars: {}, diag: [], wfName: w.name, t0: Date.now(), box: boxId,
    vals: () => ({ ...(state.values[w.id] || {}), ...c.vars }),
    settings, isAborted: () => aborted,
    log: (t, cls) => log(t, cls, boxId),
    heartbeat: () => E.lockTouch("ui"),
    manual: async (label, i) => {
      $("manualText").textContent = `${i + 1}. ${label}`;
      $("manual").style.display = "block";
      await new Promise((r) => (manualResolve = r));
      $("manual").style.display = "none";
      return !aborted;
    },
    copy: async (value, s) => {
      await copyText(value);
      if (s.collect) { (w.collected ||= []).push(value); save(); renderCollected(); renderBulkCol(); }
    },
  };
  lastCtx = c;
  for (const id of ["diagCopy", "bulkDiagCopy"]) $(id).style.display = "none";
  $(boxId === "bulkLog" ? "bulkDiagCopy" : "diagCopy").style.display = "";
  return c;
}

// ---------- Διάγνωση ----------
// Κείμενο για επικόλληση στη συνομιλία: βήματα, ρυθμίσεις, τι «έμαθε» κάθε βήμα και τι έγινε στην εκτέλεση.
// ΔΕΝ περιέχει: ονόματα, ΑΜΚΑ/ΑΜ, τιμές πεδίων, κείμενο των στοιχείων που μάθατε.
let lastCtx = null;
function diagText() {
  const c = lastCtx;
  if (!c) return "";
  const st = settings();
  const w = state.workflows.find((x) => x.name === c.wfName) || wf();
  const varOnly = (v) => (v ? String(v).replace(/[^{}]+(?=\{|$)/g, (m) => (m.trim() ? "…" : m)) : "");
  const L = [];
  L.push(`ef-bot ${chrome.runtime.getManifest().version} · μηχανή ${E.VERSION || "παλιά"} · ${new Date(c.t0).toLocaleString("el-GR")} · ${navigator.userAgent.match(/Chrome\/[\d.]+/)?.[0] || ""}`);
  L.push(`Ρυθμίσεις: αναμονή ${st.timeout}s · παύση ${st.delay}ms · φόρτωση ${st.busyOff ? "ΚΛΕΙΣΤΗ" : "ενεργή"}${st.busySel ? " +δικό CSS" : ""}`);
  L.push(`Διαδικασία: ${w?.name || "?"}`);
  for (const [i, s] of (w?.steps || []).entries()) {
    const t = s.target;
    L.push(`  ${i + 1}. [${s.type}${s.optional ? ",προαιρ." : ""}${s.disabled ? ",ΑΝΕΝΕΡΓΟ" : ""}${s.count ? ",παράλ." + s.count : ""}${s.each ? ",ανά γραμμή" : ""}] ${s.label}` +
      ` · τιμή:${varOnly(s.value) || "-"}` +
      ` · στόχος:${t ? `${t.tag}${(t.cls || []).map((x) => "." + x).join("")}${t.editable ? " (πεδίο)" : ""}${t.name || t.aria || t.placeholder ? " +όνομα" : ""}${t.text ? " +κείμενο" : ""} @${t.framePath || "?"}` : "ΔΕΝ ΕΧΕΙ ΜΑΘΕΙ"}`);
  }
  L.push("Εκτέλεση:");
  for (const d of c.diag) {
    const { t, ev, ...rest } = d;
    const kv = Object.entries(rest).filter(([k]) => k !== "label").map(([k, v]) => `${k}=${v}`).join(" ");
    L.push(`  +${((t - c.t0) / 1000).toFixed(1)}s ${ev}${d.label ? " «" + d.label + "»" : ""} ${kv}`);
  }
  return L.join("\n");
}
async function copyDiag(boxId) {
  const t = diagText();
  if (!t) return;
  await copyText(t);
  log("🩻 Η διάγνωση αντιγράφηκε. Επικολλήστε την (Ctrl+V) στη συνομιλία με το Claude.", "ok", boxId);
}
$("diagCopy").onclick = () => copyDiag("log");
$("bulkDiagCopy").onclick = () => copyDiag("bulkLog");

async function acquireUiLock(boxId) {
  const t0 = Date.now();
  let note = null;
  while (!(await E.lockAcquire("ui"))) {
    if (!note) note = log("⏳ Τρέχει έλεγχος παρακολούθησης, περιμένω…", "run", boxId);
    if (Date.now() - t0 > 3 * 60000 || aborted) { note.remove(); return false; }
    await sleep(2000);
  }
  note?.remove();
  return true;
}
function setBusy(b) {
  for (const id of ["go", "bulkGo"]) $(id).disabled = b;
  for (const id of ["stop", "bulkStop"]) $(id).disabled = !b;
}

// ---------- Εκτέλεση (ένας ασθενής) ----------
let launchNotes = []; // μηνύματα της εκκίνησης από το Παραδόχαρτο που πρέπει να μείνουν στο ημερολόγιο
async function run(fromIdx = 0) {
  const w = wf();
  aborted = false;
  if (!fromIdx) { $("log").innerHTML = ""; launchNotes.forEach(([t, c]) => log(t, c)); launchNotes = []; }
  $("retry")?.remove();
  setBusy(true);
  let items = E.plan(w, curVals(w));
  let resumeAt = null, locked = false, line = null;
  try {
    // Αν δόθηκε ασθενής (όνομα ή ΑΜ), ανοίγουμε πρώτα τον ασθενή με τη βοηθητική διαδικασία
    const who = String(curVals(w)[E.BULKVAR] || "").trim();
    if (who && !w.hidden) {
      const opener = state.workflows.find((x) => x.id === settings().openerId);
      if (!opener) throw new Error("Δεν βρέθηκε η διαδικασία «Άνοιγμα ασθενή»");
      const n = untaught(opener);
      if (n) throw new Error(`Η διαδικασία «${opener.name}» έχει ${n} βήματα που δεν έχουν «μάθει» (Ρύθμιση). Αλλιώς αφήστε κενό τον ασθενή και ανοίξτε τον εσείς.`);
      if (!opener.steps.some((s) => !s.disabled && s.type === "check" && s.target))
        throw new Error("Η διαδικασία «Άνοιγμα ασθενή» πρέπει να έχει ενεργό βήμα «Έλεγχος ασθενή».");
      const base = E.lineVars(E.BULKVAR, who);
      items = [
        ...E.plan(opener, curVals(w), base).map((it) => ({ ...it, tag: it.tag + " · άνοιγμα ασθενή" })),
        ...E.plan(w, curVals(w), base),
      ];
    }
    if (!fromIdx) {
      const missing = missingVars(w);
      if (missing.length) throw new Error("Συμπληρώστε: " + missing.map(pretty).join(", "));
      let tab = pendingTab ? await chrome.tabs.get(pendingTab).catch(() => null) : null;
      pendingTab = null;
      if (!tab) tab = await targetTab();
      ctx = makeCtx(tab.id, w);
    }
    locked = await acquireUiLock();
    if (!locked) throw new Error("Τρέχει έλεγχος παρακολούθησης. Δοκιμάστε ξανά σε λίγο.");
    let restarted = false;
    for (;;) try {
    await E.execPlan(ctx, items, {
      from: fromIdx,
      onStart: (it) => { line = log(`… ${it.i + 1}. ${it.s.label}${it.tag}`, "run"); },
      onDone: (it, _k, r) => {
        if (typeof r === "string" && r.startsWith("read:")) line.textContent = `✓ ${it.i + 1}. ${it.s.label}: ${r.slice(5)}`;
        else if (typeof r === "string" && r.startsWith("skipif:")) {
          const n = parseInt(r.slice(7)) || 0;
          line.textContent = n ? `⏭ ${it.i + 1}. ${it.s.label}: ήδη έγινε, παραλείφθηκαν ${n} βήματα` : `– ${it.i + 1}. ${it.s.label}: δεν έχει γίνει, συνεχίζω`;
          line.className = n ? "ok" : "";
          return;
        }
        else if (r === "skip") { line.textContent = `– ${it.i + 1}. ${it.s.label}${it.tag} (δεν εμφανίστηκε, παραλείφθηκε)`; line.className = ""; return; }
        else line.textContent = `✓ ${it.i + 1}. ${it.s.label}${it.tag}`;
        line.className = "ok";
      },
    });
    break;
    } catch (e) {
      if (!e.restart || restarted) throw e;
      restarted = true; fromIdx = 0; ctx.guard = null;
      log("↻ " + e.message + ". Ξαναρχίζω από την αρχή (αναζήτηση και έλεγχος ασθενή).", "run");
    }
    log("✅ Ολοκληρώθηκε. Ελέγξτε τα στοιχεία στον φάκελο και πατήστε εσείς Αποθήκευση.", "ok");
    if (ctx.misses?.length) log(`⚠ Δεν βρέθηκαν στη λίστα και παραλείφθηκαν: ${ctx.misses.join(", ")}. Προσθέστε τα με το χέρι αν χρειάζεται.`, "err");
    // Σβήνουμε τα στοιχεία του ασθενή ώστε να μη μεταφερθούν κατά λάθος στον επόμενο
    const keep = w.keep || [];
    state.values[w.id] = Object.fromEntries(Object.entries(curVals(w)).filter(([k]) => keep.includes(k)));
    save(); renderRun();
  } catch (e) {
    log(e.aborted ? "■ Διακόπηκε" : "✗ " + e.message, "err");
    resumeAt = e.k ?? fromIdx;
  } finally {
    if (resumeAt !== null && resumeAt < items.length) {
      const b = document.createElement("button");
      b.id = "retry"; b.className = "btn p"; b.style.marginTop = "8px";
      b.textContent = `↻ Συνέχεια από το βήμα ${items[resumeAt].i + 1}${items[resumeAt].tag.includes("άνοιγμα ασθενή") ? " (άνοιγμα ασθενή)" : ""}`;
      const at = resumeAt;
      b.onclick = () => run(at);
      $("log").appendChild(b);
    }
    if (locked) E.lockRelease("ui");
    setBusy(false);
    $("manual").style.display = "none";
  }
}

async function testStep(i) {
  aborted = false;
  $("log").innerHTML = "";
  const w = wf();
  const s = w.steps[i];
  try {
    const tab = await targetTab();
    const home = ctx?.homeTabId ?? tab.id;
    ctx = makeCtx(tab.id, w);
    ctx.homeTabId = home;
    const first = s.each ? String(curVals(w)[s.each] || "").split(/\r?\n/)[0].trim() : "";
    const extra = s.each ? E.lineVars(s.each, first) : {};
    const r = await E.runStep(ctx, s, i, extra);
    log(`✓ Δοκιμή βήματος ${i + 1} πέτυχε${typeof r === "string" && r.startsWith("read:") ? ": " + r.slice(5) : ""}`, "ok");
  } catch (e) { log(`✗ Βήμα ${i + 1}: ${e.message}`, "err"); }
  showTab("run");
}

// ---------- Μαζική εκτέλεση ----------
let bulk = { rows: [] };
const isOk = (r) => r.status === "ok";

function renderBulkRows() {
  const box = $("bulkRows");
  box.innerHTML = "";
  const icon = { wait: "○", run: "⏳", ok: "✓", fail: "✗", skip: "⊘" };
  for (const r of bulk.rows) {
    const d = document.createElement("div");
    d.className = "brow st-" + r.status;
    const k = document.createElement("span");
    k.className = "k";
    k.textContent = r.text;
    const note = r.status === "run" ? r.step : r.msg;
    if (note) { const sm = document.createElement("small"); sm.textContent = note; k.appendChild(sm); }
    const i = document.createElement("span");
    i.textContent = icon[r.status];
    d.append(i, k);
    box.appendChild(d);
    if (r.status === "run") d.scrollIntoView({ block: "nearest" });
  }
}
function bulkText() { return $("bulkList").value; }
const bulkSave = () => chrome.storage.session.set({ efbotBulk: bulkText() }).catch(() => {});

async function runBulk() {
  const w = wf();
  const opener = state.workflows.find((x) => x.id === settings().openerId);
  aborted = false;
  $("bulkLog").innerHTML = "";
  const rows = bulkText().split(/\r?\n/).map((x) => x.trim()).filter(Boolean)
    .map((text) => ({ text, status: "wait", msg: "", step: "" }));
  bulk.rows = rows; renderBulkRows();
  const L = (t, c) => log(t, c, "bulkLog");
  let locked = false;
  try {
    if (!rows.length) throw new Error("Η λίστα ασθενών είναι κενή");
    if (!opener) throw new Error("Επιλέξτε διαδικασία «Άνοιγμα ασθενή»");
    if (opener.id === w.id) throw new Error("Η διαδικασία «Άνοιγμα ασθενή» δεν μπορεί να είναι η ίδια με αυτήν που θα τρέξει. Αλλάξτε τη διαδικασία από το μενού πάνω δεξιά.");
    for (const x of [opener, w]) {
      const n = untaught(x);
      if (n) throw new Error(`Η διαδικασία «${x.name}» έχει ${n} βήματα που δεν έχουν «μάθει» ακόμα (καρτέλα Ρύθμιση).`);
    }
    // Ασφάλεια: χωρίς έλεγχο ασθενή δεν επιτρέπεται μαζική εκτέλεση
    if (!opener.steps.some((s) => !s.disabled && s.type === "check" && s.target))
      throw new Error("Η διαδικασία «Άνοιγμα ασθενή» πρέπει να έχει ενεργό βήμα «Έλεγχος ασθενή», ώστε να μη δουλέψει το bot σε λάθος ασθενή.");
    const missing = missingVars(w);
    if (missing.length) throw new Error("Συμπληρώστε στα πεδία: " + missing.map(pretty).join(", "));
    const tab = await targetTab();
    if (!confirm(`Θα τρέξει η διαδικασία «${w.name}» για ${rows.length} ασθενείς.\nΤο bot δεν πατά ποτέ Αποθήκευση/Υποβολή. Σε ανάλογα βήματα θα σας ζητήσει να το κάνετε εσείς.\n\nΣυνέχεια;`)) return;
    ctx = makeCtx(tab.id, w, "bulkLog");
    setBusy(true);
    locked = await acquireUiLock("bulkLog");
    if (!locked) throw new Error("Τρέχει έλεγχος παρακολούθησης. Δοκιμάστε ξανά σε λίγο.");
    let consecutiveFails = 0, stoppedWhy = "";
    for (const row of rows) {
      if (aborted) break;
      row.status = "run"; row.step = "ξεκινά…"; renderBulkRows();
      try {
        ctx.vars = {};
        await E.switchTab(ctx, "αρχική"); // κάθε ασθενής ξεκινά από την καρτέλα του φακέλου
        const base = E.lineVars(E.BULKVAR, row.text);
        const items = [...E.plan(opener, ctx.vals(), base), ...E.plan(w, ctx.vals(), base)];
        await E.execPlan(ctx, items, {
          onStart: (it, k) => { row.step = `${k + 1}/${items.length} · ${it.s.label}`; renderBulkRows(); },
        });
        row.status = "ok"; row.msg = ""; consecutiveFails = 0;
      } catch (e) {
        if (e.aborted) { row.status = "wait"; row.msg = "διακόπηκε"; break; }
        row.msg = e.message;
        if (e.mismatch) { row.status = "skip"; row.msg = "Παραλείφθηκε: " + e.message; }
        else { row.status = "fail"; consecutiveFails++; }
        // Δύο αποτυχίες στη σειρά: κάτι δεν πάει καλά με την οθόνη, δεν συνεχίζουμε στους υπόλοιπους
        if (consecutiveFails >= 2) { stoppedWhy = "Σταμάτησε μετά από 2 συνεχόμενες αποτυχίες. Ελέγξτε την οθόνη και ξαναπροσπαθήστε με τους υπόλοιπους."; break; }
      }
      renderBulkRows();
    }
    renderBulkRows();
    const n = (st) => rows.filter((r) => r.status === st).length;
    const left = rows.filter((r) => !isOk(r));
    L(`${aborted ? "■ Διακόπηκε. " : "Τέλος. "}✓ ${n("ok")}  ✗ ${n("fail")}  ⊘ ${n("skip")}  ○ ${n("wait")}`, n("fail") || n("skip") ? "err" : "ok");
    if (stoppedWhy) L(stoppedWhy, "err");
    // Στη λίστα μένουν μόνο όσοι δεν ολοκληρώθηκαν, για να ξαναδοκιμάσετε
    $("bulkList").value = left.map((r) => r.text).join("\n");
    bulkSave(); updateBulkInfo();
    if (rows.some(isOk) && w.steps.some((s) => s.type === "copy" && s.collect)) L("Ο πίνακας είναι έτοιμος παρακάτω: πατήστε «Αντιγραφή όλων».", "ok");
  } catch (e) {
    L("✗ " + e.message, "err");
  } finally {
    if (locked) E.lockRelease("ui");
    setBusy(false);
    $("manual").style.display = "none";
  }
}
function updateBulkInfo() {
  const n = bulkText().split(/\r?\n/).filter((x) => x.trim()).length;
  $("bulkInfo").textContent = n ? `${n} ασθενείς στη λίστα.` : "";
}

// ---------- Εκμάθηση ----------
async function pick(i) {
  pickingIdx = i;
  renderSetup();
  await chrome.storage.local.set({ efbotPicking: { stepId: i, ts: Date.now() } });
}
chrome.runtime.onMessage.addListener(async (msg) => {
  if (msg.type === "picked" && pickingIdx === "menu") {
    pickingIdx = null;
    await chrome.storage.local.remove("efbotPicking");
    const host = msg.desc.host;
    const { efbotMenu, efbotHosts } = await chrome.storage.local.get(["efbotMenu", "efbotHosts"]);
    const menu = efbotMenu || {};
    menu[host] = { target: msg.desc };
    const hosts = efbotHosts || [];
    if (!hosts.includes(host)) hosts.push(host);
    await chrome.storage.local.set({ efbotMenu: menu, efbotHosts: hosts });
    renderGeneral();
    return;
  }
  if (msg.type === "picked" && pickingIdx !== null) {
    const s = wf().steps[pickingIdx];
    s.target = msg.desc;
    // Αν το στοιχείο είναι πεδίο κειμένου, το βήμα γίνεται «Συμπλήρωση»
    if (s.type === "click" && msg.desc.editable) {
      s.type = "fill";
      if (!s.value) s.value = s.fillValue || "";
    }
    pickingIdx = null;
    chrome.storage.local.remove("efbotPicking");
    save(); renderSetup(); renderRun();
  }
  if (msg.type === "pickCancel") {
    pickingIdx = null; chrome.storage.local.remove("efbotPicking");
    renderSetup(); $("menuInfo") && renderGeneral();
  }
});

// ---------- Εμφάνιση ----------
function renderWfSelect() {
  $("wf").innerHTML = "";
  for (const w of state.workflows) $("wf").add(new Option(w.name, w.id, false, w.id === state.current));
}

function renderForm(box, w, withPatient = false) {
  const vals = curVals(w);
  box.innerHTML = "";
  for (const k of shownVars(w)) {
    const lab = document.createElement("label");
    lab.textContent = pretty(k);
    const isList = w.steps.some((s) => s.each === k);
    const long = isList || /κείμενο|σημείωσ|ιστορικ|text/i.test(k);
    const inp = document.createElement(long ? "textarea" : "input");
    if (!long) inp.type = "text";
    inp.value = vals[k] || "";
    inp.dataset.var = k;
    if (isList) inp.placeholder = "μία ανά γραμμή";
    inp.oninput = () => { vals[k] = inp.value; save(); };
    box.append(lab, inp);
  }
  if (withPatient && !w.hidden) {
    const lab = document.createElement("label");
    lab.textContent = "Ασθενής (προαιρετικό)";
    const inp = document.createElement("input");
    inp.type = "text"; inp.dataset.var = E.BULKVAR;
    inp.placeholder = "όνομα ή ΑΜ· κενό = ο ασθενής που έχετε ήδη ανοίξει";
    inp.value = vals[E.BULKVAR] || "";
    inp.oninput = () => { vals[E.BULKVAR] = inp.value; save(); };
    box.prepend(lab, inp);
    const h = document.createElement("div");
    h.className = "hint";
    h.textContent = "Αν το συμπληρώσετε, το bot ανοίγει πρώτα τον ασθενή (διαδικασία «Άνοιγμα ασθενή») και ελέγχει ότι άνοιξε ο σωστός.";
    lab.after(inp); inp.after(h);
  }
  const n = untaught(w);
  if (n) {
    const d = document.createElement("div");
    d.className = "note";
    d.textContent = `⚠ ${n} βήματα δεν έχουν «μάθει» ακόμα πού να πατήσουν. Πηγαίνετε στη Ρύθμιση.`;
    box.prepend(d);
  }
}
function renderRun() {
  const w = wf();
  $("preNote").textContent = w.pre || "";
  $("preNote").style.display = w.pre ? "block" : "none";
  renderForm($("form"), w, true);
  renderCollected();
}

// Λίστα συλλογής (π.χ. ασθενείς για το πρόγραμμα χειρουργείου ή πίνακας εργαστηριακών) για επικόλληση σε Excel
const hasCollect = (w) => w.steps.some((s) => s.type === "copy" && s.collect);
function collectedText(w, withHeader) {
  const rows = [...(w.collected || [])];
  if (withHeader && w.collectHeader) rows.unshift(E.render(w.collectHeader, curVals(w)));
  return rows.join("\n");
}
function renderCollected() {
  const w = wf();
  const box = $("collected");
  const rows = w.collected || [];
  if (!hasCollect(w)) { box.style.display = "none"; return; }
  box.style.display = "block";
  $("colCount").textContent = rows.length;
  $("colHdr").parentElement.style.display = w.collectHeader ? "" : "none";
  $("colRows").textContent = rows.map((r) => r.replace(/\t/g, " | ")).join("\n") || "(κενή)";
}
function renderBulkCol() {
  const w = wf();
  const on = hasCollect(w);
  $("bulkCol").style.display = on ? "block" : "none";
  if (on) $("bulkColCount").textContent = (w.collected || []).length;
}
$("colCopy").onclick = async () => {
  await copyText(collectedText(wf(), $("colHdr").checked));
  log("📋 Αντιγράφηκαν όλες οι γραμμές. Πατήστε Ctrl+V στο Excel.", "ok");
};
$("colClear").onclick = () => { if (confirm("Άδειασμα λίστας;")) { wf().collected = []; save(); renderCollected(); renderBulkCol(); } };
$("bulkColCopy").onclick = async () => {
  await copyText(collectedText(wf(), true));
  log("📋 Αντιγράφηκε ο πίνακας. Πατήστε Ctrl+V στο Excel.", "ok", "bulkLog");
};
$("bulkColClear").onclick = $("colClear").onclick;

function renderBulk() {
  const w = wf();
  $("bulkWfNote").textContent = `Θα τρέξει η διαδικασία «${w.name}» για κάθε ασθενή της λίστας. Αλλάξτε τη από το μενού πάνω δεξιά.`;
  const sel = $("openerSel");
  sel.innerHTML = "";
  for (const x of state.workflows) sel.add(new Option(x.name, x.id, false, x.id === settings().openerId));
  renderForm($("bulkForm"), w);
  renderBulkRows(); renderBulkCol(); updateBulkInfo();
}
$("openerSel").onchange = (e) => { settings().openerId = e.target.value; save(); };
$("bulkList").oninput = () => { bulkSave(); updateBulkInfo(); };
$("bulkGo").onclick = () => runBulk();
$("bulkClear").onclick = () => { $("bulkList").value = ""; bulkSave(); updateBulkInfo(); bulk.rows = []; renderBulkRows(); };

function renderSetup() {
  const w = wf();
  $("pre").value = w.pre || "";
  $("keep").value = (w.keep || []).join(", ");
  const box = $("steps");
  box.innerHTML = "";
  w.steps.forEach((s, i) => {
    const el = document.createElement("div");
    el.className = "step" + (s.disabled ? " off" : "") + (pickingIdx === i ? " picking" : "");
    const needsTarget = !NO_TARGET.includes(s.type);
    const ph = {
      click: "(μόνο για dropdown: επιλογή)", fill: "κείμενο ή {μεταβλητή}", choose: "κείμενο γραμμής ή {μεταβλητή}",
      read: "(προαιρετικά: ετικέτα προς αφαίρεση, π.χ. Επώνυμο:)", check: "π.χ. {αμ}", copy: "π.χ. {επώνυμο}\\t{όνομα}",
      skipif: "κενό = αν φαίνεται το στοιχείο · * = αν έχει τιμή · ή κείμενο, π.χ. {θεράπων}", tab: "κομμάτι διεύθυνσης/τίτλου ή «αρχική»", goto: "https://… ή /διαδρομή/{αμ}", manual: "", wait: "ms",
    }[s.type] || "";
    el.innerHTML = `
      <div class="top">
        <input type="checkbox" title="Ενεργό" ${s.disabled ? "" : "checked"} data-k="on">
        <span class="num">${i + 1}</span>
        <input class="lbl" type="text" data-k="label">
        ${needsTarget ? `<button class="btn p s" data-a="pick" title="Εκμάθηση: κλικ στο στοιχείο">${pickingIdx === i ? "Κλικ στη σελίδα…" : "🎯"}</button>` : ""}
        <button class="btn s" data-a="test" title="Δοκιμή μόνο αυτού του βήματος">▶</button>
      </div>
      <div class="det">
        <span>Τύπος</span><select data-k="type">${Object.entries(TYPES).map(([k, v]) => `<option value="${k}" ${k === s.type ? "selected" : ""}>${v}</option>`).join("")}</select>
        <span>Τιμή</span><input type="text" data-k="value" placeholder="${esc(ph)}">
        ${s.type === "read" ? `<span>Αποθήκευση ως</span><input type="text" data-k="saveAs" placeholder="όνομα μεταβλητής, π.χ. αμ">
          <span>Μόνο γραμμές</span><input type="text" data-k="filter" placeholder="(προαιρετικά) π.χ. Hb, WBC, CRP">` : ""}
        ${s.type === "copy" ? `<span>Συλλογή</span><label style="margin:0;font-weight:400"><input type="checkbox" data-k="collect" ${s.collect ? "checked" : ""}> πρόσθεσε και στη λίστα για μαζική επικόλληση</label>` : ""}
        ${s.type === "skipif" ? `<span>Παράλειψη επόμενων</span><input type="text" data-k="count" placeholder="πόσα βήματα, π.χ. 3">` : ""}
        ${s.type === "goto" ? `<span>Νέα καρτέλα</span><label style="margin:0;font-weight:400"><input type="checkbox" data-k="newTab" ${s.newTab ? "checked" : ""}> άνοιγμα σε νέα καρτέλα (αλλιώς στην ίδια)</label>` : ""}
        ${s.type === "fill" ? `<span>Enter μετά</span><input type="checkbox" data-k="enter" ${s.enter ? "checked" : ""}>` : ""}
        ${needsTarget ? `<span>Μόνο αν εμφανιστεί</span><label style="margin:0;font-weight:400"><input type="checkbox" data-k="optional" ${s.optional ? "checked" : ""}> ${s.type === "manual" ? "παύση μόνο όταν εμφανιστεί το στοιχείο 🎯" : "αλλιώς παράλειψη"}</label>` : ""}
        <span>Για κάθε γραμμή</span><input type="text" data-k="each" placeholder="(όνομα μεταβλητής, π.χ. εξετάσεις)">
        <span>Αναμονή μετά</span><input type="text" data-k="delay" placeholder="600 ms">
        ${needsTarget ? `<span>Στοιχείο</span><span class="tgt ${s.target ? "" : "none"}">${s.target ? describeTarget(s.target) : s.type === "manual" ? "(προαιρετικό)" : "δεν έχει οριστεί"}</span>` : ""}
      </div>
      <div class="bar" style="margin:6px 0 0">
        <button class="btn s" data-a="up">↑</button><button class="btn s" data-a="down">↓</button>
        <button class="btn s" data-a="dup">Αντίγραφο</button><button class="btn s" data-a="del">Διαγραφή</button>
      </div>`;
    el.querySelector('[data-k=label]').value = s.label || "";
    el.querySelector('[data-k=value]').value = s.value || "";
    el.querySelector('[data-k=delay]').value = s.delay ?? "";
    el.querySelector('[data-k=each]').value = s.each || "";
    const ct = el.querySelector('[data-k=count]'); if (ct) ct.value = s.count ?? "";
    const sa = el.querySelector('[data-k=saveAs]'); if (sa) sa.value = s.saveAs || "";
    const fl = el.querySelector('[data-k=filter]'); if (fl) fl.value = s.filter || "";
    el.addEventListener("change", (e) => {
      const k = e.target.dataset.k;
      if (!k) return;
      if (k === "on") s.disabled = !e.target.checked;
      else if (k === "enter") s.enter = e.target.checked;
      else if (k === "optional") s.optional = e.target.checked;
      else if (k === "collect") s.collect = e.target.checked;
      else if (k === "newTab") s.newTab = e.target.checked;
      else if (k === "filter") s.filter = e.target.value;
      else if (k === "saveAs") s.saveAs = e.target.value.trim().replace(/\s+/g, "_");
      else if (k === "count") s.count = e.target.value ? parseInt(e.target.value) : undefined;
      else if (k === "delay") s.delay = e.target.value ? parseInt(e.target.value) : undefined;
      else s[k] = e.target.value;
      save(); renderSetup(); renderRun();
    });
    el.addEventListener("click", (e) => {
      const a = e.target.dataset.a;
      if (!a) return;
      if (a === "pick") return pick(i);
      if (a === "test") return testStep(i);
      if (a === "up" && i > 0) [w.steps[i - 1], w.steps[i]] = [w.steps[i], w.steps[i - 1]];
      if (a === "down" && i < w.steps.length - 1) [w.steps[i + 1], w.steps[i]] = [w.steps[i], w.steps[i + 1]];
      if (a === "dup") w.steps.splice(i + 1, 0, structuredClone(s));
      if (a === "del" && confirm(`Διαγραφή βήματος «${s.label}»;`)) w.steps.splice(i, 1);
      save(); renderSetup(); renderRun();
    });
    box.appendChild(el);
  });
}
const esc = (t) => t.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
function describeTarget(t) {
  const what = t.text ? `«${t.text}»` : t.name ? `πεδίο ${t.name}` : t.placeholder ? `«${t.placeholder}»` : t.css;
  return esc(`${t.tag} ${what}`);
}

const VIEWS = { run: "runView", bulk: "bulkView", mon: "monView", labs: "labsView", setup: "setupView" };
const TABS = { run: "tabRun", bulk: "tabBulk", mon: "tabMon", labs: "tabLabs", setup: "tabSetup" };
function showTab(which) {
  for (const k of Object.keys(VIEWS)) {
    $(VIEWS[k]).style.display = k === which ? "" : "none";
    $(TABS[k]).classList.toggle("on", k === which);
  }
  if (which === "run") renderRun();
  else if (which === "bulk") renderBulk();
  else if (which === "mon") initMon();
  else if (which === "labs") renderLabs();
  else renderSetup();
}

// ---------- Συμβάντα ----------
for (const k of Object.keys(TABS)) $(TABS[k]).onclick = () => showTab(k);
$("go").onclick = () => run(0);
const stopAll = () => { aborted = true; manualResolve?.(); };
$("stop").onclick = stopAll;
$("bulkStop").onclick = stopAll;
$("cont").onclick = () => manualResolve?.();
$("clear").onclick = () => { state.values[state.current] = { ...(wf().defaults || {}) }; save(); renderRun(); };
$("wf").onchange = (e) => {
  state.current = e.target.value; save(); renderRun(); renderSetup();
  if ($("bulkView").style.display !== "none") renderBulk();
};
$("pre").onchange = (e) => { wf().pre = e.target.value; save(); };
$("keep").onchange = (e) => { wf().keep = e.target.value.split(",").map((x) => x.trim().replace(/\s+/g, "_")).filter(Boolean); save(); };
$("add").onclick = () => { wf().steps.push({ label: "Νέο βήμα", type: "click" }); save(); renderSetup(); };
$("newWf").onclick = () => {
  const name = prompt("Όνομα νέας διαδικασίας:");
  if (!name) return;
  const id = "wf" + Date.now();
  state.workflows.push({ id, name, pre: "", steps: [{ label: "Πρώτο βήμα", type: "click" }] });
  state.current = id; save(); renderWfSelect(); showTab("setup");
};
$("renWf").onclick = () => {
  const name = prompt("Νέο όνομα:", wf().name);
  if (name) { wf().name = name; save(); renderWfSelect(); }
};
$("delWf").onclick = () => {
  if (state.workflows.length < 2) return alert("Πρέπει να υπάρχει τουλάχιστον μία διαδικασία.");
  if (!confirm(`Διαγραφή της διαδικασίας «${wf().name}»;`)) return;
  state.workflows = state.workflows.filter((w) => w.id !== state.current);
  state.current = state.workflows[0].id; save(); renderWfSelect(); showTab("setup");
};
// Εξαγωγή/εισαγωγή ρυθμίσεων (χωρίς τις τιμές των πεδίων και χωρίς λίστες ασθενών), για διανομή σε άλλους υπολογιστές
$("exp").onclick = async () => {
  const { efbotMenu } = await chrome.storage.local.get("efbotMenu");
  const wfs = state.workflows.map(({ collected, ...rest }) => rest);
  const blob = new Blob([JSON.stringify({ workflows: wfs, menu: efbotMenu || {}, links: settings().linksText || "" }, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = "efbot-diadikasies.json"; a.click();
};
$("imp").onclick = () => $("impFile").click();
$("impFile").onchange = async (e) => {
  try {
    const data = JSON.parse(await e.target.files[0].text());
    if (!Array.isArray(data.workflows)) throw new Error();
    for (const w of data.workflows) {
      const i = state.workflows.findIndex((x) => x.id === w.id);
      if (i >= 0) state.workflows[i] = w; else state.workflows.push(w);
    }
    if (data.links && !settings().linksText) settings().linksText = data.links;
    if (data.menu && typeof data.menu === "object") {
      const { efbotMenu, efbotHosts } = await chrome.storage.local.get(["efbotMenu", "efbotHosts"]);
      const hosts = efbotHosts || [];
      for (const h of Object.keys(data.menu)) if (!hosts.includes(h)) hosts.push(h);
      await chrome.storage.local.set({ efbotMenu: { ...(efbotMenu || {}), ...data.menu }, efbotHosts: hosts });
    }
    save(); renderWfSelect(); showTab("setup");
    alert("Οι διαδικασίες εισήχθησαν.");
  } catch { alert("Μη έγκυρο αρχείο."); }
};

// ---------- Γενικές ρυθμίσεις ----------
async function renderGeneral() {
  const st = settings();
  $("barPos").value = st.barPos;
  $("timeout").value = st.timeout;
  $("delay").value = st.delay;
  $("busyOn").checked = !st.busyOff;
  $("busySel").value = st.busySel || "";
  $("menuLabel").value = st.menuLabel || "";
  $("barAlso").checked = !!st.barAlso;
  $("linksText").value = st.linksText || "";
  $("therMap").value = st.therMap || "";
  $("emrUser").value = st.emrUser || "";
  $("appHosts").value = st.appHosts || "";
  $("comorbAuto").checked = !!st.comorbAuto;
  chrome.storage.session.get("efbotComorbState").then(({ efbotComorbState: c }) => { if (c) $("comorbAutoState").textContent = c; });
  let host = "";
  try { host = new URL((await targetTab()).url).host; } catch (e) {}
  const { efbotHosts, efbotMenu } = await chrome.storage.local.get(["efbotHosts", "efbotMenu"]);
  const hosts = efbotHosts || [];
  const on = host && hosts.includes(host);
  $("hostBtn").textContent = on ? "Απόκρυψη κουμπιών από αυτή την εφαρμογή" : "Εμφάνιση κουμπιών σε αυτή την εφαρμογή";
  $("hostBtn").disabled = !host;
  $("hostInfo").textContent = hosts.length ? "Κουμπιά εμφανίζονται σε: " + hosts.join(", ") : "Ανοίξτε την εφαρμογή της κλινικής και πατήστε το κουμπί.";
  $("hostBtn").onclick = async () => {
    const next = on ? hosts.filter((h) => h !== host) : [...hosts, host];
    await chrome.storage.local.set({ efbotHosts: next });
    renderGeneral();
  };
  const m = efbotMenu || {};
  const mine = host && m[host];
  $("menuInfo").textContent = mine
    ? `Ορισμένο δίπλα στο: ${mine.target.text ? "«" + mine.target.text + "»" : mine.target.css}`
    : Object.keys(m).length ? "Ορισμένο σε: " + Object.keys(m).join(", ") : "Δεν έχει οριστεί. Θα εμφανίζεται η πλωτή μπάρα κάτω.";
  $("menuDel").disabled = !mine;
}
$("gen").addEventListener("toggle", () => $("gen").open && renderGeneral());
$("barPos").onchange = (e) => { settings().barPos = e.target.value; save(); };
$("timeout").onchange = (e) => { settings().timeout = parseInt(e.target.value) || 30; save(); };
$("delay").onchange = (e) => { const v = parseInt(e.target.value); settings().delay = isNaN(v) ? 0 : v; save(); };
$("busyOn").onchange = (e) => { settings().busyOff = !e.target.checked; save(); };
$("busySel").onchange = (e) => { settings().busySel = e.target.value.trim(); save(); };
$("menuLabel").onchange = (e) => { settings().menuLabel = e.target.value.trim(); save(); };
$("barAlso").onchange = (e) => { settings().barAlso = e.target.checked; save(); };
$("linksText").onchange = (e) => { settings().linksText = e.target.value; save(); };
$("therMap").onchange = (e) => { settings().therMap = e.target.value; save(); };
$("comorbAuto").onchange = (e) => { settings().comorbAuto = e.target.checked; save(); };
$("comorbAutoNow").onclick = async () => { $("comorbAutoState").textContent = "έλεγχος…"; await save(); const r = await chrome.runtime.sendMessage({ type: "comorbAutoNow" }).catch(() => null); $("comorbAutoState").textContent = r?.msg || "—"; };
$("emrUser").onchange = (e) => { settings().emrUser = e.target.value.trim(); save(); };
// 🔒 Κωδικοί: τους κρατά (κρυπτογραφημένους) το background· το πάνελ τους ζητά/γράφει με μηνύματα
const sec = {
  get: (keys) => chrome.runtime.sendMessage({ cmd: "secretsGet", keys }).then((r) => r || {}, () => ({})),
  set: (patch) => chrome.runtime.sendMessage({ cmd: "secretsSet", patch }).then((r) => { if (!r || r.ok === false) throw new Error(r?.err || "σφάλμα αποθήκευσης"); return r; }),
};
// Κωδικός φακέλου: χωριστά από τις ρυθμίσεις (δεν μπαίνει ποτέ σε διάγνωση/εξαγωγή)
async function emrPassRender() {
  const { efbotEmrCred: c } = await sec.get(["efbotEmrCred"]);
  $("emrPass").value = ""; $("emrPass").placeholder = c?.pass ? "•••••• (αποθηκευμένος)" : "κωδικός του φακέλου (για σύνδεση χωρίς κλικ)";
  $("emrPassState").textContent = c?.pass ? "σύνδεση χωρίς κλικ: ενεργή" : "σύνδεση χωρίς κλικ: ανενεργή";
  $("botIncog").checked = !!settings().botIncog;
  const allowed = await chrome.extension.isAllowedIncognitoAccess().catch(() => false);
  $("botIncogHint").textContent = allowed ? "Επιτρέπεται στην ανώνυμη περιήγηση ✓" : "Χρειάζεται: chrome://extensions → ef-bot → Λεπτομέρειες → «Να επιτρέπεται στην ανώνυμη περιήγηση».";
}
$("emrPassSave").onclick = async () => {
  const pass = $("emrPass").value;
  if (!pass) { $("emrPassState").textContent = "γράψτε πρώτα τον κωδικό"; return; }
  if (!String(settings().emrUser || "").trim()) { $("emrPassState").textContent = "συμπληρώστε και το όνομα χρήστη"; return; }
  try { await sec.set({ efbotEmrCred: { pass, ts: Date.now() } }); } catch (e) { $("emrPassState").textContent = "δεν αποθηκεύτηκε: " + e.message; return; }
  await chrome.storage.session.remove("efbotEmrLoginBad");
  emrPassRender();
};
$("emrPassDel").onclick = async () => { await sec.set({ efbotEmrCred: null }).catch(() => {}); emrPassRender(); };
$("botIncog").onchange = (e) => { settings().botIncog = e.target.checked; save(); emrPassRender(); };
emrPassRender();
// 🔑 κωδικοί από τη σύνδεση του χρήστη (βλ. background: credLearnSave)
async function credRender() {
  const { efbotCredByHost: all = {} } = await sec.get(["efbotCredByHost"]);
  const vs = await chrome.runtime.sendMessage({ cmd: "vaultStatus" }).catch(() => null);
  const { efbotCredLearn: u } = await chrome.storage.session.get("efbotCredLearn");
  const left = u && u > Date.now() ? Math.ceil((u - Date.now()) / 60000) : 0;
  $("credState").textContent = left ? "ενεργό για ακόμα " + left + "′ — συνδεθείτε τώρα" : "";
  const hs = Object.keys(all);
  const esc = (x) => String(x == null ? "" : x).replace(/[<>&]/g, "");
  const names = (h) => { const v = all[h]; const l = Array.isArray(v) ? v : (v ? [v] : []); const us = l.map((a) => esc(a.user)).filter(Boolean); return us.length > 1 ? " (" + us.length + " λογαριασμοί: " + us.join(", ") + ")" : us.length ? " (" + us[0] + ")" : ""; };
  $("credList").innerHTML = hs.length ? "Αποθηκευμένες συνδέσεις: " + hs.map((h) => "<b>" + esc(h) + "</b>" + names(h)).join(", ") + "<br><span style=\"color:#64748b\">Για πολλούς λογαριασμούς ΑΗΦΥ: πατήστε «Μάθε» και συνδεθείτε με τον καθένα μία φορά. Αν ένας δεν μπαίνει (π.χ. άλλαξε κωδικός), το bot δοκιμάζει τον επόμενο.</span>" : "Καμία αποθηκευμένη σύνδεση.";
  const vt = !vs ? "" : vs.mode === "dpapi" ? "🔒 Κρυπτογραφημένοι με τα Windows — ανοίγουν μόνο σε αυτόν τον υπολογιστή και αυτόν τον χρήστη."
    : vs.mode === "locked" ? "⚠️ Οι κωδικοί είναι κλειδωμένοι και δεν ανοίγουν" + (vs.err ? " (" + vs.err + ")" : "") + ". Να τρέχει το efbot-update.bat· αν άλλαξε χρήστης Windows, «Διαγραφή όλων» και ξανά «Μάθε»."
    : vs.helper ? "Ετοιμάζεται η κρυπτογράφηση…" : "⚠️ Χωρίς κρυπτογράφηση: λείπει το βοηθητικό των Windows (το εγκαθιστά το efbot-update.bat)." + (vs.err ? " " + vs.err : "");
  if (vt) $("credList").innerHTML += "<div style=\"margin-top:4px;color:" + (vs.mode === "dpapi" ? "#15803d" : "#b45309") + "\">" + vt.replace(/[<>&]/g, "") + "</div>";
}
$("credLearn").onclick = async () => { await chrome.storage.session.set({ efbotCredLearn: Date.now() + 15 * 60000 }); credRender(); };
$("credDel").onclick = async () => { if (!confirm("Διαγραφή όλων των αποθηκευμένων κωδικών από αυτόν τον υπολογιστή;")) return; await chrome.runtime.sendMessage({ cmd: "secretsWipe" }).catch(() => {}); await chrome.storage.session.remove("efbotCredLearn"); credRender(); emrPassRender(); };
chrome.storage.onChanged.addListener((ch) => { if (ch.efbotCredByHost || ch.efbotCredLearn || ch.efbotVault) credRender(); });
credRender();
$("appHosts").onchange = (e) => { settings().appHosts = e.target.value.trim(); save(); };
$("menuPick").onclick = async () => {
  pickingIdx = "menu";
  $("menuInfo").textContent = "Πηγαίνετε στην εφαρμογή και κάντε κλικ σε ένα στοιχείο του μενού της (Esc = ακύρωση)…";
  await chrome.storage.local.set({ efbotPicking: { stepId: "menu", ts: Date.now() } });
};
$("menuDel").onclick = async () => {
  let host = "";
  try { host = new URL((await targetTab()).url).host; } catch (e) {}
  const { efbotMenu } = await chrome.storage.local.get("efbotMenu");
  if (efbotMenu && host) { delete efbotMenu[host]; await chrome.storage.local.set({ efbotMenu }); }
  renderGeneral();
};

// ---------- Παρακολούθηση νέων εργαστηριακών ----------
// Η ίδια η παρακολούθηση τρέχει στο background (background.js). Εδώ μόνο ρυθμίσεις και εμφάνιση.
const MON_CFG = "efbotMonCfg", MON_ST = "efbotMonState";
const monDefault = () => ({ on: false, interval: 10, wfId: "elegxos_ergastirion", tabId: null, match: "", tests: "", list: "", showAm: false });
async function getMonCfg() { return (await chrome.storage.local.get(MON_CFG))[MON_CFG] || monDefault(); }
async function setMonCfg(patch) {
  const c = { ...(await getMonCfg()), ...patch };
  if (!c.salt) c.salt = [...crypto.getRandomValues(new Uint8Array(8))].map((b) => b.toString(16).padStart(2, "0")).join("");
  await chrome.storage.local.set({ [MON_CFG]: c });
  return c;
}
const hhmm = (ts) => { const d = new Date(ts); return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`; };

async function initMon() {
  const c = await getMonCfg();
  $("monOn").checked = !!c.on;
  $("monInt").value = String(c.interval || 10);
  $("monList").value = c.list || "";
  $("monTests").value = c.tests || "";
  $("monShowAm").checked = !!c.showAm;
  const sel = $("monWf");
  sel.innerHTML = "";
  for (const w of state.workflows) sel.add(new Option(w.name, w.id, false, w.id === c.wfId));
  renderMon();
}
async function renderMon() {
  const c = await getMonCfg();
  const st = (await chrome.storage.local.get(MON_ST))[MON_ST] || {};
  const alerts = (await chrome.storage.session.get("efbotAlerts")).efbotAlerts || [];
  // Ένδειξη στην καρτέλα
  $("monBadge").style.display = alerts.length ? "" : "none";
  $("monBadge").textContent = alerts.length;
  $("monTabInfo").textContent = c.match ? `Καρτέλα εργαστηρίων: ${c.match}` : "Δεν έχει οριστεί καρτέλα.";
  // Κατάσταση
  const al = await chrome.alarms.get("efbot-monitor");
  let t = c.on ? `🟢 Ενεργή · έλεγχος κάθε ${c.interval} λεπτά` : "⚪ Ανενεργή.";
  if (c.on && al) t += ` · επόμενος περίπου ${hhmm(al.scheduledTime)}`;
  if (st.lastTs) t += `\nΤελευταίος έλεγχος ${hhmm(st.lastTs)}: ${st.lastMsg || ""}`;
  $("monStatus").textContent = t;
  $("monStatus").style.whiteSpace = "pre-line";
  // Νέα αποτελέσματα
  const box = $("monAlerts");
  box.innerHTML = "";
  if (alerts.length) {
    const head = document.createElement("div");
    head.className = "row";
    head.style.cssText = "justify-content:space-between;margin-bottom:6px";
    const b = document.createElement("b"); b.textContent = `🔔 Νέα αποτελέσματα (${alerts.length})`;
    const ok = document.createElement("button"); ok.className = "btn s"; ok.textContent = "Το είδα";
    ok.onclick = async () => { await chrome.runtime.sendMessage({ type: "alertsAck" }); renderMon(); };
    head.append(b, ok); box.appendChild(head);
    for (const a of alerts) {
      const d = document.createElement("div"); d.className = "alert";
      const h = document.createElement("b"); h.textContent = `ΑΜ ${a.key} · ${hhmm(a.ts)}`;
      const pre = document.createElement("pre"); pre.textContent = a.lines.join("\n");
      d.append(h, pre); box.appendChild(d);
    }
  }
  // Ανά ασθενή
  const rows = $("monRows");
  rows.innerHTML = "";
  const icon = { base: "●", ok: "✓", new: "🔔", error: "✗" };
  const cls = { base: "st-wait", ok: "st-ok", new: "st-run", error: "st-fail" };
  for (const line of (c.list || "").split(/\r?\n/).map((x) => x.trim()).filter(Boolean)) {
    const key = line.split(";")[0].trim();
    const s = (st.status || {})[key];
    const d = document.createElement("div");
    d.className = "brow " + (s ? cls[s.state] : "st-wait");
    const i = document.createElement("span"); i.textContent = s ? icon[s.state] : "○";
    const k = document.createElement("span"); k.className = "k"; k.textContent = key;
    if (s) { const sm = document.createElement("small"); sm.textContent = `${hhmm(s.ts)} · ${s.msg}`; k.appendChild(sm); }
    d.append(i, k); rows.appendChild(d);
  }
}
chrome.storage.onChanged.addListener((ch, area) => {
  if ((area === "local" && (ch[MON_ST] || ch[MON_CFG])) || (area === "session" && ch.efbotAlerts)) renderMon();
});

$("monOn").onchange = async (e) => {
  if (e.target.checked) {
    const c = await getMonCfg();
    const w = state.workflows.find((x) => x.id === $("monWf").value);
    const why = !c.match && !c.tabId ? "Ορίστε πρώτα την καρτέλα εργαστηρίων (βήμα 1)."
      : !$("monList").value.trim() ? "Η λίστα παρακολούθησης είναι κενή."
      : !w ? "Επιλέξτε διαδικασία ελέγχου."
      : untaught(w) ? `Η διαδικασία «${w.name}» έχει ${untaught(w)} βήματα που δεν έχουν «μάθει» (καρτέλα Ρύθμιση).`
      : "";
    if (why) { e.target.checked = false; alert(why); return; }
  }
  await setMonCfg({ on: e.target.checked });
  renderMon();
};
$("monTab").onclick = async () => {
  try {
    const tab = await targetTab();
    await setMonCfg({ tabId: tab.id, match: new URL(tab.url).host });
    renderMon();
  } catch (e) { alert(e.message); }
};
$("monList").oninput = (e) => { setMonCfg({ list: e.target.value }); };
$("monTests").onchange = (e) => setMonCfg({ tests: e.target.value.trim() });
$("monInt").onchange = (e) => setMonCfg({ interval: parseInt(e.target.value) || 10 });
$("monWf").onchange = (e) => setMonCfg({ wfId: e.target.value });
$("monShowAm").onchange = (e) => setMonCfg({ showAm: e.target.checked });
$("monNow").onclick = async () => {
  await setMonCfg({});
  $("monStatus").textContent = "Έλεγχος σε εξέλιξη…";
  chrome.runtime.sendMessage({ type: "monitorNow" });
};
$("monReset").onclick = async () => {
  if (!confirm("Να ξεχάσει το bot τι έχει δει μέχρι τώρα;\nΣτον επόμενο έλεγχο θα γίνει νέα αρχική καταγραφή, χωρίς ειδοποίηση.")) return;
  await chrome.storage.local.remove(MON_ST);
  await chrome.runtime.sendMessage({ type: "alertsAck" });
  renderMon();
};

// ---------- Σύνδεση στον φάκελο ----------
// Αν η καρτέλα δείχνει σελίδα σύνδεσης: γράφουμε το όνομα χρήστη (Γενικές ρυθμίσεις) ώστε ο Chrome να συμπληρώσει
// τον αποθηκευμένο κωδικό, και πατάμε «Σύνδεση» μόνο αν ο Chrome τον συμπλήρωσε. Τον κωδικό δεν τον διαβάζουμε ποτέ.
// Αλλιώς περιμένουμε τον χρήστη να συνδεθεί (έως 3 λεπτά) και συνεχίζουμε μόνοι μας.
async function ensureLoggedIn(tabId) {
  const probe = async (user, act, pass = "") => {
    try {
      const [r] = await chrome.scripting.executeScript({ target: { tabId }, args: [user, act, pass], func: (user, act, pass) => {
        const vis = (e) => { if (!e) return false; const r = e.getBoundingClientRect(); const cs = getComputedStyle(e); return r.width > 0 && r.height > 0 && cs.display !== "none" && cs.visibility !== "hidden"; };
        if (document.querySelector("#appForm\\:tabview\\:patientsTable, [id='appForm:patientRightMenu']")) return { state: "ready" };
        const pw = [...document.querySelectorAll("input[type=password]")].find(vis);
        if (!pw) return { state: document.readyState === "complete" ? "other" : "loading" };
        const form = pw.form || document;
        const fields = [...form.querySelectorAll("input:not([type=hidden]):not([type=password]):not([type=checkbox]):not([type=radio]):not([type=submit]):not([type=button])")].filter(vis);
        const userEl = fields.filter((f) => f.compareDocumentPosition(pw) & Node.DOCUMENT_POSITION_FOLLOWING).pop() || fields[0];
        // Ο Chrome συμπληρώνει όνομα και κωδικό αλλά ΚΡΥΒΕΙ τις τιμές από τα scripts (φαίνονται κενές): ελέγχουμε τη σήμανση :autofill
        const auto = (e) => { try { return !!e && (e.matches(":autofill") || e.matches(":-webkit-autofill")); } catch (x) { return false; } };
        const filled = auto(pw) || !!pw.value;
        // Όνομα χρήστη ΜΟΝΟ αν ο Chrome δεν έχει συμπληρώσει τίποτα (αλλιώς θα «ξεχνούσε» τον κωδικό)
        if (act === "user" && user && userEl && !auto(userEl) && !filled && userEl.value !== user) {
          const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
          userEl.focus(); set.call(userEl, user);
          for (const t of ["input", "change", "keyup"]) userEl.dispatchEvent(new Event(t, { bubbles: true }));
          userEl.blur(); pw.focus();
        }
        const btn = [...form.querySelectorAll("button, input[type=submit], a.ui-button, [role=button]")].filter(vis)
          .find((b) => /submit/i.test(b.type) || /σύνδεση|συνδεση|είσοδος|εισοδος|login|sign in/i.test(b.innerText || b.value || ""));
        // Ο Chrome «δίνει» τον αποθηκευμένο κωδικό στη σελίδα ΜΟΝΟ μετά από πραγματικό κλικ/πλήκτρο του χρήστη.
        // Αν ο κωδικός φαίνεται ήδη (ο χρήστης αλληλεπίδρασε), πατάμε «Είσοδος». Αλλιώς μόνο επισημαίνουμε το κουμπί.
        if (act === "submit" && pw.value && btn) { btn.click(); return { state: "submitted" }; }
        // Σύνδεση χωρίς κλικ: όνομα και κωδικός από τις ρυθμίσεις του bot (όχι από τον Chrome)
        if (act === "creds" && user && pass && userEl && btn) {
          const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
          for (const [el, v] of [[userEl, user], [pw, pass]]) {
            el.focus(); set.call(el, v);
            for (const t of ["input", "change", "keyup"]) el.dispatchEvent(new Event(t, { bubbles: true }));
          }
          pw.blur();
          btn.click();
          return { state: "submitted" };
        }
        const err = [...document.querySelectorAll(".error, .errorMessage, .alert, [class*=error], [id*=error]")].filter(vis).map((e) => e.innerText.trim()).filter(Boolean).join(" ").slice(0, 160);
        if (act === "focus" && btn) {
          btn.style.outline = "4px solid #f59e0b"; btn.style.outlineOffset = "3px";
          btn.focus();
          return { state: "focused" };
        }
        return { state: "login", filled, exposed: !!pw.value, user: !!userEl && !!userEl.value, err };
      } });
      return r?.result || { state: "other" };
    } catch (e) { return { state: "error" }; }
  };
  const user = String(settings().emrUser || "").trim();
  const { efbotEmrCred: cred } = await sec.get(["efbotEmrCred"]);
  const credSig = cred?.pass ? user + "|" + cred.pass.length + "|" + (cred.ts || 0) : "";
  const { efbotEmrLoginBad: bad } = await chrome.storage.session.get("efbotEmrLoginBad");
  let credTried = !credSig || bad === credSig, credAt = 0, credReloaded = false;
  const t0 = Date.now();
  let note = null, triedUser = false, submitted = 0, focused = false;
  while (Date.now() - t0 < 180000 && !aborted) {
    const s = await probe(user, "");
    if (s.state === "ready") { note?.remove(); if (submitted || triedUser || credAt) log(credAt ? "🔐 Συνδέθηκα μόνος μου στον φάκελο." : "🔐 Συνδεθήκατε στον φάκελο.", "ok"); return true; }
    if (s.state === "login" && credAt && Date.now() - credAt > 12000 && !s.err && !credReloaded) {
      // καμία ένδειξη λάθους: ξαναφόρτωση της σελίδας ΧΩΡΙΣ νέα υποβολή κωδικού (η σύνδεση μπορεί να έγινε)
      credReloaded = true; credAt = Date.now();
      await chrome.tabs.update(tabId, { url: "https://apps.e-ygeia.gov.gr/emr-ui/views/home.xhtml" }).catch(() => {});
      await E.waitLoaded(tabId, 30000, () => aborted).catch(() => {});
      continue;
    }
    if (s.state === "login" && credAt && Date.now() - credAt > 12000) {
      // ξανά σελίδα σύνδεσης μετά την αυτόματη προσπάθεια: λάθος στοιχεία — δεν ξαναδοκιμάζουμε (κλείδωμα λογαριασμού)
      credAt = 0; submitted = 99; triedUser = true; // καμία άλλη αυτόματη υποβολή σε αυτή την εκτέλεση
      await chrome.storage.session.set({ efbotEmrLoginBad: credSig });
      note?.remove();
      log("🔐 Η αυτόματη σύνδεση στον φάκελο απέτυχε" + (s.err ? ": " + s.err : "") + ". Ελέγξτε όνομα/κωδικό στις Γενικές ρυθμίσεις. Μέχρι τότε συνδεθείτε με το χέρι.", "err");
      try { chrome.notifications.create({ type: "basic", iconUrl: "icons/icon128.png", title: "Φάκελος: η αυτόματη σύνδεση απέτυχε", message: "Ελέγξτε όνομα χρήστη/κωδικό στο ef-bot. Δεν θα ξαναδοκιμάσει μέχρι να τα αποθηκεύσετε ξανά.", priority: 2 }); } catch (e) {}
    }
    if (s.state === "login" && !credTried) {
      credTried = true; credAt = Date.now();
      note = log("🔐 Σύνδεση στον φάκελο (αυτόματα)…", "run");
      await probe(user, "creds", cred.pass);
      await sleep(2500); continue;
    }
    if (s.state === "login" && credAt) { await sleep(1000); continue; }
    if (s.state === "login") {
      if (!triedUser && user) { await probe(user, "user"); triedUser = true; await sleep(1500); continue; }
      if (s.exposed && submitted < 2) {
        await probe(user, "submit"); submitted++;
        if (!note) note = log("🔐 Σύνδεση στον φάκελο…", "run");
        await sleep(2500); continue;
      }
      if (s.filled && !focused) {
        // Ο κωδικός είναι συμπληρωμένος από τον Chrome: χρειάζεται ΕΝΑ κλικ του χρήστη (προστασία του Chrome)
        focused = true;
        await chrome.tabs.update(tabId, { active: true }).catch(() => {});
        await probe(user, "focus");
        note?.remove();
        note = log("🔐 Πατήστε «Είσοδος» στη σελίδα σύνδεσης (ή Enter). Ο Chrome δίνει τον αποθηκευμένο κωδικό μόνο με δικό σας κλικ· συνεχίζω μόλις συνδεθείτε.", "run");
      } else if (!s.filled && !note) {
        note = log(`🔐 Ο φάκελος ζητά σύνδεση. ${user ? "Διαλέξτε τον λογαριασμό «" + user + "» στη λίστα του Chrome και πατήστε «Είσοδος»" : "Συνδεθείτε"}· συνεχίζω μόλις συνδεθείτε.`, "run");
      }
    }
    await sleep(1000);
  }
  note?.remove();
  if (!aborted) log("✗ Δεν έγινε σύνδεση στον φάκελο μέσα σε 3 λεπτά. Συνδεθείτε και πατήστε ▶ Εκτέλεση.", "err");
  return false;
}

// ---------- Εξιτήριο από το Παραδόχαρτο ----------
async function launchFromApp(l) {
  const w = state.workflows.find((x) => x.id === l.wfId);
  if (!w) return;
  state.current = w.id;
  const v = curVals(w);
  v[E.BULKVAR] = l.app.name;
  v["κείμενο_διάγνωσης"] = l.app.text;
  v["επιπλέον_διαγνώσεις"] = String(l.app.extraDx || "");
  const up = (t) => String(t || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().trim();
  const th = mapTherapist(l.app.therapist) || up(l.app.therapistName);
  if (th) v["θεράπων"] = th;
  save(); renderWfSelect(); showTab("run");
  $("log").innerHTML = "";
  if (l.incog) launchNotes.push(["🕶 Το bot δουλεύει στο δικό του παράθυρο (ξεχωριστή σύνδεση) — μπορείτε να συνεχίσετε στον δικό σας φάκελο.", ""]);
  if (l.incogDenied) launchNotes.push(["⚠ Ζητήσατε «δικό του παράθυρο», αλλά η επέκταση δεν επιτρέπεται στην ανώνυμη περιήγηση (chrome://extensions → ef-bot → Λεπτομέρειες). Δουλεύω στον κοινό φάκελο.", "err"]);
  launchNotes.forEach(([t, c]) => log(t, c));
  if (l.app.extraDx) launchNotes.push([`🩺 Συννοσηρότητες ως επιπλέον διαγνώσεις: ${String(l.app.extraDx).split("\n").join(", ")}`, ""]);
  log(`📥 Από το Παραδόχαρτο: ${l.app.name}${l.app.therapist ? " · θεράπων " + l.app.therapist + (th ? " → " + th : " (δεν βρέθηκε όνομα, κρατώ: " + (v["θεράπων"] || "—") + ")") : " · χωρίς θεράποντα στο Παραδόχαρτο"}`, "run");
  if (l.noEmr) { log("✗ Δεν άνοιξε καρτέλα του ηλεκτρονικού φακέλου. Ανοίξτε τον, συνδεθείτε και πατήστε ▶ Εκτέλεση.", "err"); return; }
  if (!(await ensureLoggedIn(l.tabId))) return;
  pendingTab = l.tabId;
  const missing = missingVars(w);
  if (missing.length) {
    log("Συμπληρώστε: " + missing.map(pretty).join(", ") + " και πατήστε ▶ Εκτέλεση", "run");
    document.querySelector(`[data-var="${CSS.escape(missing[0])}"]`)?.focus();
    return;
  }
  run();
}

// ---------- Έναρξη από κουμπί μέσα στην εφαρμογή ----------
// Θεράπων: κωδικός Παραδόχαρτου → όνομα όπως στη λίστα «Εντελών Ιατρός» (Γενικές ρυθμίσεις, «ΚΩΔ ; ΕΠΩΝΥΜΟ»)
function mapTherapist(code) {
  if (!code) return "";
  for (const l of String(settings().therMap || "").split(/\r?\n/)) {
    const i = l.indexOf(";");
    if (i > 0 && l.slice(0, i).trim().toLowerCase() === code.trim().toLowerCase()) return l.slice(i + 1).trim();
  }
  return "";
}
let pendingTab = null; // καρτέλα του φακέλου που βρήκε το background (εκτέλεση από το Παραδόχαρτο)
async function handleLaunch(l) {
  if (!l || Date.now() - l.ts > 15000) return;
  await chrome.storage.local.remove("efbotLaunch");
  if (l.view) { showTab(l.view); return; }
  if (l.app) return launchFromApp(l);
  if (!state.workflows.find((w) => w.id === l.wfId)) return;
  state.current = l.wfId; save();
  renderWfSelect(); showTab("run");
  $("log").innerHTML = "";
  const missing = missingVars(wf());
  const op = state.workflows.find((x) => x.id === settings().openerId);
  const canOpen = op && !untaught(op) && !wf().hidden;
  if (!missing.length && !(canOpen && !String(curVals(wf())[E.BULKVAR] || "").trim() && settings().askPatient !== false)) return run();
  if (!missing.length) {
    log("Γράψτε το όνομα ή ΑΜ του ασθενή (ή αφήστε κενό για τον τρέχοντα) και πατήστε ▶ Εκτέλεση", "run");
    document.querySelector(`[data-var="${E.BULKVAR}"]`)?.focus();
    return;
  }
  log("Συμπληρώστε τα πεδία και πατήστε ▶ Εκτέλεση", "run");
  document.querySelector(`[data-var="${CSS.escape(missing[0])}"]`)?.focus();
}
chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch.efbotLaunch?.newValue) handleLaunch(ch.efbotLaunch.newValue); });

// ---------- Αυτόματη ανανέωση (όσο το πάνελ είναι ανοιχτό, έλεγχος κάθε 3 δευτ.) ----------
// Το πρόγραμμα ενημέρωσης των Windows αντικαθιστά τα αρχεία· εδώ το βλέπουμε και ξαναφορτώνουμε την επέκταση.
async function panelUpdateCheck() {
  try {
    if ($("go").disabled || $("bulkGo").disabled) return; // τρέχει διαδικασία
    const disk = await (await fetch(chrome.runtime.getURL("manifest.json"), { cache: "no-store" })).json();
    const mine = chrome.runtime.getManifest().version;
    if (!disk.version || disk.version === mine) return;
    const { efbotLock: l } = await chrome.storage.session.get("efbotLock");
    if (l && Date.now() - l.ts < 8 * 60000) return;
    // ⛔ ΟΧΙ επαναφόρτωση ενώ τρέχει εργασία (αιτία των «διακόπηκε δύο φορές από επανεκκίνηση», έλεγχος 5/11) — το SW θα ενημερωθεί μόλις τελειώσει
    const st = await chrome.storage.local.get(["efbotRunJob", "efbotRunSide", "efbotApJob"]);
    if (st.efbotRunJob || st.efbotRunSide || st.efbotApJob) return;
    await chrome.storage.local.set({ efbotUpdated: { from: mine, to: disk.version, ts: Date.now() }, efbotReinject: disk.version });
    chrome.runtime.reload();
  } catch (e) {}
}
setInterval(panelUpdateCheck, 3000);
(async () => {
  $("ver").textContent = "v" + chrome.runtime.getManifest().version;
  if (E.VERSION !== chrome.runtime.getManifest().version)
    log(`⚠ Τρέχει παλιό αρχείο (μηχανή ${E.VERSION || "παλιά"}). Στο chrome://extensions πατήστε ↻ στον «Βοηθό» και ελέγξτε ότι υπάρχει μόνο ΜΙΑ τέτοια επέκταση.`, "err");
  const { efbotUpdated: u } = await chrome.storage.local.get("efbotUpdated");
  if (u && Date.now() - u.ts < 10 * 60000) {
    log(`🔄 Η επέκταση ενημερώθηκε: ${u.from} → ${u.to}`, "ok");
    chrome.storage.local.remove("efbotUpdated");
  }
})();

chrome.storage.local.remove("efbotPicking");
load().then(async () => {
  settings();
  if (!settings().openerId) settings().openerId = "anoigma";
  renderWfSelect(); showTab("run");
  $("bulkList").value = (await chrome.storage.session.get("efbotBulk").catch(() => ({}))).efbotBulk || "";
  renderMon();
  handleLaunch((await chrome.storage.local.get("efbotLaunch")).efbotLaunch);
});

// ---------- Εργαστηριακά (Medilabi) για τους ασθενείς του Παραδόχαρτου ----------
// Η παρακολούθηση τρέχει στο background (background.js). Εδώ ρυθμίσεις και εμφάνιση.
async function labsCfgGet() { return { on: false, interval: 10, notifyAll: false, toApp: true, pushPhone: true, ...((await chrome.storage.local.get("efbotLabsCfg")).efbotLabsCfg || {}) }; }
async function labsCfgSet(patch) { await chrome.storage.local.set({ efbotLabsCfg: { ...(await labsCfgGet()), ...patch } }); }
async function renderLabs() {
  const c = await labsCfgGet();
  $("labsOn").checked = !!c.on; $("labsInt").value = String(c.interval || 10); $("labsAll").checked = !!c.notifyAll; $("labsApp").checked = c.toApp !== false; $("labsPush").checked = c.pushPhone !== false;
  const st = (await chrome.storage.session.get("efbotLabs")).efbotLabs || {};
  $("labsStatus").textContent = st.lastTs ? `${hhmm(st.lastTs)} · ${st.lastMsg || ""}` : (c.on ? "Περιμένει τον πρώτο έλεγχο…" : "Ανενεργή");
  const box = $("labsList"); box.innerHTML = "";
  const ps = Object.values(st.patients || {}).sort((a, b) => (b.rows || []).filter((r) => r.flag).length - (a.rows || []).filter((r) => r.flag).length || a.name.localeCompare(b.name, "el"));
  const icon = { done: "🟢", pending: "🔴", abnormal: "🔵" };
  for (const p of ps) {
    const d = document.createElement("div");
    d.className = "step"; d.style.padding = "6px 8px";
    const bad = (p.rows || []).filter((r) => r.flag);
    const head = document.createElement("div");
    head.style.cssText = "display:flex;justify-content:space-between;gap:6px;font-weight:600";
    const n = document.createElement("span"); n.textContent = p.name;
    const g = document.createElement("span"); g.style.fontWeight = "400";
    g.textContent = p.msg ? "⚠ " + p.msg : Object.entries(p.groups || {}).map(([k, v]) => icon[v] || "").join("") || "—";
    g.title = Object.entries(p.groups || {}).map(([k, v]) => `${icon[v] || ""} ${k}`).join("\n");
    head.append(n, g); d.appendChild(head);
    if (bad.length) {
      const t = document.createElement("div"); t.style.cssText = "font-size:12.5px;color:#b91c1c;margin-top:3px";
      t.textContent = bad.map((b) => `${b.test} ${b.value}${b.flag === "H" ? "↑" : "↓"}${b.range ? " (" + b.range + ")" : ""}`).join(" · ");
      d.appendChild(t);
    } else if ((p.rows || []).length) {
      const t = document.createElement("div"); t.style.cssText = "font-size:12px;color:#15803d;margin-top:3px";
      t.textContent = `Σημερινά: ${p.rows.length} τιμές, όλες φυσιολογικές`;
      d.appendChild(t);
    }
    if (p.sentTs) {
      const t = document.createElement("div"); t.style.cssText = "font-size:11.5px;color:#64748b;margin-top:2px";
      t.textContent = `📋 στο Παραδόχαρτο ${hhmm(p.sentTs)}`;
      d.appendChild(t);
    }
    box.appendChild(d);
  }
  if (!ps.length) box.innerHTML = '<div class="hint">Δεν υπάρχουν ακόμα δεδομένα.</div>';
}
$("labsOn").onchange = async (e) => { await labsCfgSet({ on: e.target.checked }); if (e.target.checked) chrome.runtime.sendMessage({ type: "labsNow" }); renderLabs(); };
$("labsInt").onchange = (e) => labsCfgSet({ interval: parseInt(e.target.value) || 10 });
$("labsAll").onchange = (e) => labsCfgSet({ notifyAll: e.target.checked });
$("labsApp").onchange = (e) => labsCfgSet({ toApp: e.target.checked });
$("labsPush").onchange = (e) => labsCfgSet({ pushPhone: e.target.checked });
async function labsCredRender() {
  const { efbotLabsCred: c } = await sec.get(["efbotLabsCred"]);
  $("labsCredUser").value = c?.user || ""; $("labsCredPass").value = ""; $("labsCredPass").placeholder = c?.pass ? "•••••• (αποθηκευμένος)" : "";
  $("labsCredState").textContent = c?.user && c?.pass ? "· ενεργή" : "· ανενεργή";
}
$("labsCredSave").onclick = async () => {
  const { efbotLabsCred: c } = await sec.get(["efbotLabsCred"]);
  const user = $("labsCredUser").value.trim(), pass = $("labsCredPass").value || c?.pass || "";
  if (!user || !pass) { $("labsCredState").textContent = "· συμπληρώστε χρήστη και κωδικό"; return; }
  try { await sec.set({ efbotLabsCred: { user, pass, ts: Date.now() } }); } catch (e) { $("labsCredState").textContent = "· δεν αποθηκεύτηκε: " + e.message; return; }
  await chrome.storage.session.remove("efbotLabsLoginTry");
  labsCredRender();
};
$("labsCredDel").onclick = async () => { await sec.set({ efbotLabsCred: null }).catch(() => {}); labsCredRender(); };
labsCredRender();
$("labsNow").onclick = async () => { $("labsStatus").textContent = "Έλεγχος σε εξέλιξη…"; await chrome.runtime.sendMessage({ type: "labsNow" }); renderLabs(); };
chrome.storage.onChanged.addListener((ch, area) => { if (area === "session" && ch.efbotLabs && $("labsView").style.display !== "none") renderLabs(); });
