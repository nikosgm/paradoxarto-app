﻿# ef-bot vault helper (Chrome native messaging host "gr.efbot.vault")
# Protects/unprotects a small key with Windows DPAPI (CurrentUser scope). Nothing is stored here.
# Protocol: 4-byte little-endian length + UTF-8 JSON, one request per launch.
$ErrorActionPreference = "Stop"
$stdin  = [Console]::OpenStandardInput()
$stdout = [Console]::OpenStandardOutput()
function ReadN([int]$n) {
  $b = New-Object byte[] $n; $o = 0
  while ($o -lt $n) { $r = $stdin.Read($b, $o, $n - $o); if ($r -le 0) { exit 0 }; $o += $r }
  return ,$b
}
function Reply($obj) {
  $j = [Text.Encoding]::UTF8.GetBytes(($obj | ConvertTo-Json -Compress))
  $stdout.Write([BitConverter]::GetBytes([int]$j.Length), 0, 4)
  $stdout.Write($j, 0, $j.Length)
  $stdout.Flush()
}
try {
  $len = [BitConverter]::ToInt32((ReadN 4), 0)
  if ($len -le 0 -or $len -gt 33554432) { Reply @{ ok = $false; err = "bad length" }; exit 0 }
  $msg = [Text.Encoding]::UTF8.GetString((ReadN $len)) | ConvertFrom-Json
  Add-Type -AssemblyName System.Security
  $ent = [Text.Encoding]::UTF8.GetBytes("ef-bot-vault-v1")
  $scope = [Security.Cryptography.DataProtectionScope]::CurrentUser
  switch ([string]$msg.op) {
    "ping"      { Reply @{ ok = $true; v = 1; user = [Environment]::UserName } }
    "protect"   { $d = [Convert]::FromBase64String([string]$msg.data); Reply @{ ok = $true; data = [Convert]::ToBase64String([Security.Cryptography.ProtectedData]::Protect($d, $ent, $scope)) } }
    "unprotect" { $d = [Convert]::FromBase64String([string]$msg.data); Reply @{ ok = $true; data = [Convert]::ToBase64String([Security.Cryptography.ProtectedData]::Unprotect($d, $ent, $scope)) } }
    "update"    {
      # ξαναξεκινά το πρόγραμμα αυτόματων ενημερώσεων του ef-bot, ΜΟΝΟ αν δεν τρέχει ήδη (καμία άλλη εντολή δεν εκτελείται)
      $pf = Join-Path $PSScriptRoot "updater-path.txt"
      if (-not (Test-Path -LiteralPath $pf)) { Reply @{ ok = $false; err = "δεν είναι γνωστός ο φάκελος του ef-bot (τρέξτε μία φορά το efbot-update.bat)" }; break }
      $bat = ([IO.File]::ReadAllText($pf)).Trim()
      if (-not ($bat -match 'efbot-update\.bat$') -or -not (Test-Path -LiteralPath $bat)) { Reply @{ ok = $false; err = "λάθος διαδρομή προγράμματος ενημέρωσης" }; break }
      $run = @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -match 'efbot-update\.ps1' }).Count
      if ($run -gt 0) { Reply @{ ok = $true; already = $true }; break }
      $cl = "cmd.exe /c start `"ef-bot`" /min `"$bat`""
      $r = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = $cl; CurrentDirectory = $env:TEMP }
      if ($r.ReturnValue -ne 0) { Reply @{ ok = $false; err = "δεν ξεκίνησε (κωδικός $($r.ReturnValue))" }; break }
      Reply @{ ok = $true; started = $true }
    }
    { $_ -eq "hidewin" -or $_ -eq "showwin" } {
      # Κρύβει/δείχνει τα παράθυρα του bot (τίτλος με σήμανση) — ούτε στη γραμμή εργασιών. Μόνο παράθυρα του chrome.exe.
      Add-Type -TypeDefinition @"
using System; using System.Text; using System.Collections.Generic; using System.Runtime.InteropServices;
public static class EfWin {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc f, IntPtr l);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  public static List<long> Find(string m) { var r = new List<long>(); EnumWindows(delegate (IntPtr h, IntPtr l) { var sb = new StringBuilder(512); GetWindowText(h, sb, 512); if (sb.ToString().Contains(m)) r.Add(h.ToInt64()); return true; }, IntPtr.Zero); return r; }
}
"@
      $hs = @()
      if ($msg.h) { $hs = @($msg.h | ForEach-Object { [long]$_ }) }
      elseif (([string]$msg.marker).Length -ge 6) { $hs = @([EfWin]::Find([string]$msg.marker)) }
      $done = @()
      foreach ($h in $hs) {
        $pid0 = [uint32]0; [EfWin]::GetWindowThreadProcessId([IntPtr]$h, [ref]$pid0) | Out-Null
        $pn = (Get-Process -Id $pid0 -ErrorAction SilentlyContinue).ProcessName
        if ($pn -ne "chrome") { continue }
        [EfWin]::ShowWindow([IntPtr]$h, $(if ([string]$msg.op -eq "hidewin") { 0 } else { 6 })) | Out-Null
        $done += $h
      }
      Reply @{ ok = $true; n = $done.Count; h = $done }
    }
    "trim"      {
      # 🧹 «Συμπίεση» μνήμης: EmptyWorkingSet στα προγράμματα ΤΟΥ ΙΔΙΟΥ χρήστη (χωρίς δικαιώματα διαχειριστή, χωρίς κλείσιμο τίποτα).
      # Τα Windows μεταφέρουν τις σελίδες που δεν χρησιμοποιούνται στη λίστα αναμονής· ό,τι χρειαστεί ξαναφορτώνει αυτόματα.
      Add-Type -Namespace EfMem -Name Psapi -MemberDefinition '[DllImport("psapi.dll")] public static extern bool EmptyWorkingSet(IntPtr hProcess);' -ErrorAction SilentlyContinue
      $n = 0; $before = (Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory
      $sid = (Get-Process -Id $PID).SessionId
      foreach ($p in Get-Process -ErrorAction SilentlyContinue) {
        if ($p.SessionId -ne $sid -or $p.Id -eq $PID) { continue }   # μόνο η συνεδρία του χρήστη· ξένες διεργασίες απορρίπτονται από τα Windows (χωρίς διαχειριστή)
        try { if ([EfMem.Psapi]::EmptyWorkingSet($p.Handle)) { $n++ } } catch {}
      }
      Start-Sleep -Milliseconds 800; $after = (Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory
      Reply @{ ok = $true; n = $n; freedMb = [int](($after - $before) / 1024) }
    }
    "printers"  {
      # ΜΟΝΟ ανάγνωση: εκτυπωτές των Windows και αν είναι έτοιμοι
      $pr = @(Get-CimInstance Win32_Printer -ErrorAction SilentlyContinue | ForEach-Object { @{ name = $_.Name; def = [bool]$_.Default; off = [bool]$_.WorkOffline; st = [int]$_.PrinterStatus; err = [int]$_.DetectedErrorState; net = [bool]$_.Network } })
      Reply @{ ok = $true; printers = $pr }
    }
    "printhtml" {
      # 🖨 Τυπώνει μία σελίδα (HTML από το ef-bot) στον εκτυπωτή A4, χωρίς παράθυρο: ξεχωριστό, προσωρινό προφίλ Chrome με --kiosk-printing
      # και επιλεγμένο εκτυπωτή. Δεν αλλάζει τον προεπιλεγμένο εκτυπωτή των Windows ούτε άλλη ρύθμιση.
      $skip = 'zebra|zdesigner|label|ετικ|barcode|godex|tsc|datamax|dymo|brother ql|pdf|xps|onenote|fax|send to|αποστολή'
      $all = @(Get-CimInstance Win32_Printer -ErrorAction SilentlyContinue)
      $ready = { param($p) -not $p.WorkOffline -and @(0,3,4,5).Contains([int]$p.PrinterStatus) -or (-not $p.WorkOffline -and [int]$p.PrinterStatus -eq 2) }
      $want = [string]$msg.printer; $pick = $null
      if ($want) { $pick = $all | Where-Object { $_.Name -eq $want } | Select-Object -First 1 }
      if (-not $pick) { $pick = $all | Where-Object { $_.Default -and $_.Name -notmatch $skip -and (& $ready $_) } | Select-Object -First 1 }
      if (-not $pick) { $pick = $all | Where-Object { $_.Name -notmatch $skip -and (& $ready $_) } | Sort-Object @{ e = { [int](-not $_.Network) } } | Select-Object -First 1 }
      if (-not $pick) { Reply @{ ok = $false; err = "δεν βρέθηκε έτοιμος εκτυπωτής A4"; printers = @($all | ForEach-Object { $_.Name }) }; break }
      $chrome = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe") | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
      if (-not $chrome) { Reply @{ ok = $false; err = "δεν βρέθηκε το chrome.exe" }; break }
      $root = Join-Path $env:TEMP "efbot-print"; $prof = Join-Path $root "profile"; New-Item -ItemType Directory -Path (Join-Path $prof "Default") -Force | Out-Null
      Get-ChildItem -LiteralPath $root -Filter "p-*.html" -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt (Get-Date).AddHours(-2) } | Remove-Item -Force -ErrorAction SilentlyContinue
      $app = @{ version = 2; recentDestinations = @(@{ id = $pick.Name; origin = "local"; account = "" }); selectedDestinationId = $pick.Name; mediaSize = @{ height_microns = 297000; width_microns = 210000; name = "ISO_A4"; custom_display_name = "A4" }; isHeaderFooterEnabled = $false; isCssBackgroundEnabled = $true; scaling = "100"; scalingType = 0 }
      $pref = @{ printing = @{ print_preview_sticky_settings = @{ appState = ($app | ConvertTo-Json -Compress -Depth 5) } } }
      [IO.File]::WriteAllText((Join-Path $prof "Default\Preferences"), ($pref | ConvertTo-Json -Compress -Depth 6), (New-Object Text.UTF8Encoding $false))
      $f = Join-Path $root ("p-" + [DateTime]::Now.ToString("yyyyMMddHHmmssfff") + ".html")
      $html = [string]$msg.html + '<script>window.addEventListener("load",function(){setTimeout(function(){window.print();setTimeout(function(){window.close()},4000)},600)})</script>'
      [IO.File]::WriteAllText($f, $html, (New-Object Text.UTF8Encoding $false))
      $args2 = @("--user-data-dir=`"$prof`"", "--kiosk-printing", "--no-first-run", "--no-default-browser-check", "--disable-extensions", "--new-window", "--window-position=-2400,-2400", "`"file:///$($f -replace '\\','/')`"")
      Start-Process -FilePath $chrome -ArgumentList $args2 -WindowStyle Minimized | Out-Null
      Reply @{ ok = $true; printer = $pick.Name }
    }
    "sysinfo"   {
      # ΜΟΝΟ ανάγνωση: φόρτος του υπολογιστή (για διάγνωση «κολλάει»)
      $os = Get-CimInstance Win32_OperatingSystem; $cpu = (Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average
      $P = @(Get-Process -ErrorAction SilentlyContinue)
      $grp = { param($n) $x = @($P | Where-Object { $_.ProcessName -eq $n }); @{ n = $x.Count; mb = [int](($x | Measure-Object WorkingSet64 -Sum).Sum / 1MB); cpu = [int](($x | Measure-Object CPU -Sum).Sum) } }
      $top = @($P | Sort-Object WorkingSet64 -Descending | Select-Object -First 8 | ForEach-Object { @{ p = $_.ProcessName; mb = [int]($_.WorkingSet64 / 1MB); cpu = [int]$_.CPU } })
      $dk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'" -ErrorAction SilentlyContinue
      $rb = (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired") -or (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending")
      Reply @{ ok = $true; reboot = [bool]$rb; diskFreeGb = $(if ($dk) { [int]($dk.FreeSpace / 1GB) } else { -1 }); diskGb = $(if ($dk) { [int]($dk.Size / 1GB) } else { 0 }); cpu = [int]$cpu; ramMb = [int]($os.TotalVisibleMemorySize / 1024); freeMb = [int]($os.FreePhysicalMemory / 1024); upH = [int](((Get-Date) - $os.LastBootUpTime).TotalHours); chrome = (& $grp "chrome"); ps = (& $grp "powershell"); top = $top; cores = [Environment]::ProcessorCount }
    }
    default     { Reply @{ ok = $false; err = "unknown op" } }
  }
} catch {
  try { Reply @{ ok = $false; err = $_.Exception.Message } } catch {}
}
exit 0
